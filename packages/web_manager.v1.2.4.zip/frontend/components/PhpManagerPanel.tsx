/**
 * PHP management panel — versions, extensions, php.ini (embedded in Web Manager).
 */
import { useState, useEffect, useMemo } from 'react';
import * as Icons from 'lucide-react';

const INSTALLABLE_VERSIONS = ['7.4', '8.0', '8.1', '8.2', '8.3', '8.4'];
const API = '/api/web_manager/php';

const ALL_PHP_MODULES = [
  'bcmath', 'calendar', 'curl', 'dom', 'exif', 'fileinfo', 'filter', 'ftp',
  'gd', 'gettext', 'gmp', 'hash', 'iconv', 'imap', 'intl', 'json',
  'ldap', 'mbstring', 'mysqli', 'mysqlnd', 'opcache', 'openssl', 'pcntl',
  'pcre', 'pdo', 'pdo_mysql', 'pdo_pgsql', 'pdo_sqlite', 'pgsql', 'posix',
  'readline', 'redis', 'session', 'shmop', 'simplexml', 'soap', 'sockets',
  'sodium', 'sqlite3', 'sysvmsg', 'sysvsem', 'sysvshm', 'tokenizer',
  'xml', 'xmlreader', 'xmlrpc', 'xmlwriter', 'xsl', 'zip', 'zlib',
  'imagick', 'xdebug', 'memcached', 'mongodb', 'apcu',
];

type Tab = 'versions' | 'modules' | 'ini';
type ModuleState = Record<string, boolean>;

interface InstalledVersion {
  version: string;
  status: 'active' | 'installed' | 'available';
}

interface Props {
  isDark: boolean;
  language: string;
  authHeaders: Record<string, string>;
}

export default function PhpManagerPanel({ isDark, language, authHeaders }: Props) {
  const [tab, setTab] = useState<Tab>('versions');
  const [versions, setVersions] = useState<InstalledVersion[]>([]);
  const [selectedVersion, setSelectedVersion] = useState<string>('8.2');
  const [moduleStates, setModuleStates] = useState<ModuleState>({});
  const [moduleSearch, setModuleSearch] = useState('');
  const [moduleFilter, setModuleFilter] = useState<'all' | 'enabled' | 'disabled'>('all');
  const [phpIniContent, setPhpIniContent] = useState('');
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [installing, setInstalling] = useState<string | null>(null);
  const [togglingMod, setTogglingMod] = useState<string | null>(null);
  const [msg, setMsg] = useState<{ text: string; tone: 'ok' | 'err' | 'warn' } | null>(null);

  const tr = {
    en: {
      tabVersions: 'Versions',
      tabModules: 'Extensions',
      tabIni: 'php.ini',
      install: 'Install',
      uninstall: 'Remove',
      setActive: 'Set Active',
      active: 'Active',
      installed: 'Installed',
      available: 'Available',
      saveIni: 'Save & Reload',
      saving: 'Saving...',
      modSearch: 'Search extensions...',
      allMods: 'All',
      enabledMods: 'Enabled',
      disabledMods: 'Disabled',
      loading: 'Loading...',
      loadFailed: 'Could not load PHP versions from the server.',
      extNeedInstall: 'Install this PHP version on the Versions tab before managing extensions.',
      activeLabel: 'Active',
    },
    vi: {
      tabVersions: 'Phiên bản',
      tabModules: 'Extensions',
      tabIni: 'php.ini',
      install: 'Cài đặt',
      uninstall: 'Gỡ',
      setActive: 'Đặt mặc định',
      active: 'Đang dùng',
      installed: 'Đã cài',
      available: 'Có thể cài',
      saveIni: 'Lưu & Reload',
      saving: 'Đang lưu...',
      modSearch: 'Tìm extension...',
      allMods: 'Tất cả',
      enabledMods: 'Đang bật',
      disabledMods: 'Đang tắt',
      loading: 'Đang tải...',
      loadFailed: 'Không tải được danh sách phiên bản PHP từ máy chủ.',
      extNeedInstall: 'Hãy cài phiên bản PHP này ở tab Phiên bản trước khi quản lý extension.',
      activeLabel: 'Đang dùng',
    },
  }[language === 'vi' ? 'vi' : 'en'];

  const headers = useMemo(
    () => ({ 'Content-Type': 'application/json', ...authHeaders }),
    [authHeaders],
  );

  const showMsg = (text: string, tone: 'ok' | 'err' | 'warn' = 'ok') => {
    setMsg({ text, tone });
    setTimeout(() => setMsg(null), tone === 'warn' ? 6500 : 4000);
  };

  const fetchVersions = async () => {
    setLoading(true);
    try {
      const res = await fetch(`${API}/versions`, { headers });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        showMsg(typeof err?.detail === 'string' ? err.detail : tr.loadFailed, 'err');
        return;
      }
      const data = await res.json();
      const installed: string[] = data.versions || [];
      const active: string =
        (data.active && installed.includes(data.active) ? data.active : '') || installed[0] || '';
      setVersions(
        INSTALLABLE_VERSIONS.map((v) => ({
          version: v,
          status:
            v === active && installed.includes(v)
              ? 'active'
              : installed.includes(v)
                ? 'installed'
                : 'available',
        })),
      );
      if (active) setSelectedVersion((prev) => prev || active);
      else if (installed[0]) setSelectedVersion(installed[0]);
    } catch {
      showMsg(tr.loadFailed, 'err');
    } finally {
      setLoading(false);
    }
  };

  const fetchModules = async (ver: string) => {
    setLoading(true);
    try {
      const res = await fetch(`${API}/modules/${ver}`, { headers });
      if (res.ok) {
        const data = await res.json();
        const enabled: string[] = data.enabled || data.modules || [];
        const init: ModuleState = {};
        ALL_PHP_MODULES.forEach((m) => {
          init[m] = enabled.includes(m);
        });
        setModuleStates(init);
      }
    } catch {
      /* ignore */
    } finally {
      setLoading(false);
    }
  };

  const fetchIni = async (ver: string) => {
    setLoading(true);
    try {
      const res = await fetch(`${API}/php_ini/${ver}`, { headers });
      if (res.ok) {
        const data = await res.json();
        setPhpIniContent(data.content || '');
      }
    } catch {
      /* ignore */
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchVersions();
  }, []);

  useEffect(() => {
    if (tab === 'modules') fetchModules(selectedVersion);
    if (tab === 'ini') fetchIni(selectedVersion);
  }, [tab, selectedVersion]);

  const handleInstall = async (ver: string) => {
    setInstalling(ver);
    try {
      const res = await fetch(`${API}/install`, {
        method: 'POST',
        headers,
        body: JSON.stringify({ version: ver }),
      });
      const d = await res.json();
      const detail = typeof d?.detail === 'string' ? d.detail : d?.message;
      showMsg(detail || (res.ok ? 'Done.' : 'Failed.'), res.ok ? 'ok' : 'err');
      if (res.ok) {
        await fetchVersions();
        if (tab === 'modules') fetchModules(selectedVersion);
        if (tab === 'ini') fetchIni(selectedVersion);
      }
    } catch {
      showMsg('Connection error.', 'err');
    } finally {
      setInstalling(null);
    }
  };

  const handleUninstall = async (ver: string) => {
    if (!confirm(`Remove PHP ${ver}?`)) return;
    try {
      const res = await fetch(`${API}/uninstall/${ver}`, { method: 'DELETE', headers });
      const d = await res.json();
      const detail = typeof d?.detail === 'string' ? d.detail : d?.message;
      showMsg(detail || (res.ok ? 'Done.' : 'Failed.'), res.ok ? 'ok' : 'err');
      if (res.ok) {
        await fetchVersions();
        if (tab === 'modules') fetchModules(selectedVersion);
        if (tab === 'ini') fetchIni(selectedVersion);
      }
    } catch {
      showMsg('Connection error.', 'err');
    }
  };

  const handleSetActive = async (ver: string) => {
    try {
      const res = await fetch(`${API}/set_active`, {
        method: 'POST',
        headers,
        body: JSON.stringify({ version: ver }),
      });
      const d = await res.json();
      const detail = typeof d?.detail === 'string' ? d.detail : d?.message;
      showMsg(detail || (res.ok ? 'Done.' : 'Failed.'), res.ok ? 'ok' : 'err');
      if (res.ok) fetchVersions();
    } catch {
      showMsg('Connection error.', 'err');
    }
  };

  const handleToggleModule = async (mod: string, enable: boolean) => {
    setTogglingMod(mod);
    const prev = moduleStates[mod];
    setModuleStates((s) => ({ ...s, [mod]: enable }));
    try {
      const res = await fetch(`${API}/module_toggle`, {
        method: 'POST',
        headers,
        body: JSON.stringify({ version: selectedVersion, module: mod, enable }),
      });
      const d = await res.json().catch(() => ({}));
      if (!res.ok) {
        setModuleStates((s) => ({ ...s, [mod]: prev }));
        showMsg(typeof d?.detail === 'string' ? d.detail : 'Failed.', 'err');
        return;
      }
      if (d.status === 'warning' && d.message) {
        showMsg(d.message, 'warn');
        await fetchModules(selectedVersion);
        return;
      }
      await fetchModules(selectedVersion);
    } catch {
      setModuleStates((s) => ({ ...s, [mod]: prev }));
      showMsg('Connection error.', 'err');
    } finally {
      setTogglingMod(null);
    }
  };

  const handleSaveIni = async () => {
    setSaving(true);
    try {
      const res = await fetch(`${API}/php_ini/${selectedVersion}`, {
        method: 'POST',
        headers,
        body: JSON.stringify({ content: phpIniContent }),
      });
      const d = await res.json();
      showMsg(d.message || 'Saved.', res.ok ? 'ok' : 'err');
    } catch {
      showMsg('Connection error.', 'err');
    } finally {
      setSaving(false);
    }
  };

  const filteredModules = useMemo(
    () =>
      ALL_PHP_MODULES.filter((m) => {
        const matchSearch = m.toLowerCase().includes(moduleSearch.toLowerCase());
        const matchFilter =
          moduleFilter === 'all' || (moduleFilter === 'enabled' ? moduleStates[m] : !moduleStates[m]);
        return matchSearch && matchFilter;
      }),
    [moduleSearch, moduleFilter, moduleStates],
  );

  const selectedPhpInstalled = useMemo(() => {
    const row = versions.find((v) => v.version === selectedVersion);
    return row?.status === 'installed' || row?.status === 'active';
  }, [versions, selectedVersion]);

  const card = `rounded-2xl border p-5 md:p-6 ${isDark ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'} shadow-sm`;
  const btn = (color: string) =>
    `px-3 py-1.5 rounded-lg text-xs font-semibold transition flex items-center gap-1.5 border ${color}`;
  const tabCls = (t: Tab) =>
    `px-4 py-2 text-xs font-semibold rounded-lg transition ${
      tab === t
        ? 'bg-blue-600 text-white'
        : isDark
          ? 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
          : 'text-slate-500 hover:text-slate-700 hover:bg-slate-100'
    }`;
  const statusBadge = (s: InstalledVersion['status']) => {
    if (s === 'active')
      return isDark ? 'bg-green-500/15 text-green-400 border-green-500/30' : 'bg-green-50 text-green-600 border-green-200';
    if (s === 'installed')
      return isDark ? 'bg-blue-500/15 text-blue-400 border-blue-500/30' : 'bg-blue-50 text-blue-600 border-blue-200';
    return isDark ? 'bg-slate-700/40 text-slate-400 border-slate-700' : 'bg-slate-100 text-slate-500 border-slate-200';
  };

  return (
    <div className="space-y-5">
      <div className={`${card} flex flex-col md:flex-row md:items-center justify-between gap-4`}>
        <div className="flex items-center gap-2">
          <Icons.Code2 className={`w-4 h-4 shrink-0 ${isDark ? 'text-blue-400' : 'text-blue-600'}`} />
          <select
            value={selectedVersion}
            onChange={(e) => setSelectedVersion(e.target.value)}
            className={`text-xs font-mono font-semibold px-3 py-2 rounded-lg border transition focus:outline-none focus:border-blue-500 ${
              isDark ? 'bg-slate-800 border-slate-700 text-slate-200' : 'bg-white border-slate-200 text-slate-800'
            }`}
          >
            {INSTALLABLE_VERSIONS.map((v) => (
              <option key={v} value={v}>
                PHP {v}
              </option>
            ))}
          </select>
        </div>
      </div>

      {msg && (
        <div
          className={`p-3 border rounded-xl text-xs flex items-center gap-2 ${
            msg.tone === 'err'
              ? isDark
                ? 'bg-red-950/20 border-red-600/30 text-red-400'
                : 'bg-red-50 border-red-200 text-red-600'
              : msg.tone === 'warn'
                ? isDark
                  ? 'bg-amber-950/25 border-amber-600/30 text-amber-300'
                  : 'bg-amber-50 border-amber-200 text-amber-900'
                : isDark
                  ? 'bg-green-950/20 border-green-600/30 text-green-400'
                  : 'bg-green-50 border-green-200 text-green-700'
          }`}
        >
          {msg.tone === 'err' ? (
            <Icons.AlertCircle className="w-4 h-4 shrink-0" />
          ) : msg.tone === 'warn' ? (
            <Icons.AlertTriangle className="w-4 h-4 shrink-0" />
          ) : (
            <Icons.CheckCircle2 className="w-4 h-4 shrink-0" />
          )}
          {msg.text}
        </div>
      )}

      <div className="flex gap-2 flex-wrap">
        <button type="button" className={tabCls('versions')} onClick={() => setTab('versions')}>
          <span className="flex items-center gap-1.5">
            <Icons.Layers className="w-3.5 h-3.5" />
            {tr.tabVersions}
          </span>
        </button>
        <button type="button" className={tabCls('modules')} onClick={() => setTab('modules')}>
          <span className="flex items-center gap-1.5">
            <Icons.Box className="w-3.5 h-3.5" />
            {tr.tabModules}
          </span>
        </button>
        <button type="button" className={tabCls('ini')} onClick={() => setTab('ini')}>
          <span className="flex items-center gap-1.5">
            <Icons.FileText className="w-3.5 h-3.5" />
            {tr.tabIni}
          </span>
        </button>
      </div>

      {tab === 'versions' && (
        <div className={card}>
          {loading ? (
            <div className="flex items-center gap-2 text-xs text-slate-400 py-6">
              <Icons.Loader className="w-4 h-4 animate-spin text-blue-500" /> {tr.loading}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr
                    className={`text-xs font-bold uppercase tracking-wider border-b ${
                      isDark ? 'text-slate-400 border-slate-800' : 'text-slate-500 border-slate-100'
                    }`}
                  >
                    <th className="py-3 px-4">Version</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className={`text-xs divide-y ${isDark ? 'divide-slate-800/50' : 'divide-slate-100'}`}>
                  {versions.map(({ version, status }) => (
                    <tr key={version} className={`transition ${isDark ? 'hover:bg-slate-800/30' : 'hover:bg-slate-50'}`}>
                      <td className={`py-3 px-4 font-mono font-bold ${isDark ? 'text-blue-400' : 'text-blue-600'}`}>
                        PHP {version}
                      </td>
                      <td className="py-3 px-4">
                        <span className={`px-2.5 py-0.5 rounded border text-[10px] uppercase font-bold ${statusBadge(status)}`}>
                          {status === 'active' ? tr.active : status === 'installed' ? tr.installed : tr.available}
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-2 justify-end flex-wrap">
                          {status === 'available' && (
                            <button
                              type="button"
                              onClick={() => handleInstall(version)}
                              disabled={installing === version}
                              className={btn(
                                isDark
                                  ? 'bg-blue-600/20 border-blue-600/40 text-blue-400 hover:bg-blue-600/30'
                                  : 'bg-blue-50 border-blue-200 text-blue-600 hover:bg-blue-100',
                              )}
                            >
                              {installing === version ? (
                                <Icons.Loader className="w-3.5 h-3.5 animate-spin" />
                              ) : (
                                <Icons.Download className="w-3.5 h-3.5" />
                              )}
                              {installing === version ? '...' : tr.install}
                            </button>
                          )}
                          {status === 'installed' && (
                            <>
                              <button
                                type="button"
                                onClick={() => handleSetActive(version)}
                                className={btn(
                                  isDark
                                    ? 'bg-green-600/20 border-green-600/40 text-green-400 hover:bg-green-600/30'
                                    : 'bg-green-50 border-green-200 text-green-600 hover:bg-green-100',
                                )}
                              >
                                <Icons.Star className="w-3.5 h-3.5" /> {tr.setActive}
                              </button>
                              <button
                                type="button"
                                onClick={() => handleUninstall(version)}
                                className={btn(
                                  isDark
                                    ? 'bg-red-600/20 border-red-600/40 text-red-400 hover:bg-red-600/30'
                                    : 'bg-red-50 border-red-200 text-red-600 hover:bg-red-100',
                                )}
                              >
                                <Icons.Trash2 className="w-3.5 h-3.5" /> {tr.uninstall}
                              </button>
                            </>
                          )}
                          {status === 'active' && (
                            <div className="flex items-center gap-2 justify-end flex-wrap">
                              <span
                                className={`text-[10px] font-semibold flex items-center gap-1 ${
                                  isDark ? 'text-green-400' : 'text-green-600'
                                }`}
                              >
                                <Icons.CheckCircle2 className="w-3.5 h-3.5" /> {tr.activeLabel}
                              </span>
                              <button
                                type="button"
                                onClick={() => handleUninstall(version)}
                                className={btn(
                                  isDark
                                    ? 'bg-red-600/20 border-red-600/40 text-red-400 hover:bg-red-600/30'
                                    : 'bg-red-50 border-red-200 text-red-600 hover:bg-red-100',
                                )}
                              >
                                <Icons.Trash2 className="w-3.5 h-3.5" /> {tr.uninstall}
                              </button>
                            </div>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {tab === 'modules' && (
        <div className={`${card} space-y-4`}>
          {!selectedPhpInstalled && (
            <div
              className={`flex items-start gap-2 rounded-xl border px-3 py-2.5 text-xs ${
                isDark ? 'border-amber-500/30 bg-amber-950/20 text-amber-200' : 'border-amber-200 bg-amber-50 text-amber-900'
              }`}
            >
              <Icons.Info className="w-4 h-4 shrink-0 mt-0.5" />
              {tr.extNeedInstall}
            </div>
          )}
          <div className="flex flex-col sm:flex-row gap-3">
            <div
              className={`flex items-center gap-2 px-3 py-2 rounded-lg border flex-1 ${
                isDark ? 'bg-slate-800 border-slate-700' : 'bg-slate-50 border-slate-200'
              }`}
            >
              <Icons.Search className="w-4 h-4 shrink-0 text-slate-400" />
              <input
                type="text"
                placeholder={tr.modSearch}
                value={moduleSearch}
                onChange={(e) => setModuleSearch(e.target.value)}
                className={`bg-transparent text-xs flex-1 focus:outline-none ${
                  isDark ? 'text-slate-200 placeholder-slate-600' : 'text-slate-700 placeholder-slate-400'
                }`}
              />
            </div>
            <div
              className={`flex rounded-lg border overflow-hidden text-xs font-semibold ${
                isDark ? 'border-slate-700' : 'border-slate-200'
              }`}
            >
              {(['all', 'enabled', 'disabled'] as const).map((f) => (
                <button
                  key={f}
                  type="button"
                  onClick={() => setModuleFilter(f)}
                  className={`px-3 py-2 transition ${
                    moduleFilter === f
                      ? 'bg-blue-600 text-white'
                      : isDark
                        ? 'bg-slate-800 text-slate-400 hover:text-slate-200'
                        : 'bg-white text-slate-500 hover:text-slate-700'
                  }`}
                >
                  {f === 'all' ? tr.allMods : f === 'enabled' ? tr.enabledMods : tr.disabledMods}
                </button>
              ))}
            </div>
          </div>

          <div className={`flex gap-4 text-xs ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
            <span className={`${isDark ? 'text-green-400' : 'text-green-600'} font-semibold`}>
              ● {Object.values(moduleStates).filter(Boolean).length} enabled
            </span>
            <span className={`${isDark ? 'text-slate-500' : 'text-slate-400'} font-semibold`}>
              ○ {Object.values(moduleStates).filter((v) => !v).length} disabled
            </span>
            <span className="ml-auto">PHP {selectedVersion}</span>
          </div>

          {loading ? (
            <div className="flex items-center gap-2 text-xs text-slate-400 py-6">
              <Icons.Loader className="w-4 h-4 animate-spin text-blue-500" /> {tr.loading}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
              {filteredModules.map((mod) => {
                const enabled = moduleStates[mod] ?? false;
                const toggling = togglingMod === mod;
                return (
                  <div
                    key={mod}
                    className={`flex items-center justify-between px-3 py-2.5 rounded-xl border transition ${
                      enabled
                        ? isDark
                          ? 'bg-blue-600/10 border-blue-600/30'
                          : 'bg-blue-50 border-blue-200'
                        : isDark
                          ? 'bg-slate-900/40 border-slate-800'
                          : 'bg-white border-slate-200'
                    }`}
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <Icons.Package
                        className={`w-3.5 h-3.5 shrink-0 ${
                          enabled ? (isDark ? 'text-blue-400' : 'text-blue-500') : isDark ? 'text-slate-600' : 'text-slate-300'
                        }`}
                      />
                      <span
                        className={`font-mono text-xs font-semibold truncate ${
                          enabled ? (isDark ? 'text-slate-200' : 'text-slate-700') : isDark ? 'text-slate-500' : 'text-slate-400'
                        }`}
                      >
                        {mod}
                      </span>
                    </div>
                    <button
                      type="button"
                      onClick={() => handleToggleModule(mod, !enabled)}
                      disabled={toggling || !selectedPhpInstalled}
                      title={enabled ? 'Disable' : 'Enable'}
                      className={`relative w-9 h-5 rounded-full border transition-all shrink-0 ml-2 ${
                        toggling ? 'opacity-50' : ''
                      } ${
                        enabled
                          ? 'bg-blue-600 border-blue-600'
                          : isDark
                            ? 'bg-slate-700 border-slate-600'
                            : 'bg-slate-200 border-slate-300'
                      }`}
                    >
                      <span
                        className={`absolute top-0.5 w-3.5 h-3.5 rounded-full bg-white shadow transition-all ${
                          enabled ? 'left-[18px]' : 'left-0.5'
                        }`}
                      />
                    </button>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {tab === 'ini' && (
        <div className={`${card} space-y-4`}>
          <h3
            className={`text-xs font-bold uppercase tracking-wider flex items-center gap-2 ${
              isDark ? 'text-slate-300' : 'text-slate-600'
            }`}
          >
            <Icons.FileText className={`w-4 h-4 ${isDark ? 'text-blue-400' : 'text-blue-600'}`} />
            php.ini — PHP {selectedVersion}
          </h3>
          {loading ? (
            <div className="flex items-center gap-2 text-xs text-slate-400 py-6">
              <Icons.Loader className="w-4 h-4 animate-spin text-blue-500" /> {tr.loading}
            </div>
          ) : (
            <>
              <textarea
                value={phpIniContent}
                onChange={(e) => setPhpIniContent(e.target.value)}
                rows={22}
                spellCheck={false}
                className={`w-full border rounded-xl px-4 py-3 font-mono text-xs focus:outline-none focus:border-blue-500 transition resize-none ${
                  isDark
                    ? 'bg-slate-950/80 border-slate-800 text-slate-200 hover:border-slate-700'
                    : 'bg-slate-50 border-slate-200 text-slate-800'
                }`}
              />
              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => fetchIni(selectedVersion)}
                  className={btn(
                    isDark
                      ? 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700'
                      : 'bg-slate-100 border-slate-200 text-slate-600 hover:bg-slate-200',
                  )}
                >
                  <Icons.RefreshCw className="w-3.5 h-3.5" /> Reset
                </button>
                <button
                  type="button"
                  onClick={handleSaveIni}
                  disabled={saving}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-semibold transition flex items-center gap-1.5 shadow"
                >
                  {saving ? <Icons.Loader className="w-3.5 h-3.5 animate-spin" /> : <Icons.Save className="w-3.5 h-3.5" />}
                  {saving ? tr.saving : tr.saveIni}
                </button>
              </div>
            </>
          )}
        </div>
      )}
    </div>
  );
}
