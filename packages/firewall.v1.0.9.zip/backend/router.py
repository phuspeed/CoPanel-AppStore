"""
Firewall Module Router
Manages ufw firewall rules and Fail2Ban intrusion prevention system.
"""
import os
import re
import shutil
import subprocess
from pathlib import Path
from typing import List, Dict, Any, Optional
from fastapi import APIRouter, Depends, HTTPException
from core.auth import require_module
from pydantic import BaseModel, Field

router = APIRouter(dependencies=[Depends(require_module("firewall"))])

IS_WINDOWS = os.name == 'nt'

# Global mock data for non-Linux testing
MOCK_RULES = [
    {"port": "22/tcp", "action": "ALLOW", "comment": "Default SSH"},
    {"port": "80/tcp", "action": "ALLOW", "comment": "Web Traffic"},
    {"port": "8686/tcp", "action": "ALLOW", "comment": "CoPanel Web UI"}
]
MOCK_STATUS = "active"
MOCK_F2B_INSTALLED = True
MOCK_F2B_ACTIVE = True
MOCK_F2B_JAILS = ["sshd"]
MOCK_F2B_BANNED = [{"ip": "192.168.1.100", "jail": "sshd"}]

# Schemas
class RuleRequest(BaseModel):
    port: str = Field(..., description="e.g. 80, 443/tcp")
    action: str = Field("ALLOW", description="ALLOW or DENY")
    comment: Optional[str] = ""

class DeleteRuleRequest(BaseModel):
    port: str
    action: str

class UnbanRequest(BaseModel):
    jail: str
    ip: str


_UFW_PORT_RE = re.compile(
    r"^(?P<port>(?:\d{1,5})(?:/(?:tcp|udp))?|\d{1,5}:(?:tcp|udp))\s*$",
    re.IGNORECASE,
)


_UFW_COMMENT_MAX_LEN = 80


def validate_ufw_comment(comment: Optional[str]) -> Optional[str]:
    """Return a safe UFW rule comment or None when empty."""
    text = (comment or "").strip()
    if not text:
        return None
    if "\n" in text or "\r" in text or "\0" in text:
        raise ValueError("Comment cannot contain newlines.")
    if len(text) > _UFW_COMMENT_MAX_LEN:
        raise ValueError(f"Comment must be at most {_UFW_COMMENT_MAX_LEN} characters.")
    if re.search(r"[\"';|&$`\\]", text):
        raise ValueError("Comment contains invalid characters.")
    return text


def validate_ufw_port(port: str) -> str:
    """Return normalized port spec or raise ValueError."""
    spec = (port or "").strip()
    if not spec or "\n" in spec or "\r" in spec:
        raise ValueError("Port is required.")
    if not _UFW_PORT_RE.match(spec):
        raise ValueError(f"Invalid port specification: {spec}")
    base = spec.split("/", 1)[0].split(":", 1)[0]
    try:
        n = int(base)
    except ValueError:
        raise ValueError(f"Invalid port: {spec}")
    if n < 1 or n > 65535:
        raise ValueError(f"Port out of range: {n}")
    return spec


def parse_ufw_rule_line(line_strip: str) -> Optional[Dict[str, str]]:
    """Parse one ``ufw status`` rule line into port/action/from/comment."""
    if not line_strip or "Status:" in line_strip or "To " in line_strip or "Action " in line_strip or "---" in line_strip:
        return None
    line_strip = re.sub(r"^\[\s*\d+\]\s*", "", line_strip)
    match = re.search(r"^(.*?)\s+(ALLOW(?:\s+IN)?|DENY(?:\s+IN)?)\s+(.*)$", line_strip, re.IGNORECASE)
    if not match:
        return None
    port = match.group(1).strip()
    action = match.group(2).replace(" IN", "").replace(" in", "").strip().upper()
    tail = match.group(3).strip()
    comment = ""
    from_spec = ""
    if "#" in tail:
        left, right = tail.split("#", 1)
        from_spec = left.strip()
        comment = right.strip()
    else:
        from_spec = tail.strip()
    return {"port": port, "action": action, "from": from_spec, "comment": comment}


def find_ufw_path() -> str:
    for p in ["/usr/sbin/ufw", "/sbin/ufw", "/usr/bin/ufw", "/bin/ufw"]:
        if os.path.exists(p) and os.access(p, os.X_OK):
            return p
    w = shutil.which("ufw")
    if w:
        return w
    return "ufw"


def find_fail2ban_path() -> str:
    for p in ["/usr/bin/fail2ban-client", "/bin/fail2ban-client", "/usr/sbin/fail2ban-client", "/sbin/fail2ban-client"]:
        if os.path.exists(p) and os.access(p, os.X_OK):
            return p
    w = shutil.which("fail2ban-client")
    if w:
        return w
    return "fail2ban-client"


def check_fail2ban_installed() -> bool:
    if IS_WINDOWS:
        return MOCK_F2B_INSTALLED
    p = find_fail2ban_path()
    if p and p != "fail2ban-client":
        return True
    if shutil.which("fail2ban-client"):
        return True
    # Fallback: package/service may exist before PATH is refreshed.
    if Path("/etc/fail2ban").exists() or Path("/lib/systemd/system/fail2ban.service").exists():
        return True
    try:
        if shutil.which("dpkg-query"):
            res = subprocess.run(
                ["dpkg-query", "-W", "-f=${Status}", "fail2ban"],
                shell=False,
                capture_output=True,
                text=True,
            )
            if "install ok installed" in (res.stdout or ""):
                return True
        if shutil.which("rpm"):
            res = subprocess.run(["rpm", "-q", "fail2ban"], shell=False, capture_output=True, text=True)
            if res.returncode == 0:
                return True
    except Exception:
        pass
    return False


def check_fail2ban_active(f2b_path: str) -> bool:
    """Detect Fail2Ban active state with client + systemd fallbacks."""
    # Primary signal: fail2ban-client ping
    ping_res = _run_with_optional_sudo([f2b_path, "ping"])
    ping_text = f"{ping_res.stdout}\n{ping_res.stderr}".lower()
    if ping_res.returncode == 0 and "server echoed" in ping_text and "pong" in ping_text:
        return True

    # Secondary signal: fail2ban-client status exits 0 when daemon is reachable
    status_res = _run_with_optional_sudo([f2b_path, "status"])
    if status_res.returncode == 0:
        return True

    # Fallback: check service manager for environments where client needs permissions
    if shutil.which("systemctl"):
        systemd_res = _run_with_optional_sudo(["systemctl", "is-active", "fail2ban"])
        if systemd_res.returncode == 0 and "active" in (systemd_res.stdout or "").strip().lower():
            return True

    return False


def run_cmd(cmd: List[str]) -> str:
    """Run system command using subprocess safely."""
    try:
        res = subprocess.run(cmd, shell=False, capture_output=True, text=True, check=False)
        return res.stdout if res.returncode == 0 else res.stderr
    except Exception:
        return ""


def _run_with_optional_sudo(cmd: List[str]) -> subprocess.CompletedProcess:
    """Run command directly first, then fallback to non-interactive sudo."""
    res = subprocess.run(cmd, shell=False, capture_output=True, text=True, check=False)
    if res.returncode == 0:
        return res
    sudo_bin = shutil.which("sudo")
    if sudo_bin:
        sudo_res = subprocess.run([sudo_bin, "-n", *cmd], shell=False, capture_output=True, text=True, check=False)
        if sudo_res.returncode == 0:
            return sudo_res
        return sudo_res
    return res


@router.get("/status")
async def get_firewall_status() -> Dict[str, Any]:
    """Get status and rules list from ufw."""
    global MOCK_STATUS, MOCK_RULES
    if IS_WINDOWS:
        return {
            "status": "success",
            "active": MOCK_STATUS == "active",
            "rules": MOCK_RULES
        }

    ufw_path = find_ufw_path()
    has_ufw = shutil.which("ufw") or Path(ufw_path).exists()
    if not has_ufw:
        return {
            "status": "success",
            "active": False,
            "rules": [],
            "error_message": "UFW Firewall is not installed on this system."
        }

    try:
        res = subprocess.run([ufw_path, "status"], shell=False, capture_output=True, text=True, check=False)
        out = res.stdout if res.returncode == 0 else res.stderr

        is_active = "Status: active" in out

        # Extract rules
        rules = []
        lines = out.splitlines()
        for line in lines:
            parsed = parse_ufw_rule_line(line.strip())
            if parsed:
                rules.append(parsed)

        return {
            "status": "success",
            "active": is_active,
            "rules": rules
        }
    except Exception as e:
        return {
            "status": "success",
            "active": False,
            "rules": [],
            "error_message": f"Failed to execute UFW status check: {str(e)}"
        }


def run_ufw_cmd(action: str, port: str, comment: Optional[str] = None) -> bool:
    """Helper to run UFW commands natively."""
    ufw_path = find_ufw_path()
    cmd: List[str] = [ufw_path, action, port]
    safe_comment = validate_ufw_comment(comment)
    if safe_comment:
        cmd.extend(["comment", safe_comment])
    try:
        res = _run_with_optional_sudo(cmd)
        if res.returncode == 0:
            return True
    except Exception:
        pass
    return False


def run_ufw_delete_cmd(action: str, port: str) -> bool:
    """Helper to run UFW delete commands."""
    ufw_path = find_ufw_path()
    try:
        res = _run_with_optional_sudo([ufw_path, "--force", "delete", action, port])
        if res.returncode == 0:
            return True
    except Exception:
        pass
    return False


@router.post("/enable")
async def enable_firewall() -> Dict[str, Any]:
    """Enable UFW firewall."""
    global MOCK_STATUS
    if IS_WINDOWS:
        MOCK_STATUS = "active"
        return {"status": "success", "message": "Firewall enabled successfully (Mock Mode)."}
    ufw_path = find_ufw_path()
    try:
        _run_with_optional_sudo([ufw_path, "allow", "22"])
        res = _run_with_optional_sudo([ufw_path, "--force", "enable"])
        if res.returncode == 0:
            return {"status": "success", "message": "Firewall enabled successfully."}
        raise HTTPException(status_code=500, detail=(res.stderr or res.stdout or "Failed to enable firewall.").strip())
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/disable")
async def disable_firewall() -> Dict[str, Any]:
    """Disable UFW firewall."""
    global MOCK_STATUS
    if IS_WINDOWS:
        MOCK_STATUS = "inactive"
        return {"status": "success", "message": "Firewall disabled successfully (Mock Mode)."}
    ufw_path = find_ufw_path()
    try:
        res = _run_with_optional_sudo([ufw_path, "disable"])
        if res.returncode == 0:
            return {"status": "success", "message": "Firewall disabled successfully."}
        raise HTTPException(status_code=500, detail=(res.stderr or res.stdout or "Failed to disable firewall.").strip())
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/add")
async def add_firewall_rule(req: RuleRequest) -> Dict[str, Any]:
    """Add a rule to the firewall."""
    global MOCK_RULES

    if "22" in req.port and req.action.upper() == "DENY":
        raise HTTPException(
            status_code=400,
            detail="Cannot add a rule blocking SSH port 22 to prevent lockout."
        )

    try:
        port_spec = validate_ufw_port(req.port)
        rule_comment = validate_ufw_comment(req.comment)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))

    if IS_WINDOWS:
        for rule in MOCK_RULES:
            if rule["port"] == port_spec:
                raise HTTPException(status_code=400, detail="Rule already exists.")
        MOCK_RULES.append({
            "port": port_spec,
            "action": req.action.upper(),
            "comment": req.comment or ""
        })
        return {
            "status": "success",
            "message": "Firewall rule added successfully (Mock Mode)."
        }

    try:
        if not run_ufw_cmd(req.action.lower(), port_spec, rule_comment):
            ufw_path = find_ufw_path()
            dbg_cmd: List[str] = [ufw_path, req.action.lower(), port_spec]
            if rule_comment:
                dbg_cmd.extend(["comment", rule_comment])
            dbg = _run_with_optional_sudo(dbg_cmd)
            detail = (dbg.stderr or dbg.stdout or "").strip()
            if "password is required" in detail.lower() or "a password is required" in detail.lower():
                detail = "Permission denied to run UFW non-interactively. Configure sudoers for the CoPanel service user."
            if "invalid" in detail.lower() or "bad port" in detail.lower():
                raise HTTPException(status_code=400, detail=detail or "Invalid port.")
            raise HTTPException(status_code=500, detail=detail or "Failed to apply firewall rule via ufw CLI.")

        return {
            "status": "success",
            "message": "Firewall rule added successfully."
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/delete")
async def delete_firewall_rule(req: DeleteRuleRequest) -> Dict[str, Any]:
    """Delete a rule from the firewall."""
    global MOCK_RULES

    if "22" in req.port:
        raise HTTPException(
            status_code=400,
            detail="Cannot delete SSH rule for port 22 to prevent lockout."
        )

    if IS_WINDOWS:
        original_count = len(MOCK_RULES)
        MOCK_RULES = [r for r in MOCK_RULES if not (r["port"] == req.port and r["action"] == req.action.upper())]
        if len(MOCK_RULES) == original_count:
            raise HTTPException(status_code=404, detail="Rule not found in Mock Mode.")
        return {
            "status": "success",
            "message": "Firewall rule deleted successfully (Mock Mode)."
        }

    try:
        if not run_ufw_delete_cmd(req.action.lower(), req.port):
            ufw_path = find_ufw_path()
            dbg = _run_with_optional_sudo([ufw_path, "--force", "delete", req.action.lower(), req.port])
            detail = (dbg.stderr or dbg.stdout or "").strip()
            if "password is required" in detail.lower() or "a password is required" in detail.lower():
                detail = "Permission denied to run UFW non-interactively. Configure sudoers for the CoPanel service user."
            raise HTTPException(status_code=500, detail=detail or "Failed to delete firewall rule via ufw CLI.")

        return {
            "status": "success",
            "message": "Firewall rule deleted successfully."
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# --- FAIL2BAN SPECIFIC ENDPOINTS ---

@router.get("/fail2ban/status")
async def get_fail2ban_status() -> Dict[str, Any]:
    """Fetch real Fail2Ban status and banned IPs list."""
    global MOCK_F2B_ACTIVE, MOCK_F2B_JAILS, MOCK_F2B_BANNED
    
    installed = check_fail2ban_installed()
    if not installed:
        return {
            "status": "success",
            "installed": False,
            "active": False,
            "jails": [],
            "banned": []
        }

    if IS_WINDOWS:
        return {
            "status": "success",
            "installed": True,
            "active": MOCK_F2B_ACTIVE,
            "jails": MOCK_F2B_JAILS,
            "banned": MOCK_F2B_BANNED
        }

    f2b_path = find_fail2ban_path()
    try:
        is_active = check_fail2ban_active(f2b_path)
        
        # Get all Jails
        res = _run_with_optional_sudo([f2b_path, "status"])
        jails = []
        if res.returncode == 0:
            match = re.search(r'Jail list:\s+(.+)', res.stdout)
            if match:
                jails = [j.strip() for j in match.group(1).split(',')]
                
        # Get banned IPs for each jail
        banned = []
        for jail in jails:
            jres = _run_with_optional_sudo([f2b_path, "status", jail])
            if jres.returncode == 0:
                ip_match = re.search(r'Banned IP list:\s+(.+)', jres.stdout)
                if ip_match:
                    ips = [ip.strip() for ip in ip_match.group(1).split(' ') if ip.strip()]
                    for ip in ips:
                        banned.append({"ip": ip, "jail": jail})

        return {
            "status": "success",
            "installed": True,
            "active": is_active,
            "jails": jails,
            "banned": banned
        }
    except Exception as e:
        return {
            "status": "success",
            "installed": True,
            "active": False,
            "jails": [],
            "banned": [],
            "error_message": f"Fail2Ban is installed but unresponsive: {str(e)}"
        }


@router.post("/fail2ban/install")
async def install_fail2ban() -> Dict[str, Any]:
    """Trigger Fail2Ban installation on system."""
    global MOCK_F2B_INSTALLED
    if IS_WINDOWS:
        MOCK_F2B_INSTALLED = True
        return {"status": "success", "message": "Fail2Ban installed successfully (Mock Mode)."}

    # Determine package manager
    try:
        from core import sysexec as _sysexec

        result = _sysexec.pkg_install(["fail2ban"])
        if result.get("ok"):
            # Start and enable service right after install so status endpoint
            # immediately reports active state.
            if shutil.which("systemctl"):
                _run_with_optional_sudo(["systemctl", "enable", "fail2ban"])
                _run_with_optional_sudo(["systemctl", "restart", "fail2ban"])
            return {"status": "success", "message": "Fail2Ban installed successfully!"}
        raise HTTPException(status_code=500, detail=str(result.get("output_tail") or "Installation failed."))
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/fail2ban/enable")
async def enable_fail2ban() -> Dict[str, Any]:
    """Enable and start Fail2Ban service."""
    global MOCK_F2B_INSTALLED, MOCK_F2B_ACTIVE
    if IS_WINDOWS:
        MOCK_F2B_INSTALLED = True
        MOCK_F2B_ACTIVE = True
        return {"status": "success", "message": "Fail2Ban enabled successfully (Mock Mode)."}

    if not check_fail2ban_installed():
        raise HTTPException(status_code=400, detail="Fail2Ban is not installed.")

    if not shutil.which("systemctl"):
        raise HTTPException(status_code=500, detail="systemctl not available on this system.")

    try:
        enable_res = _run_with_optional_sudo(["systemctl", "enable", "fail2ban"])
        if enable_res.returncode != 0:
            raise HTTPException(status_code=500, detail=(enable_res.stderr or enable_res.stdout or "Failed to enable Fail2Ban service.").strip())

        restart_res = _run_with_optional_sudo(["systemctl", "restart", "fail2ban"])
        if restart_res.returncode != 0:
            raise HTTPException(status_code=500, detail=(restart_res.stderr or restart_res.stdout or "Failed to start Fail2Ban service.").strip())

        return {"status": "success", "message": "Fail2Ban enabled and started successfully."}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/fail2ban/unban")
async def unban_ip(req: UnbanRequest) -> Dict[str, Any]:
    """Unbans an IP address from a Fail2Ban jail."""
    global MOCK_F2B_BANNED
    if IS_WINDOWS:
        MOCK_F2B_BANNED = [b for b in MOCK_F2B_BANNED if not (b["ip"] == req.ip and b["jail"] == req.jail)]
        return {"status": "success", "message": f"Successfully unbanned IP {req.ip} from {req.jail} (Mock Mode)."}

    f2b_path = find_fail2ban_path()
    try:
        res = _run_with_optional_sudo([f2b_path, "set", req.jail, "unbanip", req.ip])
        if res.returncode == 0:
            return {"status": "success", "message": f"Successfully unbanned IP {req.ip} from {req.jail}."}
        raise HTTPException(status_code=500, detail=(res.stderr or res.stdout or f"Failed to unban IP {req.ip}.").strip())
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))