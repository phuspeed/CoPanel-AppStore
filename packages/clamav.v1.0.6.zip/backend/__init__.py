"""ClamAV AppStore module."""
