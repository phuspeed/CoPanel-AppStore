# SSL Manager Module Init
