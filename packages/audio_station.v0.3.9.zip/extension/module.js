var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);

// src/modules/audio_station/index.tsx
import { useCallback, useEffect as useEffect3, useMemo, useRef as useRef2, useState as useState3 } from "react";

// src/core/hooks/useAppShellContext.ts
import { useOutletContext } from "react-router-dom";

// src/core/shell/ShellContext.tsx
import { createContext, useContext } from "react";
import { jsx } from "react/jsx-runtime";
var ShellContext = createContext(null);
function useShellContext() {
  return useContext(ShellContext);
}

// src/core/hooks/useAppShellContext.ts
var FALLBACK = {
  theme: localStorage.getItem("copanel_theme") || "light",
  setTheme: () => {
  },
  language: localStorage.getItem("copanel_lang") || "en",
  setLanguage: () => {
  }
};
function useAppShellContext() {
  const shell = useShellContext();
  const outlet = useOutletContext();
  if (shell) return shell;
  if (outlet?.theme) {
    return {
      theme: outlet.theme,
      setTheme: outlet.setTheme ?? (() => {
      }),
      language: outlet.language ?? "en",
      setLanguage: outlet.setLanguage ?? (() => {
      })
    };
  }
  return FALLBACK;
}

// node_modules/clsx/dist/clsx.mjs
function r(e) {
  var t, f, n = "";
  if ("string" == typeof e || "number" == typeof e) n += e;
  else if ("object" == typeof e) if (Array.isArray(e)) {
    var o = e.length;
    for (t = 0; t < o; t++) e[t] && (f = r(e[t])) && (n && (n += " "), n += f);
  } else for (f in e) e[f] && (n && (n += " "), n += f);
  return n;
}
function clsx() {
  for (var e, t, f = 0, n = "", o = arguments.length; f < o; f++) (e = arguments[f]) && (t = r(e)) && (n && (n += " "), n += t);
  return n;
}

// node_modules/tailwind-merge/dist/bundle-mjs.mjs
var CLASS_PART_SEPARATOR = "-";
var createClassGroupUtils = (config) => {
  const classMap = createClassMap(config);
  const {
    conflictingClassGroups,
    conflictingClassGroupModifiers
  } = config;
  const getClassGroupId = (className) => {
    const classParts = className.split(CLASS_PART_SEPARATOR);
    if (classParts[0] === "" && classParts.length !== 1) {
      classParts.shift();
    }
    return getGroupRecursive(classParts, classMap) || getGroupIdForArbitraryProperty(className);
  };
  const getConflictingClassGroupIds = (classGroupId, hasPostfixModifier) => {
    const conflicts = conflictingClassGroups[classGroupId] || [];
    if (hasPostfixModifier && conflictingClassGroupModifiers[classGroupId]) {
      return [...conflicts, ...conflictingClassGroupModifiers[classGroupId]];
    }
    return conflicts;
  };
  return {
    getClassGroupId,
    getConflictingClassGroupIds
  };
};
var getGroupRecursive = (classParts, classPartObject) => {
  if (classParts.length === 0) {
    return classPartObject.classGroupId;
  }
  const currentClassPart = classParts[0];
  const nextClassPartObject = classPartObject.nextPart.get(currentClassPart);
  const classGroupFromNextClassPart = nextClassPartObject ? getGroupRecursive(classParts.slice(1), nextClassPartObject) : void 0;
  if (classGroupFromNextClassPart) {
    return classGroupFromNextClassPart;
  }
  if (classPartObject.validators.length === 0) {
    return void 0;
  }
  const classRest = classParts.join(CLASS_PART_SEPARATOR);
  return classPartObject.validators.find(({
    validator
  }) => validator(classRest))?.classGroupId;
};
var arbitraryPropertyRegex = /^\[(.+)\]$/;
var getGroupIdForArbitraryProperty = (className) => {
  if (arbitraryPropertyRegex.test(className)) {
    const arbitraryPropertyClassName = arbitraryPropertyRegex.exec(className)[1];
    const property = arbitraryPropertyClassName?.substring(0, arbitraryPropertyClassName.indexOf(":"));
    if (property) {
      return "arbitrary.." + property;
    }
  }
};
var createClassMap = (config) => {
  const {
    theme,
    prefix
  } = config;
  const classMap = {
    nextPart: /* @__PURE__ */ new Map(),
    validators: []
  };
  const prefixedClassGroupEntries = getPrefixedClassGroupEntries(Object.entries(config.classGroups), prefix);
  prefixedClassGroupEntries.forEach(([classGroupId, classGroup]) => {
    processClassesRecursively(classGroup, classMap, classGroupId, theme);
  });
  return classMap;
};
var processClassesRecursively = (classGroup, classPartObject, classGroupId, theme) => {
  classGroup.forEach((classDefinition) => {
    if (typeof classDefinition === "string") {
      const classPartObjectToEdit = classDefinition === "" ? classPartObject : getPart(classPartObject, classDefinition);
      classPartObjectToEdit.classGroupId = classGroupId;
      return;
    }
    if (typeof classDefinition === "function") {
      if (isThemeGetter(classDefinition)) {
        processClassesRecursively(classDefinition(theme), classPartObject, classGroupId, theme);
        return;
      }
      classPartObject.validators.push({
        validator: classDefinition,
        classGroupId
      });
      return;
    }
    Object.entries(classDefinition).forEach(([key, classGroup2]) => {
      processClassesRecursively(classGroup2, getPart(classPartObject, key), classGroupId, theme);
    });
  });
};
var getPart = (classPartObject, path) => {
  let currentClassPartObject = classPartObject;
  path.split(CLASS_PART_SEPARATOR).forEach((pathPart) => {
    if (!currentClassPartObject.nextPart.has(pathPart)) {
      currentClassPartObject.nextPart.set(pathPart, {
        nextPart: /* @__PURE__ */ new Map(),
        validators: []
      });
    }
    currentClassPartObject = currentClassPartObject.nextPart.get(pathPart);
  });
  return currentClassPartObject;
};
var isThemeGetter = (func) => func.isThemeGetter;
var getPrefixedClassGroupEntries = (classGroupEntries, prefix) => {
  if (!prefix) {
    return classGroupEntries;
  }
  return classGroupEntries.map(([classGroupId, classGroup]) => {
    const prefixedClassGroup = classGroup.map((classDefinition) => {
      if (typeof classDefinition === "string") {
        return prefix + classDefinition;
      }
      if (typeof classDefinition === "object") {
        return Object.fromEntries(Object.entries(classDefinition).map(([key, value]) => [prefix + key, value]));
      }
      return classDefinition;
    });
    return [classGroupId, prefixedClassGroup];
  });
};
var createLruCache = (maxCacheSize) => {
  if (maxCacheSize < 1) {
    return {
      get: () => void 0,
      set: () => {
      }
    };
  }
  let cacheSize = 0;
  let cache = /* @__PURE__ */ new Map();
  let previousCache = /* @__PURE__ */ new Map();
  const update = (key, value) => {
    cache.set(key, value);
    cacheSize++;
    if (cacheSize > maxCacheSize) {
      cacheSize = 0;
      previousCache = cache;
      cache = /* @__PURE__ */ new Map();
    }
  };
  return {
    get(key) {
      let value = cache.get(key);
      if (value !== void 0) {
        return value;
      }
      if ((value = previousCache.get(key)) !== void 0) {
        update(key, value);
        return value;
      }
    },
    set(key, value) {
      if (cache.has(key)) {
        cache.set(key, value);
      } else {
        update(key, value);
      }
    }
  };
};
var IMPORTANT_MODIFIER = "!";
var createParseClassName = (config) => {
  const {
    separator,
    experimentalParseClassName
  } = config;
  const isSeparatorSingleCharacter = separator.length === 1;
  const firstSeparatorCharacter = separator[0];
  const separatorLength = separator.length;
  const parseClassName = (className) => {
    const modifiers = [];
    let bracketDepth = 0;
    let modifierStart = 0;
    let postfixModifierPosition;
    for (let index = 0; index < className.length; index++) {
      let currentCharacter = className[index];
      if (bracketDepth === 0) {
        if (currentCharacter === firstSeparatorCharacter && (isSeparatorSingleCharacter || className.slice(index, index + separatorLength) === separator)) {
          modifiers.push(className.slice(modifierStart, index));
          modifierStart = index + separatorLength;
          continue;
        }
        if (currentCharacter === "/") {
          postfixModifierPosition = index;
          continue;
        }
      }
      if (currentCharacter === "[") {
        bracketDepth++;
      } else if (currentCharacter === "]") {
        bracketDepth--;
      }
    }
    const baseClassNameWithImportantModifier = modifiers.length === 0 ? className : className.substring(modifierStart);
    const hasImportantModifier = baseClassNameWithImportantModifier.startsWith(IMPORTANT_MODIFIER);
    const baseClassName = hasImportantModifier ? baseClassNameWithImportantModifier.substring(1) : baseClassNameWithImportantModifier;
    const maybePostfixModifierPosition = postfixModifierPosition && postfixModifierPosition > modifierStart ? postfixModifierPosition - modifierStart : void 0;
    return {
      modifiers,
      hasImportantModifier,
      baseClassName,
      maybePostfixModifierPosition
    };
  };
  if (experimentalParseClassName) {
    return (className) => experimentalParseClassName({
      className,
      parseClassName
    });
  }
  return parseClassName;
};
var sortModifiers = (modifiers) => {
  if (modifiers.length <= 1) {
    return modifiers;
  }
  const sortedModifiers = [];
  let unsortedModifiers = [];
  modifiers.forEach((modifier) => {
    const isArbitraryVariant = modifier[0] === "[";
    if (isArbitraryVariant) {
      sortedModifiers.push(...unsortedModifiers.sort(), modifier);
      unsortedModifiers = [];
    } else {
      unsortedModifiers.push(modifier);
    }
  });
  sortedModifiers.push(...unsortedModifiers.sort());
  return sortedModifiers;
};
var createConfigUtils = (config) => ({
  cache: createLruCache(config.cacheSize),
  parseClassName: createParseClassName(config),
  ...createClassGroupUtils(config)
});
var SPLIT_CLASSES_REGEX = /\s+/;
var mergeClassList = (classList, configUtils) => {
  const {
    parseClassName,
    getClassGroupId,
    getConflictingClassGroupIds
  } = configUtils;
  const classGroupsInConflict = [];
  const classNames = classList.trim().split(SPLIT_CLASSES_REGEX);
  let result = "";
  for (let index = classNames.length - 1; index >= 0; index -= 1) {
    const originalClassName = classNames[index];
    const {
      modifiers,
      hasImportantModifier,
      baseClassName,
      maybePostfixModifierPosition
    } = parseClassName(originalClassName);
    let hasPostfixModifier = Boolean(maybePostfixModifierPosition);
    let classGroupId = getClassGroupId(hasPostfixModifier ? baseClassName.substring(0, maybePostfixModifierPosition) : baseClassName);
    if (!classGroupId) {
      if (!hasPostfixModifier) {
        result = originalClassName + (result.length > 0 ? " " + result : result);
        continue;
      }
      classGroupId = getClassGroupId(baseClassName);
      if (!classGroupId) {
        result = originalClassName + (result.length > 0 ? " " + result : result);
        continue;
      }
      hasPostfixModifier = false;
    }
    const variantModifier = sortModifiers(modifiers).join(":");
    const modifierId = hasImportantModifier ? variantModifier + IMPORTANT_MODIFIER : variantModifier;
    const classId = modifierId + classGroupId;
    if (classGroupsInConflict.includes(classId)) {
      continue;
    }
    classGroupsInConflict.push(classId);
    const conflictGroups = getConflictingClassGroupIds(classGroupId, hasPostfixModifier);
    for (let i = 0; i < conflictGroups.length; ++i) {
      const group = conflictGroups[i];
      classGroupsInConflict.push(modifierId + group);
    }
    result = originalClassName + (result.length > 0 ? " " + result : result);
  }
  return result;
};
function twJoin() {
  let index = 0;
  let argument;
  let resolvedValue;
  let string = "";
  while (index < arguments.length) {
    if (argument = arguments[index++]) {
      if (resolvedValue = toValue(argument)) {
        string && (string += " ");
        string += resolvedValue;
      }
    }
  }
  return string;
}
var toValue = (mix) => {
  if (typeof mix === "string") {
    return mix;
  }
  let resolvedValue;
  let string = "";
  for (let k = 0; k < mix.length; k++) {
    if (mix[k]) {
      if (resolvedValue = toValue(mix[k])) {
        string && (string += " ");
        string += resolvedValue;
      }
    }
  }
  return string;
};
function createTailwindMerge(createConfigFirst, ...createConfigRest) {
  let configUtils;
  let cacheGet;
  let cacheSet;
  let functionToCall = initTailwindMerge;
  function initTailwindMerge(classList) {
    const config = createConfigRest.reduce((previousConfig, createConfigCurrent) => createConfigCurrent(previousConfig), createConfigFirst());
    configUtils = createConfigUtils(config);
    cacheGet = configUtils.cache.get;
    cacheSet = configUtils.cache.set;
    functionToCall = tailwindMerge;
    return tailwindMerge(classList);
  }
  function tailwindMerge(classList) {
    const cachedResult = cacheGet(classList);
    if (cachedResult) {
      return cachedResult;
    }
    const result = mergeClassList(classList, configUtils);
    cacheSet(classList, result);
    return result;
  }
  return function callTailwindMerge() {
    return functionToCall(twJoin.apply(null, arguments));
  };
}
var fromTheme = (key) => {
  const themeGetter = (theme) => theme[key] || [];
  themeGetter.isThemeGetter = true;
  return themeGetter;
};
var arbitraryValueRegex = /^\[(?:([a-z-]+):)?(.+)\]$/i;
var fractionRegex = /^\d+\/\d+$/;
var stringLengths = /* @__PURE__ */ new Set(["px", "full", "screen"]);
var tshirtUnitRegex = /^(\d+(\.\d+)?)?(xs|sm|md|lg|xl)$/;
var lengthUnitRegex = /\d+(%|px|r?em|[sdl]?v([hwib]|min|max)|pt|pc|in|cm|mm|cap|ch|ex|r?lh|cq(w|h|i|b|min|max))|\b(calc|min|max|clamp)\(.+\)|^0$/;
var colorFunctionRegex = /^(rgba?|hsla?|hwb|(ok)?(lab|lch)|color-mix)\(.+\)$/;
var shadowRegex = /^(inset_)?-?((\d+)?\.?(\d+)[a-z]+|0)_-?((\d+)?\.?(\d+)[a-z]+|0)/;
var imageRegex = /^(url|image|image-set|cross-fade|element|(repeating-)?(linear|radial|conic)-gradient)\(.+\)$/;
var isLength = (value) => isNumber(value) || stringLengths.has(value) || fractionRegex.test(value);
var isArbitraryLength = (value) => getIsArbitraryValue(value, "length", isLengthOnly);
var isNumber = (value) => Boolean(value) && !Number.isNaN(Number(value));
var isArbitraryNumber = (value) => getIsArbitraryValue(value, "number", isNumber);
var isInteger = (value) => Boolean(value) && Number.isInteger(Number(value));
var isPercent = (value) => value.endsWith("%") && isNumber(value.slice(0, -1));
var isArbitraryValue = (value) => arbitraryValueRegex.test(value);
var isTshirtSize = (value) => tshirtUnitRegex.test(value);
var sizeLabels = /* @__PURE__ */ new Set(["length", "size", "percentage"]);
var isArbitrarySize = (value) => getIsArbitraryValue(value, sizeLabels, isNever);
var isArbitraryPosition = (value) => getIsArbitraryValue(value, "position", isNever);
var imageLabels = /* @__PURE__ */ new Set(["image", "url"]);
var isArbitraryImage = (value) => getIsArbitraryValue(value, imageLabels, isImage);
var isArbitraryShadow = (value) => getIsArbitraryValue(value, "", isShadow);
var isAny = () => true;
var getIsArbitraryValue = (value, label, testValue) => {
  const result = arbitraryValueRegex.exec(value);
  if (result) {
    if (result[1]) {
      return typeof label === "string" ? result[1] === label : label.has(result[1]);
    }
    return testValue(result[2]);
  }
  return false;
};
var isLengthOnly = (value) => (
  // `colorFunctionRegex` check is necessary because color functions can have percentages in them which which would be incorrectly classified as lengths.
  // For example, `hsl(0 0% 0%)` would be classified as a length without this check.
  // I could also use lookbehind assertion in `lengthUnitRegex` but that isn't supported widely enough.
  lengthUnitRegex.test(value) && !colorFunctionRegex.test(value)
);
var isNever = () => false;
var isShadow = (value) => shadowRegex.test(value);
var isImage = (value) => imageRegex.test(value);
var getDefaultConfig = () => {
  const colors = fromTheme("colors");
  const spacing = fromTheme("spacing");
  const blur = fromTheme("blur");
  const brightness = fromTheme("brightness");
  const borderColor = fromTheme("borderColor");
  const borderRadius = fromTheme("borderRadius");
  const borderSpacing = fromTheme("borderSpacing");
  const borderWidth = fromTheme("borderWidth");
  const contrast = fromTheme("contrast");
  const grayscale = fromTheme("grayscale");
  const hueRotate = fromTheme("hueRotate");
  const invert = fromTheme("invert");
  const gap = fromTheme("gap");
  const gradientColorStops = fromTheme("gradientColorStops");
  const gradientColorStopPositions = fromTheme("gradientColorStopPositions");
  const inset = fromTheme("inset");
  const margin = fromTheme("margin");
  const opacity = fromTheme("opacity");
  const padding = fromTheme("padding");
  const saturate = fromTheme("saturate");
  const scale = fromTheme("scale");
  const sepia = fromTheme("sepia");
  const skew = fromTheme("skew");
  const space = fromTheme("space");
  const translate = fromTheme("translate");
  const getOverscroll = () => ["auto", "contain", "none"];
  const getOverflow = () => ["auto", "hidden", "clip", "visible", "scroll"];
  const getSpacingWithAutoAndArbitrary = () => ["auto", isArbitraryValue, spacing];
  const getSpacingWithArbitrary = () => [isArbitraryValue, spacing];
  const getLengthWithEmptyAndArbitrary = () => ["", isLength, isArbitraryLength];
  const getNumberWithAutoAndArbitrary = () => ["auto", isNumber, isArbitraryValue];
  const getPositions = () => ["bottom", "center", "left", "left-bottom", "left-top", "right", "right-bottom", "right-top", "top"];
  const getLineStyles = () => ["solid", "dashed", "dotted", "double", "none"];
  const getBlendModes = () => ["normal", "multiply", "screen", "overlay", "darken", "lighten", "color-dodge", "color-burn", "hard-light", "soft-light", "difference", "exclusion", "hue", "saturation", "color", "luminosity"];
  const getAlign = () => ["start", "end", "center", "between", "around", "evenly", "stretch"];
  const getZeroAndEmpty = () => ["", "0", isArbitraryValue];
  const getBreaks = () => ["auto", "avoid", "all", "avoid-page", "page", "left", "right", "column"];
  const getNumberAndArbitrary = () => [isNumber, isArbitraryValue];
  return {
    cacheSize: 500,
    separator: ":",
    theme: {
      colors: [isAny],
      spacing: [isLength, isArbitraryLength],
      blur: ["none", "", isTshirtSize, isArbitraryValue],
      brightness: getNumberAndArbitrary(),
      borderColor: [colors],
      borderRadius: ["none", "", "full", isTshirtSize, isArbitraryValue],
      borderSpacing: getSpacingWithArbitrary(),
      borderWidth: getLengthWithEmptyAndArbitrary(),
      contrast: getNumberAndArbitrary(),
      grayscale: getZeroAndEmpty(),
      hueRotate: getNumberAndArbitrary(),
      invert: getZeroAndEmpty(),
      gap: getSpacingWithArbitrary(),
      gradientColorStops: [colors],
      gradientColorStopPositions: [isPercent, isArbitraryLength],
      inset: getSpacingWithAutoAndArbitrary(),
      margin: getSpacingWithAutoAndArbitrary(),
      opacity: getNumberAndArbitrary(),
      padding: getSpacingWithArbitrary(),
      saturate: getNumberAndArbitrary(),
      scale: getNumberAndArbitrary(),
      sepia: getZeroAndEmpty(),
      skew: getNumberAndArbitrary(),
      space: getSpacingWithArbitrary(),
      translate: getSpacingWithArbitrary()
    },
    classGroups: {
      // Layout
      /**
       * Aspect Ratio
       * @see https://tailwindcss.com/docs/aspect-ratio
       */
      aspect: [{
        aspect: ["auto", "square", "video", isArbitraryValue]
      }],
      /**
       * Container
       * @see https://tailwindcss.com/docs/container
       */
      container: ["container"],
      /**
       * Columns
       * @see https://tailwindcss.com/docs/columns
       */
      columns: [{
        columns: [isTshirtSize]
      }],
      /**
       * Break After
       * @see https://tailwindcss.com/docs/break-after
       */
      "break-after": [{
        "break-after": getBreaks()
      }],
      /**
       * Break Before
       * @see https://tailwindcss.com/docs/break-before
       */
      "break-before": [{
        "break-before": getBreaks()
      }],
      /**
       * Break Inside
       * @see https://tailwindcss.com/docs/break-inside
       */
      "break-inside": [{
        "break-inside": ["auto", "avoid", "avoid-page", "avoid-column"]
      }],
      /**
       * Box Decoration Break
       * @see https://tailwindcss.com/docs/box-decoration-break
       */
      "box-decoration": [{
        "box-decoration": ["slice", "clone"]
      }],
      /**
       * Box Sizing
       * @see https://tailwindcss.com/docs/box-sizing
       */
      box: [{
        box: ["border", "content"]
      }],
      /**
       * Display
       * @see https://tailwindcss.com/docs/display
       */
      display: ["block", "inline-block", "inline", "flex", "inline-flex", "table", "inline-table", "table-caption", "table-cell", "table-column", "table-column-group", "table-footer-group", "table-header-group", "table-row-group", "table-row", "flow-root", "grid", "inline-grid", "contents", "list-item", "hidden"],
      /**
       * Floats
       * @see https://tailwindcss.com/docs/float
       */
      float: [{
        float: ["right", "left", "none", "start", "end"]
      }],
      /**
       * Clear
       * @see https://tailwindcss.com/docs/clear
       */
      clear: [{
        clear: ["left", "right", "both", "none", "start", "end"]
      }],
      /**
       * Isolation
       * @see https://tailwindcss.com/docs/isolation
       */
      isolation: ["isolate", "isolation-auto"],
      /**
       * Object Fit
       * @see https://tailwindcss.com/docs/object-fit
       */
      "object-fit": [{
        object: ["contain", "cover", "fill", "none", "scale-down"]
      }],
      /**
       * Object Position
       * @see https://tailwindcss.com/docs/object-position
       */
      "object-position": [{
        object: [...getPositions(), isArbitraryValue]
      }],
      /**
       * Overflow
       * @see https://tailwindcss.com/docs/overflow
       */
      overflow: [{
        overflow: getOverflow()
      }],
      /**
       * Overflow X
       * @see https://tailwindcss.com/docs/overflow
       */
      "overflow-x": [{
        "overflow-x": getOverflow()
      }],
      /**
       * Overflow Y
       * @see https://tailwindcss.com/docs/overflow
       */
      "overflow-y": [{
        "overflow-y": getOverflow()
      }],
      /**
       * Overscroll Behavior
       * @see https://tailwindcss.com/docs/overscroll-behavior
       */
      overscroll: [{
        overscroll: getOverscroll()
      }],
      /**
       * Overscroll Behavior X
       * @see https://tailwindcss.com/docs/overscroll-behavior
       */
      "overscroll-x": [{
        "overscroll-x": getOverscroll()
      }],
      /**
       * Overscroll Behavior Y
       * @see https://tailwindcss.com/docs/overscroll-behavior
       */
      "overscroll-y": [{
        "overscroll-y": getOverscroll()
      }],
      /**
       * Position
       * @see https://tailwindcss.com/docs/position
       */
      position: ["static", "fixed", "absolute", "relative", "sticky"],
      /**
       * Top / Right / Bottom / Left
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      inset: [{
        inset: [inset]
      }],
      /**
       * Right / Left
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      "inset-x": [{
        "inset-x": [inset]
      }],
      /**
       * Top / Bottom
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      "inset-y": [{
        "inset-y": [inset]
      }],
      /**
       * Start
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      start: [{
        start: [inset]
      }],
      /**
       * End
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      end: [{
        end: [inset]
      }],
      /**
       * Top
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      top: [{
        top: [inset]
      }],
      /**
       * Right
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      right: [{
        right: [inset]
      }],
      /**
       * Bottom
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      bottom: [{
        bottom: [inset]
      }],
      /**
       * Left
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      left: [{
        left: [inset]
      }],
      /**
       * Visibility
       * @see https://tailwindcss.com/docs/visibility
       */
      visibility: ["visible", "invisible", "collapse"],
      /**
       * Z-Index
       * @see https://tailwindcss.com/docs/z-index
       */
      z: [{
        z: ["auto", isInteger, isArbitraryValue]
      }],
      // Flexbox and Grid
      /**
       * Flex Basis
       * @see https://tailwindcss.com/docs/flex-basis
       */
      basis: [{
        basis: getSpacingWithAutoAndArbitrary()
      }],
      /**
       * Flex Direction
       * @see https://tailwindcss.com/docs/flex-direction
       */
      "flex-direction": [{
        flex: ["row", "row-reverse", "col", "col-reverse"]
      }],
      /**
       * Flex Wrap
       * @see https://tailwindcss.com/docs/flex-wrap
       */
      "flex-wrap": [{
        flex: ["wrap", "wrap-reverse", "nowrap"]
      }],
      /**
       * Flex
       * @see https://tailwindcss.com/docs/flex
       */
      flex: [{
        flex: ["1", "auto", "initial", "none", isArbitraryValue]
      }],
      /**
       * Flex Grow
       * @see https://tailwindcss.com/docs/flex-grow
       */
      grow: [{
        grow: getZeroAndEmpty()
      }],
      /**
       * Flex Shrink
       * @see https://tailwindcss.com/docs/flex-shrink
       */
      shrink: [{
        shrink: getZeroAndEmpty()
      }],
      /**
       * Order
       * @see https://tailwindcss.com/docs/order
       */
      order: [{
        order: ["first", "last", "none", isInteger, isArbitraryValue]
      }],
      /**
       * Grid Template Columns
       * @see https://tailwindcss.com/docs/grid-template-columns
       */
      "grid-cols": [{
        "grid-cols": [isAny]
      }],
      /**
       * Grid Column Start / End
       * @see https://tailwindcss.com/docs/grid-column
       */
      "col-start-end": [{
        col: ["auto", {
          span: ["full", isInteger, isArbitraryValue]
        }, isArbitraryValue]
      }],
      /**
       * Grid Column Start
       * @see https://tailwindcss.com/docs/grid-column
       */
      "col-start": [{
        "col-start": getNumberWithAutoAndArbitrary()
      }],
      /**
       * Grid Column End
       * @see https://tailwindcss.com/docs/grid-column
       */
      "col-end": [{
        "col-end": getNumberWithAutoAndArbitrary()
      }],
      /**
       * Grid Template Rows
       * @see https://tailwindcss.com/docs/grid-template-rows
       */
      "grid-rows": [{
        "grid-rows": [isAny]
      }],
      /**
       * Grid Row Start / End
       * @see https://tailwindcss.com/docs/grid-row
       */
      "row-start-end": [{
        row: ["auto", {
          span: [isInteger, isArbitraryValue]
        }, isArbitraryValue]
      }],
      /**
       * Grid Row Start
       * @see https://tailwindcss.com/docs/grid-row
       */
      "row-start": [{
        "row-start": getNumberWithAutoAndArbitrary()
      }],
      /**
       * Grid Row End
       * @see https://tailwindcss.com/docs/grid-row
       */
      "row-end": [{
        "row-end": getNumberWithAutoAndArbitrary()
      }],
      /**
       * Grid Auto Flow
       * @see https://tailwindcss.com/docs/grid-auto-flow
       */
      "grid-flow": [{
        "grid-flow": ["row", "col", "dense", "row-dense", "col-dense"]
      }],
      /**
       * Grid Auto Columns
       * @see https://tailwindcss.com/docs/grid-auto-columns
       */
      "auto-cols": [{
        "auto-cols": ["auto", "min", "max", "fr", isArbitraryValue]
      }],
      /**
       * Grid Auto Rows
       * @see https://tailwindcss.com/docs/grid-auto-rows
       */
      "auto-rows": [{
        "auto-rows": ["auto", "min", "max", "fr", isArbitraryValue]
      }],
      /**
       * Gap
       * @see https://tailwindcss.com/docs/gap
       */
      gap: [{
        gap: [gap]
      }],
      /**
       * Gap X
       * @see https://tailwindcss.com/docs/gap
       */
      "gap-x": [{
        "gap-x": [gap]
      }],
      /**
       * Gap Y
       * @see https://tailwindcss.com/docs/gap
       */
      "gap-y": [{
        "gap-y": [gap]
      }],
      /**
       * Justify Content
       * @see https://tailwindcss.com/docs/justify-content
       */
      "justify-content": [{
        justify: ["normal", ...getAlign()]
      }],
      /**
       * Justify Items
       * @see https://tailwindcss.com/docs/justify-items
       */
      "justify-items": [{
        "justify-items": ["start", "end", "center", "stretch"]
      }],
      /**
       * Justify Self
       * @see https://tailwindcss.com/docs/justify-self
       */
      "justify-self": [{
        "justify-self": ["auto", "start", "end", "center", "stretch"]
      }],
      /**
       * Align Content
       * @see https://tailwindcss.com/docs/align-content
       */
      "align-content": [{
        content: ["normal", ...getAlign(), "baseline"]
      }],
      /**
       * Align Items
       * @see https://tailwindcss.com/docs/align-items
       */
      "align-items": [{
        items: ["start", "end", "center", "baseline", "stretch"]
      }],
      /**
       * Align Self
       * @see https://tailwindcss.com/docs/align-self
       */
      "align-self": [{
        self: ["auto", "start", "end", "center", "stretch", "baseline"]
      }],
      /**
       * Place Content
       * @see https://tailwindcss.com/docs/place-content
       */
      "place-content": [{
        "place-content": [...getAlign(), "baseline"]
      }],
      /**
       * Place Items
       * @see https://tailwindcss.com/docs/place-items
       */
      "place-items": [{
        "place-items": ["start", "end", "center", "baseline", "stretch"]
      }],
      /**
       * Place Self
       * @see https://tailwindcss.com/docs/place-self
       */
      "place-self": [{
        "place-self": ["auto", "start", "end", "center", "stretch"]
      }],
      // Spacing
      /**
       * Padding
       * @see https://tailwindcss.com/docs/padding
       */
      p: [{
        p: [padding]
      }],
      /**
       * Padding X
       * @see https://tailwindcss.com/docs/padding
       */
      px: [{
        px: [padding]
      }],
      /**
       * Padding Y
       * @see https://tailwindcss.com/docs/padding
       */
      py: [{
        py: [padding]
      }],
      /**
       * Padding Start
       * @see https://tailwindcss.com/docs/padding
       */
      ps: [{
        ps: [padding]
      }],
      /**
       * Padding End
       * @see https://tailwindcss.com/docs/padding
       */
      pe: [{
        pe: [padding]
      }],
      /**
       * Padding Top
       * @see https://tailwindcss.com/docs/padding
       */
      pt: [{
        pt: [padding]
      }],
      /**
       * Padding Right
       * @see https://tailwindcss.com/docs/padding
       */
      pr: [{
        pr: [padding]
      }],
      /**
       * Padding Bottom
       * @see https://tailwindcss.com/docs/padding
       */
      pb: [{
        pb: [padding]
      }],
      /**
       * Padding Left
       * @see https://tailwindcss.com/docs/padding
       */
      pl: [{
        pl: [padding]
      }],
      /**
       * Margin
       * @see https://tailwindcss.com/docs/margin
       */
      m: [{
        m: [margin]
      }],
      /**
       * Margin X
       * @see https://tailwindcss.com/docs/margin
       */
      mx: [{
        mx: [margin]
      }],
      /**
       * Margin Y
       * @see https://tailwindcss.com/docs/margin
       */
      my: [{
        my: [margin]
      }],
      /**
       * Margin Start
       * @see https://tailwindcss.com/docs/margin
       */
      ms: [{
        ms: [margin]
      }],
      /**
       * Margin End
       * @see https://tailwindcss.com/docs/margin
       */
      me: [{
        me: [margin]
      }],
      /**
       * Margin Top
       * @see https://tailwindcss.com/docs/margin
       */
      mt: [{
        mt: [margin]
      }],
      /**
       * Margin Right
       * @see https://tailwindcss.com/docs/margin
       */
      mr: [{
        mr: [margin]
      }],
      /**
       * Margin Bottom
       * @see https://tailwindcss.com/docs/margin
       */
      mb: [{
        mb: [margin]
      }],
      /**
       * Margin Left
       * @see https://tailwindcss.com/docs/margin
       */
      ml: [{
        ml: [margin]
      }],
      /**
       * Space Between X
       * @see https://tailwindcss.com/docs/space
       */
      "space-x": [{
        "space-x": [space]
      }],
      /**
       * Space Between X Reverse
       * @see https://tailwindcss.com/docs/space
       */
      "space-x-reverse": ["space-x-reverse"],
      /**
       * Space Between Y
       * @see https://tailwindcss.com/docs/space
       */
      "space-y": [{
        "space-y": [space]
      }],
      /**
       * Space Between Y Reverse
       * @see https://tailwindcss.com/docs/space
       */
      "space-y-reverse": ["space-y-reverse"],
      // Sizing
      /**
       * Width
       * @see https://tailwindcss.com/docs/width
       */
      w: [{
        w: ["auto", "min", "max", "fit", "svw", "lvw", "dvw", isArbitraryValue, spacing]
      }],
      /**
       * Min-Width
       * @see https://tailwindcss.com/docs/min-width
       */
      "min-w": [{
        "min-w": [isArbitraryValue, spacing, "min", "max", "fit"]
      }],
      /**
       * Max-Width
       * @see https://tailwindcss.com/docs/max-width
       */
      "max-w": [{
        "max-w": [isArbitraryValue, spacing, "none", "full", "min", "max", "fit", "prose", {
          screen: [isTshirtSize]
        }, isTshirtSize]
      }],
      /**
       * Height
       * @see https://tailwindcss.com/docs/height
       */
      h: [{
        h: [isArbitraryValue, spacing, "auto", "min", "max", "fit", "svh", "lvh", "dvh"]
      }],
      /**
       * Min-Height
       * @see https://tailwindcss.com/docs/min-height
       */
      "min-h": [{
        "min-h": [isArbitraryValue, spacing, "min", "max", "fit", "svh", "lvh", "dvh"]
      }],
      /**
       * Max-Height
       * @see https://tailwindcss.com/docs/max-height
       */
      "max-h": [{
        "max-h": [isArbitraryValue, spacing, "min", "max", "fit", "svh", "lvh", "dvh"]
      }],
      /**
       * Size
       * @see https://tailwindcss.com/docs/size
       */
      size: [{
        size: [isArbitraryValue, spacing, "auto", "min", "max", "fit"]
      }],
      // Typography
      /**
       * Font Size
       * @see https://tailwindcss.com/docs/font-size
       */
      "font-size": [{
        text: ["base", isTshirtSize, isArbitraryLength]
      }],
      /**
       * Font Smoothing
       * @see https://tailwindcss.com/docs/font-smoothing
       */
      "font-smoothing": ["antialiased", "subpixel-antialiased"],
      /**
       * Font Style
       * @see https://tailwindcss.com/docs/font-style
       */
      "font-style": ["italic", "not-italic"],
      /**
       * Font Weight
       * @see https://tailwindcss.com/docs/font-weight
       */
      "font-weight": [{
        font: ["thin", "extralight", "light", "normal", "medium", "semibold", "bold", "extrabold", "black", isArbitraryNumber]
      }],
      /**
       * Font Family
       * @see https://tailwindcss.com/docs/font-family
       */
      "font-family": [{
        font: [isAny]
      }],
      /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */
      "fvn-normal": ["normal-nums"],
      /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */
      "fvn-ordinal": ["ordinal"],
      /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */
      "fvn-slashed-zero": ["slashed-zero"],
      /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */
      "fvn-figure": ["lining-nums", "oldstyle-nums"],
      /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */
      "fvn-spacing": ["proportional-nums", "tabular-nums"],
      /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */
      "fvn-fraction": ["diagonal-fractions", "stacked-fractions"],
      /**
       * Letter Spacing
       * @see https://tailwindcss.com/docs/letter-spacing
       */
      tracking: [{
        tracking: ["tighter", "tight", "normal", "wide", "wider", "widest", isArbitraryValue]
      }],
      /**
       * Line Clamp
       * @see https://tailwindcss.com/docs/line-clamp
       */
      "line-clamp": [{
        "line-clamp": ["none", isNumber, isArbitraryNumber]
      }],
      /**
       * Line Height
       * @see https://tailwindcss.com/docs/line-height
       */
      leading: [{
        leading: ["none", "tight", "snug", "normal", "relaxed", "loose", isLength, isArbitraryValue]
      }],
      /**
       * List Style Image
       * @see https://tailwindcss.com/docs/list-style-image
       */
      "list-image": [{
        "list-image": ["none", isArbitraryValue]
      }],
      /**
       * List Style Type
       * @see https://tailwindcss.com/docs/list-style-type
       */
      "list-style-type": [{
        list: ["none", "disc", "decimal", isArbitraryValue]
      }],
      /**
       * List Style Position
       * @see https://tailwindcss.com/docs/list-style-position
       */
      "list-style-position": [{
        list: ["inside", "outside"]
      }],
      /**
       * Placeholder Color
       * @deprecated since Tailwind CSS v3.0.0
       * @see https://tailwindcss.com/docs/placeholder-color
       */
      "placeholder-color": [{
        placeholder: [colors]
      }],
      /**
       * Placeholder Opacity
       * @see https://tailwindcss.com/docs/placeholder-opacity
       */
      "placeholder-opacity": [{
        "placeholder-opacity": [opacity]
      }],
      /**
       * Text Alignment
       * @see https://tailwindcss.com/docs/text-align
       */
      "text-alignment": [{
        text: ["left", "center", "right", "justify", "start", "end"]
      }],
      /**
       * Text Color
       * @see https://tailwindcss.com/docs/text-color
       */
      "text-color": [{
        text: [colors]
      }],
      /**
       * Text Opacity
       * @see https://tailwindcss.com/docs/text-opacity
       */
      "text-opacity": [{
        "text-opacity": [opacity]
      }],
      /**
       * Text Decoration
       * @see https://tailwindcss.com/docs/text-decoration
       */
      "text-decoration": ["underline", "overline", "line-through", "no-underline"],
      /**
       * Text Decoration Style
       * @see https://tailwindcss.com/docs/text-decoration-style
       */
      "text-decoration-style": [{
        decoration: [...getLineStyles(), "wavy"]
      }],
      /**
       * Text Decoration Thickness
       * @see https://tailwindcss.com/docs/text-decoration-thickness
       */
      "text-decoration-thickness": [{
        decoration: ["auto", "from-font", isLength, isArbitraryLength]
      }],
      /**
       * Text Underline Offset
       * @see https://tailwindcss.com/docs/text-underline-offset
       */
      "underline-offset": [{
        "underline-offset": ["auto", isLength, isArbitraryValue]
      }],
      /**
       * Text Decoration Color
       * @see https://tailwindcss.com/docs/text-decoration-color
       */
      "text-decoration-color": [{
        decoration: [colors]
      }],
      /**
       * Text Transform
       * @see https://tailwindcss.com/docs/text-transform
       */
      "text-transform": ["uppercase", "lowercase", "capitalize", "normal-case"],
      /**
       * Text Overflow
       * @see https://tailwindcss.com/docs/text-overflow
       */
      "text-overflow": ["truncate", "text-ellipsis", "text-clip"],
      /**
       * Text Wrap
       * @see https://tailwindcss.com/docs/text-wrap
       */
      "text-wrap": [{
        text: ["wrap", "nowrap", "balance", "pretty"]
      }],
      /**
       * Text Indent
       * @see https://tailwindcss.com/docs/text-indent
       */
      indent: [{
        indent: getSpacingWithArbitrary()
      }],
      /**
       * Vertical Alignment
       * @see https://tailwindcss.com/docs/vertical-align
       */
      "vertical-align": [{
        align: ["baseline", "top", "middle", "bottom", "text-top", "text-bottom", "sub", "super", isArbitraryValue]
      }],
      /**
       * Whitespace
       * @see https://tailwindcss.com/docs/whitespace
       */
      whitespace: [{
        whitespace: ["normal", "nowrap", "pre", "pre-line", "pre-wrap", "break-spaces"]
      }],
      /**
       * Word Break
       * @see https://tailwindcss.com/docs/word-break
       */
      break: [{
        break: ["normal", "words", "all", "keep"]
      }],
      /**
       * Hyphens
       * @see https://tailwindcss.com/docs/hyphens
       */
      hyphens: [{
        hyphens: ["none", "manual", "auto"]
      }],
      /**
       * Content
       * @see https://tailwindcss.com/docs/content
       */
      content: [{
        content: ["none", isArbitraryValue]
      }],
      // Backgrounds
      /**
       * Background Attachment
       * @see https://tailwindcss.com/docs/background-attachment
       */
      "bg-attachment": [{
        bg: ["fixed", "local", "scroll"]
      }],
      /**
       * Background Clip
       * @see https://tailwindcss.com/docs/background-clip
       */
      "bg-clip": [{
        "bg-clip": ["border", "padding", "content", "text"]
      }],
      /**
       * Background Opacity
       * @deprecated since Tailwind CSS v3.0.0
       * @see https://tailwindcss.com/docs/background-opacity
       */
      "bg-opacity": [{
        "bg-opacity": [opacity]
      }],
      /**
       * Background Origin
       * @see https://tailwindcss.com/docs/background-origin
       */
      "bg-origin": [{
        "bg-origin": ["border", "padding", "content"]
      }],
      /**
       * Background Position
       * @see https://tailwindcss.com/docs/background-position
       */
      "bg-position": [{
        bg: [...getPositions(), isArbitraryPosition]
      }],
      /**
       * Background Repeat
       * @see https://tailwindcss.com/docs/background-repeat
       */
      "bg-repeat": [{
        bg: ["no-repeat", {
          repeat: ["", "x", "y", "round", "space"]
        }]
      }],
      /**
       * Background Size
       * @see https://tailwindcss.com/docs/background-size
       */
      "bg-size": [{
        bg: ["auto", "cover", "contain", isArbitrarySize]
      }],
      /**
       * Background Image
       * @see https://tailwindcss.com/docs/background-image
       */
      "bg-image": [{
        bg: ["none", {
          "gradient-to": ["t", "tr", "r", "br", "b", "bl", "l", "tl"]
        }, isArbitraryImage]
      }],
      /**
       * Background Color
       * @see https://tailwindcss.com/docs/background-color
       */
      "bg-color": [{
        bg: [colors]
      }],
      /**
       * Gradient Color Stops From Position
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */
      "gradient-from-pos": [{
        from: [gradientColorStopPositions]
      }],
      /**
       * Gradient Color Stops Via Position
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */
      "gradient-via-pos": [{
        via: [gradientColorStopPositions]
      }],
      /**
       * Gradient Color Stops To Position
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */
      "gradient-to-pos": [{
        to: [gradientColorStopPositions]
      }],
      /**
       * Gradient Color Stops From
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */
      "gradient-from": [{
        from: [gradientColorStops]
      }],
      /**
       * Gradient Color Stops Via
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */
      "gradient-via": [{
        via: [gradientColorStops]
      }],
      /**
       * Gradient Color Stops To
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */
      "gradient-to": [{
        to: [gradientColorStops]
      }],
      // Borders
      /**
       * Border Radius
       * @see https://tailwindcss.com/docs/border-radius
       */
      rounded: [{
        rounded: [borderRadius]
      }],
      /**
       * Border Radius Start
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-s": [{
        "rounded-s": [borderRadius]
      }],
      /**
       * Border Radius End
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-e": [{
        "rounded-e": [borderRadius]
      }],
      /**
       * Border Radius Top
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-t": [{
        "rounded-t": [borderRadius]
      }],
      /**
       * Border Radius Right
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-r": [{
        "rounded-r": [borderRadius]
      }],
      /**
       * Border Radius Bottom
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-b": [{
        "rounded-b": [borderRadius]
      }],
      /**
       * Border Radius Left
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-l": [{
        "rounded-l": [borderRadius]
      }],
      /**
       * Border Radius Start Start
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-ss": [{
        "rounded-ss": [borderRadius]
      }],
      /**
       * Border Radius Start End
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-se": [{
        "rounded-se": [borderRadius]
      }],
      /**
       * Border Radius End End
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-ee": [{
        "rounded-ee": [borderRadius]
      }],
      /**
       * Border Radius End Start
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-es": [{
        "rounded-es": [borderRadius]
      }],
      /**
       * Border Radius Top Left
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-tl": [{
        "rounded-tl": [borderRadius]
      }],
      /**
       * Border Radius Top Right
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-tr": [{
        "rounded-tr": [borderRadius]
      }],
      /**
       * Border Radius Bottom Right
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-br": [{
        "rounded-br": [borderRadius]
      }],
      /**
       * Border Radius Bottom Left
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-bl": [{
        "rounded-bl": [borderRadius]
      }],
      /**
       * Border Width
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w": [{
        border: [borderWidth]
      }],
      /**
       * Border Width X
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-x": [{
        "border-x": [borderWidth]
      }],
      /**
       * Border Width Y
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-y": [{
        "border-y": [borderWidth]
      }],
      /**
       * Border Width Start
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-s": [{
        "border-s": [borderWidth]
      }],
      /**
       * Border Width End
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-e": [{
        "border-e": [borderWidth]
      }],
      /**
       * Border Width Top
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-t": [{
        "border-t": [borderWidth]
      }],
      /**
       * Border Width Right
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-r": [{
        "border-r": [borderWidth]
      }],
      /**
       * Border Width Bottom
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-b": [{
        "border-b": [borderWidth]
      }],
      /**
       * Border Width Left
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-l": [{
        "border-l": [borderWidth]
      }],
      /**
       * Border Opacity
       * @see https://tailwindcss.com/docs/border-opacity
       */
      "border-opacity": [{
        "border-opacity": [opacity]
      }],
      /**
       * Border Style
       * @see https://tailwindcss.com/docs/border-style
       */
      "border-style": [{
        border: [...getLineStyles(), "hidden"]
      }],
      /**
       * Divide Width X
       * @see https://tailwindcss.com/docs/divide-width
       */
      "divide-x": [{
        "divide-x": [borderWidth]
      }],
      /**
       * Divide Width X Reverse
       * @see https://tailwindcss.com/docs/divide-width
       */
      "divide-x-reverse": ["divide-x-reverse"],
      /**
       * Divide Width Y
       * @see https://tailwindcss.com/docs/divide-width
       */
      "divide-y": [{
        "divide-y": [borderWidth]
      }],
      /**
       * Divide Width Y Reverse
       * @see https://tailwindcss.com/docs/divide-width
       */
      "divide-y-reverse": ["divide-y-reverse"],
      /**
       * Divide Opacity
       * @see https://tailwindcss.com/docs/divide-opacity
       */
      "divide-opacity": [{
        "divide-opacity": [opacity]
      }],
      /**
       * Divide Style
       * @see https://tailwindcss.com/docs/divide-style
       */
      "divide-style": [{
        divide: getLineStyles()
      }],
      /**
       * Border Color
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color": [{
        border: [borderColor]
      }],
      /**
       * Border Color X
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-x": [{
        "border-x": [borderColor]
      }],
      /**
       * Border Color Y
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-y": [{
        "border-y": [borderColor]
      }],
      /**
       * Border Color S
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-s": [{
        "border-s": [borderColor]
      }],
      /**
       * Border Color E
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-e": [{
        "border-e": [borderColor]
      }],
      /**
       * Border Color Top
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-t": [{
        "border-t": [borderColor]
      }],
      /**
       * Border Color Right
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-r": [{
        "border-r": [borderColor]
      }],
      /**
       * Border Color Bottom
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-b": [{
        "border-b": [borderColor]
      }],
      /**
       * Border Color Left
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-l": [{
        "border-l": [borderColor]
      }],
      /**
       * Divide Color
       * @see https://tailwindcss.com/docs/divide-color
       */
      "divide-color": [{
        divide: [borderColor]
      }],
      /**
       * Outline Style
       * @see https://tailwindcss.com/docs/outline-style
       */
      "outline-style": [{
        outline: ["", ...getLineStyles()]
      }],
      /**
       * Outline Offset
       * @see https://tailwindcss.com/docs/outline-offset
       */
      "outline-offset": [{
        "outline-offset": [isLength, isArbitraryValue]
      }],
      /**
       * Outline Width
       * @see https://tailwindcss.com/docs/outline-width
       */
      "outline-w": [{
        outline: [isLength, isArbitraryLength]
      }],
      /**
       * Outline Color
       * @see https://tailwindcss.com/docs/outline-color
       */
      "outline-color": [{
        outline: [colors]
      }],
      /**
       * Ring Width
       * @see https://tailwindcss.com/docs/ring-width
       */
      "ring-w": [{
        ring: getLengthWithEmptyAndArbitrary()
      }],
      /**
       * Ring Width Inset
       * @see https://tailwindcss.com/docs/ring-width
       */
      "ring-w-inset": ["ring-inset"],
      /**
       * Ring Color
       * @see https://tailwindcss.com/docs/ring-color
       */
      "ring-color": [{
        ring: [colors]
      }],
      /**
       * Ring Opacity
       * @see https://tailwindcss.com/docs/ring-opacity
       */
      "ring-opacity": [{
        "ring-opacity": [opacity]
      }],
      /**
       * Ring Offset Width
       * @see https://tailwindcss.com/docs/ring-offset-width
       */
      "ring-offset-w": [{
        "ring-offset": [isLength, isArbitraryLength]
      }],
      /**
       * Ring Offset Color
       * @see https://tailwindcss.com/docs/ring-offset-color
       */
      "ring-offset-color": [{
        "ring-offset": [colors]
      }],
      // Effects
      /**
       * Box Shadow
       * @see https://tailwindcss.com/docs/box-shadow
       */
      shadow: [{
        shadow: ["", "inner", "none", isTshirtSize, isArbitraryShadow]
      }],
      /**
       * Box Shadow Color
       * @see https://tailwindcss.com/docs/box-shadow-color
       */
      "shadow-color": [{
        shadow: [isAny]
      }],
      /**
       * Opacity
       * @see https://tailwindcss.com/docs/opacity
       */
      opacity: [{
        opacity: [opacity]
      }],
      /**
       * Mix Blend Mode
       * @see https://tailwindcss.com/docs/mix-blend-mode
       */
      "mix-blend": [{
        "mix-blend": [...getBlendModes(), "plus-lighter", "plus-darker"]
      }],
      /**
       * Background Blend Mode
       * @see https://tailwindcss.com/docs/background-blend-mode
       */
      "bg-blend": [{
        "bg-blend": getBlendModes()
      }],
      // Filters
      /**
       * Filter
       * @deprecated since Tailwind CSS v3.0.0
       * @see https://tailwindcss.com/docs/filter
       */
      filter: [{
        filter: ["", "none"]
      }],
      /**
       * Blur
       * @see https://tailwindcss.com/docs/blur
       */
      blur: [{
        blur: [blur]
      }],
      /**
       * Brightness
       * @see https://tailwindcss.com/docs/brightness
       */
      brightness: [{
        brightness: [brightness]
      }],
      /**
       * Contrast
       * @see https://tailwindcss.com/docs/contrast
       */
      contrast: [{
        contrast: [contrast]
      }],
      /**
       * Drop Shadow
       * @see https://tailwindcss.com/docs/drop-shadow
       */
      "drop-shadow": [{
        "drop-shadow": ["", "none", isTshirtSize, isArbitraryValue]
      }],
      /**
       * Grayscale
       * @see https://tailwindcss.com/docs/grayscale
       */
      grayscale: [{
        grayscale: [grayscale]
      }],
      /**
       * Hue Rotate
       * @see https://tailwindcss.com/docs/hue-rotate
       */
      "hue-rotate": [{
        "hue-rotate": [hueRotate]
      }],
      /**
       * Invert
       * @see https://tailwindcss.com/docs/invert
       */
      invert: [{
        invert: [invert]
      }],
      /**
       * Saturate
       * @see https://tailwindcss.com/docs/saturate
       */
      saturate: [{
        saturate: [saturate]
      }],
      /**
       * Sepia
       * @see https://tailwindcss.com/docs/sepia
       */
      sepia: [{
        sepia: [sepia]
      }],
      /**
       * Backdrop Filter
       * @deprecated since Tailwind CSS v3.0.0
       * @see https://tailwindcss.com/docs/backdrop-filter
       */
      "backdrop-filter": [{
        "backdrop-filter": ["", "none"]
      }],
      /**
       * Backdrop Blur
       * @see https://tailwindcss.com/docs/backdrop-blur
       */
      "backdrop-blur": [{
        "backdrop-blur": [blur]
      }],
      /**
       * Backdrop Brightness
       * @see https://tailwindcss.com/docs/backdrop-brightness
       */
      "backdrop-brightness": [{
        "backdrop-brightness": [brightness]
      }],
      /**
       * Backdrop Contrast
       * @see https://tailwindcss.com/docs/backdrop-contrast
       */
      "backdrop-contrast": [{
        "backdrop-contrast": [contrast]
      }],
      /**
       * Backdrop Grayscale
       * @see https://tailwindcss.com/docs/backdrop-grayscale
       */
      "backdrop-grayscale": [{
        "backdrop-grayscale": [grayscale]
      }],
      /**
       * Backdrop Hue Rotate
       * @see https://tailwindcss.com/docs/backdrop-hue-rotate
       */
      "backdrop-hue-rotate": [{
        "backdrop-hue-rotate": [hueRotate]
      }],
      /**
       * Backdrop Invert
       * @see https://tailwindcss.com/docs/backdrop-invert
       */
      "backdrop-invert": [{
        "backdrop-invert": [invert]
      }],
      /**
       * Backdrop Opacity
       * @see https://tailwindcss.com/docs/backdrop-opacity
       */
      "backdrop-opacity": [{
        "backdrop-opacity": [opacity]
      }],
      /**
       * Backdrop Saturate
       * @see https://tailwindcss.com/docs/backdrop-saturate
       */
      "backdrop-saturate": [{
        "backdrop-saturate": [saturate]
      }],
      /**
       * Backdrop Sepia
       * @see https://tailwindcss.com/docs/backdrop-sepia
       */
      "backdrop-sepia": [{
        "backdrop-sepia": [sepia]
      }],
      // Tables
      /**
       * Border Collapse
       * @see https://tailwindcss.com/docs/border-collapse
       */
      "border-collapse": [{
        border: ["collapse", "separate"]
      }],
      /**
       * Border Spacing
       * @see https://tailwindcss.com/docs/border-spacing
       */
      "border-spacing": [{
        "border-spacing": [borderSpacing]
      }],
      /**
       * Border Spacing X
       * @see https://tailwindcss.com/docs/border-spacing
       */
      "border-spacing-x": [{
        "border-spacing-x": [borderSpacing]
      }],
      /**
       * Border Spacing Y
       * @see https://tailwindcss.com/docs/border-spacing
       */
      "border-spacing-y": [{
        "border-spacing-y": [borderSpacing]
      }],
      /**
       * Table Layout
       * @see https://tailwindcss.com/docs/table-layout
       */
      "table-layout": [{
        table: ["auto", "fixed"]
      }],
      /**
       * Caption Side
       * @see https://tailwindcss.com/docs/caption-side
       */
      caption: [{
        caption: ["top", "bottom"]
      }],
      // Transitions and Animation
      /**
       * Tranisition Property
       * @see https://tailwindcss.com/docs/transition-property
       */
      transition: [{
        transition: ["none", "all", "", "colors", "opacity", "shadow", "transform", isArbitraryValue]
      }],
      /**
       * Transition Duration
       * @see https://tailwindcss.com/docs/transition-duration
       */
      duration: [{
        duration: getNumberAndArbitrary()
      }],
      /**
       * Transition Timing Function
       * @see https://tailwindcss.com/docs/transition-timing-function
       */
      ease: [{
        ease: ["linear", "in", "out", "in-out", isArbitraryValue]
      }],
      /**
       * Transition Delay
       * @see https://tailwindcss.com/docs/transition-delay
       */
      delay: [{
        delay: getNumberAndArbitrary()
      }],
      /**
       * Animation
       * @see https://tailwindcss.com/docs/animation
       */
      animate: [{
        animate: ["none", "spin", "ping", "pulse", "bounce", isArbitraryValue]
      }],
      // Transforms
      /**
       * Transform
       * @see https://tailwindcss.com/docs/transform
       */
      transform: [{
        transform: ["", "gpu", "none"]
      }],
      /**
       * Scale
       * @see https://tailwindcss.com/docs/scale
       */
      scale: [{
        scale: [scale]
      }],
      /**
       * Scale X
       * @see https://tailwindcss.com/docs/scale
       */
      "scale-x": [{
        "scale-x": [scale]
      }],
      /**
       * Scale Y
       * @see https://tailwindcss.com/docs/scale
       */
      "scale-y": [{
        "scale-y": [scale]
      }],
      /**
       * Rotate
       * @see https://tailwindcss.com/docs/rotate
       */
      rotate: [{
        rotate: [isInteger, isArbitraryValue]
      }],
      /**
       * Translate X
       * @see https://tailwindcss.com/docs/translate
       */
      "translate-x": [{
        "translate-x": [translate]
      }],
      /**
       * Translate Y
       * @see https://tailwindcss.com/docs/translate
       */
      "translate-y": [{
        "translate-y": [translate]
      }],
      /**
       * Skew X
       * @see https://tailwindcss.com/docs/skew
       */
      "skew-x": [{
        "skew-x": [skew]
      }],
      /**
       * Skew Y
       * @see https://tailwindcss.com/docs/skew
       */
      "skew-y": [{
        "skew-y": [skew]
      }],
      /**
       * Transform Origin
       * @see https://tailwindcss.com/docs/transform-origin
       */
      "transform-origin": [{
        origin: ["center", "top", "top-right", "right", "bottom-right", "bottom", "bottom-left", "left", "top-left", isArbitraryValue]
      }],
      // Interactivity
      /**
       * Accent Color
       * @see https://tailwindcss.com/docs/accent-color
       */
      accent: [{
        accent: ["auto", colors]
      }],
      /**
       * Appearance
       * @see https://tailwindcss.com/docs/appearance
       */
      appearance: [{
        appearance: ["none", "auto"]
      }],
      /**
       * Cursor
       * @see https://tailwindcss.com/docs/cursor
       */
      cursor: [{
        cursor: ["auto", "default", "pointer", "wait", "text", "move", "help", "not-allowed", "none", "context-menu", "progress", "cell", "crosshair", "vertical-text", "alias", "copy", "no-drop", "grab", "grabbing", "all-scroll", "col-resize", "row-resize", "n-resize", "e-resize", "s-resize", "w-resize", "ne-resize", "nw-resize", "se-resize", "sw-resize", "ew-resize", "ns-resize", "nesw-resize", "nwse-resize", "zoom-in", "zoom-out", isArbitraryValue]
      }],
      /**
       * Caret Color
       * @see https://tailwindcss.com/docs/just-in-time-mode#caret-color-utilities
       */
      "caret-color": [{
        caret: [colors]
      }],
      /**
       * Pointer Events
       * @see https://tailwindcss.com/docs/pointer-events
       */
      "pointer-events": [{
        "pointer-events": ["none", "auto"]
      }],
      /**
       * Resize
       * @see https://tailwindcss.com/docs/resize
       */
      resize: [{
        resize: ["none", "y", "x", ""]
      }],
      /**
       * Scroll Behavior
       * @see https://tailwindcss.com/docs/scroll-behavior
       */
      "scroll-behavior": [{
        scroll: ["auto", "smooth"]
      }],
      /**
       * Scroll Margin
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-m": [{
        "scroll-m": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Margin X
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-mx": [{
        "scroll-mx": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Margin Y
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-my": [{
        "scroll-my": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Margin Start
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-ms": [{
        "scroll-ms": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Margin End
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-me": [{
        "scroll-me": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Margin Top
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-mt": [{
        "scroll-mt": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Margin Right
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-mr": [{
        "scroll-mr": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Margin Bottom
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-mb": [{
        "scroll-mb": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Margin Left
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-ml": [{
        "scroll-ml": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Padding
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-p": [{
        "scroll-p": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Padding X
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-px": [{
        "scroll-px": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Padding Y
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-py": [{
        "scroll-py": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Padding Start
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-ps": [{
        "scroll-ps": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Padding End
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-pe": [{
        "scroll-pe": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Padding Top
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-pt": [{
        "scroll-pt": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Padding Right
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-pr": [{
        "scroll-pr": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Padding Bottom
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-pb": [{
        "scroll-pb": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Padding Left
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-pl": [{
        "scroll-pl": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Snap Align
       * @see https://tailwindcss.com/docs/scroll-snap-align
       */
      "snap-align": [{
        snap: ["start", "end", "center", "align-none"]
      }],
      /**
       * Scroll Snap Stop
       * @see https://tailwindcss.com/docs/scroll-snap-stop
       */
      "snap-stop": [{
        snap: ["normal", "always"]
      }],
      /**
       * Scroll Snap Type
       * @see https://tailwindcss.com/docs/scroll-snap-type
       */
      "snap-type": [{
        snap: ["none", "x", "y", "both"]
      }],
      /**
       * Scroll Snap Type Strictness
       * @see https://tailwindcss.com/docs/scroll-snap-type
       */
      "snap-strictness": [{
        snap: ["mandatory", "proximity"]
      }],
      /**
       * Touch Action
       * @see https://tailwindcss.com/docs/touch-action
       */
      touch: [{
        touch: ["auto", "none", "manipulation"]
      }],
      /**
       * Touch Action X
       * @see https://tailwindcss.com/docs/touch-action
       */
      "touch-x": [{
        "touch-pan": ["x", "left", "right"]
      }],
      /**
       * Touch Action Y
       * @see https://tailwindcss.com/docs/touch-action
       */
      "touch-y": [{
        "touch-pan": ["y", "up", "down"]
      }],
      /**
       * Touch Action Pinch Zoom
       * @see https://tailwindcss.com/docs/touch-action
       */
      "touch-pz": ["touch-pinch-zoom"],
      /**
       * User Select
       * @see https://tailwindcss.com/docs/user-select
       */
      select: [{
        select: ["none", "text", "all", "auto"]
      }],
      /**
       * Will Change
       * @see https://tailwindcss.com/docs/will-change
       */
      "will-change": [{
        "will-change": ["auto", "scroll", "contents", "transform", isArbitraryValue]
      }],
      // SVG
      /**
       * Fill
       * @see https://tailwindcss.com/docs/fill
       */
      fill: [{
        fill: [colors, "none"]
      }],
      /**
       * Stroke Width
       * @see https://tailwindcss.com/docs/stroke-width
       */
      "stroke-w": [{
        stroke: [isLength, isArbitraryLength, isArbitraryNumber]
      }],
      /**
       * Stroke
       * @see https://tailwindcss.com/docs/stroke
       */
      stroke: [{
        stroke: [colors, "none"]
      }],
      // Accessibility
      /**
       * Screen Readers
       * @see https://tailwindcss.com/docs/screen-readers
       */
      sr: ["sr-only", "not-sr-only"],
      /**
       * Forced Color Adjust
       * @see https://tailwindcss.com/docs/forced-color-adjust
       */
      "forced-color-adjust": [{
        "forced-color-adjust": ["auto", "none"]
      }]
    },
    conflictingClassGroups: {
      overflow: ["overflow-x", "overflow-y"],
      overscroll: ["overscroll-x", "overscroll-y"],
      inset: ["inset-x", "inset-y", "start", "end", "top", "right", "bottom", "left"],
      "inset-x": ["right", "left"],
      "inset-y": ["top", "bottom"],
      flex: ["basis", "grow", "shrink"],
      gap: ["gap-x", "gap-y"],
      p: ["px", "py", "ps", "pe", "pt", "pr", "pb", "pl"],
      px: ["pr", "pl"],
      py: ["pt", "pb"],
      m: ["mx", "my", "ms", "me", "mt", "mr", "mb", "ml"],
      mx: ["mr", "ml"],
      my: ["mt", "mb"],
      size: ["w", "h"],
      "font-size": ["leading"],
      "fvn-normal": ["fvn-ordinal", "fvn-slashed-zero", "fvn-figure", "fvn-spacing", "fvn-fraction"],
      "fvn-ordinal": ["fvn-normal"],
      "fvn-slashed-zero": ["fvn-normal"],
      "fvn-figure": ["fvn-normal"],
      "fvn-spacing": ["fvn-normal"],
      "fvn-fraction": ["fvn-normal"],
      "line-clamp": ["display", "overflow"],
      rounded: ["rounded-s", "rounded-e", "rounded-t", "rounded-r", "rounded-b", "rounded-l", "rounded-ss", "rounded-se", "rounded-ee", "rounded-es", "rounded-tl", "rounded-tr", "rounded-br", "rounded-bl"],
      "rounded-s": ["rounded-ss", "rounded-es"],
      "rounded-e": ["rounded-se", "rounded-ee"],
      "rounded-t": ["rounded-tl", "rounded-tr"],
      "rounded-r": ["rounded-tr", "rounded-br"],
      "rounded-b": ["rounded-br", "rounded-bl"],
      "rounded-l": ["rounded-tl", "rounded-bl"],
      "border-spacing": ["border-spacing-x", "border-spacing-y"],
      "border-w": ["border-w-s", "border-w-e", "border-w-t", "border-w-r", "border-w-b", "border-w-l"],
      "border-w-x": ["border-w-r", "border-w-l"],
      "border-w-y": ["border-w-t", "border-w-b"],
      "border-color": ["border-color-s", "border-color-e", "border-color-t", "border-color-r", "border-color-b", "border-color-l"],
      "border-color-x": ["border-color-r", "border-color-l"],
      "border-color-y": ["border-color-t", "border-color-b"],
      "scroll-m": ["scroll-mx", "scroll-my", "scroll-ms", "scroll-me", "scroll-mt", "scroll-mr", "scroll-mb", "scroll-ml"],
      "scroll-mx": ["scroll-mr", "scroll-ml"],
      "scroll-my": ["scroll-mt", "scroll-mb"],
      "scroll-p": ["scroll-px", "scroll-py", "scroll-ps", "scroll-pe", "scroll-pt", "scroll-pr", "scroll-pb", "scroll-pl"],
      "scroll-px": ["scroll-pr", "scroll-pl"],
      "scroll-py": ["scroll-pt", "scroll-pb"],
      touch: ["touch-x", "touch-y", "touch-pz"],
      "touch-x": ["touch"],
      "touch-y": ["touch"],
      "touch-pz": ["touch"]
    },
    conflictingClassGroupModifiers: {
      "font-size": ["leading"]
    }
  };
};
var twMerge = /* @__PURE__ */ createTailwindMerge(getDefaultConfig);

// src/lib/utils.ts
function cn(...inputs) {
  return twMerge(clsx(inputs));
}

// src/core/viewportDesktopSite.ts
var MOBILE_DESKTOP_SITE_KEY = "copanel_mobile_desktop_site";
function isMobileDesktopSiteEnabled() {
  try {
    return localStorage.getItem(MOBILE_DESKTOP_SITE_KEY) === "1";
  } catch {
    return false;
  }
}
function isLayoutViewportWide(innerWidth = window.innerWidth) {
  return isMobileDesktopSiteEnabled() || innerWidth >= 1024;
}

// src/core/shell/WindowViewportContext.tsx
import { createContext as createContext2, useContext as useContext2, useRef } from "react";
import { jsx as jsx2 } from "react/jsx-runtime";
var WindowViewportContext = createContext2(null);
function useWindowViewport() {
  return useContext2(WindowViewportContext);
}
function useIsWindowedModule() {
  return useWindowViewport()?.isWindowed === true;
}

// src/core/shell/ModuleViewport.tsx
import { jsx as jsx3 } from "react/jsx-runtime";
function ModuleViewport({ children, className, constrained = false }) {
  const { theme } = useAppShellContext();
  const isWindowed = useIsWindowedModule();
  const isDark = theme === "dark";
  const isClassicMobile = !isWindowed && !isLayoutViewportWide();
  return /* @__PURE__ */ jsx3(
    "div",
    {
      className: cn(
        "flex flex-col transition-colors duration-200",
        isWindowed ? "h-full min-h-0" : isClassicMobile ? "min-h-0" : "min-h-screen",
        isDark ? "bg-slate-950 text-slate-100" : "bg-slate-50 text-slate-900",
        !isWindowed && constrained && "mx-auto max-w-7xl",
        className
      ),
      children
    }
  );
}

// src/core/shell/ModuleSidebarLayout.tsx
import { useEffect, useState } from "react";
import * as Icons from "lucide-react";
import { jsx as jsx4, jsxs } from "react/jsx-runtime";
function ModuleSidebarLayout({
  isDark,
  sidebar,
  children,
  mobileTitle,
  className
}) {
  const isWindowed = useIsWindowedModule();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [viewportWide, setViewportWide] = useState(() => isLayoutViewportWide());
  useEffect(() => {
    const onResize = () => setViewportWide(isLayoutViewportWide());
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  }, []);
  const useDrawer = !isWindowed && !viewportWide;
  useEffect(() => {
    if (viewportWide) setSidebarOpen(false);
  }, [viewportWide]);
  const closeSidebar = () => setSidebarOpen(false);
  if (!useDrawer) {
    return /* @__PURE__ */ jsxs("div", { className: cn("flex h-full min-h-0 flex-1 overflow-hidden", className), children: [
      sidebar,
      /* @__PURE__ */ jsx4("div", { className: "flex min-h-0 min-w-0 flex-1 flex-col overflow-hidden", children })
    ] });
  }
  return /* @__PURE__ */ jsxs("div", { className: cn("relative flex h-full min-h-0 flex-1 flex-col overflow-hidden", className), children: [
    /* @__PURE__ */ jsxs(
      "div",
      {
        className: cn(
          "flex shrink-0 items-center gap-2 border-b px-3 py-2.5",
          isDark ? "border-slate-800 bg-slate-950/90" : "border-slate-200 bg-white"
        ),
        children: [
          /* @__PURE__ */ jsx4(
            "button",
            {
              type: "button",
              onClick: () => setSidebarOpen(true),
              className: cn(
                "inline-flex items-center justify-center rounded-lg p-2",
                isDark ? "text-slate-200 hover:bg-slate-800" : "text-slate-700 hover:bg-slate-100"
              ),
              "aria-label": "Open module menu",
              children: /* @__PURE__ */ jsx4(Icons.PanelLeft, { className: "h-5 w-5" })
            }
          ),
          mobileTitle ? /* @__PURE__ */ jsx4("span", { className: cn("truncate text-sm font-semibold", isDark ? "text-slate-100" : "text-slate-900"), children: mobileTitle }) : null
        ]
      }
    ),
    sidebarOpen ? /* @__PURE__ */ jsx4(
      "button",
      {
        type: "button",
        className: "fixed inset-0 z-[60] bg-black/45",
        "aria-label": "Close module menu",
        onClick: closeSidebar
      }
    ) : null,
    /* @__PURE__ */ jsx4(
      "div",
      {
        className: cn(
          "fixed inset-y-0 left-0 z-[61] flex max-w-[min(85vw,280px)] transform shadow-xl transition-transform duration-200 ease-out",
          sidebarOpen ? "translate-x-0" : "-translate-x-full pointer-events-none"
        ),
        onClick: closeSidebar,
        children: sidebar
      }
    ),
    /* @__PURE__ */ jsx4("div", { className: "flex min-h-0 min-w-0 flex-1 flex-col overflow-hidden", children })
  ] });
}

// src/core/shell/WindowModal.tsx
import { createPortal } from "react-dom";
import * as Icons2 from "lucide-react";
import { jsx as jsx5, jsxs as jsxs2 } from "react/jsx-runtime";
var MAX_W = {
  sm: "max-w-sm",
  md: "max-w-md",
  lg: "max-w-lg",
  xl: "max-w-xl",
  "2xl": "max-w-2xl",
  "4xl": "max-w-4xl",
  "5xl": "max-w-5xl"
};
function WindowModal({
  open,
  onClose,
  children,
  title,
  className,
  maxWidth = "lg",
  closeOnBackdropClick = true
}) {
  const { theme } = useAppShellContext();
  const isDark = theme === "dark";
  const viewport = useWindowViewport();
  if (!open) return null;
  const overlay = /* @__PURE__ */ jsx5(
    "div",
    {
      className: cn(
        "z-[80] flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm",
        viewport?.isWindowed ? "absolute inset-0" : "fixed inset-0"
      ),
      onClick: closeOnBackdropClick ? onClose : void 0,
      children: /* @__PURE__ */ jsxs2(
        "div",
        {
          className: cn(
            "flex w-full flex-col overflow-hidden rounded-2xl border shadow-2xl",
            MAX_W[maxWidth],
            isDark ? "border-slate-700 bg-slate-900 text-slate-100" : "border-slate-200 bg-white text-slate-900",
            className
          ),
          onClick: (e) => e.stopPropagation(),
          children: [
            title && /* @__PURE__ */ jsxs2(
              "div",
              {
                className: cn(
                  "flex items-center justify-between border-b px-4 py-3",
                  isDark ? "border-slate-800" : "border-slate-200"
                ),
                children: [
                  /* @__PURE__ */ jsx5("h3", { className: "text-sm font-bold", children: title }),
                  /* @__PURE__ */ jsx5("button", { type: "button", onClick: onClose, className: "rounded-lg p-1 hover:bg-slate-800/50", "aria-label": "Close", children: /* @__PURE__ */ jsx5(Icons2.X, { className: "h-4 w-4" }) })
                ]
              }
            ),
            children
          ]
        }
      )
    }
  );
  if (viewport?.isWindowed && viewport.viewportRef.current) {
    return createPortal(overlay, viewport.viewportRef.current);
  }
  return createPortal(overlay, document.body);
}

// src/modules/audio_station/index.tsx
import * as Icons3 from "lucide-react";

// src/core/platform/api.ts
var PlatformError = class extends Error {
  constructor(code, message, status, details) {
    super(message);
    __publicField(this, "code");
    __publicField(this, "status");
    __publicField(this, "details");
    this.code = code;
    this.status = status;
    this.details = details;
  }
};
async function api(path, opts = {}) {
  const token = typeof window !== "undefined" ? localStorage.getItem("copanel_token") : null;
  const headers = {
    "Content-Type": "application/json",
    ...opts.headers || {}
  };
  if (token) headers["Authorization"] = `Bearer ${token}`;
  const init = {
    method: opts.method || "GET",
    headers,
    signal: opts.signal
  };
  if (opts.body !== void 0) {
    init.body = typeof opts.body === "string" ? opts.body : JSON.stringify(opts.body);
  }
  const res = await fetch(path, init);
  let body = null;
  const text = await res.text();
  if (text) {
    try {
      body = JSON.parse(text);
    } catch {
      body = text;
    }
  }
  if (opts.raw) {
    return body;
  }
  if (!res.ok) {
    const err = body && typeof body === "object" && body.error ? body.error : { code: `HTTP_${res.status}`, message: typeof body === "string" ? body : body?.detail || res.statusText };
    throw new PlatformError(err.code || `HTTP_${res.status}`, err.message || "Request failed", res.status, err.details);
  }
  if (body && typeof body === "object" && "status" in body) {
    if (body.status === "success") {
      return body.data !== void 0 ? body.data : body;
    }
    if (body.status === "error" && body.error) {
      throw new PlatformError(body.error.code, body.error.message, res.status, body.error.details);
    }
  }
  return body;
}

// src/core/platform/events.ts
var PLATFORM_SSE_DEGRADED_EVENT = "copanel-platform-sse-degraded";
var MIN_RETRY_MS = 2e3;
var MAX_RETRY_MS = 6e4;
var POLL_FALLBACK_AFTER_FAILURES = 3;
var EventHub = class {
  constructor() {
    __publicField(this, "source", null);
    __publicField(this, "handlers", /* @__PURE__ */ new Map());
    __publicField(this, "retryDelay", MIN_RETRY_MS);
    __publicField(this, "retryTimer", null);
    __publicField(this, "failureCount", 0);
  }
  on(topic, handler) {
    let set = this.handlers.get(topic);
    if (!set) {
      set = /* @__PURE__ */ new Set();
      this.handlers.set(topic, set);
    }
    set.add(handler);
    this.ensureConnected();
    return () => {
      set.delete(handler);
      if (set.size === 0) {
        this.handlers.delete(topic);
      }
      this.teardownIfIdle();
    };
  }
  emit(topic, payload) {
    const set = this.handlers.get(topic);
    if (set) {
      set.forEach((h) => {
        try {
          h(payload);
        } catch (err) {
          console.error("event handler failed", topic, err);
        }
      });
    }
  }
  buildUrl() {
    const token = localStorage.getItem("copanel_token");
    if (!token) return null;
    const params = new URLSearchParams({
      topics: "jobs,notifications",
      access_token: token
    });
    return `/api/platform/events?${params.toString()}`;
  }
  ensureConnected() {
    if (this.source) return;
    if (typeof document !== "undefined" && document.hidden) return;
    const url = this.buildUrl();
    if (!url) return;
    try {
      this.source = new EventSource(url, { withCredentials: false });
    } catch {
      this.scheduleRetry();
      return;
    }
    this.source.addEventListener("open", () => {
      this.failureCount = 0;
      this.retryDelay = MIN_RETRY_MS;
    });
    this.source.addEventListener("jobs", (e) => {
      this.onStreamMessage();
      this.parseAndEmit("jobs", e.data);
    });
    this.source.addEventListener("notifications", (e) => {
      this.onStreamMessage();
      this.parseAndEmit("notifications", e.data);
    });
    this.source.addEventListener("message", () => {
      this.onStreamMessage();
    });
    this.source.onerror = () => {
      this.failureCount += 1;
      this.source?.close();
      this.source = null;
      if (this.failureCount >= POLL_FALLBACK_AFTER_FAILURES) {
        window.dispatchEvent(new CustomEvent(PLATFORM_SSE_DEGRADED_EVENT));
      }
      this.scheduleRetry();
    };
  }
  onStreamMessage() {
    this.failureCount = 0;
    this.retryDelay = MIN_RETRY_MS;
  }
  parseAndEmit(topic, raw) {
    try {
      const msg = JSON.parse(raw);
      this.emit(topic, msg.payload || msg);
    } catch {
    }
  }
  scheduleRetry() {
    if (this.retryTimer) return;
    if (this.handlers.size === 0) return;
    const delay = this.retryDelay;
    this.retryDelay = Math.min(Math.round(this.retryDelay * 1.8), MAX_RETRY_MS);
    this.retryTimer = setTimeout(() => {
      this.retryTimer = null;
      this.ensureConnected();
    }, delay);
  }
  teardownIfIdle() {
    if (this.handlers.size > 0) return;
    if (this.retryTimer) {
      clearTimeout(this.retryTimer);
      this.retryTimer = null;
    }
    if (this.source) {
      this.source.close();
      this.source = null;
    }
    this.failureCount = 0;
    this.retryDelay = MIN_RETRY_MS;
  }
  /** Drop the SSE connection and open a new one if handlers exist and a token is present. */
  reconnect() {
    if (this.source) {
      this.source.close();
      this.source = null;
    }
    if (this.retryTimer) {
      clearTimeout(this.retryTimer);
      this.retryTimer = null;
    }
    this.failureCount = 0;
    this.retryDelay = MIN_RETRY_MS;
    if (this.handlers.size > 0) {
      this.ensureConnected();
    }
  }
};
var events = new EventHub();
function reconnectPlatformEvents() {
  events.reconnect();
}
if (typeof document !== "undefined") {
  document.addEventListener("visibilitychange", () => {
    if (!document.hidden) {
      reconnectPlatformEvents();
    }
  });
}

// src/core/platform/store.ts
import { useEffect as useEffect2, useState as useState2 } from "react";
function createStore(initial) {
  let state = initial;
  const listeners = /* @__PURE__ */ new Set();
  return {
    getState: () => state,
    setState: (updater) => {
      const patch = typeof updater === "function" ? updater(state) : updater;
      if (!patch || Object.keys(patch).length === 0) return;
      let changed = false;
      for (const key of Object.keys(patch)) {
        if (state[key] !== patch[key]) {
          changed = true;
          break;
        }
      }
      if (!changed) return;
      state = { ...state, ...patch };
      listeners.forEach((l) => l());
    },
    subscribe: (listener) => {
      listeners.add(listener);
      return () => listeners.delete(listener);
    }
  };
}

// src/core/platform/jobsStore.ts
var store = createStore({ jobs: {}, order: [], lastFetch: 0 });
function getCurrentLang() {
  return localStorage.getItem("copanel_lang") === "vi" ? "vi" : "en";
}
function pickLocalizedFromValue(value, lang) {
  if (!value) return void 0;
  if (typeof value === "string") return value;
  if (typeof value === "object") return value[lang] || value.en || value.vi || value.default;
  return void 0;
}
function resolveLocalizedField(src, baseKey, lang) {
  if (!src || typeof src !== "object") return void 0;
  const direct = pickLocalizedFromValue(src[baseKey], lang);
  if (direct) return direct;
  const fromMap = pickLocalizedFromValue(src[`${baseKey}_i18n`], lang);
  if (fromMap) return fromMap;
  const fromLangSpecific = src[`${baseKey}_${lang}`];
  if (typeof fromLangSpecific === "string" && fromLangSpecific) return fromLangSpecific;
  const fallbackEn = src[`${baseKey}_en`];
  if (typeof fallbackEn === "string" && fallbackEn) return fallbackEn;
  const fallbackVi = src[`${baseKey}_vi`];
  if (typeof fallbackVi === "string" && fallbackVi) return fallbackVi;
  return void 0;
}
function localizeJob(raw) {
  const lang = getCurrentLang();
  const payload = raw?.payload && typeof raw.payload === "object" ? raw.payload : {};
  return {
    ...raw,
    title: resolveLocalizedField(raw, "title", lang) || resolveLocalizedField(payload, "title", lang) || raw?.title || "",
    message: resolveLocalizedField(raw, "message", lang) || resolveLocalizedField(payload, "message", lang) || raw?.message,
    error: resolveLocalizedField(raw, "error", lang) || resolveLocalizedField(payload, "error", lang) || raw?.error || null
  };
}
function upsert(job) {
  const localized = localizeJob(job);
  store.setState((s) => {
    const next = { ...s.jobs, [localized.id]: { ...s.jobs[localized.id], ...localized } };
    let order = s.order;
    if (!order.includes(localized.id)) {
      order = [localized.id, ...order].slice(0, 200);
    }
    return { jobs: next, order };
  });
}
events.on("jobs", (msg) => {
  if (msg?.job) {
    upsert(msg.job);
    return;
  }
  if (msg?.job_id && msg?.event === "update") {
    const existing = store.getState().jobs[msg.job_id];
    if (existing) {
      upsert({
        ...existing,
        progress: msg.progress ?? existing.progress,
        message: msg.message ?? existing.message,
        status: msg.status ?? existing.status
      });
    }
  }
});

// src/core/platform/notificationsStore.ts
var store2 = createStore({ inbox: [], unread: 0, toasts: [] });
var TOAST_TTL_MS = 6e3;
function getCurrentLang2() {
  return localStorage.getItem("copanel_lang") === "vi" ? "vi" : "en";
}
function pickLocalizedFromValue2(value, lang) {
  if (!value) return void 0;
  if (typeof value === "string") return value;
  if (typeof value === "object") {
    return value[lang] || value.en || value.vi || value.default;
  }
  return void 0;
}
function resolveLocalizedField2(src, baseKey, lang) {
  if (!src || typeof src !== "object") return void 0;
  const direct = pickLocalizedFromValue2(src[baseKey], lang);
  if (direct) return direct;
  const fromMap = pickLocalizedFromValue2(src[`${baseKey}_i18n`], lang);
  if (fromMap) return fromMap;
  const fromLangSpecific = src[`${baseKey}_${lang}`];
  if (typeof fromLangSpecific === "string" && fromLangSpecific) return fromLangSpecific;
  const fallbackEn = src[`${baseKey}_en`];
  if (typeof fallbackEn === "string" && fallbackEn) return fallbackEn;
  const fallbackVi = src[`${baseKey}_vi`];
  if (typeof fallbackVi === "string" && fallbackVi) return fallbackVi;
  return void 0;
}
function localizeNotification(raw) {
  const lang = getCurrentLang2();
  const payload = raw?.payload && typeof raw.payload === "object" ? raw.payload : {};
  const title = resolveLocalizedField2(raw, "title", lang) || resolveLocalizedField2(payload, "title", lang) || (raw?.title || "");
  const body = resolveLocalizedField2(raw, "body", lang) || resolveLocalizedField2(payload, "body", lang) || raw?.body || null;
  return {
    ...raw,
    title,
    body
  };
}
function pushToast(t) {
  store2.setState((s) => ({ toasts: [t, ...s.toasts].slice(0, 6) }));
  if (t.ephemeral !== false) {
    setTimeout(() => {
      store2.setState((s) => ({ toasts: s.toasts.filter((x) => x.id !== t.id) }));
    }, TOAST_TTL_MS);
  }
}
events.on("notifications", (msg) => {
  if (msg?.event === "new" && msg.notification) {
    const n = localizeNotification(msg.notification);
    pushToast({ ...n, ephemeral: true });
    store2.setState((s) => ({
      inbox: [n, ...s.inbox].slice(0, 200),
      unread: s.unread + 1
    }));
  }
});

// src/modules/audio_station/index.tsx
import { Fragment, jsx as jsx6, jsxs as jsxs3 } from "react/jsx-runtime";
function fmtBytes(n) {
  if (!n || n < 0) return "\u2014";
  const units = ["B", "KB", "MB", "GB"];
  let v = n;
  let i = 0;
  while (v >= 1024 && i < units.length - 1) {
    v /= 1024;
    i += 1;
  }
  return `${v.toFixed(i === 0 ? 0 : 1)} ${units[i]}`;
}
function fmtTime(sec) {
  if (!sec || !Number.isFinite(sec)) return "0:00";
  const m = Math.floor(sec / 60);
  const s = Math.floor(sec % 60);
  return `${m}:${s.toString().padStart(2, "0")}`;
}
function streamUrl(path) {
  const token = localStorage.getItem("copanel_token") || "";
  const params = new URLSearchParams({
    path,
    access_token: token
  });
  params.set("token", token);
  return `/api/audio_station/stream?${params.toString()}`;
}
function coverUrl(opts) {
  if (!opts.hash && !opts.id && !opts.path) return null;
  const token = localStorage.getItem("copanel_token") || "";
  const params = new URLSearchParams({ access_token: token, token });
  if (opts.hash) params.set("hash", opts.hash);
  else if (opts.id) params.set("id", opts.id);
  else if (opts.path) params.set("path", opts.path);
  return `/api/audio_station/cover?${params.toString()}`;
}
function broadcastActivity(payload) {
  if (typeof window === "undefined") return;
  const trackName = payload.currentTrack?.name?.trim();
  const playbackState = trackName ? payload.playing ? "playing" : "paused" : null;
  const title = trackName ? payload.playing ? `\u25B6 ${trackName}` : `\u23F8 ${trackName}` : "Audio Player";
  window.dispatchEvent(
    new CustomEvent("copanel:module-activity", {
      detail: {
        modulePath: "/audio-player",
        playing: payload.playing,
        playbackState,
        trackName,
        title
      }
    })
  );
}
function CoverThumb({
  track,
  album,
  className = "w-10 h-10"
}) {
  const src = coverUrl({ hash: album?.cover_hash || track?.cover_hash || void 0 }) || (track?.path ? coverUrl({ path: track.path }) : null) || (track?.id ? coverUrl({ id: track.id }) : null);
  if (!src) {
    return /* @__PURE__ */ jsx6("div", { className: `${className} rounded bg-teal-500/10 flex items-center justify-center shrink-0`, children: /* @__PURE__ */ jsx6(Icons3.Disc, { className: "w-5 h-5 text-teal-500/50" }) });
  }
  return /* @__PURE__ */ jsx6("img", { src, alt: "", className: `${className} rounded object-cover shrink-0 bg-slate-200` });
}
function AudioStation() {
  const { theme, language } = useAppShellContext();
  const isDark = theme === "dark";
  const t = useMemo(
    () => language === "vi" ? {
      title: "Audio Player",
      subtitle: "Th\u01B0 vi\u1EC7n nh\u1EA1c \u2014 duy\u1EC7t th\u01B0 m\u1EE5c & ph\xE1t nh\u1EA1c",
      search: "T\xECm nh\u1EA1c\u2026",
      settings: "C\xE0i \u0111\u1EB7t",
      home: "Trang ch\u1EE7",
      myMusic: "NH\u1EA0C C\u1EE6A T\xD4I",
      allMusic: "T\u1EA5t c\u1EA3 nh\u1EA1c",
      byFolder: "Theo th\u01B0 m\u1EE5c",
      byAlbum: "Theo album",
      byArtist: "Theo ngh\u1EC7 s\u0129",
      byGenre: "Theo th\u1EC3 lo\u1EA1i",
      comingSoon: "C\u1EA7n qu\xE9t th\u01B0 vi\u1EC7n \u2014 s\u1EAFp c\xF3",
      noFiles: "Kh\xF4ng c\xF3 file nh\u1EA1c trong th\u01B0 m\u1EE5c n\xE0y.",
      noFolders: "Ch\u01B0a c\xF3 th\u01B0 m\u1EE5c nh\u1EA1c.",
      colTitle: "Ti\xEAu \u0111\u1EC1",
      colAlbum: "Album",
      colArtist: "Ngh\u1EC7 s\u0129",
      colDuration: "Th\u1EDDi l\u01B0\u1EE3ng",
      libraryRoots: "Th\u01B0 m\u1EE5c nh\u1EA1c",
      addRoot: "Th\xEAm th\u01B0 m\u1EE5c",
      browse: "Duy\u1EC7t",
      scanNow: "Qu\xE9t th\u01B0 vi\u1EC7n",
      scanOnStartup: "T\u1EF1 qu\xE9t khi kh\u1EDFi \u0111\u1ED9ng",
      save: "L\u01B0u",
      cancel: "H\u1EE7y",
      selectFolder: "Ch\u1ECDn th\u01B0 m\u1EE5c",
      useThisFolder: "Ch\u1ECDn th\u01B0 m\u1EE5c n\xE0y",
      tracks: "b\xE0i",
      albums: "album",
      artists: "ngh\u1EC7 s\u0129",
      scanning: "\u0110ang qu\xE9t\u2026",
      scanDone: "Qu\xE9t xong",
      scanError: "L\u1ED7i qu\xE9t",
      play: "Ph\xE1t",
      pause: "T\u1EA1m d\u1EEBng",
      next: "Ti\u1EBFp",
      prev: "Tr\u01B0\u1EDBc",
      queue: "H\xE0ng \u0111\u1EE3i",
      emptyQueue: "H\xE0ng \u0111\u1EE3i tr\u1ED1ng",
      openFolder: "M\u1EDF th\u01B0 m\u1EE5c",
      statsHint: "Qu\xE9t th\u01B0 vi\u1EC7n \u0111\u1EC3 nh\xF3m theo album/ngh\u1EC7 s\u0129.",
      noLibrary: "Ch\u01B0a c\xF3 nh\u1EA1c trong th\u01B0 vi\u1EC7n. B\u1EA5m Qu\xE9t th\u01B0 vi\u1EC7n.",
      back: "Quay l\u1EA1i",
      songs: "b\xE0i h\xE1t",
      indexed: "\u0111\xE3 index",
      playlists: "PLAYLIST",
      recentlyAdded: "M\u1EDBi th\xEAm",
      random100: "Ng\u1EABu nhi\xEAn 100",
      newPlaylist: "T\u1EA1o playlist",
      playlistName: "T\xEAn playlist",
      deletePlaylist: "X\xF3a playlist",
      addToPlaylist: "Th\xEAm v\xE0o playlist"
    } : {
      title: "Audio Player",
      subtitle: "Music library \u2014 browse folders and play tracks",
      search: "Search music\u2026",
      settings: "Settings",
      home: "Home",
      myMusic: "MY MUSIC",
      allMusic: "All Music",
      byFolder: "By Folder",
      byAlbum: "By Album",
      byArtist: "By Artist",
      byGenre: "By Genre",
      comingSoon: "Requires library scan \u2014 coming in v0.2",
      noFiles: "No audio files in this folder.",
      noFolders: "No music folders yet.",
      colTitle: "Title",
      colAlbum: "Album",
      colArtist: "Artist",
      colDuration: "Duration",
      libraryRoots: "Music folders",
      addRoot: "Add folder",
      browse: "Browse",
      scanNow: "Scan library",
      scanOnStartup: "Scan on startup",
      save: "Save",
      cancel: "Cancel",
      selectFolder: "Select folder",
      useThisFolder: "Use this folder",
      tracks: "tracks",
      albums: "albums",
      artists: "artists",
      scanning: "Scanning\u2026",
      scanDone: "Scan complete",
      scanError: "Scan error",
      play: "Play",
      pause: "Pause",
      next: "Next",
      prev: "Previous",
      queue: "Queue",
      emptyQueue: "Queue is empty",
      openFolder: "Open folder",
      statsHint: "Scan library to group by album/artist.",
      noLibrary: "No music in library yet. Run Scan library.",
      back: "Back",
      songs: "songs",
      indexed: "indexed",
      playlists: "PLAYLIST",
      recentlyAdded: "Recently Added",
      random100: "Random 100",
      newPlaylist: "New playlist",
      playlistName: "Playlist name",
      deletePlaylist: "Delete playlist",
      addToPlaylist: "Add to playlist"
    },
    [language]
  );
  const panel = isDark ? "bg-slate-900 border-slate-700 text-slate-100" : "bg-white border-slate-200 text-slate-900";
  const muted = isDark ? "text-slate-400" : "text-slate-500";
  const hoverRow = isDark ? "hover:bg-slate-800" : "hover:bg-slate-50";
  const activeNav = isDark ? "bg-teal-900/40 text-teal-300" : "bg-teal-50 text-teal-700";
  const [view, setView] = useState3("folder");
  const [browse, setBrowse] = useState3(null);
  const [stats, setStats] = useState3(null);
  const [loading, setLoading] = useState3(true);
  const [error, setError] = useState3(null);
  const [search, setSearch] = useState3("");
  const [settingsOpen, setSettingsOpen] = useState3(false);
  const [settings, setSettings] = useState3(null);
  const [settingsDraft, setSettingsDraft] = useState3(null);
  const [folderPicker, setFolderPicker] = useState3(null);
  const [pickerMode, setPickerMode] = useState3(null);
  const [queue, setQueue] = useState3([]);
  const [queueIndex, setQueueIndex] = useState3(0);
  const [playing, setPlaying] = useState3(false);
  const [currentTime, setCurrentTime] = useState3(0);
  const [duration, setDuration] = useState3(0);
  const [showQueue, setShowQueue] = useState3(false);
  const audioRef = useRef2(null);
  const [libTracks, setLibTracks] = useState3([]);
  const [albums, setAlbums] = useState3([]);
  const [artists, setArtists] = useState3([]);
  const [genres, setGenres] = useState3([]);
  const [topGenres, setTopGenres] = useState3([]);
  const [selectedAlbum, setSelectedAlbum] = useState3(null);
  const [selectedArtist, setSelectedArtist] = useState3(null);
  const [selectedGenre, setSelectedGenre] = useState3(null);
  const [selectedPlaylist, setSelectedPlaylist] = useState3(null);
  const [playlists, setPlaylists] = useState3([]);
  const [recentTracks, setRecentTracks] = useState3([]);
  const [newPlaylistOpen, setNewPlaylistOpen] = useState3(false);
  const [newPlaylistName, setNewPlaylistName] = useState3("");
  const [libLoading, setLibLoading] = useState3(false);
  const currentTrack = queue[queueIndex] || null;
  const loadBrowse = useCallback(async (path = "") => {
    try {
      const data = await api(`/api/audio_station/browse?path=${encodeURIComponent(path)}`);
      setBrowse(data);
      setError(null);
    } catch (e) {
      setError(e.message);
    }
  }, []);
  const loadStats = useCallback(async () => {
    try {
      const data = await api("/api/audio_station/library/stats");
      setStats(data);
    } catch {
    }
  }, []);
  const loadLibraryView = useCallback(async () => {
    if (view === "folder" || view === "home") return;
    setLibLoading(true);
    setError(null);
    const q = search.trim();
    try {
      if (view === "all") {
        const data = await api(
          `/api/audio_station/library/tracks?q=${encodeURIComponent(q)}&limit=1000`
        );
        setLibTracks(data.items || []);
      } else if (view === "recent") {
        const data = await api("/api/audio_station/library/recent?limit=100");
        setLibTracks(data.items || []);
      } else if (view === "random") {
        const data = await api("/api/audio_station/library/random?limit=100");
        setLibTracks(data.items || []);
      } else if (view === "playlist" && selectedPlaylist) {
        const data = await api(
          `/api/audio_station/playlists/${encodeURIComponent(selectedPlaylist.id)}/tracks`
        );
        setLibTracks(data.items || []);
      } else if (view === "album") {
        if (selectedAlbum) {
          const data = await api(
            `/api/audio_station/library/albums/${encodeURIComponent(selectedAlbum.key)}/tracks`
          );
          setLibTracks(data.items || []);
        } else {
          const data = await api(
            `/api/audio_station/library/albums?q=${encodeURIComponent(q)}`
          );
          setAlbums(data.items || []);
        }
      } else if (view === "artist") {
        if (selectedArtist) {
          const data = await api(
            `/api/audio_station/library/artists/${encodeURIComponent(selectedArtist)}/tracks`
          );
          setLibTracks(data.items || []);
        } else {
          const data = await api(
            `/api/audio_station/library/artists?q=${encodeURIComponent(q)}`
          );
          setArtists(data.items || []);
        }
      } else if (view === "genre") {
        if (selectedGenre) {
          const data = await api(
            `/api/audio_station/library/genres/${encodeURIComponent(selectedGenre)}/tracks`
          );
          setLibTracks(data.items || []);
        } else {
          const data = await api(
            `/api/audio_station/library/genres?q=${encodeURIComponent(q)}`
          );
          setGenres(data.items || []);
        }
      }
    } catch (e) {
      setError(e.message);
    } finally {
      setLibLoading(false);
    }
  }, [view, search, selectedAlbum, selectedArtist, selectedGenre, selectedPlaylist]);
  const loadPlaylists = useCallback(async () => {
    try {
      const data = await api("/api/audio_station/playlists");
      setPlaylists(data.items || []);
    } catch {
    }
  }, []);
  const loadRecentPreview = useCallback(async () => {
    try {
      const data = await api("/api/audio_station/library/recent?limit=8");
      setRecentTracks(data.items || []);
    } catch {
    }
  }, []);
  const loadTopGenres = useCallback(async () => {
    try {
      const data = await api("/api/audio_station/library/top-genres");
      setTopGenres(data || []);
    } catch {
    }
  }, []);
  useEffect3(() => {
    (async () => {
      setLoading(true);
      await Promise.all([loadBrowse(""), loadStats(), loadTopGenres(), loadPlaylists(), loadRecentPreview()]);
      setLoading(false);
    })();
  }, [loadBrowse, loadStats, loadTopGenres, loadPlaylists, loadRecentPreview]);
  useEffect3(() => {
    loadLibraryView();
  }, [loadLibraryView]);
  useEffect3(() => {
    if (stats?.scan.status !== "running") {
      if (view !== "folder" && view !== "home") loadLibraryView();
      loadTopGenres();
      loadPlaylists();
      loadRecentPreview();
      return;
    }
    const id = setInterval(() => {
      loadStats();
    }, 2e3);
    return () => clearInterval(id);
  }, [stats?.scan.status, view, loadStats, loadLibraryView, loadTopGenres, loadPlaylists, loadRecentPreview]);
  useEffect3(() => {
    const el = audioRef.current;
    if (!el || !currentTrack) return;
    el.src = streamUrl(currentTrack.path);
    el.load();
    if (playing) el.play().catch(() => setPlaying(false));
  }, [currentTrack?.path]);
  useEffect3(() => {
    const el = audioRef.current;
    if (!el) return;
    if (playing) el.play().catch(() => setPlaying(false));
    else el.pause();
  }, [playing]);
  useEffect3(() => {
    broadcastActivity({ playing, currentTrack });
    return () => {
      broadcastActivity({ playing: false, currentTrack: null });
    };
  }, [playing, currentTrack?.path]);
  function playTracks(tracks, startIndex = 0) {
    if (!tracks.length) return;
    setQueue(tracks);
    setQueueIndex(startIndex);
    setPlaying(true);
  }
  function playLibraryTracks(tracks, startIndex = 0) {
    playTracks(
      tracks.map((tr) => ({ name: tr.title || tr.path, path: tr.path })),
      startIndex
    );
  }
  function playLibraryTrack(track, list) {
    const idx = list.findIndex((x) => x.path === track.path);
    playLibraryTracks(list, idx >= 0 ? idx : 0);
  }
  function playFile(file) {
    if (!browse) return;
    const tracks = browse.files.map((f) => ({ name: f.name, path: f.path }));
    const idx = tracks.findIndex((x) => x.path === file.path);
    playTracks(tracks, idx >= 0 ? idx : 0);
  }
  function playAllInFolder() {
    if (!browse?.files.length) return;
    playTracks(browse.files.map((f) => ({ name: f.name, path: f.path })));
  }
  function onEnded() {
    if (queueIndex < queue.length - 1) {
      setQueueIndex((i) => i + 1);
      setPlaying(true);
    } else {
      setPlaying(false);
    }
  }
  function skipNext() {
    if (queueIndex < queue.length - 1) {
      setQueueIndex((i) => i + 1);
      setPlaying(true);
    }
  }
  function skipPrev() {
    const el = audioRef.current;
    if (el && el.currentTime > 3) {
      el.currentTime = 0;
      return;
    }
    if (queueIndex > 0) {
      setQueueIndex((i) => i - 1);
      setPlaying(true);
    }
  }
  async function openSettings() {
    const data = await api("/api/audio_station/settings");
    setSettings(data);
    setSettingsDraft({ ...data, library_roots: [...data.library_roots] });
    setSettingsOpen(true);
  }
  async function saveSettings() {
    if (!settingsDraft) return;
    const saved = await api("/api/audio_station/settings", {
      method: "PUT",
      body: settingsDraft
    });
    setSettings(saved);
    setSettingsDraft({ ...saved, library_roots: [...saved.library_roots] });
    setSettingsOpen(false);
    await Promise.all([loadBrowse(""), loadStats()]);
  }
  async function createPlaylist() {
    const name = newPlaylistName.trim();
    if (!name) return;
    const pl = await api("/api/audio_station/playlists", {
      method: "POST",
      body: { name }
    });
    setNewPlaylistName("");
    setNewPlaylistOpen(false);
    await loadPlaylists();
    setSelectedPlaylist(pl);
    setView("playlist");
  }
  async function deleteSelectedPlaylist() {
    if (!selectedPlaylist || selectedPlaylist.kind === "system") return;
    await api(`/api/audio_station/playlists/${encodeURIComponent(selectedPlaylist.id)}`, { method: "DELETE" });
    setSelectedPlaylist(null);
    setView("home");
    await loadPlaylists();
  }
  function openPlaylist(pl) {
    setSelectedAlbum(null);
    setSelectedArtist(null);
    setSelectedGenre(null);
    setSelectedPlaylist(pl);
    setView("playlist");
  }
  function openSystemPlaylist(kind) {
    const pl = playlists.find((p) => p.id === (kind === "recent" ? "__recent__" : "__random__"));
    if (pl) openPlaylist(pl);
    else setView(kind);
  }
  async function runScan() {
    await api("/api/audio_station/library/scan", { method: "POST" });
    await loadStats();
  }
  async function openFolderPicker() {
    setPickerMode("add");
    const data = await api("/api/audio_station/folders/browse");
    setFolderPicker(data);
  }
  async function browsePicker(path) {
    const data = await api(`/api/audio_station/folders/browse?path=${encodeURIComponent(path)}`);
    setFolderPicker(data);
  }
  function pickFolder(path) {
    if (!settingsDraft || pickerMode !== "add") return;
    if (!settingsDraft.library_roots.includes(path)) {
      setSettingsDraft({
        ...settingsDraft,
        library_roots: [...settingsDraft.library_roots, path]
      });
    }
    setFolderPicker(null);
    setPickerMode(null);
  }
  function removeRoot(path) {
    if (!settingsDraft || settingsDraft.library_roots.length <= 1) return;
    setSettingsDraft({
      ...settingsDraft,
      library_roots: settingsDraft.library_roots.filter((r2) => r2 !== path)
    });
  }
  const filteredFiles = useMemo(() => {
    if (!browse) return [];
    const q = search.trim().toLowerCase();
    if (!q) return browse.files;
    return browse.files.filter((f) => f.name.toLowerCase().includes(q));
  }, [browse, search]);
  const navItem = (key, label, icon, disabled = false) => {
    const Icon = Icons3[icon];
    return /* @__PURE__ */ jsxs3(
      "button",
      {
        type: "button",
        disabled,
        onClick: () => {
          if (disabled) return;
          setSelectedAlbum(null);
          setSelectedArtist(null);
          setSelectedGenre(null);
          setSelectedPlaylist(null);
          setView(key);
        },
        className: `w-full text-left px-3 py-2 rounded-md text-sm flex items-center gap-2 ${view === key ? activeNav : `${muted} ${disabled ? "opacity-40 cursor-not-allowed" : hoverRow}`}`,
        children: [
          /* @__PURE__ */ jsx6(Icon, { className: "w-4 h-4 shrink-0" }),
          label
        ]
      }
    );
  };
  const viewTitle = useMemo(() => {
    if (view === "folder") return t.byFolder;
    if (view === "all") return t.allMusic;
    if (view === "recent") return t.recentlyAdded;
    if (view === "random") return t.random100;
    if (view === "playlist") return selectedPlaylist?.name || t.playlists;
    if (view === "album") return selectedAlbum ? selectedAlbum.album : t.byAlbum;
    if (view === "artist") return selectedArtist || t.byArtist;
    if (view === "genre") return selectedGenre || t.byGenre;
    return t.home;
  }, [view, selectedAlbum, selectedArtist, selectedGenre, selectedPlaylist, t]);
  function renderTrackTable(tracks, emptyMsg) {
    if (libLoading) {
      return /* @__PURE__ */ jsx6("div", { className: `flex-1 flex items-center justify-center ${muted}`, children: /* @__PURE__ */ jsx6(Icons3.Loader2, { className: "w-8 h-8 animate-spin" }) });
    }
    if (!tracks.length) {
      return /* @__PURE__ */ jsx6("div", { className: `flex-1 flex items-center justify-center p-8 ${muted}`, children: emptyMsg });
    }
    return /* @__PURE__ */ jsx6("div", { className: "flex-1 overflow-y-auto", children: /* @__PURE__ */ jsxs3("table", { className: "w-full text-sm", children: [
      /* @__PURE__ */ jsx6("thead", { className: `sticky top-0 z-10 ${isDark ? "bg-slate-900" : "bg-white"}`, children: /* @__PURE__ */ jsxs3("tr", { className: `border-b text-left ${isDark ? "border-slate-700 text-slate-400" : "border-slate-200 text-slate-500"}`, children: [
        /* @__PURE__ */ jsx6("th", { className: "px-4 py-2 font-medium", children: t.colTitle }),
        /* @__PURE__ */ jsx6("th", { className: "px-4 py-2 font-medium hidden md:table-cell", children: t.colAlbum }),
        /* @__PURE__ */ jsx6("th", { className: "px-4 py-2 font-medium hidden lg:table-cell", children: t.colArtist }),
        /* @__PURE__ */ jsx6("th", { className: "px-4 py-2 font-medium w-24 text-right", children: t.colDuration })
      ] }) }),
      /* @__PURE__ */ jsx6("tbody", { children: tracks.map((tr) => /* @__PURE__ */ jsxs3(
        "tr",
        {
          className: `border-b cursor-pointer ${currentTrack?.path === tr.path ? isDark ? "bg-teal-900/30" : "bg-teal-50" : hoverRow} ${isDark ? "border-slate-800" : "border-slate-100"}`,
          onClick: () => playLibraryTrack(tr, tracks),
          onDoubleClick: () => playLibraryTrack(tr, tracks),
          children: [
            /* @__PURE__ */ jsx6("td", { className: "px-4 py-2", children: /* @__PURE__ */ jsxs3("div", { className: "flex items-center gap-2", children: [
              /* @__PURE__ */ jsx6(CoverThumb, { track: tr, className: "w-8 h-8" }),
              /* @__PURE__ */ jsx6("span", { className: "truncate", children: tr.title })
            ] }) }),
            /* @__PURE__ */ jsx6("td", { className: `px-4 py-2 hidden md:table-cell truncate ${muted}`, children: tr.album || "\u2014" }),
            /* @__PURE__ */ jsx6("td", { className: `px-4 py-2 hidden lg:table-cell truncate ${muted}`, children: tr.artist || "\u2014" }),
            /* @__PURE__ */ jsx6("td", { className: `px-4 py-2 text-right ${muted}`, children: tr.duration_sec ? fmtTime(tr.duration_sec) : "\u2014" })
          ]
        },
        tr.path
      )) })
    ] }) });
  }
  return /* @__PURE__ */ jsx6(ModuleViewport, { constrained: true, children: /* @__PURE__ */ jsxs3("div", { className: `flex flex-col h-full min-h-[32rem] border rounded-lg overflow-hidden ${panel}`, children: [
    /* @__PURE__ */ jsxs3("div", { className: `flex items-center gap-3 px-4 py-3 border-b shrink-0 ${isDark ? "border-slate-700" : "border-slate-200"}`, children: [
      /* @__PURE__ */ jsx6(Icons3.Music, { className: "w-6 h-6 text-teal-500" }),
      /* @__PURE__ */ jsxs3("div", { className: "flex-1 min-w-0", children: [
        /* @__PURE__ */ jsx6("h1", { className: "font-semibold text-lg leading-tight", children: t.title }),
        /* @__PURE__ */ jsx6("p", { className: `text-xs ${muted}`, children: t.subtitle })
      ] }),
      /* @__PURE__ */ jsxs3("div", { className: "relative hidden sm:block", children: [
        /* @__PURE__ */ jsx6(Icons3.Search, { className: `absolute left-2.5 top-1/2 -translate-y-1/2 w-4 h-4 ${muted}` }),
        /* @__PURE__ */ jsx6(
          "input",
          {
            value: search,
            onChange: (e) => setSearch(e.target.value),
            placeholder: t.search,
            className: `pl-8 pr-3 py-1.5 text-sm rounded-md border w-48 lg:w-64 ${isDark ? "bg-slate-800 border-slate-600" : "bg-slate-50 border-slate-300"}`
          }
        )
      ] }),
      /* @__PURE__ */ jsxs3(
        "button",
        {
          type: "button",
          onClick: openSettings,
          className: `flex items-center gap-1.5 px-3 py-1.5 text-sm rounded-md border ${isDark ? "border-slate-600 hover:bg-slate-800" : "border-slate-300 hover:bg-slate-50"}`,
          children: [
            /* @__PURE__ */ jsx6(Icons3.Settings, { className: "w-4 h-4" }),
            t.settings
          ]
        }
      )
    ] }),
    /* @__PURE__ */ jsx6(
      ModuleSidebarLayout,
      {
        isDark,
        mobileTitle: t.title,
        sidebar: /* @__PURE__ */ jsxs3(
          "aside",
          {
            className: `h-full w-52 shrink-0 border-r overflow-y-auto p-3 space-y-4 ${isDark ? "border-slate-700 bg-slate-900/50" : "border-slate-200 bg-slate-50/80"}`,
            children: [
              navItem("home", t.home, "Home"),
              /* @__PURE__ */ jsxs3("div", { children: [
                /* @__PURE__ */ jsx6("div", { className: `text-[10px] font-bold tracking-wider px-3 mb-1 ${muted}`, children: t.myMusic }),
                navItem("all", t.allMusic, "ListMusic"),
                navItem("folder", t.byFolder, "FolderOpen"),
                navItem("album", t.byAlbum, "Disc"),
                navItem("artist", t.byArtist, "Mic2"),
                navItem("genre", t.byGenre, "Tags")
              ] }),
              /* @__PURE__ */ jsxs3("div", { children: [
                /* @__PURE__ */ jsxs3("div", { className: `flex items-center justify-between px-3 mb-1`, children: [
                  /* @__PURE__ */ jsx6("div", { className: `text-[10px] font-bold tracking-wider ${muted}`, children: t.playlists }),
                  /* @__PURE__ */ jsx6(
                    "button",
                    {
                      type: "button",
                      onClick: () => setNewPlaylistOpen(true),
                      className: `p-0.5 rounded hover:bg-teal-500/20 text-teal-500`,
                      title: t.newPlaylist,
                      children: /* @__PURE__ */ jsx6(Icons3.Plus, { className: "w-3.5 h-3.5" })
                    }
                  )
                ] }),
                playlists.map((pl) => /* @__PURE__ */ jsxs3(
                  "button",
                  {
                    type: "button",
                    onClick: () => openPlaylist(pl),
                    className: `w-full text-left px-3 py-2 rounded-md text-sm flex items-center gap-2 ${view === "playlist" && selectedPlaylist?.id === pl.id ? activeNav : `${muted} ${hoverRow}`}`,
                    children: [
                      pl.kind === "system" ? /* @__PURE__ */ jsx6(Icons3.Clock, { className: "w-4 h-4 shrink-0" }) : /* @__PURE__ */ jsx6(Icons3.ListMusic, { className: "w-4 h-4 shrink-0" }),
                      /* @__PURE__ */ jsx6("span", { className: "truncate", children: pl.name })
                    ]
                  },
                  pl.id
                ))
              ] })
            ]
          }
        ),
        children: /* @__PURE__ */ jsxs3("main", { className: "flex-1 flex flex-col min-w-0 min-h-0", children: [
          error && /* @__PURE__ */ jsx6("div", { className: "mx-4 mt-3 px-3 py-2 text-sm rounded bg-red-500/10 text-red-500 border border-red-500/30", children: error }),
          view === "home" && /* @__PURE__ */ jsxs3("div", { className: "p-6 space-y-6 overflow-y-auto", children: [
            /* @__PURE__ */ jsx6("h2", { className: "text-xl font-semibold", children: t.home }),
            stats && /* @__PURE__ */ jsxs3("div", { className: "grid grid-cols-3 gap-4 max-w-lg", children: [
              /* @__PURE__ */ jsxs3("div", { className: `p-4 rounded-lg border ${isDark ? "border-slate-700" : "border-slate-200"}`, children: [
                /* @__PURE__ */ jsx6("div", { className: "text-2xl font-bold text-teal-500", children: stats.tracks }),
                /* @__PURE__ */ jsx6("div", { className: `text-sm ${muted}`, children: t.tracks })
              ] }),
              /* @__PURE__ */ jsxs3("div", { className: `p-4 rounded-lg border ${isDark ? "border-slate-700" : "border-slate-200"}`, children: [
                /* @__PURE__ */ jsx6("div", { className: "text-2xl font-bold text-teal-500", children: stats.albums }),
                /* @__PURE__ */ jsx6("div", { className: `text-sm ${muted}`, children: t.albums })
              ] }),
              /* @__PURE__ */ jsxs3("div", { className: `p-4 rounded-lg border ${isDark ? "border-slate-700" : "border-slate-200"}`, children: [
                /* @__PURE__ */ jsx6("div", { className: "text-2xl font-bold text-teal-500", children: stats.artists }),
                /* @__PURE__ */ jsx6("div", { className: `text-sm ${muted}`, children: t.artists })
              ] })
            ] }),
            /* @__PURE__ */ jsx6("p", { className: `text-sm ${muted}`, children: t.statsHint }),
            recentTracks.length > 0 && /* @__PURE__ */ jsxs3("div", { children: [
              /* @__PURE__ */ jsxs3("div", { className: "flex items-center justify-between mb-2", children: [
                /* @__PURE__ */ jsx6("h3", { className: "text-sm font-semibold", children: t.recentlyAdded }),
                /* @__PURE__ */ jsx6(
                  "button",
                  {
                    type: "button",
                    onClick: () => openSystemPlaylist("recent"),
                    className: "text-xs text-teal-500 hover:underline",
                    children: t.allMusic
                  }
                )
              ] }),
              /* @__PURE__ */ jsx6("div", { className: "space-y-1 max-w-xl", children: recentTracks.slice(0, 5).map((tr) => /* @__PURE__ */ jsxs3(
                "button",
                {
                  type: "button",
                  onClick: () => playLibraryTrack(tr, recentTracks),
                  className: `w-full flex items-center gap-3 p-2 rounded-lg text-left ${hoverRow}`,
                  children: [
                    /* @__PURE__ */ jsx6(CoverThumb, { track: tr, className: "w-10 h-10" }),
                    /* @__PURE__ */ jsxs3("div", { className: "min-w-0 flex-1", children: [
                      /* @__PURE__ */ jsx6("div", { className: "text-sm font-medium truncate", children: tr.title }),
                      /* @__PURE__ */ jsx6("div", { className: `text-xs truncate ${muted}`, children: tr.artist || tr.album })
                    ] })
                  ]
                },
                tr.path
              )) })
            ] }),
            topGenres.length > 0 && /* @__PURE__ */ jsxs3("div", { children: [
              /* @__PURE__ */ jsx6("h3", { className: "text-sm font-semibold mb-2", children: t.byGenre }),
              /* @__PURE__ */ jsx6("div", { className: "grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2 max-w-3xl", children: topGenres.map((g) => /* @__PURE__ */ jsxs3(
                "button",
                {
                  type: "button",
                  onClick: () => {
                    setSelectedGenre(g.name);
                    setView("genre");
                  },
                  className: `p-3 rounded-lg border text-left text-sm hover:border-teal-500 ${isDark ? "border-slate-700 hover:bg-slate-800" : "border-slate-200 hover:bg-slate-50"}`,
                  children: [
                    /* @__PURE__ */ jsx6("div", { className: "font-medium truncate", children: g.name }),
                    /* @__PURE__ */ jsxs3("div", { className: `text-xs ${muted}`, children: [
                      g.track_count,
                      " ",
                      t.tracks
                    ] })
                  ]
                },
                g.name
              )) })
            ] }),
            /* @__PURE__ */ jsxs3("div", { className: "flex gap-2", children: [
              /* @__PURE__ */ jsx6(
                "button",
                {
                  type: "button",
                  onClick: () => setView("folder"),
                  className: "px-4 py-2 text-sm rounded-md bg-teal-600 text-white hover:bg-teal-500",
                  children: t.byFolder
                }
              ),
              /* @__PURE__ */ jsx6(
                "button",
                {
                  type: "button",
                  onClick: runScan,
                  disabled: stats?.scan.status === "running",
                  className: "px-4 py-2 text-sm rounded-md border border-teal-600 text-teal-600 hover:bg-teal-500/10 disabled:opacity-50",
                  children: stats?.scan.status === "running" ? t.scanning : t.scanNow
                }
              )
            ] })
          ] }),
          (view === "folder" || view === "all" || view === "album" || view === "artist" || view === "genre" || view === "recent" || view === "random" || view === "playlist") && /* @__PURE__ */ jsxs3(Fragment, { children: [
            /* @__PURE__ */ jsxs3(
              "div",
              {
                className: `flex items-center justify-between px-4 py-2 border-b shrink-0 ${isDark ? "border-slate-700" : "border-slate-200"}`,
                children: [
                  /* @__PURE__ */ jsxs3("div", { className: "flex items-center gap-2 min-w-0 flex-wrap", children: [
                    (selectedAlbum || selectedArtist || selectedGenre) && /* @__PURE__ */ jsxs3(
                      "button",
                      {
                        type: "button",
                        onClick: () => {
                          setSelectedAlbum(null);
                          setSelectedArtist(null);
                          setSelectedGenre(null);
                        },
                        className: "text-sm text-teal-500 hover:underline flex items-center gap-1",
                        children: [
                          /* @__PURE__ */ jsx6(Icons3.ArrowLeft, { className: "w-4 h-4" }),
                          t.back
                        ]
                      }
                    ),
                    /* @__PURE__ */ jsx6("h2", { className: "font-semibold", children: viewTitle }),
                    view === "folder" && browse?.breadcrumbs.map((b, i) => /* @__PURE__ */ jsxs3("span", { className: "flex items-center gap-1 text-sm", children: [
                      i > 0 && /* @__PURE__ */ jsx6("span", { className: muted, children: "/" }),
                      /* @__PURE__ */ jsx6(
                        "button",
                        {
                          type: "button",
                          onClick: () => loadBrowse(b.path),
                          className: "text-teal-500 hover:underline truncate max-w-[8rem]",
                          children: b.name
                        }
                      )
                    ] }, b.path))
                  ] }),
                  view === "folder" && browse && browse.files.length > 0 && /* @__PURE__ */ jsxs3(
                    "button",
                    {
                      type: "button",
                      onClick: playAllInFolder,
                      className: "flex items-center gap-1 text-sm text-teal-600 hover:underline shrink-0",
                      children: [
                        /* @__PURE__ */ jsx6(Icons3.Play, { className: "w-4 h-4" }),
                        t.play
                      ]
                    }
                  ),
                  view === "all" && libTracks.length > 0 && /* @__PURE__ */ jsxs3(
                    "button",
                    {
                      type: "button",
                      onClick: () => playLibraryTracks(libTracks),
                      className: "flex items-center gap-1 text-sm text-teal-600 hover:underline shrink-0",
                      children: [
                        /* @__PURE__ */ jsx6(Icons3.Play, { className: "w-4 h-4" }),
                        t.play
                      ]
                    }
                  ),
                  (view === "recent" || view === "random" || view === "playlist") && libTracks.length > 0 && /* @__PURE__ */ jsxs3(
                    "button",
                    {
                      type: "button",
                      onClick: () => playLibraryTracks(libTracks),
                      className: "flex items-center gap-1 text-sm text-teal-600 hover:underline shrink-0",
                      children: [
                        /* @__PURE__ */ jsx6(Icons3.Play, { className: "w-4 h-4" }),
                        t.play
                      ]
                    }
                  ),
                  view === "playlist" && selectedPlaylist?.kind === "user" && /* @__PURE__ */ jsxs3(
                    "button",
                    {
                      type: "button",
                      onClick: deleteSelectedPlaylist,
                      className: "flex items-center gap-1 text-sm text-red-500 hover:underline shrink-0",
                      children: [
                        /* @__PURE__ */ jsx6(Icons3.Trash2, { className: "w-4 h-4" }),
                        t.deletePlaylist
                      ]
                    }
                  )
                ]
              }
            ),
            (view === "all" || view === "recent" || view === "random" || view === "playlist") && renderTrackTable(libTracks, t.noLibrary),
            view === "album" && !selectedAlbum && (libLoading ? /* @__PURE__ */ jsx6("div", { className: `flex-1 flex items-center justify-center ${muted}`, children: /* @__PURE__ */ jsx6(Icons3.Loader2, { className: "w-8 h-8 animate-spin" }) }) : albums.length === 0 ? /* @__PURE__ */ jsx6("div", { className: `flex-1 flex items-center justify-center p-8 ${muted}`, children: t.noLibrary }) : /* @__PURE__ */ jsx6("div", { className: "flex-1 overflow-y-auto p-4 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3", children: albums.map((a) => /* @__PURE__ */ jsxs3(
              "button",
              {
                type: "button",
                onClick: () => setSelectedAlbum(a),
                className: `p-3 rounded-lg border text-left hover:border-teal-500 ${isDark ? "border-slate-700 hover:bg-slate-800" : "border-slate-200 hover:bg-slate-50"}`,
                children: [
                  /* @__PURE__ */ jsx6("div", { className: `w-full aspect-square rounded mb-2 overflow-hidden ${isDark ? "bg-slate-800" : "bg-slate-100"}`, children: a.has_cover && a.cover_hash ? /* @__PURE__ */ jsx6(
                    "img",
                    {
                      src: coverUrl({ hash: a.cover_hash }) || "",
                      alt: "",
                      className: "w-full h-full object-cover"
                    }
                  ) : /* @__PURE__ */ jsx6("div", { className: "w-full h-full flex items-center justify-center", children: /* @__PURE__ */ jsx6(Icons3.Disc, { className: "w-10 h-10 text-teal-500/60" }) }) }),
                  /* @__PURE__ */ jsx6("div", { className: "font-medium text-sm truncate", children: a.album }),
                  /* @__PURE__ */ jsx6("div", { className: `text-xs truncate ${muted}`, children: a.album_artist || a.artist }),
                  /* @__PURE__ */ jsxs3("div", { className: `text-xs ${muted}`, children: [
                    a.track_count,
                    " ",
                    t.songs
                  ] })
                ]
              },
              a.key
            )) })),
            view === "album" && selectedAlbum && renderTrackTable(libTracks, t.noFiles),
            view === "artist" && !selectedArtist && (libLoading ? /* @__PURE__ */ jsx6("div", { className: `flex-1 flex items-center justify-center ${muted}`, children: /* @__PURE__ */ jsx6(Icons3.Loader2, { className: "w-8 h-8 animate-spin" }) }) : artists.length === 0 ? /* @__PURE__ */ jsx6("div", { className: `flex-1 flex items-center justify-center p-8 ${muted}`, children: t.noLibrary }) : /* @__PURE__ */ jsx6("div", { className: "flex-1 overflow-y-auto", children: /* @__PURE__ */ jsx6("table", { className: "w-full text-sm", children: /* @__PURE__ */ jsx6("tbody", { children: artists.map((a) => /* @__PURE__ */ jsxs3(
              "tr",
              {
                className: `border-b cursor-pointer ${hoverRow} ${isDark ? "border-slate-800" : "border-slate-100"}`,
                onClick: () => setSelectedArtist(a.name),
                children: [
                  /* @__PURE__ */ jsx6("td", { className: "px-4 py-2", children: /* @__PURE__ */ jsxs3("div", { className: "flex items-center gap-2", children: [
                    /* @__PURE__ */ jsx6(Icons3.Mic2, { className: "w-4 h-4 text-teal-500" }),
                    a.name
                  ] }) }),
                  /* @__PURE__ */ jsx6("td", { className: `px-4 py-2 text-right ${muted}`, children: a.track_count })
                ]
              },
              a.name
            )) }) }) })),
            view === "artist" && selectedArtist && renderTrackTable(libTracks, t.noFiles),
            view === "genre" && !selectedGenre && (libLoading ? /* @__PURE__ */ jsx6("div", { className: `flex-1 flex items-center justify-center ${muted}`, children: /* @__PURE__ */ jsx6(Icons3.Loader2, { className: "w-8 h-8 animate-spin" }) }) : genres.length === 0 ? /* @__PURE__ */ jsx6("div", { className: `flex-1 flex items-center justify-center p-8 ${muted}`, children: t.noLibrary }) : /* @__PURE__ */ jsx6("div", { className: "flex-1 overflow-y-auto p-4 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2", children: genres.map((g) => /* @__PURE__ */ jsxs3(
              "button",
              {
                type: "button",
                onClick: () => setSelectedGenre(g.name),
                className: `p-3 rounded-lg border text-left hover:border-teal-500 ${isDark ? "border-slate-700 hover:bg-slate-800" : "border-slate-200 hover:bg-slate-50"}`,
                children: [
                  /* @__PURE__ */ jsx6("div", { className: "font-medium truncate", children: g.name }),
                  /* @__PURE__ */ jsxs3("div", { className: `text-xs ${muted}`, children: [
                    g.track_count,
                    " ",
                    t.tracks
                  ] })
                ]
              },
              g.name
            )) })),
            view === "genre" && selectedGenre && renderTrackTable(libTracks, t.noFiles),
            view === "folder" && (loading && !browse ? /* @__PURE__ */ jsx6("div", { className: `flex-1 flex items-center justify-center ${muted}`, children: /* @__PURE__ */ jsx6(Icons3.Loader2, { className: "w-8 h-8 animate-spin" }) }) : /* @__PURE__ */ jsxs3("div", { className: "flex-1 overflow-y-auto", children: [
              /* @__PURE__ */ jsxs3("table", { className: "w-full text-sm", children: [
                /* @__PURE__ */ jsx6("thead", { className: `sticky top-0 z-10 ${isDark ? "bg-slate-900" : "bg-white"}`, children: /* @__PURE__ */ jsxs3("tr", { className: `border-b text-left ${isDark ? "border-slate-700 text-slate-400" : "border-slate-200 text-slate-500"}`, children: [
                  /* @__PURE__ */ jsx6("th", { className: "px-4 py-2 font-medium", children: t.colTitle }),
                  /* @__PURE__ */ jsx6("th", { className: "px-4 py-2 font-medium hidden md:table-cell", children: t.colAlbum }),
                  /* @__PURE__ */ jsx6("th", { className: "px-4 py-2 font-medium hidden lg:table-cell", children: t.colArtist }),
                  /* @__PURE__ */ jsx6("th", { className: "px-4 py-2 font-medium w-24 text-right", children: t.colDuration })
                ] }) }),
                /* @__PURE__ */ jsxs3("tbody", { children: [
                  browse?.dirs.map((d) => /* @__PURE__ */ jsx6(
                    "tr",
                    {
                      className: `border-b cursor-pointer ${hoverRow} ${isDark ? "border-slate-800" : "border-slate-100"}`,
                      onDoubleClick: () => loadBrowse(d.path),
                      children: /* @__PURE__ */ jsx6("td", { className: "px-4 py-2", colSpan: 4, children: /* @__PURE__ */ jsxs3("div", { className: "flex items-center gap-2", children: [
                        /* @__PURE__ */ jsx6(Icons3.Folder, { className: "w-4 h-4 text-amber-500 shrink-0" }),
                        /* @__PURE__ */ jsx6("span", { children: d.name }),
                        /* @__PURE__ */ jsx6(
                          "button",
                          {
                            type: "button",
                            onClick: (e) => {
                              e.stopPropagation();
                              loadBrowse(d.path);
                            },
                            className: `ml-auto text-xs ${muted} hover:text-teal-500`,
                            children: t.openFolder
                          }
                        )
                      ] }) })
                    },
                    d.path
                  )),
                  filteredFiles.map((f) => /* @__PURE__ */ jsxs3(
                    "tr",
                    {
                      className: `border-b cursor-pointer ${currentTrack?.path === f.path ? isDark ? "bg-teal-900/30" : "bg-teal-50" : hoverRow} ${isDark ? "border-slate-800" : "border-slate-100"}`,
                      onDoubleClick: () => playFile(f),
                      onClick: () => playFile(f),
                      children: [
                        /* @__PURE__ */ jsx6("td", { className: "px-4 py-2", children: /* @__PURE__ */ jsxs3("div", { className: "flex items-center gap-2", children: [
                          /* @__PURE__ */ jsx6(Icons3.Music2, { className: "w-4 h-4 text-teal-500 shrink-0" }),
                          /* @__PURE__ */ jsx6("span", { className: "truncate", children: f.name })
                        ] }) }),
                        /* @__PURE__ */ jsx6("td", { className: `px-4 py-2 hidden md:table-cell ${muted}`, children: "\u2014" }),
                        /* @__PURE__ */ jsx6("td", { className: `px-4 py-2 hidden lg:table-cell ${muted}`, children: "\u2014" }),
                        /* @__PURE__ */ jsx6("td", { className: `px-4 py-2 text-right ${muted}`, children: f.size ? fmtBytes(f.size) : "\u2014" })
                      ]
                    },
                    f.path
                  ))
                ] })
              ] }),
              browse && !browse.dirs.length && !filteredFiles.length && /* @__PURE__ */ jsx6("div", { className: `p-8 text-center ${muted}`, children: t.noFiles })
            ] }))
          ] })
        ] })
      }
    ),
    /* @__PURE__ */ jsxs3("div", { className: `border-t px-4 py-2 shrink-0 ${isDark ? "border-slate-700 bg-slate-900" : "border-slate-200 bg-slate-50"}`, children: [
      /* @__PURE__ */ jsx6(
        "audio",
        {
          ref: audioRef,
          onTimeUpdate: () => setCurrentTime(audioRef.current?.currentTime || 0),
          onLoadedMetadata: () => setDuration(audioRef.current?.duration || 0),
          onEnded,
          onPlay: () => setPlaying(true),
          onPause: () => setPlaying(false)
        }
      ),
      /* @__PURE__ */ jsxs3("div", { className: "flex items-center gap-4", children: [
        /* @__PURE__ */ jsxs3("div", { className: "flex items-center gap-1 shrink-0", children: [
          /* @__PURE__ */ jsx6("button", { type: "button", onClick: skipPrev, className: "p-2 rounded-full hover:bg-black/10", title: t.prev, children: /* @__PURE__ */ jsx6(Icons3.SkipBack, { className: "w-5 h-5" }) }),
          /* @__PURE__ */ jsx6(
            "button",
            {
              type: "button",
              onClick: () => setPlaying((p) => !p),
              className: "p-2 rounded-full bg-teal-600 text-white hover:bg-teal-500",
              title: playing ? t.pause : t.play,
              children: playing ? /* @__PURE__ */ jsx6(Icons3.Pause, { className: "w-5 h-5" }) : /* @__PURE__ */ jsx6(Icons3.Play, { className: "w-5 h-5" })
            }
          ),
          /* @__PURE__ */ jsx6("button", { type: "button", onClick: skipNext, className: "p-2 rounded-full hover:bg-black/10", title: t.next, children: /* @__PURE__ */ jsx6(Icons3.SkipForward, { className: "w-5 h-5" }) })
        ] }),
        /* @__PURE__ */ jsxs3("div", { className: "flex-1 min-w-0 flex items-center gap-3", children: [
          currentTrack && /* @__PURE__ */ jsx6(
            CoverThumb,
            {
              track: libTracks.find((x) => x.path === currentTrack.path) || { id: "", path: currentTrack.path, title: currentTrack.name, artist: "", album: "", genre: "" },
              className: "w-10 h-10 hidden sm:block"
            }
          ),
          /* @__PURE__ */ jsxs3("div", { className: "flex-1 min-w-0", children: [
            /* @__PURE__ */ jsx6("div", { className: "text-sm font-medium truncate", children: currentTrack?.name || "\u2014" }),
            /* @__PURE__ */ jsxs3("div", { className: "flex items-center gap-2 mt-1", children: [
              /* @__PURE__ */ jsx6("span", { className: `text-xs tabular-nums ${muted}`, children: fmtTime(currentTime) }),
              /* @__PURE__ */ jsx6(
                "input",
                {
                  type: "range",
                  min: 0,
                  max: duration || 0,
                  value: currentTime,
                  onChange: (e) => {
                    const v = Number(e.target.value);
                    if (audioRef.current) audioRef.current.currentTime = v;
                    setCurrentTime(v);
                  },
                  className: "flex-1 h-1 accent-teal-600"
                }
              ),
              /* @__PURE__ */ jsx6("span", { className: `text-xs tabular-nums ${muted}`, children: fmtTime(duration) })
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsx6(
          "button",
          {
            type: "button",
            onClick: () => setShowQueue((s) => !s),
            className: `p-2 rounded-md ${showQueue ? "bg-teal-600/20 text-teal-500" : hoverRow}`,
            title: t.queue,
            children: /* @__PURE__ */ jsx6(Icons3.ListMusic, { className: "w-5 h-5" })
          }
        )
      ] }),
      showQueue && /* @__PURE__ */ jsx6("div", { className: `mt-2 max-h-32 overflow-y-auto rounded border text-sm ${isDark ? "border-slate-700" : "border-slate-200"}`, children: queue.length === 0 ? /* @__PURE__ */ jsx6("div", { className: `p-3 ${muted}`, children: t.emptyQueue }) : queue.map((item, i) => /* @__PURE__ */ jsxs3(
        "button",
        {
          type: "button",
          onClick: () => {
            setQueueIndex(i);
            setPlaying(true);
          },
          className: `w-full text-left px-3 py-1.5 flex items-center gap-2 ${i === queueIndex ? isDark ? "bg-teal-900/40" : "bg-teal-50" : hoverRow}`,
          children: [
            /* @__PURE__ */ jsx6("span", { className: `w-5 text-xs ${muted}`, children: i + 1 }),
            /* @__PURE__ */ jsx6("span", { className: "truncate", children: item.name })
          ]
        },
        item.path
      )) })
    ] }),
    /* @__PURE__ */ jsx6(WindowModal, { open: newPlaylistOpen, onClose: () => setNewPlaylistOpen(false), title: t.newPlaylist, children: /* @__PURE__ */ jsxs3("div", { className: "p-4", children: [
      /* @__PURE__ */ jsx6(
        "input",
        {
          value: newPlaylistName,
          onChange: (e) => setNewPlaylistName(e.target.value),
          placeholder: t.playlistName,
          className: `w-full px-3 py-2 text-sm rounded border mb-3 ${isDark ? "bg-slate-800 border-slate-600" : "bg-white border-slate-300"}`
        }
      ),
      /* @__PURE__ */ jsxs3("div", { className: "flex gap-2 justify-end", children: [
        /* @__PURE__ */ jsx6("button", { type: "button", onClick: () => setNewPlaylistOpen(false), className: `px-3 py-1.5 text-sm rounded border ${isDark ? "border-slate-600" : "border-slate-300"}`, children: t.cancel }),
        /* @__PURE__ */ jsx6("button", { type: "button", onClick: createPlaylist, className: "px-3 py-1.5 text-sm rounded bg-teal-600 text-white hover:bg-teal-500", children: t.save })
      ] })
    ] }) }),
    /* @__PURE__ */ jsx6(WindowModal, { open: settingsOpen && !!settingsDraft, onClose: () => setSettingsOpen(false), title: t.settings, maxWidth: "2xl", className: "max-w-2xl", children: settingsDraft && /* @__PURE__ */ jsxs3("div", { className: "p-4 space-y-4", children: [
      /* @__PURE__ */ jsxs3("div", { children: [
        /* @__PURE__ */ jsx6("label", { className: `block text-sm font-medium mb-2 ${muted}`, children: t.libraryRoots }),
        /* @__PURE__ */ jsx6("div", { className: "space-y-2", children: settingsDraft.library_roots.map((root) => /* @__PURE__ */ jsxs3("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsx6("code", { className: `flex-1 text-xs px-2 py-1.5 rounded border truncate ${isDark ? "bg-slate-800 border-slate-600" : "bg-slate-50 border-slate-300"}`, children: root }),
          /* @__PURE__ */ jsx6(
            "button",
            {
              type: "button",
              disabled: settingsDraft.library_roots.length <= 1,
              onClick: () => removeRoot(root),
              className: "p-1.5 text-red-500 hover:bg-red-500/10 rounded disabled:opacity-30",
              children: /* @__PURE__ */ jsx6(Icons3.Trash2, { className: "w-4 h-4" })
            }
          )
        ] }, root)) }),
        /* @__PURE__ */ jsxs3(
          "button",
          {
            type: "button",
            onClick: openFolderPicker,
            className: "mt-2 text-sm text-teal-600 hover:underline flex items-center gap-1",
            children: [
              /* @__PURE__ */ jsx6(Icons3.Plus, { className: "w-4 h-4" }),
              t.addRoot
            ]
          }
        )
      ] }),
      /* @__PURE__ */ jsxs3("label", { className: "flex items-center gap-2 text-sm cursor-pointer", children: [
        /* @__PURE__ */ jsx6(
          "input",
          {
            type: "checkbox",
            checked: settingsDraft.scan_on_startup,
            onChange: (e) => setSettingsDraft((prev) => prev ? { ...prev, scan_on_startup: e.target.checked } : prev)
          }
        ),
        t.scanOnStartup
      ] }),
      stats?.scan.status === "running" && /* @__PURE__ */ jsxs3("div", { className: `text-sm ${muted} flex items-center gap-2`, children: [
        /* @__PURE__ */ jsx6(Icons3.Loader2, { className: "w-4 h-4 animate-spin" }),
        t.scanning,
        " (",
        stats.scan.files_indexed,
        "/",
        stats.scan.files_found,
        " ",
        t.indexed,
        ")"
      ] }),
      /* @__PURE__ */ jsxs3("div", { className: "flex gap-2 pt-2", children: [
        /* @__PURE__ */ jsx6(
          "button",
          {
            type: "button",
            onClick: runScan,
            disabled: stats?.scan.status === "running",
            className: "px-3 py-1.5 text-sm rounded border border-teal-600 text-teal-600 hover:bg-teal-500/10 disabled:opacity-50",
            children: t.scanNow
          }
        ),
        /* @__PURE__ */ jsx6("div", { className: "flex-1" }),
        /* @__PURE__ */ jsx6("button", { type: "button", onClick: () => setSettingsOpen(false), className: `px-3 py-1.5 text-sm rounded border ${isDark ? "border-slate-600" : "border-slate-300"}`, children: t.cancel }),
        /* @__PURE__ */ jsx6("button", { type: "button", onClick: saveSettings, className: "px-3 py-1.5 text-sm rounded bg-teal-600 text-white hover:bg-teal-500", children: t.save })
      ] })
    ] }) }),
    /* @__PURE__ */ jsx6(
      WindowModal,
      {
        open: !!folderPicker,
        onClose: () => {
          setFolderPicker(null);
          setPickerMode(null);
        },
        title: t.selectFolder,
        children: folderPicker && /* @__PURE__ */ jsxs3("div", { className: "p-4", children: [
          /* @__PURE__ */ jsx6("div", { className: `text-xs mb-2 font-mono truncate ${muted}`, children: folderPicker.current }),
          /* @__PURE__ */ jsx6("div", { className: "flex flex-wrap gap-1 mb-2", children: folderPicker.volumes.map((v) => /* @__PURE__ */ jsx6("button", { type: "button", onClick: () => browsePicker(v.path), className: "text-xs px-2 py-0.5 rounded bg-teal-600/20 text-teal-600", children: v.label }, v.path)) }),
          folderPicker.parent && /* @__PURE__ */ jsxs3("button", { type: "button", onClick: () => browsePicker(folderPicker.parent), className: "text-sm text-teal-500 mb-2 flex items-center gap-1", children: [
            /* @__PURE__ */ jsx6(Icons3.ArrowUp, { className: "w-4 h-4" }),
            " .."
          ] }),
          /* @__PURE__ */ jsx6("div", { className: `max-h-48 overflow-y-auto border rounded mb-3 ${isDark ? "border-slate-700" : "border-slate-200"}`, children: folderPicker.entries.map((e) => /* @__PURE__ */ jsxs3(
            "button",
            {
              type: "button",
              onClick: () => browsePicker(e.path),
              className: `w-full text-left px-3 py-1.5 text-sm flex items-center gap-2 ${hoverRow}`,
              children: [
                /* @__PURE__ */ jsx6(Icons3.Folder, { className: "w-4 h-4 text-amber-500" }),
                e.name
              ]
            },
            e.path
          )) }),
          /* @__PURE__ */ jsx6(
            "button",
            {
              type: "button",
              onClick: () => pickFolder(folderPicker.current),
              className: "w-full py-2 text-sm rounded bg-teal-600 text-white hover:bg-teal-500",
              children: t.useThisFolder
            }
          )
        ] })
      }
    )
  ] }) });
}
export {
  AudioStation as default
};
