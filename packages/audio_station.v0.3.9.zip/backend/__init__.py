"""Audio Player module."""
