var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);

// src/modules/rsync_manager/index.tsx
import { useCallback, useEffect as useEffect3, useMemo, useState as useState3 } from "react";
import { useSearchParams } from "react-router-dom";

// src/core/hooks/useAppShellContext.ts
import { useOutletContext } from "react-router-dom";

// src/core/shell/ShellContext.tsx
import { createContext, useContext } from "react";
import { jsx } from "react/jsx-runtime";
var ShellContext = createContext(null);
function useShellContext() {
  return useContext(ShellContext);
}

// src/core/hooks/useAppShellContext.ts
var FALLBACK = {
  theme: localStorage.getItem("copanel_theme") || "light",
  setTheme: () => {
  },
  language: localStorage.getItem("copanel_lang") || "en",
  setLanguage: () => {
  }
};
function useAppShellContext() {
  const shell = useShellContext();
  const outlet = useOutletContext();
  if (shell) return shell;
  if (outlet?.theme) {
    return {
      theme: outlet.theme,
      setTheme: outlet.setTheme ?? (() => {
      }),
      language: outlet.language ?? "en",
      setLanguage: outlet.setLanguage ?? (() => {
      })
    };
  }
  return FALLBACK;
}

// src/core/shell/WindowViewportContext.tsx
import { createContext as createContext2, useContext as useContext2, useRef } from "react";
import { jsx as jsx2 } from "react/jsx-runtime";
var WindowViewportContext = createContext2(null);
function useWindowViewport() {
  return useContext2(WindowViewportContext);
}
function useIsWindowedModule() {
  return useWindowViewport()?.isWindowed === true;
}

// node_modules/clsx/dist/clsx.mjs
function r(e) {
  var t, f, n = "";
  if ("string" == typeof e || "number" == typeof e) n += e;
  else if ("object" == typeof e) if (Array.isArray(e)) {
    var o = e.length;
    for (t = 0; t < o; t++) e[t] && (f = r(e[t])) && (n && (n += " "), n += f);
  } else for (f in e) e[f] && (n && (n += " "), n += f);
  return n;
}
function clsx() {
  for (var e, t, f = 0, n = "", o = arguments.length; f < o; f++) (e = arguments[f]) && (t = r(e)) && (n && (n += " "), n += t);
  return n;
}

// node_modules/tailwind-merge/dist/bundle-mjs.mjs
var CLASS_PART_SEPARATOR = "-";
var createClassGroupUtils = (config) => {
  const classMap = createClassMap(config);
  const {
    conflictingClassGroups,
    conflictingClassGroupModifiers
  } = config;
  const getClassGroupId = (className) => {
    const classParts = className.split(CLASS_PART_SEPARATOR);
    if (classParts[0] === "" && classParts.length !== 1) {
      classParts.shift();
    }
    return getGroupRecursive(classParts, classMap) || getGroupIdForArbitraryProperty(className);
  };
  const getConflictingClassGroupIds = (classGroupId, hasPostfixModifier) => {
    const conflicts = conflictingClassGroups[classGroupId] || [];
    if (hasPostfixModifier && conflictingClassGroupModifiers[classGroupId]) {
      return [...conflicts, ...conflictingClassGroupModifiers[classGroupId]];
    }
    return conflicts;
  };
  return {
    getClassGroupId,
    getConflictingClassGroupIds
  };
};
var getGroupRecursive = (classParts, classPartObject) => {
  if (classParts.length === 0) {
    return classPartObject.classGroupId;
  }
  const currentClassPart = classParts[0];
  const nextClassPartObject = classPartObject.nextPart.get(currentClassPart);
  const classGroupFromNextClassPart = nextClassPartObject ? getGroupRecursive(classParts.slice(1), nextClassPartObject) : void 0;
  if (classGroupFromNextClassPart) {
    return classGroupFromNextClassPart;
  }
  if (classPartObject.validators.length === 0) {
    return void 0;
  }
  const classRest = classParts.join(CLASS_PART_SEPARATOR);
  return classPartObject.validators.find(({
    validator
  }) => validator(classRest))?.classGroupId;
};
var arbitraryPropertyRegex = /^\[(.+)\]$/;
var getGroupIdForArbitraryProperty = (className) => {
  if (arbitraryPropertyRegex.test(className)) {
    const arbitraryPropertyClassName = arbitraryPropertyRegex.exec(className)[1];
    const property = arbitraryPropertyClassName?.substring(0, arbitraryPropertyClassName.indexOf(":"));
    if (property) {
      return "arbitrary.." + property;
    }
  }
};
var createClassMap = (config) => {
  const {
    theme,
    prefix
  } = config;
  const classMap = {
    nextPart: /* @__PURE__ */ new Map(),
    validators: []
  };
  const prefixedClassGroupEntries = getPrefixedClassGroupEntries(Object.entries(config.classGroups), prefix);
  prefixedClassGroupEntries.forEach(([classGroupId, classGroup]) => {
    processClassesRecursively(classGroup, classMap, classGroupId, theme);
  });
  return classMap;
};
var processClassesRecursively = (classGroup, classPartObject, classGroupId, theme) => {
  classGroup.forEach((classDefinition) => {
    if (typeof classDefinition === "string") {
      const classPartObjectToEdit = classDefinition === "" ? classPartObject : getPart(classPartObject, classDefinition);
      classPartObjectToEdit.classGroupId = classGroupId;
      return;
    }
    if (typeof classDefinition === "function") {
      if (isThemeGetter(classDefinition)) {
        processClassesRecursively(classDefinition(theme), classPartObject, classGroupId, theme);
        return;
      }
      classPartObject.validators.push({
        validator: classDefinition,
        classGroupId
      });
      return;
    }
    Object.entries(classDefinition).forEach(([key, classGroup2]) => {
      processClassesRecursively(classGroup2, getPart(classPartObject, key), classGroupId, theme);
    });
  });
};
var getPart = (classPartObject, path) => {
  let currentClassPartObject = classPartObject;
  path.split(CLASS_PART_SEPARATOR).forEach((pathPart) => {
    if (!currentClassPartObject.nextPart.has(pathPart)) {
      currentClassPartObject.nextPart.set(pathPart, {
        nextPart: /* @__PURE__ */ new Map(),
        validators: []
      });
    }
    currentClassPartObject = currentClassPartObject.nextPart.get(pathPart);
  });
  return currentClassPartObject;
};
var isThemeGetter = (func) => func.isThemeGetter;
var getPrefixedClassGroupEntries = (classGroupEntries, prefix) => {
  if (!prefix) {
    return classGroupEntries;
  }
  return classGroupEntries.map(([classGroupId, classGroup]) => {
    const prefixedClassGroup = classGroup.map((classDefinition) => {
      if (typeof classDefinition === "string") {
        return prefix + classDefinition;
      }
      if (typeof classDefinition === "object") {
        return Object.fromEntries(Object.entries(classDefinition).map(([key, value]) => [prefix + key, value]));
      }
      return classDefinition;
    });
    return [classGroupId, prefixedClassGroup];
  });
};
var createLruCache = (maxCacheSize) => {
  if (maxCacheSize < 1) {
    return {
      get: () => void 0,
      set: () => {
      }
    };
  }
  let cacheSize = 0;
  let cache = /* @__PURE__ */ new Map();
  let previousCache = /* @__PURE__ */ new Map();
  const update = (key, value) => {
    cache.set(key, value);
    cacheSize++;
    if (cacheSize > maxCacheSize) {
      cacheSize = 0;
      previousCache = cache;
      cache = /* @__PURE__ */ new Map();
    }
  };
  return {
    get(key) {
      let value = cache.get(key);
      if (value !== void 0) {
        return value;
      }
      if ((value = previousCache.get(key)) !== void 0) {
        update(key, value);
        return value;
      }
    },
    set(key, value) {
      if (cache.has(key)) {
        cache.set(key, value);
      } else {
        update(key, value);
      }
    }
  };
};
var IMPORTANT_MODIFIER = "!";
var createParseClassName = (config) => {
  const {
    separator,
    experimentalParseClassName
  } = config;
  const isSeparatorSingleCharacter = separator.length === 1;
  const firstSeparatorCharacter = separator[0];
  const separatorLength = separator.length;
  const parseClassName = (className) => {
    const modifiers = [];
    let bracketDepth = 0;
    let modifierStart = 0;
    let postfixModifierPosition;
    for (let index = 0; index < className.length; index++) {
      let currentCharacter = className[index];
      if (bracketDepth === 0) {
        if (currentCharacter === firstSeparatorCharacter && (isSeparatorSingleCharacter || className.slice(index, index + separatorLength) === separator)) {
          modifiers.push(className.slice(modifierStart, index));
          modifierStart = index + separatorLength;
          continue;
        }
        if (currentCharacter === "/") {
          postfixModifierPosition = index;
          continue;
        }
      }
      if (currentCharacter === "[") {
        bracketDepth++;
      } else if (currentCharacter === "]") {
        bracketDepth--;
      }
    }
    const baseClassNameWithImportantModifier = modifiers.length === 0 ? className : className.substring(modifierStart);
    const hasImportantModifier = baseClassNameWithImportantModifier.startsWith(IMPORTANT_MODIFIER);
    const baseClassName = hasImportantModifier ? baseClassNameWithImportantModifier.substring(1) : baseClassNameWithImportantModifier;
    const maybePostfixModifierPosition = postfixModifierPosition && postfixModifierPosition > modifierStart ? postfixModifierPosition - modifierStart : void 0;
    return {
      modifiers,
      hasImportantModifier,
      baseClassName,
      maybePostfixModifierPosition
    };
  };
  if (experimentalParseClassName) {
    return (className) => experimentalParseClassName({
      className,
      parseClassName
    });
  }
  return parseClassName;
};
var sortModifiers = (modifiers) => {
  if (modifiers.length <= 1) {
    return modifiers;
  }
  const sortedModifiers = [];
  let unsortedModifiers = [];
  modifiers.forEach((modifier) => {
    const isArbitraryVariant = modifier[0] === "[";
    if (isArbitraryVariant) {
      sortedModifiers.push(...unsortedModifiers.sort(), modifier);
      unsortedModifiers = [];
    } else {
      unsortedModifiers.push(modifier);
    }
  });
  sortedModifiers.push(...unsortedModifiers.sort());
  return sortedModifiers;
};
var createConfigUtils = (config) => ({
  cache: createLruCache(config.cacheSize),
  parseClassName: createParseClassName(config),
  ...createClassGroupUtils(config)
});
var SPLIT_CLASSES_REGEX = /\s+/;
var mergeClassList = (classList, configUtils) => {
  const {
    parseClassName,
    getClassGroupId,
    getConflictingClassGroupIds
  } = configUtils;
  const classGroupsInConflict = [];
  const classNames = classList.trim().split(SPLIT_CLASSES_REGEX);
  let result = "";
  for (let index = classNames.length - 1; index >= 0; index -= 1) {
    const originalClassName = classNames[index];
    const {
      modifiers,
      hasImportantModifier,
      baseClassName,
      maybePostfixModifierPosition
    } = parseClassName(originalClassName);
    let hasPostfixModifier = Boolean(maybePostfixModifierPosition);
    let classGroupId = getClassGroupId(hasPostfixModifier ? baseClassName.substring(0, maybePostfixModifierPosition) : baseClassName);
    if (!classGroupId) {
      if (!hasPostfixModifier) {
        result = originalClassName + (result.length > 0 ? " " + result : result);
        continue;
      }
      classGroupId = getClassGroupId(baseClassName);
      if (!classGroupId) {
        result = originalClassName + (result.length > 0 ? " " + result : result);
        continue;
      }
      hasPostfixModifier = false;
    }
    const variantModifier = sortModifiers(modifiers).join(":");
    const modifierId = hasImportantModifier ? variantModifier + IMPORTANT_MODIFIER : variantModifier;
    const classId = modifierId + classGroupId;
    if (classGroupsInConflict.includes(classId)) {
      continue;
    }
    classGroupsInConflict.push(classId);
    const conflictGroups = getConflictingClassGroupIds(classGroupId, hasPostfixModifier);
    for (let i = 0; i < conflictGroups.length; ++i) {
      const group = conflictGroups[i];
      classGroupsInConflict.push(modifierId + group);
    }
    result = originalClassName + (result.length > 0 ? " " + result : result);
  }
  return result;
};
function twJoin() {
  let index = 0;
  let argument;
  let resolvedValue;
  let string = "";
  while (index < arguments.length) {
    if (argument = arguments[index++]) {
      if (resolvedValue = toValue(argument)) {
        string && (string += " ");
        string += resolvedValue;
      }
    }
  }
  return string;
}
var toValue = (mix) => {
  if (typeof mix === "string") {
    return mix;
  }
  let resolvedValue;
  let string = "";
  for (let k = 0; k < mix.length; k++) {
    if (mix[k]) {
      if (resolvedValue = toValue(mix[k])) {
        string && (string += " ");
        string += resolvedValue;
      }
    }
  }
  return string;
};
function createTailwindMerge(createConfigFirst, ...createConfigRest) {
  let configUtils;
  let cacheGet;
  let cacheSet;
  let functionToCall = initTailwindMerge;
  function initTailwindMerge(classList) {
    const config = createConfigRest.reduce((previousConfig, createConfigCurrent) => createConfigCurrent(previousConfig), createConfigFirst());
    configUtils = createConfigUtils(config);
    cacheGet = configUtils.cache.get;
    cacheSet = configUtils.cache.set;
    functionToCall = tailwindMerge;
    return tailwindMerge(classList);
  }
  function tailwindMerge(classList) {
    const cachedResult = cacheGet(classList);
    if (cachedResult) {
      return cachedResult;
    }
    const result = mergeClassList(classList, configUtils);
    cacheSet(classList, result);
    return result;
  }
  return function callTailwindMerge() {
    return functionToCall(twJoin.apply(null, arguments));
  };
}
var fromTheme = (key) => {
  const themeGetter = (theme) => theme[key] || [];
  themeGetter.isThemeGetter = true;
  return themeGetter;
};
var arbitraryValueRegex = /^\[(?:([a-z-]+):)?(.+)\]$/i;
var fractionRegex = /^\d+\/\d+$/;
var stringLengths = /* @__PURE__ */ new Set(["px", "full", "screen"]);
var tshirtUnitRegex = /^(\d+(\.\d+)?)?(xs|sm|md|lg|xl)$/;
var lengthUnitRegex = /\d+(%|px|r?em|[sdl]?v([hwib]|min|max)|pt|pc|in|cm|mm|cap|ch|ex|r?lh|cq(w|h|i|b|min|max))|\b(calc|min|max|clamp)\(.+\)|^0$/;
var colorFunctionRegex = /^(rgba?|hsla?|hwb|(ok)?(lab|lch)|color-mix)\(.+\)$/;
var shadowRegex = /^(inset_)?-?((\d+)?\.?(\d+)[a-z]+|0)_-?((\d+)?\.?(\d+)[a-z]+|0)/;
var imageRegex = /^(url|image|image-set|cross-fade|element|(repeating-)?(linear|radial|conic)-gradient)\(.+\)$/;
var isLength = (value) => isNumber(value) || stringLengths.has(value) || fractionRegex.test(value);
var isArbitraryLength = (value) => getIsArbitraryValue(value, "length", isLengthOnly);
var isNumber = (value) => Boolean(value) && !Number.isNaN(Number(value));
var isArbitraryNumber = (value) => getIsArbitraryValue(value, "number", isNumber);
var isInteger = (value) => Boolean(value) && Number.isInteger(Number(value));
var isPercent = (value) => value.endsWith("%") && isNumber(value.slice(0, -1));
var isArbitraryValue = (value) => arbitraryValueRegex.test(value);
var isTshirtSize = (value) => tshirtUnitRegex.test(value);
var sizeLabels = /* @__PURE__ */ new Set(["length", "size", "percentage"]);
var isArbitrarySize = (value) => getIsArbitraryValue(value, sizeLabels, isNever);
var isArbitraryPosition = (value) => getIsArbitraryValue(value, "position", isNever);
var imageLabels = /* @__PURE__ */ new Set(["image", "url"]);
var isArbitraryImage = (value) => getIsArbitraryValue(value, imageLabels, isImage);
var isArbitraryShadow = (value) => getIsArbitraryValue(value, "", isShadow);
var isAny = () => true;
var getIsArbitraryValue = (value, label, testValue) => {
  const result = arbitraryValueRegex.exec(value);
  if (result) {
    if (result[1]) {
      return typeof label === "string" ? result[1] === label : label.has(result[1]);
    }
    return testValue(result[2]);
  }
  return false;
};
var isLengthOnly = (value) => (
  // `colorFunctionRegex` check is necessary because color functions can have percentages in them which which would be incorrectly classified as lengths.
  // For example, `hsl(0 0% 0%)` would be classified as a length without this check.
  // I could also use lookbehind assertion in `lengthUnitRegex` but that isn't supported widely enough.
  lengthUnitRegex.test(value) && !colorFunctionRegex.test(value)
);
var isNever = () => false;
var isShadow = (value) => shadowRegex.test(value);
var isImage = (value) => imageRegex.test(value);
var getDefaultConfig = () => {
  const colors = fromTheme("colors");
  const spacing = fromTheme("spacing");
  const blur = fromTheme("blur");
  const brightness = fromTheme("brightness");
  const borderColor = fromTheme("borderColor");
  const borderRadius = fromTheme("borderRadius");
  const borderSpacing = fromTheme("borderSpacing");
  const borderWidth = fromTheme("borderWidth");
  const contrast = fromTheme("contrast");
  const grayscale = fromTheme("grayscale");
  const hueRotate = fromTheme("hueRotate");
  const invert = fromTheme("invert");
  const gap = fromTheme("gap");
  const gradientColorStops = fromTheme("gradientColorStops");
  const gradientColorStopPositions = fromTheme("gradientColorStopPositions");
  const inset = fromTheme("inset");
  const margin = fromTheme("margin");
  const opacity = fromTheme("opacity");
  const padding = fromTheme("padding");
  const saturate = fromTheme("saturate");
  const scale = fromTheme("scale");
  const sepia = fromTheme("sepia");
  const skew = fromTheme("skew");
  const space = fromTheme("space");
  const translate = fromTheme("translate");
  const getOverscroll = () => ["auto", "contain", "none"];
  const getOverflow = () => ["auto", "hidden", "clip", "visible", "scroll"];
  const getSpacingWithAutoAndArbitrary = () => ["auto", isArbitraryValue, spacing];
  const getSpacingWithArbitrary = () => [isArbitraryValue, spacing];
  const getLengthWithEmptyAndArbitrary = () => ["", isLength, isArbitraryLength];
  const getNumberWithAutoAndArbitrary = () => ["auto", isNumber, isArbitraryValue];
  const getPositions = () => ["bottom", "center", "left", "left-bottom", "left-top", "right", "right-bottom", "right-top", "top"];
  const getLineStyles = () => ["solid", "dashed", "dotted", "double", "none"];
  const getBlendModes = () => ["normal", "multiply", "screen", "overlay", "darken", "lighten", "color-dodge", "color-burn", "hard-light", "soft-light", "difference", "exclusion", "hue", "saturation", "color", "luminosity"];
  const getAlign = () => ["start", "end", "center", "between", "around", "evenly", "stretch"];
  const getZeroAndEmpty = () => ["", "0", isArbitraryValue];
  const getBreaks = () => ["auto", "avoid", "all", "avoid-page", "page", "left", "right", "column"];
  const getNumberAndArbitrary = () => [isNumber, isArbitraryValue];
  return {
    cacheSize: 500,
    separator: ":",
    theme: {
      colors: [isAny],
      spacing: [isLength, isArbitraryLength],
      blur: ["none", "", isTshirtSize, isArbitraryValue],
      brightness: getNumberAndArbitrary(),
      borderColor: [colors],
      borderRadius: ["none", "", "full", isTshirtSize, isArbitraryValue],
      borderSpacing: getSpacingWithArbitrary(),
      borderWidth: getLengthWithEmptyAndArbitrary(),
      contrast: getNumberAndArbitrary(),
      grayscale: getZeroAndEmpty(),
      hueRotate: getNumberAndArbitrary(),
      invert: getZeroAndEmpty(),
      gap: getSpacingWithArbitrary(),
      gradientColorStops: [colors],
      gradientColorStopPositions: [isPercent, isArbitraryLength],
      inset: getSpacingWithAutoAndArbitrary(),
      margin: getSpacingWithAutoAndArbitrary(),
      opacity: getNumberAndArbitrary(),
      padding: getSpacingWithArbitrary(),
      saturate: getNumberAndArbitrary(),
      scale: getNumberAndArbitrary(),
      sepia: getZeroAndEmpty(),
      skew: getNumberAndArbitrary(),
      space: getSpacingWithArbitrary(),
      translate: getSpacingWithArbitrary()
    },
    classGroups: {
      // Layout
      /**
       * Aspect Ratio
       * @see https://tailwindcss.com/docs/aspect-ratio
       */
      aspect: [{
        aspect: ["auto", "square", "video", isArbitraryValue]
      }],
      /**
       * Container
       * @see https://tailwindcss.com/docs/container
       */
      container: ["container"],
      /**
       * Columns
       * @see https://tailwindcss.com/docs/columns
       */
      columns: [{
        columns: [isTshirtSize]
      }],
      /**
       * Break After
       * @see https://tailwindcss.com/docs/break-after
       */
      "break-after": [{
        "break-after": getBreaks()
      }],
      /**
       * Break Before
       * @see https://tailwindcss.com/docs/break-before
       */
      "break-before": [{
        "break-before": getBreaks()
      }],
      /**
       * Break Inside
       * @see https://tailwindcss.com/docs/break-inside
       */
      "break-inside": [{
        "break-inside": ["auto", "avoid", "avoid-page", "avoid-column"]
      }],
      /**
       * Box Decoration Break
       * @see https://tailwindcss.com/docs/box-decoration-break
       */
      "box-decoration": [{
        "box-decoration": ["slice", "clone"]
      }],
      /**
       * Box Sizing
       * @see https://tailwindcss.com/docs/box-sizing
       */
      box: [{
        box: ["border", "content"]
      }],
      /**
       * Display
       * @see https://tailwindcss.com/docs/display
       */
      display: ["block", "inline-block", "inline", "flex", "inline-flex", "table", "inline-table", "table-caption", "table-cell", "table-column", "table-column-group", "table-footer-group", "table-header-group", "table-row-group", "table-row", "flow-root", "grid", "inline-grid", "contents", "list-item", "hidden"],
      /**
       * Floats
       * @see https://tailwindcss.com/docs/float
       */
      float: [{
        float: ["right", "left", "none", "start", "end"]
      }],
      /**
       * Clear
       * @see https://tailwindcss.com/docs/clear
       */
      clear: [{
        clear: ["left", "right", "both", "none", "start", "end"]
      }],
      /**
       * Isolation
       * @see https://tailwindcss.com/docs/isolation
       */
      isolation: ["isolate", "isolation-auto"],
      /**
       * Object Fit
       * @see https://tailwindcss.com/docs/object-fit
       */
      "object-fit": [{
        object: ["contain", "cover", "fill", "none", "scale-down"]
      }],
      /**
       * Object Position
       * @see https://tailwindcss.com/docs/object-position
       */
      "object-position": [{
        object: [...getPositions(), isArbitraryValue]
      }],
      /**
       * Overflow
       * @see https://tailwindcss.com/docs/overflow
       */
      overflow: [{
        overflow: getOverflow()
      }],
      /**
       * Overflow X
       * @see https://tailwindcss.com/docs/overflow
       */
      "overflow-x": [{
        "overflow-x": getOverflow()
      }],
      /**
       * Overflow Y
       * @see https://tailwindcss.com/docs/overflow
       */
      "overflow-y": [{
        "overflow-y": getOverflow()
      }],
      /**
       * Overscroll Behavior
       * @see https://tailwindcss.com/docs/overscroll-behavior
       */
      overscroll: [{
        overscroll: getOverscroll()
      }],
      /**
       * Overscroll Behavior X
       * @see https://tailwindcss.com/docs/overscroll-behavior
       */
      "overscroll-x": [{
        "overscroll-x": getOverscroll()
      }],
      /**
       * Overscroll Behavior Y
       * @see https://tailwindcss.com/docs/overscroll-behavior
       */
      "overscroll-y": [{
        "overscroll-y": getOverscroll()
      }],
      /**
       * Position
       * @see https://tailwindcss.com/docs/position
       */
      position: ["static", "fixed", "absolute", "relative", "sticky"],
      /**
       * Top / Right / Bottom / Left
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      inset: [{
        inset: [inset]
      }],
      /**
       * Right / Left
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      "inset-x": [{
        "inset-x": [inset]
      }],
      /**
       * Top / Bottom
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      "inset-y": [{
        "inset-y": [inset]
      }],
      /**
       * Start
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      start: [{
        start: [inset]
      }],
      /**
       * End
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      end: [{
        end: [inset]
      }],
      /**
       * Top
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      top: [{
        top: [inset]
      }],
      /**
       * Right
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      right: [{
        right: [inset]
      }],
      /**
       * Bottom
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      bottom: [{
        bottom: [inset]
      }],
      /**
       * Left
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      left: [{
        left: [inset]
      }],
      /**
       * Visibility
       * @see https://tailwindcss.com/docs/visibility
       */
      visibility: ["visible", "invisible", "collapse"],
      /**
       * Z-Index
       * @see https://tailwindcss.com/docs/z-index
       */
      z: [{
        z: ["auto", isInteger, isArbitraryValue]
      }],
      // Flexbox and Grid
      /**
       * Flex Basis
       * @see https://tailwindcss.com/docs/flex-basis
       */
      basis: [{
        basis: getSpacingWithAutoAndArbitrary()
      }],
      /**
       * Flex Direction
       * @see https://tailwindcss.com/docs/flex-direction
       */
      "flex-direction": [{
        flex: ["row", "row-reverse", "col", "col-reverse"]
      }],
      /**
       * Flex Wrap
       * @see https://tailwindcss.com/docs/flex-wrap
       */
      "flex-wrap": [{
        flex: ["wrap", "wrap-reverse", "nowrap"]
      }],
      /**
       * Flex
       * @see https://tailwindcss.com/docs/flex
       */
      flex: [{
        flex: ["1", "auto", "initial", "none", isArbitraryValue]
      }],
      /**
       * Flex Grow
       * @see https://tailwindcss.com/docs/flex-grow
       */
      grow: [{
        grow: getZeroAndEmpty()
      }],
      /**
       * Flex Shrink
       * @see https://tailwindcss.com/docs/flex-shrink
       */
      shrink: [{
        shrink: getZeroAndEmpty()
      }],
      /**
       * Order
       * @see https://tailwindcss.com/docs/order
       */
      order: [{
        order: ["first", "last", "none", isInteger, isArbitraryValue]
      }],
      /**
       * Grid Template Columns
       * @see https://tailwindcss.com/docs/grid-template-columns
       */
      "grid-cols": [{
        "grid-cols": [isAny]
      }],
      /**
       * Grid Column Start / End
       * @see https://tailwindcss.com/docs/grid-column
       */
      "col-start-end": [{
        col: ["auto", {
          span: ["full", isInteger, isArbitraryValue]
        }, isArbitraryValue]
      }],
      /**
       * Grid Column Start
       * @see https://tailwindcss.com/docs/grid-column
       */
      "col-start": [{
        "col-start": getNumberWithAutoAndArbitrary()
      }],
      /**
       * Grid Column End
       * @see https://tailwindcss.com/docs/grid-column
       */
      "col-end": [{
        "col-end": getNumberWithAutoAndArbitrary()
      }],
      /**
       * Grid Template Rows
       * @see https://tailwindcss.com/docs/grid-template-rows
       */
      "grid-rows": [{
        "grid-rows": [isAny]
      }],
      /**
       * Grid Row Start / End
       * @see https://tailwindcss.com/docs/grid-row
       */
      "row-start-end": [{
        row: ["auto", {
          span: [isInteger, isArbitraryValue]
        }, isArbitraryValue]
      }],
      /**
       * Grid Row Start
       * @see https://tailwindcss.com/docs/grid-row
       */
      "row-start": [{
        "row-start": getNumberWithAutoAndArbitrary()
      }],
      /**
       * Grid Row End
       * @see https://tailwindcss.com/docs/grid-row
       */
      "row-end": [{
        "row-end": getNumberWithAutoAndArbitrary()
      }],
      /**
       * Grid Auto Flow
       * @see https://tailwindcss.com/docs/grid-auto-flow
       */
      "grid-flow": [{
        "grid-flow": ["row", "col", "dense", "row-dense", "col-dense"]
      }],
      /**
       * Grid Auto Columns
       * @see https://tailwindcss.com/docs/grid-auto-columns
       */
      "auto-cols": [{
        "auto-cols": ["auto", "min", "max", "fr", isArbitraryValue]
      }],
      /**
       * Grid Auto Rows
       * @see https://tailwindcss.com/docs/grid-auto-rows
       */
      "auto-rows": [{
        "auto-rows": ["auto", "min", "max", "fr", isArbitraryValue]
      }],
      /**
       * Gap
       * @see https://tailwindcss.com/docs/gap
       */
      gap: [{
        gap: [gap]
      }],
      /**
       * Gap X
       * @see https://tailwindcss.com/docs/gap
       */
      "gap-x": [{
        "gap-x": [gap]
      }],
      /**
       * Gap Y
       * @see https://tailwindcss.com/docs/gap
       */
      "gap-y": [{
        "gap-y": [gap]
      }],
      /**
       * Justify Content
       * @see https://tailwindcss.com/docs/justify-content
       */
      "justify-content": [{
        justify: ["normal", ...getAlign()]
      }],
      /**
       * Justify Items
       * @see https://tailwindcss.com/docs/justify-items
       */
      "justify-items": [{
        "justify-items": ["start", "end", "center", "stretch"]
      }],
      /**
       * Justify Self
       * @see https://tailwindcss.com/docs/justify-self
       */
      "justify-self": [{
        "justify-self": ["auto", "start", "end", "center", "stretch"]
      }],
      /**
       * Align Content
       * @see https://tailwindcss.com/docs/align-content
       */
      "align-content": [{
        content: ["normal", ...getAlign(), "baseline"]
      }],
      /**
       * Align Items
       * @see https://tailwindcss.com/docs/align-items
       */
      "align-items": [{
        items: ["start", "end", "center", "baseline", "stretch"]
      }],
      /**
       * Align Self
       * @see https://tailwindcss.com/docs/align-self
       */
      "align-self": [{
        self: ["auto", "start", "end", "center", "stretch", "baseline"]
      }],
      /**
       * Place Content
       * @see https://tailwindcss.com/docs/place-content
       */
      "place-content": [{
        "place-content": [...getAlign(), "baseline"]
      }],
      /**
       * Place Items
       * @see https://tailwindcss.com/docs/place-items
       */
      "place-items": [{
        "place-items": ["start", "end", "center", "baseline", "stretch"]
      }],
      /**
       * Place Self
       * @see https://tailwindcss.com/docs/place-self
       */
      "place-self": [{
        "place-self": ["auto", "start", "end", "center", "stretch"]
      }],
      // Spacing
      /**
       * Padding
       * @see https://tailwindcss.com/docs/padding
       */
      p: [{
        p: [padding]
      }],
      /**
       * Padding X
       * @see https://tailwindcss.com/docs/padding
       */
      px: [{
        px: [padding]
      }],
      /**
       * Padding Y
       * @see https://tailwindcss.com/docs/padding
       */
      py: [{
        py: [padding]
      }],
      /**
       * Padding Start
       * @see https://tailwindcss.com/docs/padding
       */
      ps: [{
        ps: [padding]
      }],
      /**
       * Padding End
       * @see https://tailwindcss.com/docs/padding
       */
      pe: [{
        pe: [padding]
      }],
      /**
       * Padding Top
       * @see https://tailwindcss.com/docs/padding
       */
      pt: [{
        pt: [padding]
      }],
      /**
       * Padding Right
       * @see https://tailwindcss.com/docs/padding
       */
      pr: [{
        pr: [padding]
      }],
      /**
       * Padding Bottom
       * @see https://tailwindcss.com/docs/padding
       */
      pb: [{
        pb: [padding]
      }],
      /**
       * Padding Left
       * @see https://tailwindcss.com/docs/padding
       */
      pl: [{
        pl: [padding]
      }],
      /**
       * Margin
       * @see https://tailwindcss.com/docs/margin
       */
      m: [{
        m: [margin]
      }],
      /**
       * Margin X
       * @see https://tailwindcss.com/docs/margin
       */
      mx: [{
        mx: [margin]
      }],
      /**
       * Margin Y
       * @see https://tailwindcss.com/docs/margin
       */
      my: [{
        my: [margin]
      }],
      /**
       * Margin Start
       * @see https://tailwindcss.com/docs/margin
       */
      ms: [{
        ms: [margin]
      }],
      /**
       * Margin End
       * @see https://tailwindcss.com/docs/margin
       */
      me: [{
        me: [margin]
      }],
      /**
       * Margin Top
       * @see https://tailwindcss.com/docs/margin
       */
      mt: [{
        mt: [margin]
      }],
      /**
       * Margin Right
       * @see https://tailwindcss.com/docs/margin
       */
      mr: [{
        mr: [margin]
      }],
      /**
       * Margin Bottom
       * @see https://tailwindcss.com/docs/margin
       */
      mb: [{
        mb: [margin]
      }],
      /**
       * Margin Left
       * @see https://tailwindcss.com/docs/margin
       */
      ml: [{
        ml: [margin]
      }],
      /**
       * Space Between X
       * @see https://tailwindcss.com/docs/space
       */
      "space-x": [{
        "space-x": [space]
      }],
      /**
       * Space Between X Reverse
       * @see https://tailwindcss.com/docs/space
       */
      "space-x-reverse": ["space-x-reverse"],
      /**
       * Space Between Y
       * @see https://tailwindcss.com/docs/space
       */
      "space-y": [{
        "space-y": [space]
      }],
      /**
       * Space Between Y Reverse
       * @see https://tailwindcss.com/docs/space
       */
      "space-y-reverse": ["space-y-reverse"],
      // Sizing
      /**
       * Width
       * @see https://tailwindcss.com/docs/width
       */
      w: [{
        w: ["auto", "min", "max", "fit", "svw", "lvw", "dvw", isArbitraryValue, spacing]
      }],
      /**
       * Min-Width
       * @see https://tailwindcss.com/docs/min-width
       */
      "min-w": [{
        "min-w": [isArbitraryValue, spacing, "min", "max", "fit"]
      }],
      /**
       * Max-Width
       * @see https://tailwindcss.com/docs/max-width
       */
      "max-w": [{
        "max-w": [isArbitraryValue, spacing, "none", "full", "min", "max", "fit", "prose", {
          screen: [isTshirtSize]
        }, isTshirtSize]
      }],
      /**
       * Height
       * @see https://tailwindcss.com/docs/height
       */
      h: [{
        h: [isArbitraryValue, spacing, "auto", "min", "max", "fit", "svh", "lvh", "dvh"]
      }],
      /**
       * Min-Height
       * @see https://tailwindcss.com/docs/min-height
       */
      "min-h": [{
        "min-h": [isArbitraryValue, spacing, "min", "max", "fit", "svh", "lvh", "dvh"]
      }],
      /**
       * Max-Height
       * @see https://tailwindcss.com/docs/max-height
       */
      "max-h": [{
        "max-h": [isArbitraryValue, spacing, "min", "max", "fit", "svh", "lvh", "dvh"]
      }],
      /**
       * Size
       * @see https://tailwindcss.com/docs/size
       */
      size: [{
        size: [isArbitraryValue, spacing, "auto", "min", "max", "fit"]
      }],
      // Typography
      /**
       * Font Size
       * @see https://tailwindcss.com/docs/font-size
       */
      "font-size": [{
        text: ["base", isTshirtSize, isArbitraryLength]
      }],
      /**
       * Font Smoothing
       * @see https://tailwindcss.com/docs/font-smoothing
       */
      "font-smoothing": ["antialiased", "subpixel-antialiased"],
      /**
       * Font Style
       * @see https://tailwindcss.com/docs/font-style
       */
      "font-style": ["italic", "not-italic"],
      /**
       * Font Weight
       * @see https://tailwindcss.com/docs/font-weight
       */
      "font-weight": [{
        font: ["thin", "extralight", "light", "normal", "medium", "semibold", "bold", "extrabold", "black", isArbitraryNumber]
      }],
      /**
       * Font Family
       * @see https://tailwindcss.com/docs/font-family
       */
      "font-family": [{
        font: [isAny]
      }],
      /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */
      "fvn-normal": ["normal-nums"],
      /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */
      "fvn-ordinal": ["ordinal"],
      /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */
      "fvn-slashed-zero": ["slashed-zero"],
      /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */
      "fvn-figure": ["lining-nums", "oldstyle-nums"],
      /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */
      "fvn-spacing": ["proportional-nums", "tabular-nums"],
      /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */
      "fvn-fraction": ["diagonal-fractions", "stacked-fractions"],
      /**
       * Letter Spacing
       * @see https://tailwindcss.com/docs/letter-spacing
       */
      tracking: [{
        tracking: ["tighter", "tight", "normal", "wide", "wider", "widest", isArbitraryValue]
      }],
      /**
       * Line Clamp
       * @see https://tailwindcss.com/docs/line-clamp
       */
      "line-clamp": [{
        "line-clamp": ["none", isNumber, isArbitraryNumber]
      }],
      /**
       * Line Height
       * @see https://tailwindcss.com/docs/line-height
       */
      leading: [{
        leading: ["none", "tight", "snug", "normal", "relaxed", "loose", isLength, isArbitraryValue]
      }],
      /**
       * List Style Image
       * @see https://tailwindcss.com/docs/list-style-image
       */
      "list-image": [{
        "list-image": ["none", isArbitraryValue]
      }],
      /**
       * List Style Type
       * @see https://tailwindcss.com/docs/list-style-type
       */
      "list-style-type": [{
        list: ["none", "disc", "decimal", isArbitraryValue]
      }],
      /**
       * List Style Position
       * @see https://tailwindcss.com/docs/list-style-position
       */
      "list-style-position": [{
        list: ["inside", "outside"]
      }],
      /**
       * Placeholder Color
       * @deprecated since Tailwind CSS v3.0.0
       * @see https://tailwindcss.com/docs/placeholder-color
       */
      "placeholder-color": [{
        placeholder: [colors]
      }],
      /**
       * Placeholder Opacity
       * @see https://tailwindcss.com/docs/placeholder-opacity
       */
      "placeholder-opacity": [{
        "placeholder-opacity": [opacity]
      }],
      /**
       * Text Alignment
       * @see https://tailwindcss.com/docs/text-align
       */
      "text-alignment": [{
        text: ["left", "center", "right", "justify", "start", "end"]
      }],
      /**
       * Text Color
       * @see https://tailwindcss.com/docs/text-color
       */
      "text-color": [{
        text: [colors]
      }],
      /**
       * Text Opacity
       * @see https://tailwindcss.com/docs/text-opacity
       */
      "text-opacity": [{
        "text-opacity": [opacity]
      }],
      /**
       * Text Decoration
       * @see https://tailwindcss.com/docs/text-decoration
       */
      "text-decoration": ["underline", "overline", "line-through", "no-underline"],
      /**
       * Text Decoration Style
       * @see https://tailwindcss.com/docs/text-decoration-style
       */
      "text-decoration-style": [{
        decoration: [...getLineStyles(), "wavy"]
      }],
      /**
       * Text Decoration Thickness
       * @see https://tailwindcss.com/docs/text-decoration-thickness
       */
      "text-decoration-thickness": [{
        decoration: ["auto", "from-font", isLength, isArbitraryLength]
      }],
      /**
       * Text Underline Offset
       * @see https://tailwindcss.com/docs/text-underline-offset
       */
      "underline-offset": [{
        "underline-offset": ["auto", isLength, isArbitraryValue]
      }],
      /**
       * Text Decoration Color
       * @see https://tailwindcss.com/docs/text-decoration-color
       */
      "text-decoration-color": [{
        decoration: [colors]
      }],
      /**
       * Text Transform
       * @see https://tailwindcss.com/docs/text-transform
       */
      "text-transform": ["uppercase", "lowercase", "capitalize", "normal-case"],
      /**
       * Text Overflow
       * @see https://tailwindcss.com/docs/text-overflow
       */
      "text-overflow": ["truncate", "text-ellipsis", "text-clip"],
      /**
       * Text Wrap
       * @see https://tailwindcss.com/docs/text-wrap
       */
      "text-wrap": [{
        text: ["wrap", "nowrap", "balance", "pretty"]
      }],
      /**
       * Text Indent
       * @see https://tailwindcss.com/docs/text-indent
       */
      indent: [{
        indent: getSpacingWithArbitrary()
      }],
      /**
       * Vertical Alignment
       * @see https://tailwindcss.com/docs/vertical-align
       */
      "vertical-align": [{
        align: ["baseline", "top", "middle", "bottom", "text-top", "text-bottom", "sub", "super", isArbitraryValue]
      }],
      /**
       * Whitespace
       * @see https://tailwindcss.com/docs/whitespace
       */
      whitespace: [{
        whitespace: ["normal", "nowrap", "pre", "pre-line", "pre-wrap", "break-spaces"]
      }],
      /**
       * Word Break
       * @see https://tailwindcss.com/docs/word-break
       */
      break: [{
        break: ["normal", "words", "all", "keep"]
      }],
      /**
       * Hyphens
       * @see https://tailwindcss.com/docs/hyphens
       */
      hyphens: [{
        hyphens: ["none", "manual", "auto"]
      }],
      /**
       * Content
       * @see https://tailwindcss.com/docs/content
       */
      content: [{
        content: ["none", isArbitraryValue]
      }],
      // Backgrounds
      /**
       * Background Attachment
       * @see https://tailwindcss.com/docs/background-attachment
       */
      "bg-attachment": [{
        bg: ["fixed", "local", "scroll"]
      }],
      /**
       * Background Clip
       * @see https://tailwindcss.com/docs/background-clip
       */
      "bg-clip": [{
        "bg-clip": ["border", "padding", "content", "text"]
      }],
      /**
       * Background Opacity
       * @deprecated since Tailwind CSS v3.0.0
       * @see https://tailwindcss.com/docs/background-opacity
       */
      "bg-opacity": [{
        "bg-opacity": [opacity]
      }],
      /**
       * Background Origin
       * @see https://tailwindcss.com/docs/background-origin
       */
      "bg-origin": [{
        "bg-origin": ["border", "padding", "content"]
      }],
      /**
       * Background Position
       * @see https://tailwindcss.com/docs/background-position
       */
      "bg-position": [{
        bg: [...getPositions(), isArbitraryPosition]
      }],
      /**
       * Background Repeat
       * @see https://tailwindcss.com/docs/background-repeat
       */
      "bg-repeat": [{
        bg: ["no-repeat", {
          repeat: ["", "x", "y", "round", "space"]
        }]
      }],
      /**
       * Background Size
       * @see https://tailwindcss.com/docs/background-size
       */
      "bg-size": [{
        bg: ["auto", "cover", "contain", isArbitrarySize]
      }],
      /**
       * Background Image
       * @see https://tailwindcss.com/docs/background-image
       */
      "bg-image": [{
        bg: ["none", {
          "gradient-to": ["t", "tr", "r", "br", "b", "bl", "l", "tl"]
        }, isArbitraryImage]
      }],
      /**
       * Background Color
       * @see https://tailwindcss.com/docs/background-color
       */
      "bg-color": [{
        bg: [colors]
      }],
      /**
       * Gradient Color Stops From Position
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */
      "gradient-from-pos": [{
        from: [gradientColorStopPositions]
      }],
      /**
       * Gradient Color Stops Via Position
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */
      "gradient-via-pos": [{
        via: [gradientColorStopPositions]
      }],
      /**
       * Gradient Color Stops To Position
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */
      "gradient-to-pos": [{
        to: [gradientColorStopPositions]
      }],
      /**
       * Gradient Color Stops From
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */
      "gradient-from": [{
        from: [gradientColorStops]
      }],
      /**
       * Gradient Color Stops Via
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */
      "gradient-via": [{
        via: [gradientColorStops]
      }],
      /**
       * Gradient Color Stops To
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */
      "gradient-to": [{
        to: [gradientColorStops]
      }],
      // Borders
      /**
       * Border Radius
       * @see https://tailwindcss.com/docs/border-radius
       */
      rounded: [{
        rounded: [borderRadius]
      }],
      /**
       * Border Radius Start
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-s": [{
        "rounded-s": [borderRadius]
      }],
      /**
       * Border Radius End
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-e": [{
        "rounded-e": [borderRadius]
      }],
      /**
       * Border Radius Top
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-t": [{
        "rounded-t": [borderRadius]
      }],
      /**
       * Border Radius Right
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-r": [{
        "rounded-r": [borderRadius]
      }],
      /**
       * Border Radius Bottom
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-b": [{
        "rounded-b": [borderRadius]
      }],
      /**
       * Border Radius Left
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-l": [{
        "rounded-l": [borderRadius]
      }],
      /**
       * Border Radius Start Start
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-ss": [{
        "rounded-ss": [borderRadius]
      }],
      /**
       * Border Radius Start End
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-se": [{
        "rounded-se": [borderRadius]
      }],
      /**
       * Border Radius End End
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-ee": [{
        "rounded-ee": [borderRadius]
      }],
      /**
       * Border Radius End Start
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-es": [{
        "rounded-es": [borderRadius]
      }],
      /**
       * Border Radius Top Left
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-tl": [{
        "rounded-tl": [borderRadius]
      }],
      /**
       * Border Radius Top Right
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-tr": [{
        "rounded-tr": [borderRadius]
      }],
      /**
       * Border Radius Bottom Right
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-br": [{
        "rounded-br": [borderRadius]
      }],
      /**
       * Border Radius Bottom Left
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-bl": [{
        "rounded-bl": [borderRadius]
      }],
      /**
       * Border Width
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w": [{
        border: [borderWidth]
      }],
      /**
       * Border Width X
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-x": [{
        "border-x": [borderWidth]
      }],
      /**
       * Border Width Y
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-y": [{
        "border-y": [borderWidth]
      }],
      /**
       * Border Width Start
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-s": [{
        "border-s": [borderWidth]
      }],
      /**
       * Border Width End
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-e": [{
        "border-e": [borderWidth]
      }],
      /**
       * Border Width Top
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-t": [{
        "border-t": [borderWidth]
      }],
      /**
       * Border Width Right
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-r": [{
        "border-r": [borderWidth]
      }],
      /**
       * Border Width Bottom
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-b": [{
        "border-b": [borderWidth]
      }],
      /**
       * Border Width Left
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-l": [{
        "border-l": [borderWidth]
      }],
      /**
       * Border Opacity
       * @see https://tailwindcss.com/docs/border-opacity
       */
      "border-opacity": [{
        "border-opacity": [opacity]
      }],
      /**
       * Border Style
       * @see https://tailwindcss.com/docs/border-style
       */
      "border-style": [{
        border: [...getLineStyles(), "hidden"]
      }],
      /**
       * Divide Width X
       * @see https://tailwindcss.com/docs/divide-width
       */
      "divide-x": [{
        "divide-x": [borderWidth]
      }],
      /**
       * Divide Width X Reverse
       * @see https://tailwindcss.com/docs/divide-width
       */
      "divide-x-reverse": ["divide-x-reverse"],
      /**
       * Divide Width Y
       * @see https://tailwindcss.com/docs/divide-width
       */
      "divide-y": [{
        "divide-y": [borderWidth]
      }],
      /**
       * Divide Width Y Reverse
       * @see https://tailwindcss.com/docs/divide-width
       */
      "divide-y-reverse": ["divide-y-reverse"],
      /**
       * Divide Opacity
       * @see https://tailwindcss.com/docs/divide-opacity
       */
      "divide-opacity": [{
        "divide-opacity": [opacity]
      }],
      /**
       * Divide Style
       * @see https://tailwindcss.com/docs/divide-style
       */
      "divide-style": [{
        divide: getLineStyles()
      }],
      /**
       * Border Color
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color": [{
        border: [borderColor]
      }],
      /**
       * Border Color X
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-x": [{
        "border-x": [borderColor]
      }],
      /**
       * Border Color Y
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-y": [{
        "border-y": [borderColor]
      }],
      /**
       * Border Color S
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-s": [{
        "border-s": [borderColor]
      }],
      /**
       * Border Color E
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-e": [{
        "border-e": [borderColor]
      }],
      /**
       * Border Color Top
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-t": [{
        "border-t": [borderColor]
      }],
      /**
       * Border Color Right
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-r": [{
        "border-r": [borderColor]
      }],
      /**
       * Border Color Bottom
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-b": [{
        "border-b": [borderColor]
      }],
      /**
       * Border Color Left
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-l": [{
        "border-l": [borderColor]
      }],
      /**
       * Divide Color
       * @see https://tailwindcss.com/docs/divide-color
       */
      "divide-color": [{
        divide: [borderColor]
      }],
      /**
       * Outline Style
       * @see https://tailwindcss.com/docs/outline-style
       */
      "outline-style": [{
        outline: ["", ...getLineStyles()]
      }],
      /**
       * Outline Offset
       * @see https://tailwindcss.com/docs/outline-offset
       */
      "outline-offset": [{
        "outline-offset": [isLength, isArbitraryValue]
      }],
      /**
       * Outline Width
       * @see https://tailwindcss.com/docs/outline-width
       */
      "outline-w": [{
        outline: [isLength, isArbitraryLength]
      }],
      /**
       * Outline Color
       * @see https://tailwindcss.com/docs/outline-color
       */
      "outline-color": [{
        outline: [colors]
      }],
      /**
       * Ring Width
       * @see https://tailwindcss.com/docs/ring-width
       */
      "ring-w": [{
        ring: getLengthWithEmptyAndArbitrary()
      }],
      /**
       * Ring Width Inset
       * @see https://tailwindcss.com/docs/ring-width
       */
      "ring-w-inset": ["ring-inset"],
      /**
       * Ring Color
       * @see https://tailwindcss.com/docs/ring-color
       */
      "ring-color": [{
        ring: [colors]
      }],
      /**
       * Ring Opacity
       * @see https://tailwindcss.com/docs/ring-opacity
       */
      "ring-opacity": [{
        "ring-opacity": [opacity]
      }],
      /**
       * Ring Offset Width
       * @see https://tailwindcss.com/docs/ring-offset-width
       */
      "ring-offset-w": [{
        "ring-offset": [isLength, isArbitraryLength]
      }],
      /**
       * Ring Offset Color
       * @see https://tailwindcss.com/docs/ring-offset-color
       */
      "ring-offset-color": [{
        "ring-offset": [colors]
      }],
      // Effects
      /**
       * Box Shadow
       * @see https://tailwindcss.com/docs/box-shadow
       */
      shadow: [{
        shadow: ["", "inner", "none", isTshirtSize, isArbitraryShadow]
      }],
      /**
       * Box Shadow Color
       * @see https://tailwindcss.com/docs/box-shadow-color
       */
      "shadow-color": [{
        shadow: [isAny]
      }],
      /**
       * Opacity
       * @see https://tailwindcss.com/docs/opacity
       */
      opacity: [{
        opacity: [opacity]
      }],
      /**
       * Mix Blend Mode
       * @see https://tailwindcss.com/docs/mix-blend-mode
       */
      "mix-blend": [{
        "mix-blend": [...getBlendModes(), "plus-lighter", "plus-darker"]
      }],
      /**
       * Background Blend Mode
       * @see https://tailwindcss.com/docs/background-blend-mode
       */
      "bg-blend": [{
        "bg-blend": getBlendModes()
      }],
      // Filters
      /**
       * Filter
       * @deprecated since Tailwind CSS v3.0.0
       * @see https://tailwindcss.com/docs/filter
       */
      filter: [{
        filter: ["", "none"]
      }],
      /**
       * Blur
       * @see https://tailwindcss.com/docs/blur
       */
      blur: [{
        blur: [blur]
      }],
      /**
       * Brightness
       * @see https://tailwindcss.com/docs/brightness
       */
      brightness: [{
        brightness: [brightness]
      }],
      /**
       * Contrast
       * @see https://tailwindcss.com/docs/contrast
       */
      contrast: [{
        contrast: [contrast]
      }],
      /**
       * Drop Shadow
       * @see https://tailwindcss.com/docs/drop-shadow
       */
      "drop-shadow": [{
        "drop-shadow": ["", "none", isTshirtSize, isArbitraryValue]
      }],
      /**
       * Grayscale
       * @see https://tailwindcss.com/docs/grayscale
       */
      grayscale: [{
        grayscale: [grayscale]
      }],
      /**
       * Hue Rotate
       * @see https://tailwindcss.com/docs/hue-rotate
       */
      "hue-rotate": [{
        "hue-rotate": [hueRotate]
      }],
      /**
       * Invert
       * @see https://tailwindcss.com/docs/invert
       */
      invert: [{
        invert: [invert]
      }],
      /**
       * Saturate
       * @see https://tailwindcss.com/docs/saturate
       */
      saturate: [{
        saturate: [saturate]
      }],
      /**
       * Sepia
       * @see https://tailwindcss.com/docs/sepia
       */
      sepia: [{
        sepia: [sepia]
      }],
      /**
       * Backdrop Filter
       * @deprecated since Tailwind CSS v3.0.0
       * @see https://tailwindcss.com/docs/backdrop-filter
       */
      "backdrop-filter": [{
        "backdrop-filter": ["", "none"]
      }],
      /**
       * Backdrop Blur
       * @see https://tailwindcss.com/docs/backdrop-blur
       */
      "backdrop-blur": [{
        "backdrop-blur": [blur]
      }],
      /**
       * Backdrop Brightness
       * @see https://tailwindcss.com/docs/backdrop-brightness
       */
      "backdrop-brightness": [{
        "backdrop-brightness": [brightness]
      }],
      /**
       * Backdrop Contrast
       * @see https://tailwindcss.com/docs/backdrop-contrast
       */
      "backdrop-contrast": [{
        "backdrop-contrast": [contrast]
      }],
      /**
       * Backdrop Grayscale
       * @see https://tailwindcss.com/docs/backdrop-grayscale
       */
      "backdrop-grayscale": [{
        "backdrop-grayscale": [grayscale]
      }],
      /**
       * Backdrop Hue Rotate
       * @see https://tailwindcss.com/docs/backdrop-hue-rotate
       */
      "backdrop-hue-rotate": [{
        "backdrop-hue-rotate": [hueRotate]
      }],
      /**
       * Backdrop Invert
       * @see https://tailwindcss.com/docs/backdrop-invert
       */
      "backdrop-invert": [{
        "backdrop-invert": [invert]
      }],
      /**
       * Backdrop Opacity
       * @see https://tailwindcss.com/docs/backdrop-opacity
       */
      "backdrop-opacity": [{
        "backdrop-opacity": [opacity]
      }],
      /**
       * Backdrop Saturate
       * @see https://tailwindcss.com/docs/backdrop-saturate
       */
      "backdrop-saturate": [{
        "backdrop-saturate": [saturate]
      }],
      /**
       * Backdrop Sepia
       * @see https://tailwindcss.com/docs/backdrop-sepia
       */
      "backdrop-sepia": [{
        "backdrop-sepia": [sepia]
      }],
      // Tables
      /**
       * Border Collapse
       * @see https://tailwindcss.com/docs/border-collapse
       */
      "border-collapse": [{
        border: ["collapse", "separate"]
      }],
      /**
       * Border Spacing
       * @see https://tailwindcss.com/docs/border-spacing
       */
      "border-spacing": [{
        "border-spacing": [borderSpacing]
      }],
      /**
       * Border Spacing X
       * @see https://tailwindcss.com/docs/border-spacing
       */
      "border-spacing-x": [{
        "border-spacing-x": [borderSpacing]
      }],
      /**
       * Border Spacing Y
       * @see https://tailwindcss.com/docs/border-spacing
       */
      "border-spacing-y": [{
        "border-spacing-y": [borderSpacing]
      }],
      /**
       * Table Layout
       * @see https://tailwindcss.com/docs/table-layout
       */
      "table-layout": [{
        table: ["auto", "fixed"]
      }],
      /**
       * Caption Side
       * @see https://tailwindcss.com/docs/caption-side
       */
      caption: [{
        caption: ["top", "bottom"]
      }],
      // Transitions and Animation
      /**
       * Tranisition Property
       * @see https://tailwindcss.com/docs/transition-property
       */
      transition: [{
        transition: ["none", "all", "", "colors", "opacity", "shadow", "transform", isArbitraryValue]
      }],
      /**
       * Transition Duration
       * @see https://tailwindcss.com/docs/transition-duration
       */
      duration: [{
        duration: getNumberAndArbitrary()
      }],
      /**
       * Transition Timing Function
       * @see https://tailwindcss.com/docs/transition-timing-function
       */
      ease: [{
        ease: ["linear", "in", "out", "in-out", isArbitraryValue]
      }],
      /**
       * Transition Delay
       * @see https://tailwindcss.com/docs/transition-delay
       */
      delay: [{
        delay: getNumberAndArbitrary()
      }],
      /**
       * Animation
       * @see https://tailwindcss.com/docs/animation
       */
      animate: [{
        animate: ["none", "spin", "ping", "pulse", "bounce", isArbitraryValue]
      }],
      // Transforms
      /**
       * Transform
       * @see https://tailwindcss.com/docs/transform
       */
      transform: [{
        transform: ["", "gpu", "none"]
      }],
      /**
       * Scale
       * @see https://tailwindcss.com/docs/scale
       */
      scale: [{
        scale: [scale]
      }],
      /**
       * Scale X
       * @see https://tailwindcss.com/docs/scale
       */
      "scale-x": [{
        "scale-x": [scale]
      }],
      /**
       * Scale Y
       * @see https://tailwindcss.com/docs/scale
       */
      "scale-y": [{
        "scale-y": [scale]
      }],
      /**
       * Rotate
       * @see https://tailwindcss.com/docs/rotate
       */
      rotate: [{
        rotate: [isInteger, isArbitraryValue]
      }],
      /**
       * Translate X
       * @see https://tailwindcss.com/docs/translate
       */
      "translate-x": [{
        "translate-x": [translate]
      }],
      /**
       * Translate Y
       * @see https://tailwindcss.com/docs/translate
       */
      "translate-y": [{
        "translate-y": [translate]
      }],
      /**
       * Skew X
       * @see https://tailwindcss.com/docs/skew
       */
      "skew-x": [{
        "skew-x": [skew]
      }],
      /**
       * Skew Y
       * @see https://tailwindcss.com/docs/skew
       */
      "skew-y": [{
        "skew-y": [skew]
      }],
      /**
       * Transform Origin
       * @see https://tailwindcss.com/docs/transform-origin
       */
      "transform-origin": [{
        origin: ["center", "top", "top-right", "right", "bottom-right", "bottom", "bottom-left", "left", "top-left", isArbitraryValue]
      }],
      // Interactivity
      /**
       * Accent Color
       * @see https://tailwindcss.com/docs/accent-color
       */
      accent: [{
        accent: ["auto", colors]
      }],
      /**
       * Appearance
       * @see https://tailwindcss.com/docs/appearance
       */
      appearance: [{
        appearance: ["none", "auto"]
      }],
      /**
       * Cursor
       * @see https://tailwindcss.com/docs/cursor
       */
      cursor: [{
        cursor: ["auto", "default", "pointer", "wait", "text", "move", "help", "not-allowed", "none", "context-menu", "progress", "cell", "crosshair", "vertical-text", "alias", "copy", "no-drop", "grab", "grabbing", "all-scroll", "col-resize", "row-resize", "n-resize", "e-resize", "s-resize", "w-resize", "ne-resize", "nw-resize", "se-resize", "sw-resize", "ew-resize", "ns-resize", "nesw-resize", "nwse-resize", "zoom-in", "zoom-out", isArbitraryValue]
      }],
      /**
       * Caret Color
       * @see https://tailwindcss.com/docs/just-in-time-mode#caret-color-utilities
       */
      "caret-color": [{
        caret: [colors]
      }],
      /**
       * Pointer Events
       * @see https://tailwindcss.com/docs/pointer-events
       */
      "pointer-events": [{
        "pointer-events": ["none", "auto"]
      }],
      /**
       * Resize
       * @see https://tailwindcss.com/docs/resize
       */
      resize: [{
        resize: ["none", "y", "x", ""]
      }],
      /**
       * Scroll Behavior
       * @see https://tailwindcss.com/docs/scroll-behavior
       */
      "scroll-behavior": [{
        scroll: ["auto", "smooth"]
      }],
      /**
       * Scroll Margin
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-m": [{
        "scroll-m": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Margin X
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-mx": [{
        "scroll-mx": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Margin Y
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-my": [{
        "scroll-my": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Margin Start
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-ms": [{
        "scroll-ms": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Margin End
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-me": [{
        "scroll-me": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Margin Top
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-mt": [{
        "scroll-mt": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Margin Right
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-mr": [{
        "scroll-mr": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Margin Bottom
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-mb": [{
        "scroll-mb": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Margin Left
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-ml": [{
        "scroll-ml": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Padding
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-p": [{
        "scroll-p": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Padding X
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-px": [{
        "scroll-px": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Padding Y
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-py": [{
        "scroll-py": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Padding Start
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-ps": [{
        "scroll-ps": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Padding End
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-pe": [{
        "scroll-pe": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Padding Top
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-pt": [{
        "scroll-pt": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Padding Right
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-pr": [{
        "scroll-pr": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Padding Bottom
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-pb": [{
        "scroll-pb": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Padding Left
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-pl": [{
        "scroll-pl": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Snap Align
       * @see https://tailwindcss.com/docs/scroll-snap-align
       */
      "snap-align": [{
        snap: ["start", "end", "center", "align-none"]
      }],
      /**
       * Scroll Snap Stop
       * @see https://tailwindcss.com/docs/scroll-snap-stop
       */
      "snap-stop": [{
        snap: ["normal", "always"]
      }],
      /**
       * Scroll Snap Type
       * @see https://tailwindcss.com/docs/scroll-snap-type
       */
      "snap-type": [{
        snap: ["none", "x", "y", "both"]
      }],
      /**
       * Scroll Snap Type Strictness
       * @see https://tailwindcss.com/docs/scroll-snap-type
       */
      "snap-strictness": [{
        snap: ["mandatory", "proximity"]
      }],
      /**
       * Touch Action
       * @see https://tailwindcss.com/docs/touch-action
       */
      touch: [{
        touch: ["auto", "none", "manipulation"]
      }],
      /**
       * Touch Action X
       * @see https://tailwindcss.com/docs/touch-action
       */
      "touch-x": [{
        "touch-pan": ["x", "left", "right"]
      }],
      /**
       * Touch Action Y
       * @see https://tailwindcss.com/docs/touch-action
       */
      "touch-y": [{
        "touch-pan": ["y", "up", "down"]
      }],
      /**
       * Touch Action Pinch Zoom
       * @see https://tailwindcss.com/docs/touch-action
       */
      "touch-pz": ["touch-pinch-zoom"],
      /**
       * User Select
       * @see https://tailwindcss.com/docs/user-select
       */
      select: [{
        select: ["none", "text", "all", "auto"]
      }],
      /**
       * Will Change
       * @see https://tailwindcss.com/docs/will-change
       */
      "will-change": [{
        "will-change": ["auto", "scroll", "contents", "transform", isArbitraryValue]
      }],
      // SVG
      /**
       * Fill
       * @see https://tailwindcss.com/docs/fill
       */
      fill: [{
        fill: [colors, "none"]
      }],
      /**
       * Stroke Width
       * @see https://tailwindcss.com/docs/stroke-width
       */
      "stroke-w": [{
        stroke: [isLength, isArbitraryLength, isArbitraryNumber]
      }],
      /**
       * Stroke
       * @see https://tailwindcss.com/docs/stroke
       */
      stroke: [{
        stroke: [colors, "none"]
      }],
      // Accessibility
      /**
       * Screen Readers
       * @see https://tailwindcss.com/docs/screen-readers
       */
      sr: ["sr-only", "not-sr-only"],
      /**
       * Forced Color Adjust
       * @see https://tailwindcss.com/docs/forced-color-adjust
       */
      "forced-color-adjust": [{
        "forced-color-adjust": ["auto", "none"]
      }]
    },
    conflictingClassGroups: {
      overflow: ["overflow-x", "overflow-y"],
      overscroll: ["overscroll-x", "overscroll-y"],
      inset: ["inset-x", "inset-y", "start", "end", "top", "right", "bottom", "left"],
      "inset-x": ["right", "left"],
      "inset-y": ["top", "bottom"],
      flex: ["basis", "grow", "shrink"],
      gap: ["gap-x", "gap-y"],
      p: ["px", "py", "ps", "pe", "pt", "pr", "pb", "pl"],
      px: ["pr", "pl"],
      py: ["pt", "pb"],
      m: ["mx", "my", "ms", "me", "mt", "mr", "mb", "ml"],
      mx: ["mr", "ml"],
      my: ["mt", "mb"],
      size: ["w", "h"],
      "font-size": ["leading"],
      "fvn-normal": ["fvn-ordinal", "fvn-slashed-zero", "fvn-figure", "fvn-spacing", "fvn-fraction"],
      "fvn-ordinal": ["fvn-normal"],
      "fvn-slashed-zero": ["fvn-normal"],
      "fvn-figure": ["fvn-normal"],
      "fvn-spacing": ["fvn-normal"],
      "fvn-fraction": ["fvn-normal"],
      "line-clamp": ["display", "overflow"],
      rounded: ["rounded-s", "rounded-e", "rounded-t", "rounded-r", "rounded-b", "rounded-l", "rounded-ss", "rounded-se", "rounded-ee", "rounded-es", "rounded-tl", "rounded-tr", "rounded-br", "rounded-bl"],
      "rounded-s": ["rounded-ss", "rounded-es"],
      "rounded-e": ["rounded-se", "rounded-ee"],
      "rounded-t": ["rounded-tl", "rounded-tr"],
      "rounded-r": ["rounded-tr", "rounded-br"],
      "rounded-b": ["rounded-br", "rounded-bl"],
      "rounded-l": ["rounded-tl", "rounded-bl"],
      "border-spacing": ["border-spacing-x", "border-spacing-y"],
      "border-w": ["border-w-s", "border-w-e", "border-w-t", "border-w-r", "border-w-b", "border-w-l"],
      "border-w-x": ["border-w-r", "border-w-l"],
      "border-w-y": ["border-w-t", "border-w-b"],
      "border-color": ["border-color-s", "border-color-e", "border-color-t", "border-color-r", "border-color-b", "border-color-l"],
      "border-color-x": ["border-color-r", "border-color-l"],
      "border-color-y": ["border-color-t", "border-color-b"],
      "scroll-m": ["scroll-mx", "scroll-my", "scroll-ms", "scroll-me", "scroll-mt", "scroll-mr", "scroll-mb", "scroll-ml"],
      "scroll-mx": ["scroll-mr", "scroll-ml"],
      "scroll-my": ["scroll-mt", "scroll-mb"],
      "scroll-p": ["scroll-px", "scroll-py", "scroll-ps", "scroll-pe", "scroll-pt", "scroll-pr", "scroll-pb", "scroll-pl"],
      "scroll-px": ["scroll-pr", "scroll-pl"],
      "scroll-py": ["scroll-pt", "scroll-pb"],
      touch: ["touch-x", "touch-y", "touch-pz"],
      "touch-x": ["touch"],
      "touch-y": ["touch"],
      "touch-pz": ["touch"]
    },
    conflictingClassGroupModifiers: {
      "font-size": ["leading"]
    }
  };
};
var twMerge = /* @__PURE__ */ createTailwindMerge(getDefaultConfig);

// src/lib/utils.ts
function cn(...inputs) {
  return twMerge(clsx(inputs));
}

// src/core/viewportDesktopSite.ts
var MOBILE_DESKTOP_SITE_KEY = "copanel_mobile_desktop_site";
function isMobileDesktopSiteEnabled() {
  try {
    return localStorage.getItem(MOBILE_DESKTOP_SITE_KEY) === "1";
  } catch {
    return false;
  }
}
function isLayoutViewportWide(innerWidth = window.innerWidth) {
  return isMobileDesktopSiteEnabled() || innerWidth >= 1024;
}

// src/core/shell/ModuleViewport.tsx
import { jsx as jsx3 } from "react/jsx-runtime";
function ModuleViewport({ children, className, constrained = false }) {
  const { theme } = useAppShellContext();
  const isWindowed = useIsWindowedModule();
  const isDark = theme === "dark";
  const isClassicMobile = !isWindowed && !isLayoutViewportWide();
  return /* @__PURE__ */ jsx3(
    "div",
    {
      className: cn(
        "flex flex-col transition-colors duration-200",
        isWindowed ? "h-full min-h-0" : isClassicMobile ? "min-h-0" : "min-h-screen",
        isDark ? "bg-slate-950 text-slate-100" : "bg-slate-50 text-slate-900",
        !isWindowed && constrained && "mx-auto max-w-7xl",
        className
      ),
      children
    }
  );
}

// src/core/shell/ModuleSidebarLayout.tsx
import { useEffect, useState } from "react";
import * as Icons from "lucide-react";
import { jsx as jsx4, jsxs } from "react/jsx-runtime";
function ModuleSidebarLayout({
  isDark,
  sidebar,
  children,
  mobileTitle,
  className
}) {
  const isWindowed = useIsWindowedModule();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [viewportWide, setViewportWide] = useState(() => isLayoutViewportWide());
  useEffect(() => {
    const onResize = () => setViewportWide(isLayoutViewportWide());
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  }, []);
  const useDrawer = !isWindowed && !viewportWide;
  useEffect(() => {
    if (viewportWide) setSidebarOpen(false);
  }, [viewportWide]);
  const closeSidebar = () => setSidebarOpen(false);
  if (!useDrawer) {
    return /* @__PURE__ */ jsxs("div", { className: cn("flex h-full min-h-0 flex-1 overflow-hidden", className), children: [
      sidebar,
      /* @__PURE__ */ jsx4("div", { className: "flex min-h-0 min-w-0 flex-1 flex-col overflow-hidden", children })
    ] });
  }
  return /* @__PURE__ */ jsxs("div", { className: cn("relative flex h-full min-h-0 flex-1 flex-col overflow-hidden", className), children: [
    /* @__PURE__ */ jsxs(
      "div",
      {
        className: cn(
          "flex shrink-0 items-center gap-2 border-b px-3 py-2.5",
          isDark ? "border-slate-800 bg-slate-950/90" : "border-slate-200 bg-white"
        ),
        children: [
          /* @__PURE__ */ jsx4(
            "button",
            {
              type: "button",
              onClick: () => setSidebarOpen(true),
              className: cn(
                "inline-flex items-center justify-center rounded-lg p-2",
                isDark ? "text-slate-200 hover:bg-slate-800" : "text-slate-700 hover:bg-slate-100"
              ),
              "aria-label": "Open module menu",
              children: /* @__PURE__ */ jsx4(Icons.PanelLeft, { className: "h-5 w-5" })
            }
          ),
          mobileTitle ? /* @__PURE__ */ jsx4("span", { className: cn("truncate text-sm font-semibold", isDark ? "text-slate-100" : "text-slate-900"), children: mobileTitle }) : null
        ]
      }
    ),
    sidebarOpen ? /* @__PURE__ */ jsx4(
      "button",
      {
        type: "button",
        className: "fixed inset-0 z-[60] bg-black/45",
        "aria-label": "Close module menu",
        onClick: closeSidebar
      }
    ) : null,
    /* @__PURE__ */ jsx4(
      "div",
      {
        className: cn(
          "fixed inset-y-0 left-0 z-[61] flex max-w-[min(85vw,280px)] transform shadow-xl transition-transform duration-200 ease-out",
          sidebarOpen ? "translate-x-0" : "-translate-x-full pointer-events-none"
        ),
        onClick: closeSidebar,
        children: sidebar
      }
    ),
    /* @__PURE__ */ jsx4("div", { className: "flex min-h-0 min-w-0 flex-1 flex-col overflow-hidden", children })
  ] });
}

// src/core/shell/WindowModal.tsx
import { createPortal } from "react-dom";
import * as Icons2 from "lucide-react";
import { jsx as jsx5, jsxs as jsxs2 } from "react/jsx-runtime";
var MAX_W = {
  sm: "max-w-sm",
  md: "max-w-md",
  lg: "max-w-lg",
  xl: "max-w-xl",
  "2xl": "max-w-2xl",
  "4xl": "max-w-4xl",
  "5xl": "max-w-5xl"
};
function WindowModal({
  open,
  onClose,
  children,
  title,
  className,
  maxWidth = "lg",
  closeOnBackdropClick = true
}) {
  const { theme } = useAppShellContext();
  const isDark = theme === "dark";
  const viewport = useWindowViewport();
  if (!open) return null;
  const overlay = /* @__PURE__ */ jsx5(
    "div",
    {
      className: cn(
        "z-[80] flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm",
        viewport?.isWindowed ? "absolute inset-0" : "fixed inset-0"
      ),
      onClick: closeOnBackdropClick ? onClose : void 0,
      children: /* @__PURE__ */ jsxs2(
        "div",
        {
          className: cn(
            "flex w-full flex-col overflow-hidden rounded-2xl border shadow-2xl",
            MAX_W[maxWidth],
            isDark ? "border-slate-700 bg-slate-900 text-slate-100" : "border-slate-200 bg-white text-slate-900",
            className
          ),
          onClick: (e) => e.stopPropagation(),
          children: [
            title && /* @__PURE__ */ jsxs2(
              "div",
              {
                className: cn(
                  "flex items-center justify-between border-b px-4 py-3",
                  isDark ? "border-slate-800" : "border-slate-200"
                ),
                children: [
                  /* @__PURE__ */ jsx5("h3", { className: "text-sm font-bold", children: title }),
                  /* @__PURE__ */ jsx5("button", { type: "button", onClick: onClose, className: "rounded-lg p-1 hover:bg-slate-800/50", "aria-label": "Close", children: /* @__PURE__ */ jsx5(Icons2.X, { className: "h-4 w-4" }) })
                ]
              }
            ),
            children
          ]
        }
      )
    }
  );
  if (viewport?.isWindowed && viewport.viewportRef.current) {
    return createPortal(overlay, viewport.viewportRef.current);
  }
  return createPortal(overlay, document.body);
}

// src/core/desktopChrome.ts
var ACCENT = {
  blue: {
    border: { dark: "border-blue-500", light: "border-blue-600" },
    icon: "text-blue-500",
    badgeActive: {
      dark: "bg-blue-500/25 text-blue-200",
      light: "bg-blue-100 text-blue-700"
    },
    softBg: {
      dark: "bg-blue-500/15",
      light: "bg-blue-50"
    }
  },
  cyan: {
    border: { dark: "border-cyan-500", light: "border-cyan-600" },
    icon: "text-cyan-500",
    badgeActive: {
      dark: "bg-cyan-500/25 text-cyan-200",
      light: "bg-cyan-100 text-cyan-700"
    },
    softBg: {
      dark: "bg-cyan-500/15",
      light: "bg-cyan-50"
    }
  },
  teal: {
    border: { dark: "border-teal-500", light: "border-teal-600" },
    icon: "text-teal-500",
    badgeActive: {
      dark: "bg-teal-500/25 text-teal-200",
      light: "bg-teal-100 text-teal-700"
    },
    softBg: {
      dark: "bg-teal-500/15",
      light: "bg-teal-50"
    }
  },
  sky: {
    border: { dark: "border-sky-500", light: "border-sky-600" },
    icon: "text-sky-500",
    badgeActive: {
      dark: "bg-sky-500/25 text-sky-200",
      light: "bg-sky-100 text-sky-700"
    },
    softBg: {
      dark: "bg-sky-500/15",
      light: "bg-sky-50"
    }
  }
};
function chromeSidebar(isDark, width = "md") {
  return cn(
    "flex h-full shrink-0 flex-col border-r",
    width === "sm" ? "w-[200px]" : "w-[220px]",
    isDark ? "border-slate-800 bg-slate-950/95" : "border-slate-200 bg-[#f4f6f8]"
  );
}
function chromeSidebarHeader(isDark) {
  return cn("border-b px-4 py-3.5", isDark ? "border-slate-800" : "border-slate-200");
}
function chromeSidebarIconBox(isDark) {
  return cn(
    "flex h-9 w-9 items-center justify-center rounded-lg",
    isDark ? "bg-slate-800" : "border border-slate-200 bg-white shadow-sm"
  );
}
function chromeSidebarTitle(isDark) {
  return cn("truncate text-sm font-semibold", isDark ? "text-slate-100" : "text-slate-900");
}
function chromeSidebarSubtitle(isDark) {
  return cn("line-clamp-2 text-[11px] leading-snug", isDark ? "text-slate-500" : "text-slate-500");
}
function chromeSidebarNav() {
  return "flex-1 space-y-0.5 overflow-y-auto p-2";
}
function chromeNavItem(isDark, active, accent = "blue") {
  const a = ACCENT[accent];
  return cn(
    "flex w-full items-center gap-2.5 rounded-md border-l-2 py-2.5 pl-[10px] pr-3 text-left text-sm transition-colors",
    active ? isDark ? cn(a.border.dark, "bg-slate-800/90 text-white") : cn(a.border.light, "bg-white text-slate-900 shadow-sm") : isDark ? "border-transparent text-slate-300 hover:bg-slate-900/70" : "border-transparent text-slate-700 hover:bg-white/90"
  );
}
function chromeNavIcon(isDark, active, accent = "blue") {
  return cn("h-4 w-4 shrink-0", active ? ACCENT[accent].icon : isDark ? "text-slate-500" : "text-slate-400");
}

// src/modules/rsync_manager/index.tsx
import * as Icons3 from "lucide-react";

// src/core/platform/api.ts
var PlatformError = class extends Error {
  constructor(code, message, status, details) {
    super(message);
    __publicField(this, "code");
    __publicField(this, "status");
    __publicField(this, "details");
    this.code = code;
    this.status = status;
    this.details = details;
  }
};
async function api(path, opts = {}) {
  const token = typeof window !== "undefined" ? localStorage.getItem("copanel_token") : null;
  const headers = {
    "Content-Type": "application/json",
    ...opts.headers || {}
  };
  if (token) headers["Authorization"] = `Bearer ${token}`;
  const init = {
    method: opts.method || "GET",
    headers,
    signal: opts.signal
  };
  if (opts.body !== void 0) {
    init.body = typeof opts.body === "string" ? opts.body : JSON.stringify(opts.body);
  }
  const res = await fetch(path, init);
  let body = null;
  const text = await res.text();
  if (text) {
    try {
      body = JSON.parse(text);
    } catch {
      body = text;
    }
  }
  if (opts.raw) {
    return body;
  }
  if (!res.ok) {
    const err = body && typeof body === "object" && body.error ? body.error : { code: `HTTP_${res.status}`, message: typeof body === "string" ? body : body?.detail || res.statusText };
    throw new PlatformError(err.code || `HTTP_${res.status}`, err.message || "Request failed", res.status, err.details);
  }
  if (body && typeof body === "object" && "status" in body) {
    if (body.status === "success") {
      return body.data !== void 0 ? body.data : body;
    }
    if (body.status === "error" && body.error) {
      throw new PlatformError(body.error.code, body.error.message, res.status, body.error.details);
    }
  }
  return body;
}

// src/core/platform/events.ts
var PLATFORM_SSE_DEGRADED_EVENT = "copanel-platform-sse-degraded";
var MIN_RETRY_MS = 2e3;
var MAX_RETRY_MS = 6e4;
var POLL_FALLBACK_AFTER_FAILURES = 3;
var EventHub = class {
  constructor() {
    __publicField(this, "source", null);
    __publicField(this, "handlers", /* @__PURE__ */ new Map());
    __publicField(this, "retryDelay", MIN_RETRY_MS);
    __publicField(this, "retryTimer", null);
    __publicField(this, "failureCount", 0);
  }
  on(topic, handler) {
    let set = this.handlers.get(topic);
    if (!set) {
      set = /* @__PURE__ */ new Set();
      this.handlers.set(topic, set);
    }
    set.add(handler);
    this.ensureConnected();
    return () => {
      set.delete(handler);
      if (set.size === 0) {
        this.handlers.delete(topic);
      }
      this.teardownIfIdle();
    };
  }
  emit(topic, payload) {
    const set = this.handlers.get(topic);
    if (set) {
      set.forEach((h) => {
        try {
          h(payload);
        } catch (err) {
          console.error("event handler failed", topic, err);
        }
      });
    }
  }
  buildUrl() {
    const token = localStorage.getItem("copanel_token");
    if (!token) return null;
    const params = new URLSearchParams({
      topics: "jobs,notifications",
      access_token: token
    });
    return `/api/platform/events?${params.toString()}`;
  }
  ensureConnected() {
    if (this.source) return;
    if (typeof document !== "undefined" && document.hidden) return;
    const url = this.buildUrl();
    if (!url) return;
    try {
      this.source = new EventSource(url, { withCredentials: false });
    } catch {
      this.scheduleRetry();
      return;
    }
    this.source.addEventListener("open", () => {
      this.failureCount = 0;
      this.retryDelay = MIN_RETRY_MS;
    });
    this.source.addEventListener("jobs", (e) => {
      this.onStreamMessage();
      this.parseAndEmit("jobs", e.data);
    });
    this.source.addEventListener("notifications", (e) => {
      this.onStreamMessage();
      this.parseAndEmit("notifications", e.data);
    });
    this.source.addEventListener("message", () => {
      this.onStreamMessage();
    });
    this.source.onerror = () => {
      this.failureCount += 1;
      this.source?.close();
      this.source = null;
      if (this.failureCount >= POLL_FALLBACK_AFTER_FAILURES) {
        window.dispatchEvent(new CustomEvent(PLATFORM_SSE_DEGRADED_EVENT));
      }
      this.scheduleRetry();
    };
  }
  onStreamMessage() {
    this.failureCount = 0;
    this.retryDelay = MIN_RETRY_MS;
  }
  parseAndEmit(topic, raw) {
    try {
      const msg = JSON.parse(raw);
      this.emit(topic, msg.payload || msg);
    } catch {
    }
  }
  scheduleRetry() {
    if (this.retryTimer) return;
    if (this.handlers.size === 0) return;
    const delay = this.retryDelay;
    this.retryDelay = Math.min(Math.round(this.retryDelay * 1.8), MAX_RETRY_MS);
    this.retryTimer = setTimeout(() => {
      this.retryTimer = null;
      this.ensureConnected();
    }, delay);
  }
  teardownIfIdle() {
    if (this.handlers.size > 0) return;
    if (this.retryTimer) {
      clearTimeout(this.retryTimer);
      this.retryTimer = null;
    }
    if (this.source) {
      this.source.close();
      this.source = null;
    }
    this.failureCount = 0;
    this.retryDelay = MIN_RETRY_MS;
  }
  /** Drop the SSE connection and open a new one if handlers exist and a token is present. */
  reconnect() {
    if (this.source) {
      this.source.close();
      this.source = null;
    }
    if (this.retryTimer) {
      clearTimeout(this.retryTimer);
      this.retryTimer = null;
    }
    this.failureCount = 0;
    this.retryDelay = MIN_RETRY_MS;
    if (this.handlers.size > 0) {
      this.ensureConnected();
    }
  }
};
var events = new EventHub();
function reconnectPlatformEvents() {
  events.reconnect();
}
if (typeof document !== "undefined") {
  document.addEventListener("visibilitychange", () => {
    if (!document.hidden) {
      reconnectPlatformEvents();
    }
  });
}

// src/core/platform/store.ts
import { useEffect as useEffect2, useState as useState2 } from "react";
function createStore(initial) {
  let state = initial;
  const listeners = /* @__PURE__ */ new Set();
  return {
    getState: () => state,
    setState: (updater) => {
      const patch = typeof updater === "function" ? updater(state) : updater;
      if (!patch || Object.keys(patch).length === 0) return;
      let changed = false;
      for (const key of Object.keys(patch)) {
        if (state[key] !== patch[key]) {
          changed = true;
          break;
        }
      }
      if (!changed) return;
      state = { ...state, ...patch };
      listeners.forEach((l) => l());
    },
    subscribe: (listener) => {
      listeners.add(listener);
      return () => listeners.delete(listener);
    }
  };
}
function useStore(store3, selector) {
  const [state, setState] = useState2(() => store3.getState());
  useEffect2(() => {
    const unsub = store3.subscribe(() => setState(store3.getState()));
    return unsub;
  }, [store3]);
  return selector(state);
}

// src/core/platform/jobsStore.ts
var store = createStore({ jobs: {}, order: [], lastFetch: 0 });
function getCurrentLang() {
  return localStorage.getItem("copanel_lang") === "vi" ? "vi" : "en";
}
function pickLocalizedFromValue(value, lang) {
  if (!value) return void 0;
  if (typeof value === "string") return value;
  if (typeof value === "object") return value[lang] || value.en || value.vi || value.default;
  return void 0;
}
function resolveLocalizedField(src, baseKey, lang) {
  if (!src || typeof src !== "object") return void 0;
  const direct = pickLocalizedFromValue(src[baseKey], lang);
  if (direct) return direct;
  const fromMap = pickLocalizedFromValue(src[`${baseKey}_i18n`], lang);
  if (fromMap) return fromMap;
  const fromLangSpecific = src[`${baseKey}_${lang}`];
  if (typeof fromLangSpecific === "string" && fromLangSpecific) return fromLangSpecific;
  const fallbackEn = src[`${baseKey}_en`];
  if (typeof fallbackEn === "string" && fallbackEn) return fallbackEn;
  const fallbackVi = src[`${baseKey}_vi`];
  if (typeof fallbackVi === "string" && fallbackVi) return fallbackVi;
  return void 0;
}
function localizeJob(raw) {
  const lang = getCurrentLang();
  const payload = raw?.payload && typeof raw.payload === "object" ? raw.payload : {};
  return {
    ...raw,
    title: resolveLocalizedField(raw, "title", lang) || resolveLocalizedField(payload, "title", lang) || raw?.title || "",
    message: resolveLocalizedField(raw, "message", lang) || resolveLocalizedField(payload, "message", lang) || raw?.message,
    error: resolveLocalizedField(raw, "error", lang) || resolveLocalizedField(payload, "error", lang) || raw?.error || null
  };
}
function upsert(job) {
  const localized = localizeJob(job);
  store.setState((s) => {
    const next = { ...s.jobs, [localized.id]: { ...s.jobs[localized.id], ...localized } };
    let order = s.order;
    if (!order.includes(localized.id)) {
      order = [localized.id, ...order].slice(0, 200);
    }
    return { jobs: next, order };
  });
}
events.on("jobs", (msg) => {
  if (msg?.job) {
    upsert(msg.job);
    return;
  }
  if (msg?.job_id && msg?.event === "update") {
    const existing = store.getState().jobs[msg.job_id];
    if (existing) {
      upsert({
        ...existing,
        progress: msg.progress ?? existing.progress,
        message: msg.message ?? existing.message,
        status: msg.status ?? existing.status
      });
    }
  }
});
var jobsApi = {
  async refresh(limit = 50) {
    const list = await api(`/api/platform/jobs?limit=${limit}`);
    const rows = Array.isArray(list) ? list : [];
    store.setState(() => {
      const map = {};
      const order = [];
      for (const raw of rows) {
        if (!raw || typeof raw !== "object" || !raw.id) continue;
        const j = localizeJob(raw);
        map[j.id] = j;
        order.push(j.id);
      }
      return { jobs: map, order, lastFetch: Date.now() };
    });
  },
  async get(id) {
    const data = await api(`/api/platform/jobs/${id}`);
    const job = localizeJob(data);
    upsert(job);
    return job;
  },
  async cancel(id) {
    return api(`/api/platform/jobs/${id}/cancel`, { method: "POST" });
  }
};
function useJob(id) {
  return useStore(store, (s) => id ? s.jobs[id] : void 0);
}

// src/core/platform/notificationsStore.ts
var store2 = createStore({ inbox: [], unread: 0, toasts: [] });
var TOAST_TTL_MS = 6e3;
function getCurrentLang2() {
  return localStorage.getItem("copanel_lang") === "vi" ? "vi" : "en";
}
function pickLocalizedFromValue2(value, lang) {
  if (!value) return void 0;
  if (typeof value === "string") return value;
  if (typeof value === "object") {
    return value[lang] || value.en || value.vi || value.default;
  }
  return void 0;
}
function resolveLocalizedField2(src, baseKey, lang) {
  if (!src || typeof src !== "object") return void 0;
  const direct = pickLocalizedFromValue2(src[baseKey], lang);
  if (direct) return direct;
  const fromMap = pickLocalizedFromValue2(src[`${baseKey}_i18n`], lang);
  if (fromMap) return fromMap;
  const fromLangSpecific = src[`${baseKey}_${lang}`];
  if (typeof fromLangSpecific === "string" && fromLangSpecific) return fromLangSpecific;
  const fallbackEn = src[`${baseKey}_en`];
  if (typeof fallbackEn === "string" && fallbackEn) return fallbackEn;
  const fallbackVi = src[`${baseKey}_vi`];
  if (typeof fallbackVi === "string" && fallbackVi) return fallbackVi;
  return void 0;
}
function localizeNotification(raw) {
  const lang = getCurrentLang2();
  const payload = raw?.payload && typeof raw.payload === "object" ? raw.payload : {};
  const title = resolveLocalizedField2(raw, "title", lang) || resolveLocalizedField2(payload, "title", lang) || (raw?.title || "");
  const body = resolveLocalizedField2(raw, "body", lang) || resolveLocalizedField2(payload, "body", lang) || raw?.body || null;
  return {
    ...raw,
    title,
    body
  };
}
function pushToast(t) {
  store2.setState((s) => ({ toasts: [t, ...s.toasts].slice(0, 6) }));
  if (t.ephemeral !== false) {
    setTimeout(() => {
      store2.setState((s) => ({ toasts: s.toasts.filter((x) => x.id !== t.id) }));
    }, TOAST_TTL_MS);
  }
}
events.on("notifications", (msg) => {
  if (msg?.event === "new" && msg.notification) {
    const n = localizeNotification(msg.notification);
    pushToast({ ...n, ephemeral: true });
    store2.setState((s) => ({
      inbox: [n, ...s.inbox].slice(0, 200),
      unread: s.unread + 1
    }));
  }
});

// src/modules/rsync_manager/index.tsx
import { jsx as jsx6, jsxs as jsxs3 } from "react/jsx-runtime";
var STEP_ORDER = ["mode", "target", "detect", "scope", "review", "done"];
var STEP_ICONS = {
  mode: Icons3.Layers,
  target: Icons3.Server,
  detect: Icons3.ShieldCheck,
  scope: Icons3.FolderSync,
  review: Icons3.ClipboardCheck,
  done: Icons3.Flag
};
function RsyncManager() {
  const { theme, language } = useAppShellContext();
  const isDark = theme === "dark";
  const lang = language === "vi" ? "vi" : "en";
  const windowed = useIsWindowedModule();
  const [searchParams, setSearchParams] = useSearchParams();
  const [step, setStep] = useState3("mode");
  const [mode, setMode] = useState3("clone");
  const [host, setHost] = useState3("");
  const [port, setPort] = useState3("22");
  const [user, setUser] = useState3("root");
  const [identityFile, setIdentityFile] = useState3("");
  const [sshHints, setSshHints] = useState3([]);
  const [presets, setPresets] = useState3({});
  const [presetId, setPresetId] = useState3("copanel");
  const [localPath, setLocalPath] = useState3("/opt/copanel");
  const [remotePath, setRemotePath] = useState3("/opt/copanel");
  const [extraWeb, setExtraWeb] = useState3(false);
  const [excludes, setExcludes] = useState3("");
  const [wantDelete, setWantDelete] = useState3(false);
  const [estimateGb, setEstimateGb] = useState3("");
  const [compat, setCompat] = useState3(null);
  const [checkLoading, setCheckLoading] = useState3(false);
  const [installLoading, setInstallLoading] = useState3(false);
  const [estimateLoading, setEstimateLoading] = useState3(false);
  const [submitting, setSubmitting] = useState3(false);
  const [error, setError] = useState3(null);
  const [confirmOpen, setConfirmOpen] = useState3(false);
  const [confirmDry, setConfirmDry] = useState3(true);
  const [jobId, setJobId] = useState3(searchParams.get("job"));
  const job = useJob(jobId);
  const [checklist, setChecklist] = useState3([]);
  const [checkedIds, setCheckedIds] = useState3({});
  const tr = useMemo(() => TEXT[lang], [lang]);
  const labels = {
    mode: tr.stepMode,
    target: tr.stepTarget,
    detect: tr.stepDetect,
    scope: tr.stepScope,
    review: tr.stepReview,
    done: tr.stepDone
  };
  const stepMeta = {
    mode: { title: tr.modeTitle, desc: tr.modeDesc },
    target: { title: tr.targetTitle, desc: tr.targetDesc },
    detect: { title: tr.detectTitle, desc: tr.detectDesc },
    scope: { title: tr.scopeTitle, desc: tr.scopeDesc },
    review: { title: tr.reviewTitle, desc: tr.reviewDesc },
    done: { title: tr.doneTitle, desc: tr.doneDesc }
  };
  const loadMeta = useCallback(() => {
    api("/api/rsync_manager/presets").then((p) => {
      setPresets(p || {});
      const cop = p?.copanel;
      if (cop?.excludes) setExcludes((cop.excludes || []).join("\n"));
    }).catch(() => {
    });
    api("/api/rsync_manager/ssh_hints").then((d) => setSshHints(d?.keys || [])).catch(() => setSshHints([]));
  }, []);
  useEffect3(() => {
    loadMeta();
  }, [loadMeta]);
  useEffect3(() => {
    const id = searchParams.get("job");
    if (id) {
      setJobId(id);
      setStep("review");
    }
  }, [searchParams]);
  useEffect3(() => {
    if (!jobId) return;
    const t = setInterval(() => {
      jobsApi.get(jobId).catch(() => {
      });
    }, 1500);
    return () => clearInterval(t);
  }, [jobId]);
  useEffect3(() => {
    if (job?.status === "success") {
      setStep("done");
      void loadChecklist();
    }
  }, [job?.status]);
  const applyPreset = (id) => {
    setPresetId(id);
    const p = presets[id];
    if (!p) return;
    if (p.local_path) setLocalPath(p.local_path);
    if (p.remote_path) setRemotePath(p.remote_path);
    setExcludes((p.excludes || []).join("\n"));
    setWantDelete(!!p.delete_default && mode !== "clone");
  };
  const buildPaths = () => {
    const paths = [{ local_path: localPath.trim(), remote_path: remotePath.trim() }];
    if (extraWeb) {
      paths.push({ local_path: "/var/www", remote_path: "/var/www" });
    }
    return paths;
  };
  const sshPayload = () => ({
    host: host.trim(),
    port: parseInt(port, 10) || 22,
    user: user.trim(),
    identity_file: identityFile.trim() || null
  });
  const runCompatibility = async () => {
    setError(null);
    setCheckLoading(true);
    setCompat(null);
    try {
      const est = parseFloat(estimateGb.replace(",", ".")) || 0;
      const estimated_bytes = Math.max(0, Math.floor(est * 1024 ** 3));
      const data = await api("/api/rsync_manager/compatibility", {
        method: "POST",
        body: {
          ...sshPayload(),
          estimated_bytes,
          remote_path: remotePath.trim() || "/opt/copanel"
        }
      });
      setCompat(data);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Error");
    } finally {
      setCheckLoading(false);
    }
  };
  const installRsync = async () => {
    setError(null);
    setInstallLoading(true);
    try {
      const data = await api("/api/rsync_manager/install_rsync", {
        method: "POST",
        body: sshPayload()
      });
      if (!data.ok) {
        setError(data.stderr_tail || tr.installFail);
      }
      await runCompatibility();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Error");
    } finally {
      setInstallLoading(false);
    }
  };
  const runEstimate = async () => {
    setEstimateLoading(true);
    try {
      const data = await api("/api/rsync_manager/estimate", {
        method: "POST",
        body: {
          local_path: localPath.trim(),
          excludes: excludes.split("\n").map((l) => l.trim()).filter(Boolean)
        }
      });
      if (data.bytes > 0) {
        const gb = data.bytes / 1024 ** 3;
        setEstimateGb(gb >= 10 ? gb.toFixed(1) : gb.toFixed(2));
      }
    } catch {
    } finally {
      setEstimateLoading(false);
    }
  };
  const loadChecklist = async () => {
    try {
      const data = await api("/api/rsync_manager/checklist", {
        method: "POST",
        body: { mode, scenario: compat?.scenario || "target_rsync" }
      });
      setChecklist(lang === "vi" ? data.vi || data.en : data.en || []);
    } catch {
      setChecklist([]);
    }
  };
  const submitJob = async (dryRun) => {
    setError(null);
    setSubmitting(true);
    setConfirmOpen(false);
    try {
      if (!dryRun && compat?.can_proceed !== true) {
        throw new Error(tr.cannotProceed);
      }
      const data = await api("/api/rsync_manager/sync_job", {
        method: "POST",
        body: {
          ...sshPayload(),
          paths: buildPaths(),
          excludes: excludes.split("\n").map((l) => l.trim()).filter(Boolean),
          dry_run: dryRun,
          delete: wantDelete && mode !== "clone",
          mode
        }
      });
      setJobId(data.job_id);
      setSearchParams({ job: data.job_id });
      setStep("review");
      void jobsApi.refresh().catch(() => {
      });
      void jobsApi.get(data.job_id).catch(() => {
      });
    } catch (e) {
      setError(e instanceof Error ? e.message : "Error");
    } finally {
      setSubmitting(false);
    }
  };
  const resetWizard = () => {
    setJobId(null);
    setSearchParams({});
    setStep("mode");
    setCompat(null);
    setCheckedIds({});
    setError(null);
  };
  const stepIndex = STEP_ORDER.indexOf(step);
  const canNext = () => {
    if (step === "mode") return true;
    if (step === "target") return !!host.trim() && !!user.trim();
    if (step === "detect") return compat?.can_proceed === true;
    if (step === "scope") return !!localPath.trim() && !!remotePath.trim();
    return true;
  };
  const goNext = async () => {
    if (step === "detect" && !compat) {
      await runCompatibility();
      return;
    }
    if (step === "scope" && !estimateGb) {
      void runEstimate();
    }
    const next = STEP_ORDER[Math.min(STEP_ORDER.length - 1, stepIndex + 1)];
    setStep(next);
    if (next === "done") void loadChecklist();
  };
  const scenarioBadge = () => {
    const s = compat?.scenario;
    if (!s) return null;
    const map = {
      both_copanel: tr.scenarioBoth,
      target_rsync: tr.scenarioRsync,
      need_rsync: tr.scenarioNeed,
      blocked: tr.scenarioBlocked
    };
    return map[s] || s;
  };
  const card = cn(
    "rounded-2xl border p-4 md:p-5 space-y-4",
    isDark ? "bg-slate-900/60 border-slate-800" : "bg-white border-slate-200"
  );
  const muted = isDark ? "text-slate-400" : "text-slate-500";
  const inputCls = cn(
    "w-full rounded-xl border px-3 py-2 text-sm font-mono",
    isDark ? "bg-slate-950 border-slate-700 text-slate-100" : "bg-slate-50 border-slate-200 text-slate-900"
  );
  const renderMode = () => /* @__PURE__ */ jsx6("div", { className: "grid gap-3 md:grid-cols-3", children: [
    { id: "clone", icon: Icons3.Copy, title: tr.cloneTitle, desc: tr.cloneDesc },
    { id: "sync", icon: Icons3.RefreshCw, title: tr.syncTitle, desc: tr.syncDesc },
    { id: "move", icon: Icons3.ArrowRightLeft, title: tr.moveTitle, desc: tr.moveDesc }
  ].map((m) => {
    const active = mode === m.id;
    const Icon = m.icon;
    return /* @__PURE__ */ jsxs3(
      "button",
      {
        type: "button",
        onClick: () => {
          setMode(m.id);
          if (m.id === "clone") setWantDelete(false);
        },
        className: cn(
          "text-left rounded-2xl border p-4 transition-colors",
          active ? isDark ? "border-sky-500/60 bg-sky-500/10" : "border-sky-400 bg-sky-50" : isDark ? "border-slate-800 hover:border-slate-700" : "border-slate-200 hover:border-slate-300"
        ),
        children: [
          /* @__PURE__ */ jsx6(Icon, { className: cn("w-6 h-6 mb-2", active ? "text-sky-500" : muted) }),
          /* @__PURE__ */ jsx6("div", { className: "font-bold text-sm", children: m.title }),
          /* @__PURE__ */ jsx6("p", { className: cn("text-xs mt-1 leading-relaxed", muted), children: m.desc })
        ]
      },
      m.id
    );
  }) });
  const renderTarget = () => /* @__PURE__ */ jsxs3("div", { className: "space-y-4", children: [
    /* @__PURE__ */ jsxs3("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-3", children: [
      /* @__PURE__ */ jsxs3("label", { className: "space-y-1", children: [
        /* @__PURE__ */ jsx6("span", { className: cn("text-xs font-bold", muted), children: tr.host }),
        /* @__PURE__ */ jsx6("input", { value: host, onChange: (e) => setHost(e.target.value), className: inputCls, placeholder: "203.0.113.10" })
      ] }),
      /* @__PURE__ */ jsxs3("label", { className: "space-y-1", children: [
        /* @__PURE__ */ jsx6("span", { className: cn("text-xs font-bold", muted), children: tr.port }),
        /* @__PURE__ */ jsx6("input", { value: port, onChange: (e) => setPort(e.target.value), className: inputCls })
      ] }),
      /* @__PURE__ */ jsxs3("label", { className: "space-y-1 md:col-span-2", children: [
        /* @__PURE__ */ jsx6("span", { className: cn("text-xs font-bold", muted), children: tr.user }),
        /* @__PURE__ */ jsx6("input", { value: user, onChange: (e) => setUser(e.target.value), className: inputCls })
      ] }),
      /* @__PURE__ */ jsxs3("label", { className: "space-y-1 md:col-span-2", children: [
        /* @__PURE__ */ jsx6("span", { className: cn("text-xs font-bold", muted), children: tr.identity }),
        /* @__PURE__ */ jsx6(
          "input",
          {
            value: identityFile,
            onChange: (e) => setIdentityFile(e.target.value),
            className: inputCls,
            placeholder: "/root/.ssh/id_ed25519"
          }
        ),
        /* @__PURE__ */ jsx6("span", { className: cn("text-[10px]", muted), children: tr.identityHint })
      ] })
    ] }),
    sshHints.length > 0 && /* @__PURE__ */ jsxs3("div", { className: cn("rounded-xl border p-3 space-y-2", isDark ? "border-slate-800 bg-slate-950/50" : "border-slate-200 bg-slate-50"), children: [
      /* @__PURE__ */ jsx6("p", { className: cn("text-xs font-bold", muted), children: tr.keyHints }),
      sshHints.slice(0, 3).map((k) => /* @__PURE__ */ jsxs3("div", { className: "space-y-1", children: [
        /* @__PURE__ */ jsx6(
          "button",
          {
            type: "button",
            className: cn("text-xs font-mono underline", isDark ? "text-sky-400" : "text-sky-700"),
            onClick: () => setIdentityFile(k.identity_file),
            children: k.identity_file
          }
        ),
        k.public_key && /* @__PURE__ */ jsx6("pre", { className: cn("text-[10px] font-mono overflow-x-auto whitespace-pre-wrap break-all", muted), children: k.public_key })
      ] }, k.identity_file)),
      /* @__PURE__ */ jsx6("p", { className: cn("text-[10px]", muted), children: tr.keyAuthHint })
    ] })
  ] });
  const renderDetect = () => /* @__PURE__ */ jsxs3("div", { className: "space-y-4", children: [
    /* @__PURE__ */ jsxs3("div", { className: "flex flex-wrap gap-2", children: [
      /* @__PURE__ */ jsxs3(
        "button",
        {
          type: "button",
          onClick: () => void runCompatibility(),
          disabled: checkLoading || !host.trim(),
          className: "inline-flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-bold text-white bg-sky-600 hover:bg-sky-500 disabled:opacity-50",
          children: [
            checkLoading ? /* @__PURE__ */ jsx6(Icons3.Loader, { className: "w-4 h-4 animate-spin" }) : /* @__PURE__ */ jsx6(Icons3.ShieldCheck, { className: "w-4 h-4" }),
            checkLoading ? tr.checking : tr.check
          ]
        }
      ),
      compat?.scenario === "need_rsync" && /* @__PURE__ */ jsxs3(
        "button",
        {
          type: "button",
          onClick: () => void installRsync(),
          disabled: installLoading,
          className: "inline-flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-bold text-white bg-amber-600 hover:bg-amber-500 disabled:opacity-50",
          children: [
            installLoading ? /* @__PURE__ */ jsx6(Icons3.Loader, { className: "w-4 h-4 animate-spin" }) : /* @__PURE__ */ jsx6(Icons3.Download, { className: "w-4 h-4" }),
            tr.installRsync
          ]
        }
      ),
      compat && /* @__PURE__ */ jsxs3(
        "span",
        {
          className: cn(
            "inline-flex items-center gap-1 rounded-full px-3 py-1 text-xs font-bold",
            compat.can_proceed ? isDark ? "bg-emerald-950/50 text-emerald-300" : "bg-emerald-100 text-emerald-800" : isDark ? "bg-red-950/50 text-red-300" : "bg-red-100 text-red-800"
          ),
          children: [
            compat.can_proceed ? /* @__PURE__ */ jsx6(Icons3.Check, { className: "w-3.5 h-3.5" }) : /* @__PURE__ */ jsx6(Icons3.X, { className: "w-3.5 h-3.5" }),
            compat.can_proceed ? tr.canProceed : tr.cannotProceed
          ]
        }
      ),
      compat?.scenario && /* @__PURE__ */ jsx6("span", { className: cn("inline-flex items-center rounded-full px-3 py-1 text-xs font-semibold border", isDark ? "border-slate-700 text-slate-300" : "border-slate-200 text-slate-700"), children: scenarioBadge() })
    ] }),
    compat && /* @__PURE__ */ jsxs3("div", { className: "grid gap-2 md:grid-cols-2", children: [
      /* @__PURE__ */ jsx6(
        InfoPill,
        {
          isDark,
          label: tr.sourcePanel,
          value: compat.local_copanel?.present ? `CoPanel ${compat.local_copanel.version || ""}`.trim() : tr.noCopanel,
          ok: !!compat.local_copanel?.present
        }
      ),
      /* @__PURE__ */ jsx6(
        InfoPill,
        {
          isDark,
          label: tr.targetPanel,
          value: compat.remote_copanel?.present ? `CoPanel ${compat.remote_copanel.version || ""}`.trim() : compat.remote_rsync ? tr.rsyncOnly : tr.noRsync,
          ok: !!compat.remote_copanel?.present || !!compat.remote_rsync
        }
      )
    ] }),
    compat?.items?.length ? /* @__PURE__ */ jsx6("div", { className: "overflow-x-auto rounded-xl border border-slate-700/30", children: /* @__PURE__ */ jsxs3("table", { className: "w-full text-xs", children: [
      /* @__PURE__ */ jsx6("thead", { children: /* @__PURE__ */ jsxs3("tr", { className: isDark ? "bg-slate-950/80" : "bg-slate-100", children: [
        /* @__PURE__ */ jsx6("th", { className: "text-left p-2", children: tr.tableItem }),
        /* @__PURE__ */ jsx6("th", { className: "text-left p-2", children: tr.source }),
        /* @__PURE__ */ jsx6("th", { className: "text-left p-2", children: tr.target }),
        /* @__PURE__ */ jsx6("th", { className: "text-left p-2", children: "Status" })
      ] }) }),
      /* @__PURE__ */ jsx6("tbody", { children: compat.items.map((it) => /* @__PURE__ */ jsxs3("tr", { className: "border-t border-slate-700/20", children: [
        /* @__PURE__ */ jsxs3("td", { className: "p-2 align-top", children: [
          /* @__PURE__ */ jsx6("span", { className: "font-mono font-bold", children: it.id }),
          /* @__PURE__ */ jsx6("div", { className: cn("mt-1", muted), children: it.message })
        ] }),
        /* @__PURE__ */ jsx6("td", { className: "p-2 font-mono align-top break-all", children: it.source || "\u2014" }),
        /* @__PURE__ */ jsx6("td", { className: "p-2 font-mono align-top break-all", children: it.target || "\u2014" }),
        /* @__PURE__ */ jsx6("td", { className: cn("p-2 font-bold align-top", sevStyle(it.severity, isDark)), children: it.severity })
      ] }, it.id)) })
    ] }) }) : /* @__PURE__ */ jsx6("p", { className: cn("text-sm", muted), children: tr.detectHint })
  ] });
  const renderScope = () => /* @__PURE__ */ jsxs3("div", { className: "space-y-4", children: [
    /* @__PURE__ */ jsx6("div", { className: "flex flex-wrap gap-2", children: Object.values(presets).map((p) => /* @__PURE__ */ jsx6(
      "button",
      {
        type: "button",
        onClick: () => applyPreset(p.id),
        className: cn(
          "rounded-xl border px-3 py-1.5 text-xs font-bold",
          presetId === p.id ? "border-sky-500 text-sky-600 bg-sky-500/10" : isDark ? "border-slate-700 text-slate-300" : "border-slate-200 text-slate-600"
        ),
        children: lang === "vi" ? p.label_vi : p.label_en
      },
      p.id
    )) }),
    /* @__PURE__ */ jsxs3("label", { className: "space-y-1 block", children: [
      /* @__PURE__ */ jsx6("span", { className: cn("text-xs font-bold", muted), children: tr.localPath }),
      /* @__PURE__ */ jsx6("input", { value: localPath, onChange: (e) => setLocalPath(e.target.value), className: inputCls })
    ] }),
    /* @__PURE__ */ jsxs3("label", { className: "space-y-1 block", children: [
      /* @__PURE__ */ jsx6("span", { className: cn("text-xs font-bold", muted), children: tr.remotePath }),
      /* @__PURE__ */ jsx6("input", { value: remotePath, onChange: (e) => setRemotePath(e.target.value), className: inputCls })
    ] }),
    /* @__PURE__ */ jsxs3("label", { className: "inline-flex items-center gap-2 text-sm cursor-pointer", children: [
      /* @__PURE__ */ jsx6("input", { type: "checkbox", checked: extraWeb, onChange: (e) => setExtraWeb(e.target.checked), className: "rounded" }),
      tr.alsoWeb
    ] }),
    /* @__PURE__ */ jsxs3("label", { className: "space-y-1 block", children: [
      /* @__PURE__ */ jsx6("span", { className: cn("text-xs font-bold", muted), children: tr.excludes }),
      /* @__PURE__ */ jsx6(
        "textarea",
        {
          value: excludes,
          onChange: (e) => setExcludes(e.target.value),
          rows: 6,
          spellCheck: false,
          className: cn(inputCls, "text-xs")
        }
      ),
      /* @__PURE__ */ jsx6("span", { className: cn("text-[10px]", muted), children: tr.excludesHint })
    ] }),
    mode !== "clone" && /* @__PURE__ */ jsxs3("label", { className: "inline-flex items-start gap-2 text-sm cursor-pointer", children: [
      /* @__PURE__ */ jsx6(
        "input",
        {
          type: "checkbox",
          checked: wantDelete,
          onChange: (e) => setWantDelete(e.target.checked),
          className: "rounded mt-1"
        }
      ),
      /* @__PURE__ */ jsxs3("span", { children: [
        /* @__PURE__ */ jsx6("span", { className: "font-bold", children: tr.deleteOpt }),
        /* @__PURE__ */ jsx6("span", { className: cn("block text-xs", muted), children: tr.deleteHint })
      ] })
    ] }),
    /* @__PURE__ */ jsxs3("div", { className: "flex flex-wrap items-end gap-3", children: [
      /* @__PURE__ */ jsxs3("label", { className: "space-y-1 block max-w-xs", children: [
        /* @__PURE__ */ jsx6("span", { className: cn("text-xs font-bold", muted), children: tr.estimateGb }),
        /* @__PURE__ */ jsx6("input", { value: estimateGb, onChange: (e) => setEstimateGb(e.target.value), className: inputCls, placeholder: "20" })
      ] }),
      /* @__PURE__ */ jsx6(
        "button",
        {
          type: "button",
          onClick: () => void runEstimate(),
          disabled: estimateLoading,
          className: cn("rounded-xl border px-3 py-2 text-xs font-bold", isDark ? "border-slate-700" : "border-slate-200"),
          children: estimateLoading ? tr.estimating : tr.autoEstimate
        }
      )
    ] })
  ] });
  const renderReview = () => {
    if (jobId) {
      return /* @__PURE__ */ jsx6(RunPanel, { job, isDark, onReset: resetWizard, tr });
    }
    return /* @__PURE__ */ jsxs3("div", { className: "space-y-3 text-sm", children: [
      /* @__PURE__ */ jsx6(Row, { k: tr.modeLabel, v: mode, isDark }),
      /* @__PURE__ */ jsx6(Row, { k: "SSH", v: `${user}@${host}:${port}`, isDark, mono: true }),
      /* @__PURE__ */ jsx6(Row, { k: tr.localPath, v: localPath, isDark, mono: true }),
      /* @__PURE__ */ jsx6(Row, { k: tr.remotePath, v: remotePath, isDark, mono: true }),
      extraWeb && /* @__PURE__ */ jsx6(Row, { k: "Extra", v: "/var/www \u2192 /var/www", isDark, mono: true }),
      /* @__PURE__ */ jsx6(Row, { k: "--delete", v: wantDelete && mode !== "clone" ? "yes" : "no", isDark }),
      /* @__PURE__ */ jsx6(Row, { k: tr.scenario, v: scenarioBadge() || "\u2014", isDark }),
      /* @__PURE__ */ jsx6("p", { className: cn("text-xs", muted), children: tr.warnDocker }),
      /* @__PURE__ */ jsx6("p", { className: cn("text-xs", muted), children: tr.sqlNote })
    ] });
  };
  const renderDone = () => /* @__PURE__ */ jsxs3("div", { className: "space-y-3", children: [
    job?.status === "success" && /* @__PURE__ */ jsx6("p", { className: cn("text-sm font-semibold", isDark ? "text-emerald-400" : "text-emerald-700"), children: tr.jobSuccess }),
    (checklist.length ? checklist : []).map((c) => /* @__PURE__ */ jsxs3(
      "label",
      {
        className: cn(
          "flex gap-3 rounded-xl border p-3 cursor-pointer",
          isDark ? "border-slate-800" : "border-slate-200",
          checkedIds[c.id] && (isDark ? "bg-emerald-950/20" : "bg-emerald-50")
        ),
        children: [
          /* @__PURE__ */ jsx6(
            "input",
            {
              type: "checkbox",
              checked: !!checkedIds[c.id],
              onChange: (e) => setCheckedIds((s) => ({ ...s, [c.id]: e.target.checked })),
              className: "mt-1 rounded"
            }
          ),
          /* @__PURE__ */ jsxs3("span", { children: [
            /* @__PURE__ */ jsx6("span", { className: "text-sm font-bold block", children: c.title }),
            /* @__PURE__ */ jsx6("span", { className: cn("text-xs", muted), children: c.detail })
          ] })
        ]
      },
      c.id
    )),
    !checklist.length && /* @__PURE__ */ jsx6("p", { className: cn("text-sm", muted), children: tr.doneHint }),
    /* @__PURE__ */ jsxs3(
      "button",
      {
        type: "button",
        onClick: resetWizard,
        className: "inline-flex items-center gap-2 rounded-xl px-4 py-2 text-sm font-bold border border-slate-300 dark:border-slate-700",
        children: [
          /* @__PURE__ */ jsx6(Icons3.RotateCcw, { className: "w-4 h-4" }),
          tr.startOver
        ]
      }
    )
  ] });
  const renderStepContent = () => {
    switch (step) {
      case "mode":
        return renderMode();
      case "target":
        return renderTarget();
      case "detect":
        return renderDetect();
      case "scope":
        return renderScope();
      case "review":
        return renderReview();
      case "done":
        return renderDone();
      default:
        return null;
    }
  };
  const sidebar = /* @__PURE__ */ jsxs3("aside", { className: chromeSidebar(isDark), children: [
    /* @__PURE__ */ jsx6("div", { className: chromeSidebarHeader(isDark), children: /* @__PURE__ */ jsxs3("div", { className: "flex items-center gap-3", children: [
      /* @__PURE__ */ jsx6("div", { className: chromeSidebarIconBox(isDark), children: /* @__PURE__ */ jsx6(Icons3.RefreshCw, { className: "h-5 w-5 text-sky-500" }) }),
      /* @__PURE__ */ jsxs3("div", { className: "min-w-0", children: [
        /* @__PURE__ */ jsx6("h1", { className: chromeSidebarTitle(isDark), children: tr.title }),
        /* @__PURE__ */ jsx6("p", { className: chromeSidebarSubtitle(isDark), children: tr.subtitle })
      ] })
    ] }) }),
    /* @__PURE__ */ jsx6("nav", { className: chromeSidebarNav(), "aria-label": "Rsync wizard steps", children: STEP_ORDER.map((id) => {
      const Icon = STEP_ICONS[id];
      const active = step === id;
      const doneIdx = STEP_ORDER.indexOf(id) < stepIndex;
      return /* @__PURE__ */ jsxs3(
        "button",
        {
          type: "button",
          disabled: !!jobId && id !== "review" && id !== "done",
          onClick: () => setStep(id),
          className: cn(chromeNavItem(isDark, active, "sky"), "disabled:opacity-50"),
          children: [
            /* @__PURE__ */ jsx6(Icon, { className: cn(chromeNavIcon(isDark, active, "sky"), !active && doneIdx && "text-emerald-500") }),
            /* @__PURE__ */ jsx6("span", { className: "flex-1 truncate font-medium", children: labels[id] }),
            doneIdx && !active && /* @__PURE__ */ jsx6(Icons3.Check, { className: "h-3.5 w-3.5 shrink-0 text-emerald-500" })
          ]
        },
        id
      );
    }) })
  ] });
  return /* @__PURE__ */ jsxs3(ModuleViewport, { className: "flex min-h-0 flex-col overflow-hidden", children: [
    /* @__PURE__ */ jsx6(
      ModuleSidebarLayout,
      {
        isDark,
        mobileTitle: tr.title,
        className: isDark ? "text-slate-100" : "text-slate-900",
        sidebar,
        children: /* @__PURE__ */ jsxs3("div", { className: "flex min-w-0 flex-1 flex-col overflow-hidden", children: [
          /* @__PURE__ */ jsxs3("main", { className: cn("min-h-0 flex-1 overflow-y-auto", windowed ? "p-5" : "p-5 md:p-8"), children: [
            /* @__PURE__ */ jsxs3("header", { className: "mb-6 space-y-1.5", children: [
              /* @__PURE__ */ jsx6("h2", { className: cn("text-lg font-bold", isDark ? "text-slate-100" : "text-slate-900"), children: stepMeta[step].title }),
              /* @__PURE__ */ jsx6("p", { className: cn("text-xs max-w-2xl", muted), children: stepMeta[step].desc })
            ] }),
            /* @__PURE__ */ jsx6("div", { className: card, children: renderStepContent() }),
            error && /* @__PURE__ */ jsxs3("p", { className: "mt-3 text-sm text-red-500 flex items-center gap-2", children: [
              /* @__PURE__ */ jsx6(Icons3.AlertCircle, { className: "w-4 h-4" }),
              " ",
              error
            ] })
          ] }),
          !jobId && step !== "done" && /* @__PURE__ */ jsxs3(
            "footer",
            {
              className: cn(
                "shrink-0 flex items-center justify-between gap-3 border-t px-5 py-4",
                isDark ? "border-slate-800 bg-slate-950/50" : "border-slate-200 bg-white/80"
              ),
              children: [
                /* @__PURE__ */ jsx6(
                  "button",
                  {
                    type: "button",
                    onClick: () => setStep(STEP_ORDER[Math.max(0, stepIndex - 1)]),
                    disabled: stepIndex === 0,
                    className: cn(
                      "px-4 py-2 rounded-xl border text-sm font-bold disabled:opacity-40",
                      isDark ? "border-slate-700 text-slate-300" : "border-slate-200 text-slate-600"
                    ),
                    children: tr.back
                  }
                ),
                step === "review" ? /* @__PURE__ */ jsxs3("div", { className: "flex flex-wrap gap-2", children: [
                  /* @__PURE__ */ jsx6(
                    "button",
                    {
                      type: "button",
                      disabled: submitting,
                      onClick: () => {
                        setConfirmDry(true);
                        setConfirmOpen(true);
                      },
                      className: "px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-bold disabled:opacity-50",
                      children: tr.dryRun
                    }
                  ),
                  /* @__PURE__ */ jsx6(
                    "button",
                    {
                      type: "button",
                      disabled: submitting || compat?.can_proceed !== true,
                      onClick: () => {
                        setConfirmDry(false);
                        setConfirmOpen(true);
                      },
                      className: "px-4 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-white text-sm font-bold disabled:opacity-50",
                      children: tr.runSync
                    }
                  )
                ] }) : /* @__PURE__ */ jsx6(
                  "button",
                  {
                    type: "button",
                    onClick: () => void goNext(),
                    disabled: !canNext() && step !== "detect",
                    className: "px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-sm font-bold disabled:opacity-50",
                    children: step === "detect" && !compat ? tr.check : tr.next
                  }
                )
              ]
            }
          )
        ] })
      }
    ),
    /* @__PURE__ */ jsx6(
      WindowModal,
      {
        open: confirmOpen,
        onClose: () => setConfirmOpen(false),
        title: confirmDry ? tr.confirmDryTitle : tr.confirmRealTitle,
        maxWidth: "md",
        children: /* @__PURE__ */ jsxs3("div", { className: "space-y-4 p-4", children: [
          /* @__PURE__ */ jsx6("p", { className: cn("text-sm", muted), children: confirmDry ? tr.confirmDryBody : tr.confirmRealBody }),
          /* @__PURE__ */ jsxs3("div", { className: cn("rounded-xl border p-3 text-xs space-y-1", isDark ? "border-slate-800 bg-slate-950" : "border-slate-200 bg-slate-50"), children: [
            /* @__PURE__ */ jsx6(Row, { k: "Mode", v: mode, isDark }),
            /* @__PURE__ */ jsx6(Row, { k: "Target", v: `${user}@${host}`, isDark, mono: true }),
            /* @__PURE__ */ jsx6(Row, { k: "Paths", v: String(buildPaths().length), isDark }),
            !confirmDry && wantDelete && mode !== "clone" && /* @__PURE__ */ jsx6("p", { className: "text-amber-600 font-bold", children: "--delete enabled" })
          ] }),
          /* @__PURE__ */ jsxs3("div", { className: "flex justify-end gap-2", children: [
            /* @__PURE__ */ jsx6(
              "button",
              {
                type: "button",
                onClick: () => setConfirmOpen(false),
                className: cn("px-4 py-2 rounded-xl text-sm font-bold border", isDark ? "border-slate-700" : "border-slate-200"),
                children: tr.cancel
              }
            ),
            /* @__PURE__ */ jsx6(
              "button",
              {
                type: "button",
                onClick: () => void submitJob(confirmDry),
                disabled: submitting,
                className: "px-4 py-2 rounded-xl bg-sky-600 text-white text-sm font-bold",
                children: tr.confirm
              }
            )
          ] })
        ] })
      }
    )
  ] });
}
function sevStyle(s, isDark) {
  if (s === "block") return isDark ? "text-red-400" : "text-red-600";
  if (s === "warn") return isDark ? "text-amber-400" : "text-amber-700";
  return isDark ? "text-emerald-400" : "text-emerald-700";
}
function InfoPill({
  label,
  value,
  ok,
  isDark
}) {
  return /* @__PURE__ */ jsxs3(
    "div",
    {
      className: cn(
        "rounded-xl border px-3 py-2 text-xs",
        ok ? isDark ? "border-emerald-500/30 bg-emerald-500/10" : "border-emerald-200 bg-emerald-50" : isDark ? "border-slate-700 bg-slate-950/40" : "border-slate-200 bg-slate-50"
      ),
      children: [
        /* @__PURE__ */ jsx6("div", { className: cn("font-bold uppercase tracking-wide", isDark ? "text-slate-400" : "text-slate-500"), children: label }),
        /* @__PURE__ */ jsx6("div", { className: "mt-0.5 font-semibold", children: value })
      ]
    }
  );
}
function Row({ k, v, isDark, mono }) {
  return /* @__PURE__ */ jsxs3("div", { className: "flex gap-3 text-xs", children: [
    /* @__PURE__ */ jsx6("span", { className: cn("w-28 shrink-0 font-bold", isDark ? "text-slate-400" : "text-slate-500"), children: k }),
    /* @__PURE__ */ jsx6("span", { className: cn("min-w-0 break-all", mono && "font-mono"), children: v })
  ] });
}
function RunPanel({
  job,
  isDark,
  onReset,
  tr
}) {
  const [logs, setLogs] = useState3("");
  useEffect3(() => {
    if (!job?.id) return;
    let cancelled = false;
    const tick = () => {
      api(
        `/api/platform/jobs/${job.id}`
      ).then((d) => {
        if (cancelled) return;
        if (Array.isArray(d.logs) && d.logs.length) {
          setLogs(
            d.logs.slice(-100).map((l) => l.line || "").filter(Boolean).join("\n")
          );
        }
      }).catch(() => {
      });
    };
    tick();
    const t = setInterval(tick, 2e3);
    return () => {
      cancelled = true;
      clearInterval(t);
    };
  }, [job?.id, job?.status, job?.progress]);
  if (!job) {
    return /* @__PURE__ */ jsx6("p", { className: cn("text-sm", isDark ? "text-slate-400" : "text-slate-500"), children: tr.submitting });
  }
  const failed = job.status === "failed";
  const done = job.status === "success";
  const running = job.status === "running" || job.status === "queued";
  return /* @__PURE__ */ jsxs3("div", { className: "space-y-4", children: [
    /* @__PURE__ */ jsxs3("div", { className: "flex items-center justify-between gap-2", children: [
      /* @__PURE__ */ jsx6("h3", { className: "text-base font-bold", children: job.title }),
      /* @__PURE__ */ jsx6("span", { className: "text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-sky-500/15 text-sky-500", children: job.status })
    ] }),
    running && /* @__PURE__ */ jsx6("div", { className: cn("h-2 rounded-full overflow-hidden", isDark ? "bg-slate-800" : "bg-slate-200"), children: /* @__PURE__ */ jsx6("div", { className: "h-full bg-sky-500 transition-all", style: { width: `${job.progress || 0}%` } }) }),
    job.message && /* @__PURE__ */ jsx6("p", { className: cn("text-xs", isDark ? "text-slate-400" : "text-slate-500"), children: job.message }),
    failed && /* @__PURE__ */ jsx6("p", { className: "text-sm text-red-500", children: job.error }),
    done && job.result?.summary && /* @__PURE__ */ jsx6("p", { className: cn("text-sm", isDark ? "text-emerald-400" : "text-emerald-700"), children: String(job.result.summary) }),
    logs && /* @__PURE__ */ jsx6(
      "pre",
      {
        className: cn(
          "rounded-xl border p-3 text-[11px] font-mono overflow-auto max-h-64 whitespace-pre-wrap",
          isDark ? "bg-slate-950 border-slate-800 text-slate-300" : "bg-slate-50 border-slate-200 text-slate-800"
        ),
        children: logs
      }
    ),
    (done || failed) && /* @__PURE__ */ jsx6(
      "button",
      {
        type: "button",
        onClick: onReset,
        className: cn("rounded-xl border px-3 py-2 text-xs font-bold", isDark ? "border-slate-700" : "border-slate-200"),
        children: tr.startOver
      }
    )
  ] });
}
var en = {
  title: "Rsync Manager",
  subtitle: "Move \xB7 Clone \xB7 Sync VPS",
  stepMode: "Mode",
  stepTarget: "Target",
  stepDetect: "Detect",
  stepScope: "Scope",
  stepReview: "Run",
  stepDone: "Checklist",
  modeTitle: "Choose migration mode",
  modeDesc: "Works when both servers have CoPanel, or the target already has rsync.",
  targetTitle: "Target SSH",
  targetDesc: "Key-based SSH from this panel to VPS 2 (BatchMode).",
  detectTitle: "Compatibility & CoPanel detect",
  detectDesc: "Detects remote CoPanel, rsync, arch, OS, and free disk.",
  scopeTitle: "Paths & excludes",
  scopeDesc: "Pick CoPanel / web presets or custom trees. Safer excludes skip config & data by default.",
  reviewTitle: "Review & run",
  reviewDesc: "Dry-run first, then real sync as a Task Center job with progress.",
  doneTitle: "Post-migrate checklist",
  doneDesc: "SQL, Docker, DNS/SSL, and cutover are manual \u2014 tick off as you finish.",
  modeLabel: "Mode",
  cloneTitle: "Clone",
  cloneDesc: "Copy trees to VPS 2 without deleting remote extras. Source stays online.",
  syncTitle: "Sync",
  syncDesc: "Incremental update. Optional --delete for a mirror.",
  moveTitle: "Move",
  moveDesc: "Full cutover workflow: sync files, then checklist for DNS/SQL/Docker.",
  host: "Host / IP",
  port: "Port",
  user: "User",
  identity: "Identity file (on this server)",
  identityHint: "Private key readable by the panel user.",
  keyHints: "Detected keys on this host",
  keyAuthHint: "Paste the public key into target ~/.ssh/authorized_keys, then select the identity path.",
  check: "Run detection",
  checking: "Checking\u2026",
  installRsync: "Install rsync on target",
  installFail: "Could not install rsync on target (need root or passwordless sudo).",
  canProceed: "Ready",
  cannotProceed: "Blocked \u2014 fix red items",
  scenarioBoth: "Both sides: CoPanel",
  scenarioRsync: "Target: rsync ready",
  scenarioNeed: "Target: needs rsync",
  scenarioBlocked: "Blocked",
  sourcePanel: "Source",
  targetPanel: "Target",
  noCopanel: "No CoPanel tree",
  rsyncOnly: "rsync only (no CoPanel yet)",
  noRsync: "rsync missing",
  detectHint: "Run detection to see architecture, OS, CoPanel, and rsync status.",
  tableItem: "Check",
  source: "Source",
  target: "Target",
  localPath: "Local source path",
  remotePath: "Remote absolute path",
  alsoWeb: "Also sync /var/www",
  excludes: "Exclude patterns (one per line)",
  excludesHint: "Default CoPanel preset skips config/, backend/data/, venv, node_modules.",
  deleteOpt: "Mirror deletions (--delete)",
  deleteHint: "Removes files on target that are gone on source. Dangerous \u2014 confirm carefully.",
  estimateGb: "Estimated size (GB)",
  autoEstimate: "Auto du",
  estimating: "Estimating\u2026",
  dryRun: "Dry run",
  runSync: "Run real sync",
  scenario: "Scenario",
  warnDocker: "Docker is not migrated; rebuild stacks on the new VPS.",
  sqlNote: "Databases: dump/restore separately (Database Manager).",
  jobSuccess: "Transfer job finished successfully.",
  doneHint: "Load checklist after a successful job, or continue manually.",
  startOver: "Start over",
  back: "Back",
  next: "Next",
  cancel: "Cancel",
  confirm: "Start",
  confirmDryTitle: "Start dry-run?",
  confirmDryBody: "No files will be written. Progress appears in Task Center.",
  confirmRealTitle: "Start real sync?",
  confirmRealBody: "Files will be copied over SSH. Ensure detection passed and excludes look correct.",
  submitting: "Submitting job\u2026"
};
var vi = {
  title: "Rsync Manager",
  subtitle: "Move \xB7 Clone \xB7 Sync VPS",
  stepMode: "Ch\u1EBF \u0111\u1ED9",
  stepTarget: "M\xE1y \u0111\xEDch",
  stepDetect: "Ph\xE1t hi\u1EC7n",
  stepScope: "Ph\u1EA1m vi",
  stepReview: "Ch\u1EA1y",
  stepDone: "Checklist",
  modeTitle: "Ch\u1ECDn ch\u1EBF \u0111\u1ED9 chuy\u1EC3n m\xE1y",
  modeDesc: "D\xF9ng khi c\u1EA3 hai m\xE1y c\xF3 CoPanel, ho\u1EB7c m\xE1y \u0111\xEDch \u0111\xE3 c\xF3 rsync.",
  targetTitle: "SSH m\xE1y \u0111\xEDch",
  targetDesc: "SSH b\u1EB1ng kh\xF3a t\u1EEB panel n\xE0y sang VPS 2 (BatchMode).",
  detectTitle: "T\u01B0\u01A1ng th\xEDch & ph\xE1t hi\u1EC7n CoPanel",
  detectDesc: "Ph\xE1t hi\u1EC7n CoPanel remote, rsync, arch, OS v\xE0 dung l\u01B0\u1EE3ng tr\u1ED1ng.",
  scopeTitle: "\u0110\u01B0\u1EDDng d\u1EABn & lo\u1EA1i tr\u1EEB",
  scopeDesc: "Preset CoPanel / web ho\u1EB7c t\xF9y ch\u1EC9nh. M\u1EB7c \u0111\u1ECBnh b\u1ECF config & data \u0111\u1EC3 an to\xE0n.",
  reviewTitle: "Xem l\u1EA1i & ch\u1EA1y",
  reviewDesc: "Dry-run tr\u01B0\u1EDBc, r\u1ED3i sync th\u1EADt qua Task Center c\xF3 ti\u1EBFn tr\xECnh.",
  doneTitle: "Checklist sau migrate",
  doneDesc: "SQL, Docker, DNS/SSL v\xE0 cutover l\xE0m th\u1EE7 c\xF4ng \u2014 \u0111\xE1nh d\u1EA5u khi xong.",
  modeLabel: "Ch\u1EBF \u0111\u1ED9",
  cloneTitle: "Clone",
  cloneDesc: "Sao ch\xE9p sang VPS 2, kh\xF4ng xo\xE1 file th\u1EEBa tr\xEAn \u0111\xEDch. Ngu\u1ED3n v\u1EABn ch\u1EA1y.",
  syncTitle: "Sync",
  syncDesc: "C\u1EADp nh\u1EADt t\u0103ng d\u1EA7n. Tu\u1EF3 ch\u1ECDn --delete \u0111\u1EC3 mirror.",
  moveTitle: "Move",
  moveDesc: "Quy tr\xECnh cutover: sync file r\u1ED3i checklist DNS/SQL/Docker.",
  host: "Host / IP",
  port: "C\u1ED5ng",
  user: "User",
  identity: "File kh\xF3a (tr\xEAn m\xE1y panel)",
  identityHint: "Private key user panel \u0111\u1ECDc \u0111\u01B0\u1EE3c.",
  keyHints: "Kh\xF3a ph\xE1t hi\u1EC7n tr\xEAn m\xE1y n\xE0y",
  keyAuthHint: "D\xE1n public key v\xE0o ~/.ssh/authorized_keys tr\xEAn \u0111\xEDch, r\u1ED3i ch\u1ECDn identity.",
  check: "Ch\u1EA1y ph\xE1t hi\u1EC7n",
  checking: "\u0110ang ki\u1EC3m tra\u2026",
  installRsync: "C\xE0i rsync tr\xEAn \u0111\xEDch",
  installFail: "Kh\xF4ng c\xE0i \u0111\u01B0\u1EE3c rsync tr\xEAn \u0111\xEDch (c\u1EA7n root ho\u1EB7c sudo kh\xF4ng m\u1EADt kh\u1EA9u).",
  canProceed: "S\u1EB5n s\xE0ng",
  cannotProceed: "B\u1ECB ch\u1EB7n \u2014 s\u1EEDa m\u1EE5c \u0111\u1ECF",
  scenarioBoth: "Hai ph\xEDa: c\xF3 CoPanel",
  scenarioRsync: "\u0110\xEDch: \u0111\xE3 c\xF3 rsync",
  scenarioNeed: "\u0110\xEDch: thi\u1EBFu rsync",
  scenarioBlocked: "B\u1ECB ch\u1EB7n",
  sourcePanel: "Ngu\u1ED3n",
  targetPanel: "\u0110\xEDch",
  noCopanel: "Kh\xF4ng c\xF3 c\xE2y CoPanel",
  rsyncOnly: "Ch\u1EC9 rsync (ch\u01B0a CoPanel)",
  noRsync: "Thi\u1EBFu rsync",
  detectHint: "Ch\u1EA1y ph\xE1t hi\u1EC7n \u0111\u1EC3 xem arch, OS, CoPanel v\xE0 rsync.",
  tableItem: "M\u1EE5c",
  source: "Ngu\u1ED3n",
  target: "\u0110\xEDch",
  localPath: "\u0110\u01B0\u1EDDng d\u1EABn ngu\u1ED3n",
  remotePath: "\u0110\u01B0\u1EDDng d\u1EABn \u0111\xEDch (tuy\u1EC7t \u0111\u1ED1i)",
  alsoWeb: "\u0110\u1ED3ng b\u1ED9 th\xEAm /var/www",
  excludes: "M\u1EABu lo\u1EA1i tr\u1EEB (m\u1ED7i d\xF2ng m\u1ED9t m\u1EABu)",
  excludesHint: "Preset CoPanel m\u1EB7c \u0111\u1ECBnh b\u1ECF config/, backend/data/, venv, node_modules.",
  deleteOpt: "Mirror xo\xE1 (--delete)",
  deleteHint: "Xo\xE1 file tr\xEAn \u0111\xEDch \u0111\xE3 m\u1EA5t \u1EDF ngu\u1ED3n. Nguy hi\u1EC3m \u2014 x\xE1c nh\u1EADn k\u1EF9.",
  estimateGb: "Dung l\u01B0\u1EE3ng \u01B0\u1EDBc t\xEDnh (GB)",
  autoEstimate: "T\u1EF1 du",
  estimating: "\u0110ang \u01B0\u1EDBc t\xEDnh\u2026",
  dryRun: "Ch\u1EA1y th\u1EED",
  runSync: "\u0110\u1ED3ng b\u1ED9 th\u1EADt",
  scenario: "K\u1ECBch b\u1EA3n",
  warnDocker: "Docker kh\xF4ng \u0111\u01B0\u1EE3c chuy\u1EC3n; d\u1EF1ng l\u1EA1i tr\xEAn VPS m\u1EDBi.",
  sqlNote: "Database: dump/restore ri\xEAng (Database Manager).",
  jobSuccess: "Job chuy\u1EC3n file \u0111\xE3 ho\xE0n t\u1EA5t.",
  doneHint: "Checklist t\u1EA3i sau job th\xE0nh c\xF4ng, ho\u1EB7c l\xE0m th\u1EE7 c\xF4ng.",
  startOver: "B\u1EAFt \u0111\u1EA7u l\u1EA1i",
  back: "Quay l\u1EA1i",
  next: "Ti\u1EBFp",
  cancel: "H\u1EE7y",
  confirm: "B\u1EAFt \u0111\u1EA7u",
  confirmDryTitle: "Ch\u1EA1y dry-run?",
  confirmDryBody: "Kh\xF4ng ghi file. Ti\u1EBFn tr\xECnh hi\u1EC7n \u1EDF Task Center.",
  confirmRealTitle: "Ch\u1EA1y sync th\u1EADt?",
  confirmRealBody: "File s\u1EBD \u0111\u01B0\u1EE3c copy qua SSH. \u0110\u1EA3m b\u1EA3o \u0111\xE3 detect OK v\xE0 excludes \u0111\xFAng.",
  submitting: "\u0110ang g\u1EEDi job\u2026"
};
var TEXT = { en, vi };
export {
  RsyncManager as default
};
