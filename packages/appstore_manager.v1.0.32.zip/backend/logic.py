"""
AppStore Manager Logic Layer
Pulls package details from dynamic GitHub index file, handles on-demand installation.
"""
import logging
import os
import urllib.request
import json
import re
import platform
import subprocess
import shutil
import shlex
import tempfile
import threading
import time
import zipfile
import sqlite3
from pathlib import Path
from typing import Any, Dict, List, Optional

CATALOG_URL = "https://raw.githubusercontent.com/phuspeed/CoPanel-AppStore/main/packages.json"
CATALOG_API_URL = "https://api.github.com/repos/phuspeed/CoPanel-AppStore/contents/packages.json"
BUILD_TASKS = {}
logger = logging.getLogger(__name__)

# Desktop UI track: keep windowMode / lazy-xterm files when AppStore ZIP overwrites modules.
DESKTOP_UI_PRESERVE_FILES: Dict[str, tuple] = {
    "appstore_manager": ("config.ts",),
    "file_manager": ("config.ts",),
    "terminal": ("config.ts", "index.tsx"),
}


def get_copanel_home() -> Path:
    """Production: /opt/copanel. Dev: repo root (directory that contains backend/)."""
    if Path("/opt/copanel").exists():
        return Path("/opt/copanel")
    # This file: <root>/backend/modules/appstore_manager/logic.py
    return Path(__file__).resolve().parent.parent.parent.parent


def _purge_module_pycache(module_dir: Path) -> None:
    cache = module_dir / "__pycache__"
    if cache.is_dir():
        shutil.rmtree(cache, ignore_errors=True)


def appstore_config_file() -> Path:
    return get_copanel_home() / "config" / "appstore_config.json"


def appstore_config_db_file() -> Path:
    return get_copanel_home() / "config" / "appstore_manager.db"


def _cfg_db() -> sqlite3.Connection:
    db_path = appstore_config_db_file()
    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row
    return conn


def _init_cfg_db() -> None:
    with _cfg_db() as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS appstore_settings (
                key TEXT PRIMARY KEY,
                value TEXT
            )
            """
        )


def _get_cfg_value(key: str, default: str = "") -> str:
    _init_cfg_db()
    with _cfg_db() as conn:
        row = conn.execute("SELECT value FROM appstore_settings WHERE key = ?", (key,)).fetchone()
    return str(row["value"]) if row and row["value"] is not None else default


def _set_cfg_value(key: str, value: str) -> None:
    _init_cfg_db()
    with _cfg_db() as conn:
        conn.execute("INSERT OR REPLACE INTO appstore_settings (key, value) VALUES (?, ?)", (key, value))


def derive_pkg_id_from_upload_name(filename: str) -> str:
    """Stable module id from an uploaded zip name (handles path junk and *.v1.0.0 style)."""
    name = Path(filename or "custom_module.zip").name
    if name.lower().endswith(".zip"):
        name = name[:-4]
    name = name.split("-v")[0].split("_v")[0]
    name = name.split(".")[0].strip().lower()
    return name or "custom_module"


def normalize_version(v: str) -> str:
    if not v or not isinstance(v, str):
        return "0.0.0"
    s = v.strip()
    if s.lower().startswith("v"):
        s = s[1:].strip()
    return s or "0.0.0"


def compare_versions(a: str, b: str) -> int:
    """
    Semver-aware comparison. Returns negative if a < b, 0 if equal, positive if a > b.
    Falls back to numeric tuple compare when PEP 440 parsing fails.
    """
    from packaging.version import InvalidVersion, Version

    na, nb = normalize_version(a), normalize_version(b)
    try:
        va, vb = Version(na), Version(nb)
        if va < vb:
            return -1
        if va > vb:
            return 1
        return 0
    except InvalidVersion:
        pass
    try:
        def numeric_tuple(s: str) -> tuple:
            parts = []
            for segment in s.replace("-", ".").split("."):
                segment = "".join(c for c in segment if c.isdigit())
                if segment:
                    parts.append(int(segment))
            return tuple(parts) if parts else (0,)

        ta, tb = numeric_tuple(na), numeric_tuple(nb)
        maxlen = max(len(ta), len(tb))
        ta = ta + (0,) * (maxlen - len(ta))
        tb = tb + (0,) * (maxlen - len(tb))
        if ta < tb:
            return -1
        if ta > tb:
            return 1
        return 0
    except Exception:
        if na == nb:
            return 0
        return 1 if na > nb else -1


def is_update_available(remote_version: str, local_version: str) -> bool:
    return compare_versions(remote_version, local_version) > 0


# Modules whose installer/runtime cannot hot-reload safely — user must restart manually.
COPANEL_RESTART_RECOMMENDED = frozenset({"appstore_manager"})

_RESTART_LOG_HINT = (
    "⚠️ Restart copanel service to activate backend changes — use «Restart CoPanel» below "
    "or run: sudo systemctl restart copanel"
)


def _new_build_task(logs: Optional[List[str]] = None) -> Dict[str, Any]:
    return {
        "status": "running",
        "logs": logs or ["Starting download and extraction..."],
        "error": "",
        "progress": 3,
        "restart_required": False,
        "restart_reason": None,
        "backend_status": "pending",
        "frontend_status": "pending",
        "ui_online": True,
    }


def _mark_restart_required(pkg_id: str, reason: str, *, log_line: Optional[str] = None) -> None:
    global BUILD_TASKS
    task = BUILD_TASKS.get(pkg_id)
    if not task:
        return
    task["restart_required"] = True
    task["restart_reason"] = reason
    task["logs"].append(log_line or _RESTART_LOG_HINT)


# Key routes that must exist after install — prefix /api/{module_id} is implied.
MODULE_ROUTE_PROBES: Dict[str, List[str]] = {
    "storage_manager": [
        "/partitions/delete",
        "/partitions/create",
        "/disks/{disk_name}/partitions",
        "/disks/{disk_name}/initialize",
        "/format",
        "/mount",
        "/version",
    ],
    "package_manager": ["/list"],
    "appstore_manager": ["/catalog", "/restart-copanel"],
}


def _module_api_routes_active(pkg_id: str) -> bool:
    """True if required API routes for this module are registered on the running process."""
    try:
        from core.module_reload import list_module_route_paths

        paths = set(list_module_route_paths(pkg_id))
        if not paths:
            return False
        prefix = f"/api/{pkg_id}"
        required = MODULE_ROUTE_PROBES.get(pkg_id)
        if required:
            for suffix in required:
                if f"{prefix}{suffix}" not in paths:
                    return False
            return True
        return any(p == prefix or p.startswith(prefix + "/") for p in paths)
    except Exception:
        return False


def _core_hot_reload_available() -> bool:
    try:
        from core import module_reload as _mr  # noqa: F401
        return True
    except ImportError:
        return False


def _finalize_module_install(
    pkg_id: str,
    *,
    backend_updated: bool,
    frontend_updated: bool,
    requires_copanel_restart: bool = False,
    is_new_backend: bool = False,
) -> None:
    """Apply post-install steps; restart copanel when hot-reload cannot expose API routes."""
    global BUILD_TASKS

    if frontend_updated:
        BUILD_TASKS[pkg_id]["logs"].append("✅ Frontend rebuilt — refresh the browser to see UI changes.")
    elif backend_updated:
        BUILD_TASKS[pkg_id]["logs"].append("ℹ️ No frontend in package — skipped npm build.")

    if not backend_updated:
        if frontend_updated:
            BUILD_TASKS[pkg_id]["logs"].append("ℹ️ Frontend-only update; backend unchanged.")
        return

    if requires_copanel_restart or pkg_id in COPANEL_RESTART_RECOMMENDED:
        _mark_restart_required(
            pkg_id,
            "module_flag" if requires_copanel_restart else "core_module",
            log_line=f"⚠️ «{pkg_id}» needs a copanel service restart to take effect.",
        )
        return

    if is_new_backend:
        _mark_restart_required(
            pkg_id,
            "new_backend",
            log_line=f"⚠️ New backend module «{pkg_id}» — restart copanel to register API routes.",
        )
        if platform.system() != "Windows":
            BUILD_TASKS[pkg_id]["logs"].append("⏳ Scheduling copanel service restart…")
            restart_backend_service(delay=5.0)
        return

    if not _core_hot_reload_available():
        BUILD_TASKS[pkg_id]["logs"].append(
            "⚠️ CoPanel core is outdated (missing core/module_reload.py). "
            "Run on the server: cd /opt/copanel && git pull origin main"
        )
        _mark_restart_required(pkg_id, "core_outdated")
        if platform.system() != "Windows":
            BUILD_TASKS[pkg_id]["logs"].append("⏳ Scheduling copanel service restart (loads module from disk)…")
            restart_backend_service(delay=5.0)
        return

    try:
        from core.module_reload import reload_module

        ok, msg = reload_module(pkg_id)
    except Exception as exc:
        ok, msg = False, str(exc)

    if ok and _module_api_routes_active(pkg_id):
        BUILD_TASKS[pkg_id]["logs"].append(f"✅ Backend API reloaded for «{pkg_id}» (no copanel restart).")
        return

    if ok:
        BUILD_TASKS[pkg_id]["logs"].append(
            f"⚠️ «{pkg_id}» hot-reload OK but required API routes are missing (stale process?)."
        )
    else:
        BUILD_TASKS[pkg_id]["logs"].append(f"⚠️ Could not hot-reload backend: {msg}")
    _mark_restart_required(pkg_id, "hot_reload_failed")
    if platform.system() != "Windows":
        BUILD_TASKS[pkg_id]["logs"].append(
            "⏳ Scheduling copanel service restart — required to register backend API routes."
        )
        restart_backend_service(delay=5.0)


def restart_backend_service(delay: float = 2.0) -> Dict[str, Any]:
    """
    Restart the copanel systemd service (Linux production).
    Runs in a daemon thread with a short delay so the HTTP response can flush first.
    """
    if platform.system() == "Windows":
        return {
            "scheduled": False,
            "message": "Restart is only available on Linux hosts with systemd.",
        }

    if not shutil.which("systemctl"):
        return {
            "scheduled": False,
            "message": "systemctl not found. Run manually: sudo systemctl restart copanel",
        }

    def _run_restart() -> subprocess.CompletedProcess:
        cmd = ["systemctl", "restart", "copanel"]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
        if result.returncode != 0 and shutil.which("sudo"):
            result = subprocess.run(
                ["sudo", "-n", "systemctl", "restart", "copanel"],
                capture_output=True,
                text=True,
                timeout=60,
            )
        return result

    def _do_restart():
        time.sleep(delay)
        try:
            result = _run_restart()
            if result.returncode != 0:
                logger.error(
                    "systemctl restart copanel failed (exit %s): %s",
                    result.returncode,
                    (result.stderr or result.stdout or "").strip(),
                )
        except Exception as exc:
            logger.exception("systemctl restart copanel failed: %s", exc)

    threading.Thread(target=_do_restart, daemon=True).start()
    return {
        "scheduled": True,
        "message": "CoPanel service restart scheduled.",
    }


CORE_PACKAGE_VERSIONS = {
    "appstore_manager": "1.0.21",
    "ssl_manager": "1.0.1",
    "backup_manager": "1.0.3",
    "package_manager": "1.0.0"
}

_PKG_ID_SAFE = re.compile(r"^[a-zA-Z][a-zA-Z0-9_]{0,63}$")
PROTECTED_UNINSTALL_IDS = frozenset(CORE_PACKAGE_VERSIONS.keys())


def _validate_uninstall_package_id(pkg_id: str) -> str:
    pid = (pkg_id or "").strip()
    if not _PKG_ID_SAFE.match(pid):
        raise ValueError("Invalid package id.")
    if pid in PROTECTED_UNINSTALL_IDS:
        raise ValueError("Cannot uninstall a core panel module.")
    return pid


def remove_local_package_record(pkg_id: str) -> None:
    """Remove pkg_id from installed_packages.json after uninstall."""
    home = get_copanel_home()
    for cfg_dir in [home / "config"]:
        installed_file = cfg_dir / "installed_packages.json"
        if not installed_file.exists():
            continue
        try:
            with open(installed_file, "r", encoding="utf-8") as f:
                data = json.load(f)
            if not isinstance(data, dict) or pkg_id not in data:
                continue
            del data[pkg_id]
            with open(installed_file, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=4)
        except Exception:
            pass


def _cpu_lacks_avx() -> bool:
    """True on older x86 CPUs (e.g. Celeron J3455) where Rollup native may segfault under parallel I/O."""
    if platform.system() != "Linux":
        return False
    try:
        with open("/proc/cpuinfo", encoding="utf-8", errors="ignore") as f:
            return "avx" not in f.read().lower()
    except OSError:
        return False


def _is_desktop_ui_track() -> bool:
    """True when panel install chose Desktop UI (config/ui_track or env)."""
    if os.environ.get("COPANEL_UI_TRACK", "").strip().lower() == "desktop":
        return True
    marker = get_copanel_home() / "config" / "ui_track"
    if marker.is_file():
        try:
            return marker.read_text(encoding="utf-8").strip().lower() == "desktop"
        except OSError:
            pass
    return False


def _is_desktop_appstore_frontend(dst: Path) -> bool:
    return (dst / "components" / "AppStoreSidebar.tsx").is_file()


def _install_frontend_module_tree(
    src_frontend: Path,
    dst_frontend: Path,
    pkg_id: str,
    log_lines: Optional[List[str]] = None,
) -> None:
    """Copy frontend module; on Desktop UI track preserve pilot windowMode / xterm files."""
    preserve_names = set(DESKTOP_UI_PRESERVE_FILES.get(pkg_id, ()))
    if _is_desktop_ui_track() and pkg_id == "appstore_manager" and _is_desktop_appstore_frontend(dst_frontend):
        preserve_names |= {"index.tsx", "i18n.ts", "types.ts", "utils.ts"}
    backups: Dict[str, str] = {}
    components_backup: Optional[Path] = None
    if _is_desktop_ui_track() and preserve_names and dst_frontend.is_dir():
        for name in preserve_names:
            path = dst_frontend / name
            if path.is_file():
                try:
                    backups[name] = path.read_text(encoding="utf-8")
                except OSError:
                    pass
        if pkg_id == "appstore_manager" and _is_desktop_appstore_frontend(dst_frontend):
            comp = dst_frontend / "components"
            if comp.is_dir():
                components_backup = get_copanel_home() / "tmp" / f"_preserve_{pkg_id}_components"
                if components_backup.exists():
                    shutil.rmtree(components_backup, ignore_errors=True)
                components_backup.parent.mkdir(parents=True, exist_ok=True)
                shutil.copytree(comp, components_backup)
        if backups or components_backup:
            if log_lines is not None:
                kept = ", ".join(sorted(backups.keys()))
                if components_backup:
                    kept = f"{kept}, components/" if kept else "components/"
                log_lines.append(f"ℹ️ Desktop UI track — preserving {pkg_id}: {kept}")

    shutil.copytree(src_frontend, dst_frontend, dirs_exist_ok=True)

    for name, content in backups.items():
        (dst_frontend / name).write_text(content, encoding="utf-8")
    if components_backup and components_backup.is_dir():
        comp = dst_frontend / "components"
        if comp.exists():
            shutil.rmtree(comp, ignore_errors=True)
        shutil.copytree(components_backup, comp)
        shutil.rmtree(components_backup, ignore_errors=True)


def _ensure_frontend_npm_deps(frontend_dir: Path, log_lines: Optional[List[str]] = None) -> bool:
    if log_lines is not None:
        log_lines.append("Running npm install in frontend...")
    is_win = platform.system() == "Windows"
    for cmd in (["npm", "install"], ["npm", "install", "--legacy-peer-deps"]):
        proc = subprocess.run(
            cmd,
            cwd=str(frontend_dir),
            capture_output=True,
            text=True,
            timeout=600,
            shell=is_win,
        )
        if proc.returncode == 0:
            return True
        err = (proc.stderr or proc.stdout or "").strip()
        if log_lines is not None and err:
            log_lines.append(f"⚠️ {' '.join(cmd)} failed: {err[-400:]}")
    return False


def _clean_frontend_dist(frontend_dir: Path, log_lines: Optional[List[str]] = None) -> None:
    dist = frontend_dir / "dist"
    if dist.is_dir():
        if log_lines is not None:
            log_lines.append("Cleaning frontend dist/ before rebuild...")
        shutil.rmtree(dist, ignore_errors=True)


def _backup_frontend_dist(frontend_dir: Path) -> Optional[Path]:
    """Copy dist/ to a temp dir so a failed build can restore the live panel."""
    dist = frontend_dir / "dist"
    index = dist / "index.html"
    if not index.is_file():
        return None
    backup_root = Path(tempfile.mkdtemp(prefix="copanel-dist-backup-"))
    shutil.copytree(dist, backup_root / "dist", dirs_exist_ok=True)
    return backup_root


def _restore_frontend_dist(frontend_dir: Path, backup_root: Path, log_lines: Optional[List[str]] = None) -> bool:
    src = backup_root / "dist"
    if not (src / "index.html").is_file():
        return False
    dist = frontend_dir / "dist"
    shutil.rmtree(dist, ignore_errors=True)
    shutil.copytree(src, dist, dirs_exist_ok=True)
    if log_lines is not None:
        log_lines.append("⚠️ Build failed — restored previous frontend dist/ so the panel stays online.")
    return True


def _discard_frontend_dist_backup(backup_root: Optional[Path]) -> None:
    if backup_root and backup_root.is_dir():
        shutil.rmtree(backup_root, ignore_errors=True)


def _staging_dist_dir(frontend_dir: Path) -> Path:
    return frontend_dir / ".build-staging"


def _promote_staging_dist(frontend_dir: Path, log_lines: Optional[List[str]] = None) -> bool:
    """Atomic swap: staging build → live dist/."""
    staging = _staging_dist_dir(frontend_dir)
    if not (staging / "index.html").is_file():
        return False
    dist = frontend_dir / "dist"
    prev = frontend_dir / ".dist-prev"
    shutil.rmtree(prev, ignore_errors=True)
    if dist.exists():
        dist.rename(prev)
    staging.rename(dist)
    shutil.rmtree(prev, ignore_errors=True)
    if log_lines is not None:
        log_lines.append("✓ Frontend dist promoted from staging (panel stayed online during build).")
    return True


def _extensions_registry_path() -> Path:
    return get_copanel_home() / "config" / "frontend_extensions.json"


def _load_extensions_registry() -> Dict[str, Any]:
    path = _extensions_registry_path()
    if not path.is_file():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _save_extensions_registry(registry: Dict[str, Any]) -> None:
    path = _extensions_registry_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(registry, indent=2) + "\n", encoding="utf-8")


def _write_extensions_index(frontend_dir: Path) -> None:
    registry = _load_extensions_registry()
    entries = []
    for pkg_id, meta in sorted(registry.items()):
        if not isinstance(meta, dict):
            continue
        entries.append(
            {
                "id": pkg_id,
                "path": meta.get("path"),
                "name": meta.get("name"),
                "manifest_url": meta.get("manifest_url") or f"/extensions/{pkg_id}/manifest.json",
                "module_url": meta.get("module_url") or f"/extensions/{pkg_id}/module.js",
            }
        )
    ext_dir = frontend_dir / "dist" / "extensions"
    ext_dir.mkdir(parents=True, exist_ok=True)
    (ext_dir / "index.json").write_text(
        json.dumps({"extensions": entries}, indent=2) + "\n",
        encoding="utf-8",
    )


def _install_frontend_extension(
    pkg_id: str,
    src_extension: Path,
    frontend_dir: Path,
    log_lines: Optional[List[str]] = None,
) -> None:
    manifest_src = src_extension / "manifest.json"
    module_src = src_extension / "module.js"
    if not manifest_src.is_file():
        raise ValueError(f"extension/manifest.json missing for {pkg_id}")
    if not module_src.is_file():
        raise ValueError(f"extension/module.js missing for {pkg_id}")

    dest = frontend_dir / "dist" / "extensions" / pkg_id
    if dest.exists():
        shutil.rmtree(dest)
    shutil.copytree(src_extension, dest, dirs_exist_ok=True)

    manifest = json.loads(manifest_src.read_text(encoding="utf-8"))
    registry = _load_extensions_registry()
    registry[pkg_id] = {
        "id": pkg_id,
        "path": manifest.get("path"),
        "name": manifest.get("name") or pkg_id,
        "manifest_url": f"/extensions/{pkg_id}/manifest.json",
        "module_url": f"/extensions/{pkg_id}/module.js",
        "version": manifest.get("version"),
        "core_ui": manifest.get("core_ui"),
    }
    _save_extensions_registry(registry)
    _write_extensions_index(frontend_dir)
    if log_lines is not None:
        log_lines.append(f"✓ Extension installed to dist/extensions/{pkg_id}/ (no npm build).")


def _remove_extension_install(pkg_id: str, frontend_dir: Path, log_lines: Optional[List[str]] = None) -> bool:
    dest = frontend_dir / "dist" / "extensions" / pkg_id
    removed = False
    if dest.exists():
        shutil.rmtree(dest)
        removed = True
    registry = _load_extensions_registry()
    if pkg_id in registry:
        del registry[pkg_id]
        _save_extensions_registry(registry)
        removed = True
    if removed:
        _write_extensions_index(frontend_dir)
        if log_lines is not None:
            log_lines.append(f"Removed extension dist/extensions/{pkg_id}/")
    return removed


def _normalize_frontend_install(
    frontend_install: Optional[str],
    extracted_dir: Path,
    *,
    auto_detect: bool = False,
) -> str:
    mode = (frontend_install or "").strip().lower()
    if not mode and auto_detect:
        if (extracted_dir / "extension" / "manifest.json").is_file():
            return "extension"
        if (extracted_dir / "frontend").is_dir():
            return "rebuild"
        return "none"
    if not mode:
        mode = "rebuild"
    if mode not in ("rebuild", "extension", "none"):
        mode = "rebuild"
    if mode == "extension" and not (extracted_dir / "extension" / "manifest.json").is_file():
        raise ValueError("ZIP missing extension/manifest.json but frontend_install=extension")
    return mode


def _should_run_npm_install(frontend_dir: Path) -> bool:
    import os

    if os.environ.get("COPANEL_FORCE_NPM_INSTALL", "").strip().lower() in ("1", "true", "yes"):
        return True
    node_modules = frontend_dir / "node_modules"
    if not node_modules.is_dir():
        return True
    pkg = frontend_dir / "package.json"
    if not pkg.is_file():
        return False
    lock = frontend_dir / "package-lock.json"
    pkg_mtime = pkg.stat().st_mtime
    lock_mtime = lock.stat().st_mtime if lock.is_file() else pkg_mtime
    nm_mtime = node_modules.stat().st_mtime
    if pkg_mtime > nm_mtime or lock_mtime > nm_mtime:
        return True
    if _cpu_lacks_avx() and not _rollup_wasm_configured(frontend_dir):
        return True
    return False


def _prepare_frontend_for_build(frontend_dir: Path, log_lines: Optional[List[str]] = None) -> None:
    """Staging build prep — never wipe live dist/ before success."""
    if _cpu_lacks_avx():
        _ensure_modern_npm(log_lines)
        _maybe_apply_rollup_wasm_override(frontend_dir, log_lines)
    else:
        _strip_wasm_overrides(frontend_dir, log_lines)
    staging = _staging_dist_dir(frontend_dir)
    shutil.rmtree(staging, ignore_errors=True)
    vite_cache = frontend_dir / "node_modules" / ".vite"
    if vite_cache.is_dir():
        if log_lines is not None:
            log_lines.append("Cleaning Vite cache...")
        shutil.rmtree(vite_cache, ignore_errors=True)


def _npm_major_version() -> int:
    try:
        proc = subprocess.run(["npm", "-v"], capture_output=True, text=True, timeout=30)
        major = (proc.stdout or "").strip().split(".")[0]
        return int(major) if major.isdigit() else 0
    except Exception:
        return 0


def _ensure_modern_npm(log_lines: Optional[List[str]] = None) -> None:
    if _npm_major_version() >= 10:
        return
    if log_lines is not None:
        log_lines.append("Upgrading npm to >= 10 (required for Rollup WASM overrides)...")
    proc = subprocess.run(
        ["npm", "install", "-g", "npm@10"],
        capture_output=True,
        text=True,
        timeout=180,
    )
    if proc.returncode != 0 and log_lines is not None:
        log_lines.append("⚠️ npm upgrade failed — WASM override path may break on no-AVX hosts.")


def _strip_wasm_overrides(frontend_dir: Path, log_lines: Optional[List[str]] = None) -> bool:
    pkg_path = frontend_dir / "package.json"
    if not pkg_path.is_file():
        return False
    try:
        data = json.loads(pkg_path.read_text(encoding="utf-8"))
    except Exception:
        return False
    overrides = data.get("overrides")
    if not isinstance(overrides, dict):
        return False
    rollup = str(overrides.get("rollup") or "")
    esbuild = str(overrides.get("esbuild") or "")
    if "wasm" not in rollup.lower() and "wasm" not in esbuild.lower():
        return False
    overrides.pop("rollup", None)
    overrides.pop("esbuild", None)
    if not overrides:
        data.pop("overrides", None)
    pkg_path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
    if log_lines is not None:
        log_lines.append("Removed WASM overrides (CPU has AVX — native esbuild/rollup).")
    return True


def _rollup_wasm_configured(frontend_dir: Path) -> bool:
    pkg = frontend_dir / "package.json"
    if not pkg.is_file():
        return False
    try:
        data = json.loads(pkg.read_text(encoding="utf-8"))
        overrides = data.get("overrides") or {}
        rollup = str(overrides.get("rollup") or "")
        esbuild = str(overrides.get("esbuild") or "")
        return "wasm" in rollup.lower() and "wasm" in esbuild.lower()
    except Exception:
        return False


def _maybe_apply_rollup_wasm_override(frontend_dir: Path, log_lines: Optional[List[str]] = None) -> bool:
    """Apply Rollup + esbuild WASM on no-AVX (same as scripts/install.sh). Returns True if npm install ran."""
    if not _cpu_lacks_avx():
        return False
    pkg_path = frontend_dir / "package.json"
    if not pkg_path.is_file():
        return False
    _ensure_modern_npm(log_lines)
    if _npm_major_version() < 10:
        if log_lines is not None:
            log_lines.append("⚠️ npm < 10 — cannot apply WASM overrides.")
        return False
    try:
        data = json.loads(pkg_path.read_text(encoding="utf-8"))
    except Exception:
        return False
    overrides = data.setdefault("overrides", {})
    changed = False
    if "wasm" not in str(overrides.get("rollup") or "").lower():
        overrides["rollup"] = "npm:@rollup/wasm-node@4.60.2"
        changed = True
    if "wasm" not in str(overrides.get("esbuild") or "").lower():
        overrides["esbuild"] = "npm:esbuild-wasm@0.21.5"
        changed = True
    if changed:
        pkg_path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
        if log_lines is not None:
            log_lines.append("ℹ️ CPU without AVX — applying Rollup + esbuild WASM overrides (npm install)...")
    elif log_lines is not None:
        log_lines.append("ℹ️ CPU without AVX — refreshing node_modules (WASM toolchain)...")
    if not _should_run_npm_install(frontend_dir):
        if log_lines is not None:
            log_lines.append("ℹ️ Skipping npm install (node_modules up to date).")
        return changed
    return _ensure_frontend_npm_deps(frontend_dir, log_lines)


def _prefer_serial_vite_build() -> bool:
    """Use serial chunk rendering (maxParallelFileOps=1) to avoid Rollup native crashes."""
    import os

    flag = os.environ.get("VITE_BUILD_SERIAL", "").strip().lower()
    if flag in ("1", "true", "yes"):
        return True
    if flag in ("0", "false", "no"):
        return False
    return _cpu_lacks_avx()


def _frontend_build_env(*, serial: bool = False) -> dict:
    """Env for npm/vite. *serial* enables VITE_BUILD_LOW_MEMORY (serial Rollup file ops + smaller heap)."""
    import os

    env = os.environ.copy()
    heap = "2048" if serial else "1536"
    extra = f"--max-old-space-size={heap}"
    existing = env.get("NODE_OPTIONS", "").strip()
    env["NODE_OPTIONS"] = f"{existing} {extra}".strip() if existing else extra
    if serial:
        env["VITE_BUILD_LOW_MEMORY"] = "1"
    return env


def _frontend_build_cmd(frontend_dir: Path) -> list:
    """Skip tsc during AppStore install when script exists; else run vite directly."""
    pkg = frontend_dir / "package.json"
    if pkg.is_file():
        try:
            data = json.loads(pkg.read_text(encoding="utf-8"))
            scripts = data.get("scripts") or {}
            if "build:appstore" in scripts:
                return ["npm", "run", "build:appstore"]
        except Exception:
            pass
    return ["npx", "vite", "build"]


def _log_blob(log_lines: Optional[List[str]]) -> str:
    return " ".join(log_lines or []).lower()


def _is_segfault_build_failure(return_code: int, log_lines: Optional[List[str]] = None) -> bool:
    if return_code == 139:
        return True
    return "segmentation fault" in _log_blob(log_lines)


def _is_oom_build_failure(return_code: int, log_lines: Optional[List[str]] = None) -> bool:
    if return_code == 137:
        return True
    blob = _log_blob(log_lines)
    return "heap out of memory" in blob or "javascript heap" in blob


def _is_retriable_build_failure(return_code: int, log_lines: Optional[List[str]] = None) -> bool:
    return _is_segfault_build_failure(return_code, log_lines) or _is_oom_build_failure(return_code, log_lines)


def _build_failure_hint(return_code: int, log_lines: Optional[List[str]]) -> str:
    if _is_segfault_build_failure(return_code, log_lines):
        return (
            "💡 Rollup native crash (exit 139). This is not low RAM. "
            "Retry with: cd /opt/copanel/frontend && VITE_BUILD_LOW_MEMORY=1 npm run build:appstore "
            "or add to package.json overrides: \"rollup\": \"npm:@rollup/wasm-node@4.60.2\" then npm install."
        )
    if _is_oom_build_failure(return_code, log_lines):
        return (
            "💡 Out of memory during build. Add swap (e.g. 2G), then: "
            "cd /opt/copanel/frontend && NODE_OPTIONS='--max-old-space-size=2048' "
            "VITE_BUILD_LOW_MEMORY=1 npm run build:appstore"
        )
    return ""


def _run_frontend_build_once(frontend_dir: Path, *, serial: bool = False) -> tuple:
    """Run one frontend build attempt. Returns (return_code, output_lines)."""
    is_win = platform.system() == "Windows"
    lines: List[str] = []
    env = _frontend_build_env(serial=serial)
    env["VITE_BUILD_OUTDIR"] = str(_staging_dist_dir(frontend_dir))
    try:
        process = subprocess.Popen(
            _frontend_build_cmd(frontend_dir),
            cwd=str(frontend_dir),
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            shell=is_win,
            bufsize=1,
            env=env,
        )
        while True:
            line = process.stdout.readline()
            if not line and process.poll() is not None:
                break
            if line:
                stripped = line.strip()
                if stripped:
                    lines.append(stripped)
        return process.wait(), lines
    except Exception as e:
        return -1, [str(e)]


def _run_frontend_build_with_retry(frontend_dir: Path) -> tuple:
    """Build frontend into staging; promote to dist/ only on success."""
    lines: List[str] = []
    try:
        _prepare_frontend_for_build(frontend_dir, lines)
        serial_first = _prefer_serial_vite_build()

        if serial_first:
            _maybe_apply_rollup_wasm_override(frontend_dir, lines)
            lines.append(
                "ℹ️ CPU without AVX — using Rollup WASM (when available) + serial Vite build."
            )
        elif _should_run_npm_install(frontend_dir):
            lines.append("Running npm install in frontend...")
            if not _ensure_frontend_npm_deps(frontend_dir, lines):
                lines.append("⚠️ npm install failed — continuing build attempt anyway.")

        return_code = -1
        max_attempts = 3
        for attempt in range(max_attempts):
            if attempt == 1:
                if _is_segfault_build_failure(return_code, lines):
                    if _maybe_apply_rollup_wasm_override(frontend_dir, lines):
                        lines.append("⚠️ Rollup segfault (exit 139) — retrying with WASM Rollup...")
                    else:
                        lines.append("⚠️ Rollup segfault (exit 139) — retrying with serial chunk rendering...")
                elif _is_oom_build_failure(return_code, lines):
                    lines.append("⚠️ Build OOM (exit 137) — retrying with reduced memory settings...")
                else:
                    break
            elif attempt == 2:
                if not _is_retriable_build_failure(return_code, lines):
                    break
                _maybe_apply_rollup_wasm_override(frontend_dir, lines)
                lines.append("⚠️ Final build retry (serial + Rollup WASM)...")

            use_serial = serial_first or attempt > 0
            attempt_code, attempt_lines = _run_frontend_build_once(frontend_dir, serial=use_serial)
            lines.extend(attempt_lines)
            return_code = attempt_code
            staging_index = _staging_dist_dir(frontend_dir) / "index.html"
            if return_code == 0 and staging_index.is_file():
                _promote_staging_dist(frontend_dir, lines)
                return 0, lines
            if return_code == 0:
                return_code = 1
                lines.append("❌ Build exited 0 but staging index.html missing.")

        if return_code != 0:
            shutil.rmtree(_staging_dist_dir(frontend_dir), ignore_errors=True)
            lines.append(
                "💡 Live panel dist/ was not replaced (staging build failed). Fix errors and retry."
            )
        return return_code, lines
    except Exception as exc:
        shutil.rmtree(_staging_dist_dir(frontend_dir), ignore_errors=True)
        return -1, lines + [str(exc)]


def _run_frontend_build_sync() -> tuple:
    """Run npm build in CoPanel frontend. Returns (success: bool, error_snippet: str)."""
    frontend_dir = get_copanel_home() / "frontend"
    if not (frontend_dir / "package.json").exists():
        return True, ""
    return_code, lines = _run_frontend_build_with_retry(frontend_dir)
    if return_code == 0:
        return True, ""
    tail = "\n".join(lines).strip()
    if len(tail) > 1500:
        tail = tail[-1500:]
    return False, tail or f"exit code {return_code}"

def get_local_version(pkg_id: str, modules_dir: Path) -> str:
    # 1. Check version.txt inside backend module directory first
    version_file = modules_dir / pkg_id / "version.txt"
    if version_file.exists():
        try:
            raw = version_file.read_text(encoding="utf-8").strip()
            if raw:
                return normalize_version(raw)
        except Exception:
            pass

    # 2. installed_packages.json under CoPanel config
    possible_installed_files = [
        get_copanel_home() / "config" / "installed_packages.json",
    ]
    for installed_file in possible_installed_files:
        if installed_file.exists():
            try:
                with open(installed_file, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    if isinstance(data, dict) and pkg_id in data:
                        val = data[pkg_id]
                        if isinstance(val, dict) and val.get("version") is not None:
                            return normalize_version(str(val["version"]))
                        return normalize_version(str(val))
            except Exception:
                pass

    # 3. Fall back to core package hardcoded version
    if pkg_id in CORE_PACKAGE_VERSIONS:
        return normalize_version(CORE_PACKAGE_VERSIONS[pkg_id])

    # 4. Default fallback
    return normalize_version("1.0.0")


def save_local_version(pkg_id: str, version: str):
    ver = normalize_version(version)
    home = get_copanel_home()
    modules_dir = home / "backend" / "modules"
    try:
        vfile = modules_dir / pkg_id / "version.txt"
        vfile.parent.mkdir(parents=True, exist_ok=True)
        vfile.write_text(ver, encoding="utf-8")
    except Exception:
        pass

    for cfg_dir in [home / "config"]:
        try:
            cfg_dir.mkdir(parents=True, exist_ok=True)
            installed_file = cfg_dir / "installed_packages.json"
            data = {}
            if installed_file.exists():
                try:
                    with open(installed_file, "r", encoding="utf-8") as f:
                        data = json.load(f)
                        if not isinstance(data, dict):
                            data = {}
                except Exception:
                    pass
            data[pkg_id] = ver
            with open(installed_file, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=4)
        except Exception:
            pass


APT_YUM_MAPPING = {
    "redis": {"apt": "redis-server", "yum": "redis"},
    "nginx": {"apt": "nginx", "yum": "nginx"},
    "mariadb": {"apt": "mariadb-server", "yum": "mariadb-server"},
    "mysql": {"apt": "mysql-server", "yum": "mysql-community-server"},
    "postgresql": {"apt": "postgresql", "yum": "postgresql-server"},
    "memcached": {"apt": "memcached", "yum": "memcached"},
}


DEPENDENCY_PACKAGES = {
    "module_redis": {"id": "redis", "apt": "redis-server", "yum": "redis"},
    "module_cron": {"id": "memcached", "apt": "memcached", "yum": "memcached"},
    "web_manager": {"id": "nginx", "apt": "nginx", "yum": "nginx"},
    "database_manager": {"id": "mariadb", "apt": "mariadb-server", "yum": "mariadb-server"},
}

PIP_PACKAGES_BY_MODULE: Dict[str, List[str]] = {
    "webdav": ["wsgidav==4.3.3", "cheroot==10.0.1"],
    "cloudflare_ddns": ["httpx==0.27.0"],
    "download_manager": ["yt-dlp"],
    "audio_station": ["mutagen==1.47.0"],
    "web_browser": ["playwright==1.49.1"],
}


def _detect_pkg_manager() -> str:
    if shutil.which("apt-get"):
        return "apt"
    if shutil.which("yum"):
        return "yum"
    return ""


def _is_pkg_installed(pkg_manager: str, pkg_name: str) -> bool:
    try:
        if pkg_manager == "apt" and shutil.which("dpkg-query"):
            res = subprocess.run(
                ["dpkg-query", "-W", "-f=${Status}", pkg_name],
                shell=False,
                capture_output=True,
                text=True,
            )
            return "install ok installed" in (res.stdout or "")
        if pkg_manager == "yum" and shutil.which("rpm"):
            res = subprocess.run(["rpm", "-q", pkg_name], shell=False, capture_output=True, text=True)
            return res.returncode == 0
    except Exception:
        return False
    return False


def _is_apt_lock_error(text: str) -> bool:
    lower = (text or "").lower()
    return (
        "lock-frontend" in lower
        or "could not get lock" in lower
        or "unable to acquire the dpkg" in lower
        or "dpkg was interrupted" in lower
    )


def _apt_install_packages(pkg_names: list, max_retries: int = 8, retry_delay: int = 8) -> dict:
    """Install multiple Debian packages in one apt-get invocation (avoids dpkg lock races)."""
    names = [p for p in pkg_names if p]
    if not names:
        return {"ok": True, "message": "No packages to install."}

    quoted = " ".join(shlex.quote(p) for p in names)
    cmd = f"sudo -n DEBIAN_FRONTEND=noninteractive apt-get install -y {quoted}"
    last_err = ""
    for attempt in range(max_retries):
        if attempt > 0:
            time.sleep(retry_delay)
        res = subprocess.run(cmd, shell=True, capture_output=True, text=True)
        out = (res.stderr or res.stdout or "").strip()
        if res.returncode == 0:
            return {"ok": True, "message": out}
        last_err = out
        
        # If the local package index is outdated, we might get 404s. Auto-update and retry immediately.
        if "404 Not Found" in out or "Unable to fetch some archives" in out:
            subprocess.run("sudo -n apt-get update", shell=True, capture_output=True, text=True)
            res = subprocess.run(cmd, shell=True, capture_output=True, text=True)
            out = (res.stderr or res.stdout or "").strip()
            if res.returncode == 0:
                return {"ok": True, "message": out}
            last_err = out

        if not _is_apt_lock_error(out):
            break
    return {"ok": False, "message": last_err or "apt-get install failed"}


def _install_system_dependencies(deps: list, is_windows: bool) -> list:
    """Install module system dependencies sequentially; batch apt packages to avoid lock contention."""
    if not deps:
        return []
    if is_windows:
        return [_install_system_dependency(dep, True) for dep in deps]

    pkg_manager = _detect_pkg_manager()
    if not pkg_manager:
        return [
            {"id": dep.get("id", "unknown"), "ok": False, "message": "No supported package manager found (apt/yum)."}
            for dep in deps
        ]

    results: list = []
    pending: list = []

    for dep in deps:
        dep_id = dep.get("id", "unknown")
        target_pkg = dep.get("apt") if pkg_manager == "apt" else dep.get("yum")
        if not target_pkg:
            results.append({"id": dep_id, "ok": False, "message": f"No package mapping for {pkg_manager}."})
            continue
        if _is_pkg_installed(pkg_manager, target_pkg):
            results.append({
                "id": dep_id,
                "ok": True,
                "message": f"Dependency '{dep_id}' already installed ({target_pkg}).",
            })
        else:
            pending.append((dep_id, target_pkg, dep))

    if not pending:
        return results

    if pkg_manager == "apt":
        batch = _apt_install_packages([t[1] for t in pending])
        for dep_id, target_pkg, _dep in pending:
            if batch.get("ok") and _is_pkg_installed(pkg_manager, target_pkg):
                results.append({
                    "id": dep_id,
                    "ok": True,
                    "message": f"Installed dependency '{dep_id}' ({target_pkg}).",
                })
            elif batch.get("ok"):
                results.append({
                    "id": dep_id,
                    "ok": False,
                    "message": f"Install command ran but package '{target_pkg}' is still missing.",
                })
            else:
                results.append({"id": dep_id, "ok": False, "message": batch.get("message") or f"Failed to install {target_pkg}."})
        return results

    for _dep_id, _target_pkg, dep in pending:
        results.append(_install_system_dependency(dep, False))
    return results


def _resolve_pip_bin() -> Optional[str]:
    home = get_copanel_home()
    for candidate in (
        home / "venv" / "bin" / "pip",
        home / "venv" / "bin" / "pip3",
        Path("/opt/copanel/venv/bin/pip"),
        Path("/opt/copanel/venv/bin/pip3"),
    ):
        if candidate.is_file():
            return str(candidate)
    return shutil.which("pip3") or shutil.which("pip")


def _is_pip_package_installed(pip_bin: str, package_name: str) -> bool:
    try:
        proc = subprocess.run(
            [pip_bin, "show", package_name],
            capture_output=True,
            text=True,
            timeout=30,
        )
        return proc.returncode == 0
    except Exception:
        return False


def _install_pip_packages(packages: List[str], is_windows: bool) -> List[Dict[str, Any]]:
    if not packages:
        return []
    if is_windows:
        return [
            {"package": pkg, "ok": True, "message": f"Skipping pip install of '{pkg}' on Windows."}
            for pkg in packages
        ]

    pip_bin = _resolve_pip_bin()
    if not pip_bin:
        return [{"package": "pip", "ok": False, "message": "pip not found in CoPanel venv."}]

    results: List[Dict[str, Any]] = []
    to_install: List[str] = []
    for pkg in packages:
        if not isinstance(pkg, str) or not pkg.strip():
            continue
        spec = pkg.strip()
        name = spec.split("==")[0].split("[")[0]
        if _is_pip_package_installed(pip_bin, name):
            results.append({"package": name, "ok": True, "message": f"Python package '{name}' already installed."})
        else:
            to_install.append(spec)

    if to_install:
        proc = subprocess.run(
            [pip_bin, "install", "--disable-pip-version-check", "-q", *to_install],
            capture_output=True,
            text=True,
            timeout=300,
        )
        out = (proc.stderr or proc.stdout or "").strip()
        if proc.returncode == 0:
            for spec in to_install:
                name = spec.split("==")[0].split("[")[0]
                results.append({"package": name, "ok": True, "message": f"Installed Python package '{name}'."})
        else:
            for spec in to_install:
                name = spec.split("==")[0].split("[")[0]
                results.append({
                    "package": name,
                    "ok": False,
                    "message": out or f"pip install failed for {name}.",
                })

    return results


def _install_system_dependency(dep: dict, is_windows: bool) -> dict:
    dep_id = dep.get("id", "unknown")
    if is_windows:
        return {"id": dep_id, "ok": True, "message": f"Skipping Linux system package '{dep_id}' on Windows."}

    pkg_manager = _detect_pkg_manager()
    if not pkg_manager:
        return {"id": dep_id, "ok": False, "message": "No supported package manager found (apt/yum)."}

    target_pkg = dep.get("apt") if pkg_manager == "apt" else dep.get("yum")
    if not target_pkg:
        return {"id": dep_id, "ok": False, "message": f"No package mapping for {pkg_manager}."}

    if _is_pkg_installed(pkg_manager, target_pkg):
        return {"id": dep_id, "ok": True, "message": f"Dependency '{dep_id}' already installed ({target_pkg})."}

    if pkg_manager == "apt":
        cmd = ["sudo", "-n", "DEBIAN_FRONTEND=noninteractive", "apt-get", "install", "-y", target_pkg]
        # sudo with env var inline needs shell; fallback to split update below if shellless fails.
        res = subprocess.run(
            "sudo -n DEBIAN_FRONTEND=noninteractive apt-get install -y " + target_pkg,
            shell=True,
            capture_output=True,
            text=True,
        )
        out = (res.stderr or res.stdout or "").strip()
        if res.returncode != 0 and ("404 Not Found" in out or "Unable to fetch some archives" in out):
            subprocess.run("sudo -n apt-get update", shell=True, capture_output=True, text=True)
            res = subprocess.run(
                "sudo -n DEBIAN_FRONTEND=noninteractive apt-get install -y " + target_pkg,
                shell=True,
                capture_output=True,
                text=True,
            )
    else:
        res = subprocess.run(["sudo", "-n", "yum", "install", "-y", target_pkg], shell=False, capture_output=True, text=True)

    if res.returncode != 0:
        detail = (res.stderr or res.stdout or "").strip()
        return {"id": dep_id, "ok": False, "message": detail or f"Failed to install {target_pkg}."}

    if _is_pkg_installed(pkg_manager, target_pkg):
        return {"id": dep_id, "ok": True, "message": f"Installed dependency '{dep_id}' ({target_pkg})."}
    return {"id": dep_id, "ok": False, "message": f"Install command ran but package '{target_pkg}' is still missing."}


class AppStoreManager:
    @staticmethod
    def load_config() -> dict:
        """Loads config from config DB (with JSON-file fallback migration)."""
        try:
            raw = _get_cfg_value("community_urls", "[]")
            parsed = json.loads(raw) if raw else []
            if isinstance(parsed, list):
                return {"community_urls": [u for u in parsed if isinstance(u, str)]}
        except Exception:
            pass

        cfg_path = appstore_config_file()
        if not cfg_path.exists():
            legacy = get_copanel_home() / "backend" / "config" / "appstore_config.json"
            if legacy.exists():
                try:
                    cfg_path.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(legacy, cfg_path)
                except Exception:
                    pass
        if cfg_path.exists():
            try:
                with open(cfg_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                if isinstance(data, dict):
                    urls = data.get("community_urls", [])
                    if not isinstance(urls, list):
                        urls = []
                    try:
                        _set_cfg_value("community_urls", json.dumps(urls))
                    except Exception:
                        pass
                    return {**data, "community_urls": urls}
            except Exception:
                pass
        return {"community_urls": []}

    @staticmethod
    def save_config(update: dict) -> bool:
        """Persists config in DB; writes JSON mirror for backward compatibility."""
        cfg_path = appstore_config_file()
        try:
            current = AppStoreManager.load_config()
            merged = {**current, **(update or {})}
            urls = merged.get("community_urls", [])
            urls = list(urls) if isinstance(urls, list) else []
            urls = [u.strip() for u in urls if isinstance(u, str) and u.strip()]
            _set_cfg_value("community_urls", json.dumps(urls))

            # Optional mirror file for compatibility with older tooling.
            cfg_path.parent.mkdir(parents=True, exist_ok=True)
            with open(cfg_path, "w", encoding="utf-8") as f:
                json.dump({"community_urls": urls}, f, indent=4)
            return True
        except Exception:
            return False

    @staticmethod
    def get_catalog() -> list:
        """Fetches available packages from remote GitHub catalog with installed status."""
        project_root = get_copanel_home()
        if Path("/opt/copanel").exists():
            modules_dir = Path("/opt/copanel/backend/modules")
        else:
            modules_dir = project_root / "backend" / "modules"
            
        packages = []
        try:
            req = urllib.request.Request(
                CATALOG_API_URL, 
                headers={
                    'User-Agent': 'Mozilla/5.0',
                    'Accept': 'application/vnd.github.v3.raw'
                }
            )
            with urllib.request.urlopen(req, timeout=5) as response:
                packages = json.loads(response.read().decode("utf-8"))
        except Exception:
            try:
                import time
                url_with_t = f"{CATALOG_URL}?t={int(time.time())}"
                req = urllib.request.Request(
                    url_with_t, 
                    headers={'User-Agent': 'Mozilla/5.0'}
                )
                with urllib.request.urlopen(req, timeout=5) as response:
                    packages = json.loads(response.read().decode("utf-8"))
            except Exception:
                packages = []

        # Load community URLs from config
        cfg = AppStoreManager.load_config()
        community_urls = cfg.get("community_urls", [])
        for url in community_urls:
            if not url or not isinstance(url, str) or not url.startswith("http"):
                continue
            try:
                fetch_url = url
                headers = {'User-Agent': 'Mozilla/5.0'}
                if "raw.githubusercontent.com" in url:
                    parts = url.replace("https://raw.githubusercontent.com/", "").split("/")
                    if len(parts) >= 3:
                        user, repo = parts[0], parts[1]
                        fetch_url = f"https://api.github.com/repos/{user}/{repo}/contents/packages.json"
                        headers['Accept'] = 'application/vnd.github.v3.raw'

                req = urllib.request.Request(fetch_url, headers=headers)
                with urllib.request.urlopen(req, timeout=5) as response:
                    comm_pkgs = json.loads(response.read().decode("utf-8"))
                    if isinstance(comm_pkgs, list):
                        for p in comm_pkgs:
                            if isinstance(p, dict) and "id" in p:
                                p["is_community"] = True
                                packages.append(p)
            except Exception:
                pass

        seen = set()
        merged_packages = []
        for p in packages:
            if p.get("id") not in seen:
                seen.add(p["id"])
                merged_packages.append(p)

        packages = merged_packages

        for p in packages:
            if not isinstance(p, dict) or "id" not in p:
                continue
            remote_ver = normalize_version(p.get("version", "1.0.0"))
            p["version"] = remote_ver
            p["remote_version"] = remote_ver
            installed = (modules_dir / p["id"]).exists()
            p["installed"] = installed
            if installed:
                local_ver = get_local_version(p["id"], modules_dir)
                p["local_version"] = local_ver
                cmpv = compare_versions(remote_ver, local_ver)
                if cmpv > 0:
                    p["has_update"] = True
                    p["update_status"] = "update_available"
                elif cmpv < 0:
                    p["has_update"] = False
                    p["update_status"] = "ahead"
                else:
                    p["has_update"] = False
                    p["update_status"] = "up_to_date"
            else:
                p["local_version"] = ""
                p["has_update"] = False
                p["update_status"] = "not_installed"
            
        return packages



    @staticmethod
    def install_package(
        pkg_id: str,
        download_url: str,
        version: str = "1.0.0",
        system_packages: list = None,
        pip_packages: list = None,
        requires_copanel_restart: bool = False,
        frontend_install: str = "rebuild",
    ) -> dict:
        """Starts package installation and frontend build in a background thread."""
        global BUILD_TASKS
        BUILD_TASKS[pkg_id] = _new_build_task()
        
        def run_install():
            is_windows = platform.system() == "Windows"
            
            # Auto-install Linux package dependencies in parallel, then enforce
            # completion before finalizing module install.
            deps = []
            if isinstance(system_packages, list) and system_packages:
                for sp in system_packages:
                    if isinstance(sp, str):
                        mapping = APT_YUM_MAPPING.get(sp.lower(), {"apt": sp.lower(), "yum": sp.lower()})
                        deps.append({"id": sp, "apt": mapping.get("apt", sp), "yum": mapping.get("yum", sp)})
            else:
                dep = DEPENDENCY_PACKAGES.get(pkg_id)
                if dep:
                    deps.append(dep)

            dep_results: list = []
            if deps:
                BUILD_TASKS[pkg_id]["logs"].append(f"Checking {len(deps)} system dependencies...")
                BUILD_TASKS[pkg_id]["progress"] = 5
                dep_results = _install_system_dependencies(deps, is_windows)
                for r in dep_results:
                    BUILD_TASKS[pkg_id]["logs"].append(r.get("message", "Dependency step completed."))
                dep_failures = [r for r in dep_results if not r.get("ok")]
                if dep_failures:
                    BUILD_TASKS[pkg_id]["status"] = "failed"
                    BUILD_TASKS[pkg_id]["error"] = "System dependency installation failed."
                    BUILD_TASKS[pkg_id]["logs"].append("❌ Installation aborted: one or more required system packages failed.")
                    BUILD_TASKS[pkg_id]["progress"] = 100
                    return

            pip_specs: List[str] = []
            if isinstance(pip_packages, list) and pip_packages:
                pip_specs = [p for p in pip_packages if isinstance(p, str) and p.strip()]
            elif pkg_id in PIP_PACKAGES_BY_MODULE:
                pip_specs = list(PIP_PACKAGES_BY_MODULE[pkg_id])

            if pip_specs:
                BUILD_TASKS[pkg_id]["logs"].append(f"Installing {len(pip_specs)} Python package(s)...")
                BUILD_TASKS[pkg_id]["progress"] = 8
                pip_results = _install_pip_packages(pip_specs, is_windows)
                for r in pip_results:
                    BUILD_TASKS[pkg_id]["logs"].append(r.get("message", "pip step completed."))
                pip_failures = [r for r in pip_results if not r.get("ok")]
                if pip_failures:
                    BUILD_TASKS[pkg_id]["status"] = "failed"
                    BUILD_TASKS[pkg_id]["error"] = "Python dependency installation failed."
                    BUILD_TASKS[pkg_id]["logs"].append("❌ Installation aborted: one or more pip packages failed.")
                    BUILD_TASKS[pkg_id]["progress"] = 100
                    return

            project_root = get_copanel_home()
            tmp_dir = project_root / "tmp"
            tmp_dir.mkdir(exist_ok=True)
            
            tmp_zip = tmp_dir / f"{pkg_id}.zip"
            extracted_dir = tmp_dir / f"extracted_{pkg_id}"
            
            try:
                BUILD_TASKS[pkg_id]["logs"].append(f"Downloading from {download_url}...")
                BUILD_TASKS[pkg_id]["progress"] = 10
                req = urllib.request.Request(
                    download_url, 
                    headers={'User-Agent': 'Mozilla/5.0'}
                )
                with urllib.request.urlopen(req, timeout=30) as response, open(tmp_zip, 'wb') as out_file:
                    out_file.write(response.read())
                
                BUILD_TASKS[pkg_id]["logs"].append("Download complete.")
                BUILD_TASKS[pkg_id]["progress"] = 30
                
                if extracted_dir.exists():
                    shutil.rmtree(extracted_dir)
                
                with zipfile.ZipFile(tmp_zip, 'r') as zip_ref:
                    zip_ref.extractall(extracted_dir)
                    
                BUILD_TASKS[pkg_id]["logs"].append("Extraction complete.")
                BUILD_TASKS[pkg_id]["progress"] = 45
                
                src_backend = extracted_dir / "backend"
                src_frontend = extracted_dir / "frontend"
                src_extension = extracted_dir / "extension"
                backend_updated = src_backend.exists()

                try:
                    install_mode = _normalize_frontend_install(frontend_install, extracted_dir)
                except ValueError as ve:
                    BUILD_TASKS[pkg_id]["status"] = "failed"
                    BUILD_TASKS[pkg_id]["error"] = str(ve)
                    BUILD_TASKS[pkg_id]["logs"].append(f"❌ {ve}")
                    BUILD_TASKS[pkg_id]["progress"] = 100
                    return

                BUILD_TASKS[pkg_id]["logs"].append(f"Frontend install mode: {install_mode}")
                
                if Path("/opt/copanel").exists():
                    dst_backend = Path(f"/opt/copanel/backend/modules/{pkg_id}")
                    dst_frontend = Path(f"/opt/copanel/frontend/src/modules/{pkg_id}")
                    frontend_cwd = Path("/opt/copanel/frontend")
                else:
                    dst_backend = project_root / "backend" / "modules" / pkg_id
                    dst_frontend = project_root / "frontend" / "src" / "modules" / pkg_id
                    frontend_cwd = project_root / "frontend"
                
                if src_backend.exists():
                    is_new_backend = not (dst_backend / "router.py").is_file()
                    BUILD_TASKS[pkg_id]["logs"].append(f"Installing backend module to {dst_backend}...")
                    shutil.copytree(src_backend, dst_backend, dirs_exist_ok=True)
                    _purge_module_pycache(dst_backend)
                    BUILD_TASKS[pkg_id]["backend_status"] = "success"
                else:
                    is_new_backend = False
                    BUILD_TASKS[pkg_id]["backend_status"] = "skipped"

                return_code = 0
                frontend_updated = False

                if install_mode == "extension":
                    BUILD_TASKS[pkg_id]["logs"].append("Installing pre-built extension (fast path)...")
                    BUILD_TASKS[pkg_id]["progress"] = 60
                    try:
                        _install_frontend_extension(
                            pkg_id,
                            src_extension,
                            frontend_cwd,
                            BUILD_TASKS[pkg_id]["logs"],
                        )
                        if src_frontend.exists():
                            BUILD_TASKS[pkg_id]["logs"].append(
                                "ℹ️ Keeping frontend/ source in ZIP for debug — runtime uses extension/."
                            )
                            _install_frontend_module_tree(
                                src_frontend,
                                dst_frontend,
                                pkg_id,
                                BUILD_TASKS[pkg_id]["logs"],
                            )
                        BUILD_TASKS[pkg_id]["frontend_status"] = "success"
                        frontend_updated = True
                    except Exception as ext_err:
                        BUILD_TASKS[pkg_id]["frontend_status"] = "failed"
                        raise ext_err
                elif install_mode == "rebuild":
                    if src_frontend.exists():
                        BUILD_TASKS[pkg_id]["logs"].append(f"Installing frontend module to {dst_frontend}...")
                        _install_frontend_module_tree(
                            src_frontend,
                            dst_frontend,
                            pkg_id,
                            BUILD_TASKS[pkg_id]["logs"],
                        )
                        frontend_updated = True
                        BUILD_TASKS[pkg_id]["logs"].append("Starting frontend build (npm run build:appstore → staging)...")
                        BUILD_TASKS[pkg_id]["progress"] = 60
                        BUILD_TASKS[pkg_id]["frontend_status"] = "building"
                        return_code, build_lines = _run_frontend_build_with_retry(frontend_cwd)
                        for line in build_lines:
                            BUILD_TASKS[pkg_id]["logs"].append(line)
                        BUILD_TASKS[pkg_id]["frontend_status"] = "success" if return_code == 0 else "failed"
                    else:
                        BUILD_TASKS[pkg_id]["logs"].append("ℹ️ No frontend in package — skipping npm build.")
                        BUILD_TASKS[pkg_id]["frontend_status"] = "skipped"
                else:
                    BUILD_TASKS[pkg_id]["logs"].append("ℹ️ frontend_install=none — skipping frontend.")
                    BUILD_TASKS[pkg_id]["frontend_status"] = "skipped"

                if return_code == 0:
                    BUILD_TASKS[pkg_id]["status"] = "success"
                    BUILD_TASKS[pkg_id]["progress"] = 100
                    BUILD_TASKS[pkg_id]["logs"].append("🎉 Installation completed successfully!")
                    try:
                        save_local_version(pkg_id, version)
                    except Exception:
                        pass
                    _finalize_module_install(
                        pkg_id,
                        backend_updated=backend_updated,
                        frontend_updated=frontend_updated,
                        requires_copanel_restart=requires_copanel_restart,
                        is_new_backend=is_new_backend,
                    )
                else:
                    BUILD_TASKS[pkg_id]["status"] = "failed"
                    BUILD_TASKS[pkg_id]["error"] = f"npm run build failed with exit code {return_code}"
                    BUILD_TASKS[pkg_id]["logs"].append(f"❌ npm run build failed with exit code {return_code}")
                    hint = _build_failure_hint(return_code, BUILD_TASKS[pkg_id]["logs"])
                    if hint:
                        BUILD_TASKS[pkg_id]["logs"].append(hint)
                    elif any("error TS" in line for line in BUILD_TASKS[pkg_id]["logs"]):
                        BUILD_TASKS[pkg_id]["logs"].append(
                            "💡 If errors reference another module (e.g. download_manager), update that module from AppStore first, then retry."
                        )
                    BUILD_TASKS[pkg_id]["progress"] = 100
                    
            except Exception as e:
                BUILD_TASKS[pkg_id]["status"] = "failed"
                BUILD_TASKS[pkg_id]["error"] = str(e)
                BUILD_TASKS[pkg_id]["logs"].append(f"❌ Error: {str(e)}")
                BUILD_TASKS[pkg_id]["progress"] = 100
            finally:
                if tmp_zip.exists(): tmp_zip.unlink()
                if extracted_dir.exists(): shutil.rmtree(extracted_dir)
                
        thread = threading.Thread(target=run_install)
        thread.daemon = True
        thread.start()
        
        return {"status": "success", "message": f"Package {pkg_id} installation started."}

    @staticmethod
    def list_installed_extensions() -> dict:
        """Return installed AppStore extension registry."""
        registry = _load_extensions_registry()
        return {"extensions": list(registry.values())}

    @staticmethod
    def get_build_status(pkg_id: str) -> dict:
        """Retrieves status and logs for the given package ID."""
        global BUILD_TASKS
        default = {
            "status": "not_started",
            "logs": [],
            "error": "",
            "progress": 0,
            "restart_required": False,
            "restart_reason": None,
            "backend_status": "unknown",
            "frontend_status": "unknown",
            "ui_online": True,
        }
        task = BUILD_TASKS.get(pkg_id)
        if not task:
            return default
        return {**default, **task}

    @staticmethod
    def trigger_copanel_restart() -> Dict[str, Any]:
        """Schedule a copanel systemd restart (admin action from UI)."""
        return restart_backend_service(delay=1.5)

    @staticmethod
    def uninstall_package(pkg_id: str) -> dict:
        """Remove backend/frontend module dirs, clear install record, rebuild frontend bundle."""
        try:
            pid = _validate_uninstall_package_id(pkg_id)
        except ValueError as e:
            return {"status": "error", "message": str(e)}

        root = get_copanel_home()
        dst_backend = root / "backend" / "modules" / pid
        dst_frontend = root / "frontend" / "src" / "modules" / pid
        frontend_dir = root / "frontend"

        removed_backend = False
        removed_frontend = False
        removed_extension = False
        try:
            if dst_backend.exists():
                shutil.rmtree(dst_backend)
                removed_backend = True
            if dst_frontend.exists():
                shutil.rmtree(dst_frontend)
                removed_frontend = True
            removed_extension = _remove_extension_install(pid, frontend_dir)
        except Exception as e:
            return {"status": "error", "message": f"Failed to remove module files: {e}"}

        remove_local_package_record(pid)

        needs_rebuild = removed_frontend
        rebuild_ok, rebuild_err = (True, "")
        if needs_rebuild:
            rebuild_ok, rebuild_err = _run_frontend_build_sync()
        parts = []
        if removed_backend:
            parts.append("Backend module removed.")
        if removed_frontend:
            parts.append("Frontend module removed.")
        if removed_extension:
            parts.append("Extension removed (no full rebuild needed).")
        if not removed_backend and not removed_frontend and not removed_extension:
            parts.append("Module was not installed locally.")
        base_msg = " ".join(parts)

        if not rebuild_ok:
            return {
                "status": "partial",
                "message": base_msg + f" Frontend rebuild failed: {rebuild_err}",
                "rebuild_ok": False,
                "removed_backend": removed_backend,
                "removed_frontend": removed_frontend,
            }

        return {
            "status": "success",
            "message": base_msg + (" Frontend rebuilt." if needs_rebuild else ""),
            "rebuild_ok": rebuild_ok,
            "removed_backend": removed_backend,
            "removed_frontend": removed_frontend,
            "removed_extension": removed_extension,
        }

    @staticmethod
    def install_local_zip(pkg_id: str, zip_path: Path) -> dict:
        """Installs a module directly from a local zip file."""
        global BUILD_TASKS
        BUILD_TASKS[pkg_id] = _new_build_task(["Starting installation from uploaded ZIP..."])
        BUILD_TASKS[pkg_id]["progress"] = 5
        
        def run_install():
            is_windows = platform.system() == "Windows"
            
            project_root = get_copanel_home()
            tmp_dir = project_root / "tmp"
            tmp_dir.mkdir(exist_ok=True)
            extracted_dir = tmp_dir / f"extracted_{pkg_id}"
            
            try:
                if extracted_dir.exists():
                    shutil.rmtree(extracted_dir)
                
                with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                    zip_ref.extractall(extracted_dir)
                    
                BUILD_TASKS[pkg_id]["logs"].append("Extraction complete.")
                BUILD_TASKS[pkg_id]["progress"] = 40
                
                found_backend = None
                found_frontend = None
                found_extension = None
                
                # Check all deep matches
                for p in extracted_dir.rglob("*"):
                    if p.is_dir():
                        if p.name == pkg_id and p.parent.name == "modules" and p.parent.parent.name == "backend":
                            found_backend = p
                        elif p.name == pkg_id and p.parent.name == "modules" and p.parent.parent.name == "src" and p.parent.parent.parent.name == "frontend":
                            found_frontend = p

                # Fallback 1: search for any backend or frontend directories
                if not found_backend:
                    for p in extracted_dir.rglob("backend"):
                        if p.is_dir():
                            if (p / "modules" / pkg_id).exists():
                                found_backend = p / "modules" / pkg_id
                            else:
                                found_backend = p

                if not found_frontend:
                    for p in extracted_dir.rglob("frontend"):
                        if p.is_dir():
                            if (p / "src" / "modules" / pkg_id).exists():
                                found_frontend = p / "src" / "modules" / pkg_id
                            else:
                                found_frontend = p

                # Fallback 2: nested parent directories
                if not found_backend or not found_frontend:
                    subdirs = [x for x in extracted_dir.iterdir() if x.is_dir()]
                    if len(subdirs) == 1:
                        if (subdirs[0] / "backend").exists():
                            found_backend = subdirs[0] / "backend"
                        if (subdirs[0] / "frontend").exists():
                            found_frontend = subdirs[0] / "frontend"

                # Standard AppStore ZIP layout (backend/ frontend/ extension/)
                if (extracted_dir / "backend").is_dir():
                    found_backend = extracted_dir / "backend"
                if (extracted_dir / "frontend").is_dir():
                    found_frontend = extracted_dir / "frontend"
                found_extension = (extracted_dir / "extension") if (extracted_dir / "extension").is_dir() else None

                if not found_backend and not found_frontend and not found_extension:
                    BUILD_TASKS[pkg_id]["status"] = "failed"
                    BUILD_TASKS[pkg_id]["error"] = "Invalid ZIP structure: need backend/, frontend/, or extension/."
                    BUILD_TASKS[pkg_id]["logs"].append(
                        "❌ Invalid ZIP structure: neither backend/, frontend/, nor extension/ found."
                    )
                    return

                try:
                    install_mode = _normalize_frontend_install(None, extracted_dir, auto_detect=True)
                except ValueError as ve:
                    BUILD_TASKS[pkg_id]["status"] = "failed"
                    BUILD_TASKS[pkg_id]["error"] = str(ve)
                    BUILD_TASKS[pkg_id]["logs"].append(f"❌ {ve}")
                    BUILD_TASKS[pkg_id]["progress"] = 100
                    return

                BUILD_TASKS[pkg_id]["logs"].append(f"Frontend install mode: {install_mode}")

                if Path("/opt/copanel").exists():
                    dst_backend = Path(f"/opt/copanel/backend/modules/{pkg_id}")
                    dst_frontend = Path(f"/opt/copanel/frontend/src/modules/{pkg_id}")
                    frontend_cwd = Path("/opt/copanel/frontend")
                else:
                    dst_backend = project_root / "backend" / "modules" / pkg_id
                    dst_frontend = project_root / "frontend" / "src" / "modules" / pkg_id
                    frontend_cwd = project_root / "frontend"
                
                if found_backend and found_backend.exists():
                    is_new_backend = not (dst_backend / "router.py").is_file()
                    BUILD_TASKS[pkg_id]["logs"].append(f"Installing backend module to {dst_backend}...")
                    dst_backend.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copytree(found_backend, dst_backend, dirs_exist_ok=True)
                    _purge_module_pycache(dst_backend)
                    BUILD_TASKS[pkg_id]["backend_status"] = "success"
                else:
                    is_new_backend = False
                    BUILD_TASKS[pkg_id]["backend_status"] = "skipped"
                backend_updated = bool(found_backend and found_backend.exists())

                return_code = 0
                frontend_updated = False

                if install_mode == "extension" and found_extension:
                    BUILD_TASKS[pkg_id]["progress"] = 65
                    _install_frontend_extension(
                        pkg_id,
                        found_extension,
                        frontend_cwd,
                        BUILD_TASKS[pkg_id]["logs"],
                    )
                    if found_frontend and found_frontend.exists():
                        dst_frontend.parent.mkdir(parents=True, exist_ok=True)
                        _install_frontend_module_tree(
                            found_frontend,
                            dst_frontend,
                            pkg_id,
                            BUILD_TASKS[pkg_id]["logs"],
                        )
                    BUILD_TASKS[pkg_id]["frontend_status"] = "success"
                    frontend_updated = True
                elif install_mode == "rebuild" and found_frontend and found_frontend.exists():
                    BUILD_TASKS[pkg_id]["logs"].append(f"Installing frontend module to {dst_frontend}...")
                    dst_frontend.parent.mkdir(parents=True, exist_ok=True)
                    _install_frontend_module_tree(
                        found_frontend,
                        dst_frontend,
                        pkg_id,
                        BUILD_TASKS[pkg_id]["logs"],
                    )
                    frontend_updated = True
                    BUILD_TASKS[pkg_id]["logs"].append("Starting frontend build (npm run build:appstore → staging)...")
                    BUILD_TASKS[pkg_id]["progress"] = 65
                    BUILD_TASKS[pkg_id]["frontend_status"] = "building"
                    return_code, build_lines = _run_frontend_build_with_retry(frontend_cwd)
                    for line in build_lines:
                        BUILD_TASKS[pkg_id]["logs"].append(line)
                    BUILD_TASKS[pkg_id]["frontend_status"] = "success" if return_code == 0 else "failed"
                else:
                    BUILD_TASKS[pkg_id]["logs"].append("ℹ️ No frontend work for this ZIP.")
                    BUILD_TASKS[pkg_id]["frontend_status"] = "skipped"

                if return_code == 0:
                    BUILD_TASKS[pkg_id]["status"] = "success"
                    BUILD_TASKS[pkg_id]["progress"] = 100
                    BUILD_TASKS[pkg_id]["logs"].append("🎉 Installation completed successfully!")
                    try:
                        if Path("/opt/copanel").exists():
                            mod_dir = Path(f"/opt/copanel/backend/modules/{pkg_id}")
                        else:
                            mod_dir = project_root / "backend" / "modules" / pkg_id
                        vf = mod_dir / "version.txt"
                        if vf.exists():
                            save_local_version(pkg_id, vf.read_text(encoding="utf-8").strip())
                    except Exception:
                        pass
                    _finalize_module_install(
                        pkg_id,
                        backend_updated=backend_updated,
                        frontend_updated=frontend_updated,
                        is_new_backend=is_new_backend,
                    )
                else:
                    BUILD_TASKS[pkg_id]["status"] = "failed"
                    BUILD_TASKS[pkg_id]["error"] = f"npm run build failed with exit code {return_code}"
                    BUILD_TASKS[pkg_id]["logs"].append(f"❌ npm run build failed with exit code {return_code}")
                    hint = _build_failure_hint(return_code, BUILD_TASKS[pkg_id]["logs"])
                    if hint:
                        BUILD_TASKS[pkg_id]["logs"].append(hint)
                    elif any("error TS" in line for line in BUILD_TASKS[pkg_id]["logs"]):
                        BUILD_TASKS[pkg_id]["logs"].append(
                            "💡 If errors reference another module (e.g. download_manager), update that module from AppStore first, then retry."
                        )
                    BUILD_TASKS[pkg_id]["progress"] = 100
                    
            except Exception as e:
                BUILD_TASKS[pkg_id]["status"] = "failed"
                BUILD_TASKS[pkg_id]["error"] = str(e)
                BUILD_TASKS[pkg_id]["logs"].append(f"❌ Error: {str(e)}")
                BUILD_TASKS[pkg_id]["progress"] = 100
            finally:
                if zip_path.exists(): zip_path.unlink()
                if extracted_dir.exists(): shutil.rmtree(extracted_dir)
                
        thread = threading.Thread(target=run_install)
        thread.daemon = True
        thread.start()
        
        return {"status": "success", "message": f"Module {pkg_id} installation started."}

