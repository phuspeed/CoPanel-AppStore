"""ClamAV AppStore module."""
