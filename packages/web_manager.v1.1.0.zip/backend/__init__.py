"""
Web Manager Module
"""
