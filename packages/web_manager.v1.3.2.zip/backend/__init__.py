"""
Web Manager Module
"""
