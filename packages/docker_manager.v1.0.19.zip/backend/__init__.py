"""
Docker Manager Module
"""
