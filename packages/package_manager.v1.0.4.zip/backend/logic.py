"""
Package Manager Module - Logic
Real installation, status detection, and credential management.
"""
import os
import json
import shutil
import subprocess
import secrets
import string
from pathlib import Path
from typing import Dict, Any, List, Optional

BASE_DIR = Path(__file__).resolve().parent.parent.parent
CONFIG_DIR = BASE_DIR.parent / "config"
PACKAGES_FILE = CONFIG_DIR / "packages.json"
MODULES_DIR = BASE_DIR / "modules"

IS_WINDOWS = os.name == 'nt'

# ---------------------------------------------------------------------------
# Package catalogue
# ---------------------------------------------------------------------------
DEFAULT_PACKAGES: List[Dict[str, Any]] = [
    # ── Web Servers & Proxies ────────────────────────────────────────────────
    {
        "id": "nginx", "name": "Nginx",
        "description": "High-performance HTTP & reverse proxy server.",
        "icon": "Server", "status": "not_installed", "category": "Web Server",
        "apt": ["nginx"], "yum": ["nginx"], "service": "nginx",
    },
    {
        "id": "apache2", "name": "Apache HTTP Server",
        "description": "Robust, industry-standard open-source web server.",
        "icon": "Globe", "status": "not_installed", "category": "Web Server",
        "apt": ["apache2"], "yum": ["httpd"], "service": "apache2",
    },
    {
        "id": "openlitespeed", "name": "OpenLiteSpeed",
        "description": "High-performance, lightweight web server by LiteSpeed.",
        "icon": "Zap", "status": "not_installed", "category": "Web Server",
        "apt": ["openlitespeed"], "yum": ["openlitespeed"], "service": "lsws",
        "detect_bin": "openlitespeed",
    },
    {
        "id": "haproxy", "name": "HAProxy",
        "description": "Reliable, high performance TCP/HTTP load balancer.",
        "icon": "Share2", "status": "not_installed", "category": "Web Server",
        "apt": ["haproxy"], "yum": ["haproxy"], "service": "haproxy",
        "detect_bin": "haproxy",
    },
    {
        "id": "varnish", "name": "Varnish Cache",
        "description": "Web application accelerator / caching HTTP reverse proxy.",
        "icon": "Wind", "status": "not_installed", "category": "Web Server",
        "apt": ["varnish"], "yum": ["varnish"], "service": "varnish",
        "detect_bin": "varnishd",
    },
    # ── Databases ────────────────────────────────────────────────────────────
    {
        "id": "mariadb", "name": "MariaDB",
        "description": "Community-developed MySQL-compatible relational database.",
        "icon": "Database", "status": "not_installed", "category": "Database",
        "apt": ["mariadb-server", "mariadb-client"], "yum": ["mariadb-server", "mariadb"],
        "service": "mariadb", "detect_bin": "mariadb",
        "post_install": "setup_mysql_user",
    },
    {
        "id": "mysql", "name": "MySQL Community Server",
        "description": "World's most popular open-source relational database.",
        "icon": "Database", "status": "not_installed", "category": "Database",
        "apt": ["mysql-server"], "yum": ["mysql-community-server"],
        "service": "mysql", "detect_bin": "mysql",
        "post_install": "setup_mysql_user",
    },
    {
        "id": "postgresql", "name": "PostgreSQL",
        "description": "Advanced open-source object-relational database system.",
        "icon": "Database", "status": "not_installed", "category": "Database",
        "apt": ["postgresql", "postgresql-contrib"], "yum": ["postgresql-server", "postgresql-contrib"],
        "service": "postgresql", "detect_bin": "psql",
        "post_install": "setup_postgres_user",
    },
    {
        "id": "mongodb", "name": "MongoDB Community",
        "description": "NoSQL document-oriented database for modern applications.",
        "icon": "Database", "status": "not_installed", "category": "Database",
        "apt": ["mongodb-org"], "yum": ["mongodb-org"],
        "service": "mongod", "detect_bin": "mongod",
    },
    {
        "id": "redis", "name": "Redis",
        "description": "In-memory key-value store used as cache and message broker.",
        "icon": "Cpu", "status": "not_installed", "category": "Database",
        "apt": ["redis-server"], "yum": ["redis"],
        "service": "redis-server", "detect_bin": "redis-server",
    },
    {
        "id": "memcached", "name": "Memcached",
        "description": "Distributed memory object caching system.",
        "icon": "Cpu", "status": "not_installed", "category": "Database",
        "apt": ["memcached"], "yum": ["memcached"],
        "service": "memcached", "detect_bin": "memcached",
    },
    # ── Database Tools ───────────────────────────────────────────────────────
    {
        "id": "phpmyadmin", "name": "phpMyAdmin",
        "description": "Web-based SQL visual administration tool.",
        "icon": "Layout", "status": "not_installed", "category": "Database Tools",
    },
    # ── Runtimes & Languages ─────────────────────────────────────────────────
    {
        "id": "nodejs", "name": "Node.js & npm",
        "description": "JavaScript runtime environment and npm package manager.",
        "icon": "Code", "status": "not_installed", "category": "Runtimes",
        "apt": ["nodejs", "npm"], "yum": ["nodejs", "npm"],
        "detect_bin": "node",
    },
    {
        "id": "pm2", "name": "PM2",
        "description": "Production process manager for Node.js apps. Requires Node.js/npm.",
        "icon": "Terminal", "status": "not_installed", "category": "Runtimes",
        "detect_bin": "pm2", "install_via": "npm", "npm_packages": ["pm2"],
    },
    {
        "id": "python3", "name": "Python 3 & Pip",
        "description": "Python programming language and package installer.",
        "icon": "Code", "status": "not_installed", "category": "Runtimes",
        "apt": ["python3", "python3-pip", "python3-venv"], "yum": ["python3", "python3-pip"],
        "detect_bin": "python3",
    },
    {
        "id": "java", "name": "Java (OpenJDK 17)",
        "description": "Standard Java Development Kit and Runtime.",
        "icon": "Coffee", "status": "not_installed", "category": "Runtimes",
        "apt": ["openjdk-17-jdk"], "yum": ["java-17-openjdk-devel"],
        "detect_bin": "java",
    },
    {
        "id": "golang", "name": "Go (Golang)",
        "description": "Statically typed, compiled programming language by Google.",
        "icon": "Box", "status": "not_installed", "category": "Runtimes",
        "apt": ["golang"], "yum": ["golang"],
        "detect_bin": "go",
    },
    {
        "id": "php-fpm", "name": "PHP-FPM",
        "description": "FastCGI Process Manager for PHP scripts.",
        "icon": "Code", "status": "not_installed", "category": "Runtimes",
        "apt": ["php-fpm", "php-cli", "php-common"], "yum": ["php-fpm", "php-cli", "php-common"],
        "detect_bin": "php",
    },
    # ── DevOps & Containers ──────────────────────────────────────────────────
    {
        "id": "docker", "name": "Docker Engine",
        "description": "Containerization platform to build and run apps.",
        "icon": "Layers", "status": "not_installed", "category": "DevOps",
        "apt": ["docker.io", "docker-compose"], "yum": ["docker", "docker-compose"],
        "detect_bin": "docker",
    },
    {
        "id": "git", "name": "Git",
        "description": "Distributed version control system.",
        "icon": "GitBranch", "status": "not_installed", "category": "DevOps",
        "apt": ["git"], "yum": ["git"],
        "detect_bin": "git",
    },
    {
        "id": "composer", "name": "Composer",
        "description": "Dependency Manager for PHP.",
        "icon": "Package", "status": "not_installed", "category": "DevOps",
        "apt": ["composer"], "yum": ["composer"],
        "detect_bin": "composer",
    },
    # ── Utilities & Process Managers ─────────────────────────────────────────
    {
        "id": "supervisor", "name": "Supervisor",
        "description": "Process control system for UNIX-like OS.",
        "icon": "Cpu", "status": "not_installed", "category": "Utilities",
        "apt": ["supervisor"], "yum": ["supervisor"],
        "detect_bin": "supervisord",
    },
    {
        "id": "htop", "name": "Htop",
        "description": "Interactive process viewer and system monitor.",
        "icon": "Activity", "status": "not_installed", "category": "Utilities",
        "apt": ["htop"], "yum": ["htop"],
        "detect_bin": "htop",
    },
    {
        "id": "zip-utils", "name": "Zip & Unzip",
        "description": "Archiving and compression utilities.",
        "icon": "Archive", "status": "not_installed", "category": "Utilities",
        "apt": ["zip", "unzip", "tar"], "yum": ["zip", "unzip", "tar"],
        "detect_bin": "unzip",
    },
    {
        "id": "net-tools", "name": "Net-tools (netstat)",
        "description": "Network diagnostic tools and commands.",
        "icon": "Wifi", "status": "not_installed", "category": "Utilities",
        "apt": ["net-tools", "curl", "wget"], "yum": ["net-tools", "curl", "wget"],
        "detect_bin": "netstat",
    },
    # ── Security & System ────────────────────────────────────────────────────
    {
        "id": "firewall_service", "name": "Advanced Linux Firewall",
        "description": "Standard host-based firewall rules management.",
        "icon": "Shield", "status": "not_installed", "category": "Security & System",
    },
    {
        "id": "fail2ban", "name": "Fail2Ban",
        "description": "Intrusion prevention software framework.",
        "icon": "Lock", "status": "not_installed", "category": "Security & System",
        "apt": ["fail2ban"], "yum": ["fail2ban"],
        "service": "fail2ban", "detect_bin": "fail2ban-client",
    },
    {
        "id": "clamav", "name": "ClamAV",
        "description": "Open source antivirus engine for detecting trojans, viruses, malware.",
        "icon": "ShieldAlert", "status": "not_installed", "category": "Security & System",
        "apt": ["clamav", "clamav-daemon"], "yum": ["clamav", "clamd"],
        "detect_bin": "clamscan",
    },
    {
        "id": "certbot", "name": "Certbot",
        "description": "Automatically enable HTTPS on your website with Let's Encrypt.",
        "icon": "Key", "status": "not_installed", "category": "Security & System",
        "apt": ["certbot"], "yum": ["certbot"],
        "detect_bin": "certbot",
    }
]


def load_packages() -> List[Dict[str, Any]]:
    """Loads all packages and detects their current status from the system."""
    if not CONFIG_DIR.exists():
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        
    saved_dict = {}
    try:
        if PACKAGES_FILE.exists():
            with open(PACKAGES_FILE, 'r', encoding='utf-8') as f:
                saved_data = json.load(f)
                saved_dict = {p["id"]: p for p in saved_data}
    except Exception:
        pass

    merged = []
    detect_binaries = {
        "nginx": "nginx",
        "apache2": "apache2",
        "openlitespeed": "openlitespeed",
        "haproxy": "haproxy",
        "varnish": "varnishd",
        "redis": "redis-server",
        "memcached": "memcached",
        "firewall_service": "ufw",
        "mysql": "mysql",
        "mariadb": "mariadb",
        "postgresql": "psql",
        "mongodb": "mongod",
        "fail2ban": "fail2ban-client",
        "nodejs": "node",
        "pm2": "pm2",
        "python3": "python3",
        "java": "java",
        "golang": "go",
        "php-fpm": "php",
        "docker": "docker",
        "git": "git",
        "composer": "composer",
        "supervisor": "supervisord",
        "htop": "htop",
        "zip-utils": "unzip",
        "net-tools": "netstat",
        "clamav": "clamscan",
        "certbot": "certbot"
    }

    for default_pkg in DEFAULT_PACKAGES:
        pkg_id = default_pkg["id"]
        status = "not_installed"
        if pkg_id in saved_dict:
            status = saved_dict[pkg_id].get("status", "not_installed")

        # Automatically detect if running
        if status == "not_installed" and pkg_id in detect_binaries:
            if shutil.which(detect_binaries[pkg_id]):
                status = "running"

        if status == "not_installed" and pkg_id == "phpmyadmin":
            if os.path.exists("/usr/share/phpmyadmin") or os.path.exists("/var/www/html/phpmyadmin"):
                status = "running"

        merged.append({**default_pkg, "status": status})
    return merged


def _pkg_manager() -> Optional[str]:
    if shutil.which("apt-get"):
        return "apt-get"
    if shutil.which("yum"):
        return "yum"
    return None


def _run_with_optional_sudo(cmd: List[str], check: bool = True) -> subprocess.CompletedProcess:
    if IS_WINDOWS:
        return subprocess.CompletedProcess(cmd, 0, "", "")
    try:
        return subprocess.run(cmd, check=check, capture_output=True, text=True)
    except Exception:
        return subprocess.run(["sudo", "-n"] + cmd, check=check, capture_output=True, text=True)


def _service_name(pkg: Dict[str, Any]) -> Optional[str]:
    if not pkg:
        return None
    return pkg.get("service")


def _packages_for_current_os(pkg: Dict[str, Any]) -> List[str]:
    pm = _pkg_manager()
    if pm == "apt-get":
        return list(pkg.get("apt") or [])
    if pm == "yum":
        return list(pkg.get("yum") or [])
    return []


def _install_npm_global(packages: List[str]) -> None:
    """Install npm packages globally. Requires node/npm on PATH."""
    if not packages:
        return
    npm = shutil.which("npm")
    if not npm:
        raise RuntimeError("Node.js/npm is required. Install the Node.js package first.")
    _run_with_optional_sudo([npm, "install", "-g"] + packages, check=True)


def _remove_npm_global(packages: List[str]) -> None:
    npm = shutil.which("npm")
    if not npm or not packages:
        return
    _run_with_optional_sudo([npm, "uninstall", "-g"] + packages, check=False)


def _pm2_bin() -> Optional[str]:
    return shutil.which("pm2")


def save_packages(packages: List[Dict[str, Any]]):
    """Saves packages to disk."""
    if not CONFIG_DIR.exists():
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    with open(PACKAGES_FILE, 'w', encoding='utf-8') as f:
        json.dump(packages, f, indent=2, ensure_ascii=False)


def get_package(pkg_id: str) -> Dict[str, Any]:
    """Retrieves a package by ID."""
    packages = load_packages()
    for p in packages:
        if p["id"] == pkg_id:
            return p
    return None


def install_package(pkg_id: str) -> Dict[str, Any]:
    """Installs the selected package."""
    packages = load_packages()
    target_pkg = None
    for p in packages:
        if p["id"] == pkg_id:
            target_pkg = p
            break

    if target_pkg:
        if IS_WINDOWS:
            target_pkg["status"] = "running"
            save_packages(packages)
            return target_pkg

        # Special install flow for phpMyAdmin
        if pkg_id == "phpmyadmin":
            pm = _pkg_manager()
            if not pm:
                raise RuntimeError("No supported package manager found.")
            if pm == "apt-get":
                _run_with_optional_sudo([pm, "update", "-y"], check=False)
                _run_with_optional_sudo([pm, "install", "-y", "phpmyadmin"], check=True)
            else:
                try:
                    _run_with_optional_sudo([pm, "install", "-y", "phpMyAdmin"], check=True)
                except Exception:
                    _run_with_optional_sudo([pm, "install", "-y", "phpmyadmin"], check=True)
            target_pkg["status"] = "running"
            save_packages(packages)
            return target_pkg

        # npm global packages (e.g. PM2)
        if target_pkg.get("install_via") == "npm":
            npm_pkgs = list(target_pkg.get("npm_packages") or [pkg_id])
            _install_npm_global(npm_pkgs)
            if pkg_id == "pm2" and _pm2_bin():
                # Best-effort: prepare daemon so System Monitor can list apps
                _run_with_optional_sudo([_pm2_bin(), "ping"], check=False)
            target_pkg["status"] = "running"
            save_packages(packages)
            return target_pkg

        os_pkgs = _packages_for_current_os(target_pkg)
        if os_pkgs:
            pm = _pkg_manager()
            if not pm:
                raise RuntimeError("No supported package manager found.")
            if pm == "apt-get":
                _run_with_optional_sudo([pm, "update", "-y"], check=False)
            _run_with_optional_sudo([pm, "install", "-y"] + os_pkgs, check=True)

        svc = _service_name(target_pkg)
        if svc:
            _run_with_optional_sudo(["systemctl", "enable", "--now", svc], check=False)

        target_pkg["status"] = "running"
        save_packages(packages)
    return target_pkg


def restart_package(pkg_id: str) -> Dict[str, Any]:
    """Restarts a running package."""
    packages = load_packages()
    target_pkg = None
    for p in packages:
        if p["id"] == pkg_id:
            target_pkg = p
            break
    if target_pkg:
        if not IS_WINDOWS:
            if pkg_id == "pm2":
                pm2 = _pm2_bin()
                if pm2:
                    # Start/restart all managed apps (also used for "Start")
                    try:
                        _run_with_optional_sudo([pm2, "restart", "all"], check=True)
                    except Exception:
                        _run_with_optional_sudo([pm2, "resurrect"], check=False)
            else:
                svc = _service_name(target_pkg)
                if svc:
                    _run_with_optional_sudo(["systemctl", "restart", svc], check=False)
        save_packages(packages)
        target_pkg["status"] = "running"
    return target_pkg


def stop_package(pkg_id: str) -> Dict[str, Any]:
    """Stops a running package."""
    packages = load_packages()
    target_pkg = None
    for p in packages:
        if p["id"] == pkg_id:
            target_pkg = p
            break
    if target_pkg:
        if not IS_WINDOWS:
            if pkg_id == "pm2":
                pm2 = _pm2_bin()
                if pm2:
                    _run_with_optional_sudo([pm2, "stop", "all"], check=False)
            else:
                svc = _service_name(target_pkg)
                if svc:
                    _run_with_optional_sudo(["systemctl", "stop", svc], check=False)
        target_pkg["status"] = "stopped"
        save_packages(packages)
    return target_pkg


def remove_package(pkg_id: str) -> Dict[str, Any]:
    """Removes a package."""
    packages = load_packages()
    target_pkg = None
    for p in packages:
        if p["id"] == pkg_id:
            target_pkg = p
            break

    if target_pkg:
        if not IS_WINDOWS:
            if pkg_id == "pm2":
                pm2 = _pm2_bin()
                if pm2:
                    _run_with_optional_sudo([pm2, "kill"], check=False)
                npm_pkgs = list(target_pkg.get("npm_packages") or ["pm2"])
                _remove_npm_global(npm_pkgs)
            else:
                svc = _service_name(target_pkg)
                if svc:
                    _run_with_optional_sudo(["systemctl", "disable", "--now", svc], check=False)

                if pkg_id == "phpmyadmin":
                    pm = _pkg_manager()
                    if pm == "apt-get":
                        _run_with_optional_sudo([pm, "remove", "-y", "phpmyadmin"], check=False)
                    elif pm == "yum":
                        _run_with_optional_sudo([pm, "remove", "-y", "phpMyAdmin"], check=False)
                        _run_with_optional_sudo([pm, "remove", "-y", "phpmyadmin"], check=False)
                elif target_pkg.get("install_via") == "npm":
                    npm_pkgs = list(target_pkg.get("npm_packages") or [pkg_id])
                    _remove_npm_global(npm_pkgs)
                else:
                    os_pkgs = _packages_for_current_os(target_pkg)
                    pm = _pkg_manager()
                    if pm and os_pkgs:
                        _run_with_optional_sudo([pm, "remove", "-y"] + os_pkgs, check=False)

        target_pkg["status"] = "not_installed"
        save_packages(packages)
    return target_pkg


def get_mysql_credentials() -> Dict[str, Any]:
    """Return MySQL credentials."""
    creds_file = Path("/opt/copanel/config/mysql_credentials.txt")
    if creds_file.exists():
        try:
            user, password = "", ""
            with open(creds_file, "r") as f:
                for line in f:
                    line = line.strip()
                    if line.startswith("MYSQL_USER="):
                        user = line.split("=", 1)[1]
                    elif line.startswith("MYSQL_PASS="):
                        password = line.split("=", 1)[1]
            return {"status": "success", "user": user, "password": password, "url": "/phpmyadmin/index.php"}
        except Exception:
            pass
    return {"status": "success", "user": "root", "password": "", "url": "/phpmyadmin/index.php"}


def get_postgres_credentials() -> Dict[str, Any]:
    """Return PostgreSQL credentials."""
    return {"status": "success", "user": "postgres", "password": ""}