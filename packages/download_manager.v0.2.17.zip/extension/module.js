var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);

// src/modules/download_manager/index.tsx
import { useCallback, useEffect as useEffect3, useMemo, useRef as useRef2, useState as useState3 } from "react";

// src/core/hooks/useAppShellContext.ts
import { useOutletContext } from "react-router-dom";

// src/core/shell/ShellContext.tsx
import { createContext, useContext } from "react";
import { jsx } from "react/jsx-runtime";
var ShellContext = createContext(null);
function useShellContext() {
  return useContext(ShellContext);
}

// src/core/hooks/useAppShellContext.ts
var FALLBACK = {
  theme: localStorage.getItem("copanel_theme") || "light",
  setTheme: () => {
  },
  language: localStorage.getItem("copanel_lang") || "en",
  setLanguage: () => {
  }
};
function useAppShellContext() {
  const shell = useShellContext();
  const outlet = useOutletContext();
  if (shell) return shell;
  if (outlet?.theme) {
    return {
      theme: outlet.theme,
      setTheme: outlet.setTheme ?? (() => {
      }),
      language: outlet.language ?? "en",
      setLanguage: outlet.setLanguage ?? (() => {
      })
    };
  }
  return FALLBACK;
}

// node_modules/clsx/dist/clsx.mjs
function r(e) {
  var t, f, n = "";
  if ("string" == typeof e || "number" == typeof e) n += e;
  else if ("object" == typeof e) if (Array.isArray(e)) {
    var o = e.length;
    for (t = 0; t < o; t++) e[t] && (f = r(e[t])) && (n && (n += " "), n += f);
  } else for (f in e) e[f] && (n && (n += " "), n += f);
  return n;
}
function clsx() {
  for (var e, t, f = 0, n = "", o = arguments.length; f < o; f++) (e = arguments[f]) && (t = r(e)) && (n && (n += " "), n += t);
  return n;
}

// node_modules/tailwind-merge/dist/bundle-mjs.mjs
var CLASS_PART_SEPARATOR = "-";
var createClassGroupUtils = (config) => {
  const classMap = createClassMap(config);
  const {
    conflictingClassGroups,
    conflictingClassGroupModifiers
  } = config;
  const getClassGroupId = (className) => {
    const classParts = className.split(CLASS_PART_SEPARATOR);
    if (classParts[0] === "" && classParts.length !== 1) {
      classParts.shift();
    }
    return getGroupRecursive(classParts, classMap) || getGroupIdForArbitraryProperty(className);
  };
  const getConflictingClassGroupIds = (classGroupId, hasPostfixModifier) => {
    const conflicts = conflictingClassGroups[classGroupId] || [];
    if (hasPostfixModifier && conflictingClassGroupModifiers[classGroupId]) {
      return [...conflicts, ...conflictingClassGroupModifiers[classGroupId]];
    }
    return conflicts;
  };
  return {
    getClassGroupId,
    getConflictingClassGroupIds
  };
};
var getGroupRecursive = (classParts, classPartObject) => {
  if (classParts.length === 0) {
    return classPartObject.classGroupId;
  }
  const currentClassPart = classParts[0];
  const nextClassPartObject = classPartObject.nextPart.get(currentClassPart);
  const classGroupFromNextClassPart = nextClassPartObject ? getGroupRecursive(classParts.slice(1), nextClassPartObject) : void 0;
  if (classGroupFromNextClassPart) {
    return classGroupFromNextClassPart;
  }
  if (classPartObject.validators.length === 0) {
    return void 0;
  }
  const classRest = classParts.join(CLASS_PART_SEPARATOR);
  return classPartObject.validators.find(({
    validator
  }) => validator(classRest))?.classGroupId;
};
var arbitraryPropertyRegex = /^\[(.+)\]$/;
var getGroupIdForArbitraryProperty = (className) => {
  if (arbitraryPropertyRegex.test(className)) {
    const arbitraryPropertyClassName = arbitraryPropertyRegex.exec(className)[1];
    const property = arbitraryPropertyClassName?.substring(0, arbitraryPropertyClassName.indexOf(":"));
    if (property) {
      return "arbitrary.." + property;
    }
  }
};
var createClassMap = (config) => {
  const {
    theme,
    prefix
  } = config;
  const classMap = {
    nextPart: /* @__PURE__ */ new Map(),
    validators: []
  };
  const prefixedClassGroupEntries = getPrefixedClassGroupEntries(Object.entries(config.classGroups), prefix);
  prefixedClassGroupEntries.forEach(([classGroupId, classGroup]) => {
    processClassesRecursively(classGroup, classMap, classGroupId, theme);
  });
  return classMap;
};
var processClassesRecursively = (classGroup, classPartObject, classGroupId, theme) => {
  classGroup.forEach((classDefinition) => {
    if (typeof classDefinition === "string") {
      const classPartObjectToEdit = classDefinition === "" ? classPartObject : getPart(classPartObject, classDefinition);
      classPartObjectToEdit.classGroupId = classGroupId;
      return;
    }
    if (typeof classDefinition === "function") {
      if (isThemeGetter(classDefinition)) {
        processClassesRecursively(classDefinition(theme), classPartObject, classGroupId, theme);
        return;
      }
      classPartObject.validators.push({
        validator: classDefinition,
        classGroupId
      });
      return;
    }
    Object.entries(classDefinition).forEach(([key, classGroup2]) => {
      processClassesRecursively(classGroup2, getPart(classPartObject, key), classGroupId, theme);
    });
  });
};
var getPart = (classPartObject, path) => {
  let currentClassPartObject = classPartObject;
  path.split(CLASS_PART_SEPARATOR).forEach((pathPart) => {
    if (!currentClassPartObject.nextPart.has(pathPart)) {
      currentClassPartObject.nextPart.set(pathPart, {
        nextPart: /* @__PURE__ */ new Map(),
        validators: []
      });
    }
    currentClassPartObject = currentClassPartObject.nextPart.get(pathPart);
  });
  return currentClassPartObject;
};
var isThemeGetter = (func) => func.isThemeGetter;
var getPrefixedClassGroupEntries = (classGroupEntries, prefix) => {
  if (!prefix) {
    return classGroupEntries;
  }
  return classGroupEntries.map(([classGroupId, classGroup]) => {
    const prefixedClassGroup = classGroup.map((classDefinition) => {
      if (typeof classDefinition === "string") {
        return prefix + classDefinition;
      }
      if (typeof classDefinition === "object") {
        return Object.fromEntries(Object.entries(classDefinition).map(([key, value]) => [prefix + key, value]));
      }
      return classDefinition;
    });
    return [classGroupId, prefixedClassGroup];
  });
};
var createLruCache = (maxCacheSize) => {
  if (maxCacheSize < 1) {
    return {
      get: () => void 0,
      set: () => {
      }
    };
  }
  let cacheSize = 0;
  let cache = /* @__PURE__ */ new Map();
  let previousCache = /* @__PURE__ */ new Map();
  const update = (key, value) => {
    cache.set(key, value);
    cacheSize++;
    if (cacheSize > maxCacheSize) {
      cacheSize = 0;
      previousCache = cache;
      cache = /* @__PURE__ */ new Map();
    }
  };
  return {
    get(key) {
      let value = cache.get(key);
      if (value !== void 0) {
        return value;
      }
      if ((value = previousCache.get(key)) !== void 0) {
        update(key, value);
        return value;
      }
    },
    set(key, value) {
      if (cache.has(key)) {
        cache.set(key, value);
      } else {
        update(key, value);
      }
    }
  };
};
var IMPORTANT_MODIFIER = "!";
var createParseClassName = (config) => {
  const {
    separator,
    experimentalParseClassName
  } = config;
  const isSeparatorSingleCharacter = separator.length === 1;
  const firstSeparatorCharacter = separator[0];
  const separatorLength = separator.length;
  const parseClassName = (className) => {
    const modifiers = [];
    let bracketDepth = 0;
    let modifierStart = 0;
    let postfixModifierPosition;
    for (let index = 0; index < className.length; index++) {
      let currentCharacter = className[index];
      if (bracketDepth === 0) {
        if (currentCharacter === firstSeparatorCharacter && (isSeparatorSingleCharacter || className.slice(index, index + separatorLength) === separator)) {
          modifiers.push(className.slice(modifierStart, index));
          modifierStart = index + separatorLength;
          continue;
        }
        if (currentCharacter === "/") {
          postfixModifierPosition = index;
          continue;
        }
      }
      if (currentCharacter === "[") {
        bracketDepth++;
      } else if (currentCharacter === "]") {
        bracketDepth--;
      }
    }
    const baseClassNameWithImportantModifier = modifiers.length === 0 ? className : className.substring(modifierStart);
    const hasImportantModifier = baseClassNameWithImportantModifier.startsWith(IMPORTANT_MODIFIER);
    const baseClassName = hasImportantModifier ? baseClassNameWithImportantModifier.substring(1) : baseClassNameWithImportantModifier;
    const maybePostfixModifierPosition = postfixModifierPosition && postfixModifierPosition > modifierStart ? postfixModifierPosition - modifierStart : void 0;
    return {
      modifiers,
      hasImportantModifier,
      baseClassName,
      maybePostfixModifierPosition
    };
  };
  if (experimentalParseClassName) {
    return (className) => experimentalParseClassName({
      className,
      parseClassName
    });
  }
  return parseClassName;
};
var sortModifiers = (modifiers) => {
  if (modifiers.length <= 1) {
    return modifiers;
  }
  const sortedModifiers = [];
  let unsortedModifiers = [];
  modifiers.forEach((modifier) => {
    const isArbitraryVariant = modifier[0] === "[";
    if (isArbitraryVariant) {
      sortedModifiers.push(...unsortedModifiers.sort(), modifier);
      unsortedModifiers = [];
    } else {
      unsortedModifiers.push(modifier);
    }
  });
  sortedModifiers.push(...unsortedModifiers.sort());
  return sortedModifiers;
};
var createConfigUtils = (config) => ({
  cache: createLruCache(config.cacheSize),
  parseClassName: createParseClassName(config),
  ...createClassGroupUtils(config)
});
var SPLIT_CLASSES_REGEX = /\s+/;
var mergeClassList = (classList, configUtils) => {
  const {
    parseClassName,
    getClassGroupId,
    getConflictingClassGroupIds
  } = configUtils;
  const classGroupsInConflict = [];
  const classNames = classList.trim().split(SPLIT_CLASSES_REGEX);
  let result = "";
  for (let index = classNames.length - 1; index >= 0; index -= 1) {
    const originalClassName = classNames[index];
    const {
      modifiers,
      hasImportantModifier,
      baseClassName,
      maybePostfixModifierPosition
    } = parseClassName(originalClassName);
    let hasPostfixModifier = Boolean(maybePostfixModifierPosition);
    let classGroupId = getClassGroupId(hasPostfixModifier ? baseClassName.substring(0, maybePostfixModifierPosition) : baseClassName);
    if (!classGroupId) {
      if (!hasPostfixModifier) {
        result = originalClassName + (result.length > 0 ? " " + result : result);
        continue;
      }
      classGroupId = getClassGroupId(baseClassName);
      if (!classGroupId) {
        result = originalClassName + (result.length > 0 ? " " + result : result);
        continue;
      }
      hasPostfixModifier = false;
    }
    const variantModifier = sortModifiers(modifiers).join(":");
    const modifierId = hasImportantModifier ? variantModifier + IMPORTANT_MODIFIER : variantModifier;
    const classId = modifierId + classGroupId;
    if (classGroupsInConflict.includes(classId)) {
      continue;
    }
    classGroupsInConflict.push(classId);
    const conflictGroups = getConflictingClassGroupIds(classGroupId, hasPostfixModifier);
    for (let i = 0; i < conflictGroups.length; ++i) {
      const group = conflictGroups[i];
      classGroupsInConflict.push(modifierId + group);
    }
    result = originalClassName + (result.length > 0 ? " " + result : result);
  }
  return result;
};
function twJoin() {
  let index = 0;
  let argument;
  let resolvedValue;
  let string = "";
  while (index < arguments.length) {
    if (argument = arguments[index++]) {
      if (resolvedValue = toValue(argument)) {
        string && (string += " ");
        string += resolvedValue;
      }
    }
  }
  return string;
}
var toValue = (mix) => {
  if (typeof mix === "string") {
    return mix;
  }
  let resolvedValue;
  let string = "";
  for (let k = 0; k < mix.length; k++) {
    if (mix[k]) {
      if (resolvedValue = toValue(mix[k])) {
        string && (string += " ");
        string += resolvedValue;
      }
    }
  }
  return string;
};
function createTailwindMerge(createConfigFirst, ...createConfigRest) {
  let configUtils;
  let cacheGet;
  let cacheSet;
  let functionToCall = initTailwindMerge;
  function initTailwindMerge(classList) {
    const config = createConfigRest.reduce((previousConfig, createConfigCurrent) => createConfigCurrent(previousConfig), createConfigFirst());
    configUtils = createConfigUtils(config);
    cacheGet = configUtils.cache.get;
    cacheSet = configUtils.cache.set;
    functionToCall = tailwindMerge;
    return tailwindMerge(classList);
  }
  function tailwindMerge(classList) {
    const cachedResult = cacheGet(classList);
    if (cachedResult) {
      return cachedResult;
    }
    const result = mergeClassList(classList, configUtils);
    cacheSet(classList, result);
    return result;
  }
  return function callTailwindMerge() {
    return functionToCall(twJoin.apply(null, arguments));
  };
}
var fromTheme = (key) => {
  const themeGetter = (theme) => theme[key] || [];
  themeGetter.isThemeGetter = true;
  return themeGetter;
};
var arbitraryValueRegex = /^\[(?:([a-z-]+):)?(.+)\]$/i;
var fractionRegex = /^\d+\/\d+$/;
var stringLengths = /* @__PURE__ */ new Set(["px", "full", "screen"]);
var tshirtUnitRegex = /^(\d+(\.\d+)?)?(xs|sm|md|lg|xl)$/;
var lengthUnitRegex = /\d+(%|px|r?em|[sdl]?v([hwib]|min|max)|pt|pc|in|cm|mm|cap|ch|ex|r?lh|cq(w|h|i|b|min|max))|\b(calc|min|max|clamp)\(.+\)|^0$/;
var colorFunctionRegex = /^(rgba?|hsla?|hwb|(ok)?(lab|lch)|color-mix)\(.+\)$/;
var shadowRegex = /^(inset_)?-?((\d+)?\.?(\d+)[a-z]+|0)_-?((\d+)?\.?(\d+)[a-z]+|0)/;
var imageRegex = /^(url|image|image-set|cross-fade|element|(repeating-)?(linear|radial|conic)-gradient)\(.+\)$/;
var isLength = (value) => isNumber(value) || stringLengths.has(value) || fractionRegex.test(value);
var isArbitraryLength = (value) => getIsArbitraryValue(value, "length", isLengthOnly);
var isNumber = (value) => Boolean(value) && !Number.isNaN(Number(value));
var isArbitraryNumber = (value) => getIsArbitraryValue(value, "number", isNumber);
var isInteger = (value) => Boolean(value) && Number.isInteger(Number(value));
var isPercent = (value) => value.endsWith("%") && isNumber(value.slice(0, -1));
var isArbitraryValue = (value) => arbitraryValueRegex.test(value);
var isTshirtSize = (value) => tshirtUnitRegex.test(value);
var sizeLabels = /* @__PURE__ */ new Set(["length", "size", "percentage"]);
var isArbitrarySize = (value) => getIsArbitraryValue(value, sizeLabels, isNever);
var isArbitraryPosition = (value) => getIsArbitraryValue(value, "position", isNever);
var imageLabels = /* @__PURE__ */ new Set(["image", "url"]);
var isArbitraryImage = (value) => getIsArbitraryValue(value, imageLabels, isImage);
var isArbitraryShadow = (value) => getIsArbitraryValue(value, "", isShadow);
var isAny = () => true;
var getIsArbitraryValue = (value, label, testValue) => {
  const result = arbitraryValueRegex.exec(value);
  if (result) {
    if (result[1]) {
      return typeof label === "string" ? result[1] === label : label.has(result[1]);
    }
    return testValue(result[2]);
  }
  return false;
};
var isLengthOnly = (value) => (
  // `colorFunctionRegex` check is necessary because color functions can have percentages in them which which would be incorrectly classified as lengths.
  // For example, `hsl(0 0% 0%)` would be classified as a length without this check.
  // I could also use lookbehind assertion in `lengthUnitRegex` but that isn't supported widely enough.
  lengthUnitRegex.test(value) && !colorFunctionRegex.test(value)
);
var isNever = () => false;
var isShadow = (value) => shadowRegex.test(value);
var isImage = (value) => imageRegex.test(value);
var getDefaultConfig = () => {
  const colors = fromTheme("colors");
  const spacing = fromTheme("spacing");
  const blur = fromTheme("blur");
  const brightness = fromTheme("brightness");
  const borderColor = fromTheme("borderColor");
  const borderRadius = fromTheme("borderRadius");
  const borderSpacing = fromTheme("borderSpacing");
  const borderWidth = fromTheme("borderWidth");
  const contrast = fromTheme("contrast");
  const grayscale = fromTheme("grayscale");
  const hueRotate = fromTheme("hueRotate");
  const invert = fromTheme("invert");
  const gap = fromTheme("gap");
  const gradientColorStops = fromTheme("gradientColorStops");
  const gradientColorStopPositions = fromTheme("gradientColorStopPositions");
  const inset = fromTheme("inset");
  const margin = fromTheme("margin");
  const opacity = fromTheme("opacity");
  const padding = fromTheme("padding");
  const saturate = fromTheme("saturate");
  const scale = fromTheme("scale");
  const sepia = fromTheme("sepia");
  const skew = fromTheme("skew");
  const space = fromTheme("space");
  const translate = fromTheme("translate");
  const getOverscroll = () => ["auto", "contain", "none"];
  const getOverflow = () => ["auto", "hidden", "clip", "visible", "scroll"];
  const getSpacingWithAutoAndArbitrary = () => ["auto", isArbitraryValue, spacing];
  const getSpacingWithArbitrary = () => [isArbitraryValue, spacing];
  const getLengthWithEmptyAndArbitrary = () => ["", isLength, isArbitraryLength];
  const getNumberWithAutoAndArbitrary = () => ["auto", isNumber, isArbitraryValue];
  const getPositions = () => ["bottom", "center", "left", "left-bottom", "left-top", "right", "right-bottom", "right-top", "top"];
  const getLineStyles = () => ["solid", "dashed", "dotted", "double", "none"];
  const getBlendModes = () => ["normal", "multiply", "screen", "overlay", "darken", "lighten", "color-dodge", "color-burn", "hard-light", "soft-light", "difference", "exclusion", "hue", "saturation", "color", "luminosity"];
  const getAlign = () => ["start", "end", "center", "between", "around", "evenly", "stretch"];
  const getZeroAndEmpty = () => ["", "0", isArbitraryValue];
  const getBreaks = () => ["auto", "avoid", "all", "avoid-page", "page", "left", "right", "column"];
  const getNumberAndArbitrary = () => [isNumber, isArbitraryValue];
  return {
    cacheSize: 500,
    separator: ":",
    theme: {
      colors: [isAny],
      spacing: [isLength, isArbitraryLength],
      blur: ["none", "", isTshirtSize, isArbitraryValue],
      brightness: getNumberAndArbitrary(),
      borderColor: [colors],
      borderRadius: ["none", "", "full", isTshirtSize, isArbitraryValue],
      borderSpacing: getSpacingWithArbitrary(),
      borderWidth: getLengthWithEmptyAndArbitrary(),
      contrast: getNumberAndArbitrary(),
      grayscale: getZeroAndEmpty(),
      hueRotate: getNumberAndArbitrary(),
      invert: getZeroAndEmpty(),
      gap: getSpacingWithArbitrary(),
      gradientColorStops: [colors],
      gradientColorStopPositions: [isPercent, isArbitraryLength],
      inset: getSpacingWithAutoAndArbitrary(),
      margin: getSpacingWithAutoAndArbitrary(),
      opacity: getNumberAndArbitrary(),
      padding: getSpacingWithArbitrary(),
      saturate: getNumberAndArbitrary(),
      scale: getNumberAndArbitrary(),
      sepia: getZeroAndEmpty(),
      skew: getNumberAndArbitrary(),
      space: getSpacingWithArbitrary(),
      translate: getSpacingWithArbitrary()
    },
    classGroups: {
      // Layout
      /**
       * Aspect Ratio
       * @see https://tailwindcss.com/docs/aspect-ratio
       */
      aspect: [{
        aspect: ["auto", "square", "video", isArbitraryValue]
      }],
      /**
       * Container
       * @see https://tailwindcss.com/docs/container
       */
      container: ["container"],
      /**
       * Columns
       * @see https://tailwindcss.com/docs/columns
       */
      columns: [{
        columns: [isTshirtSize]
      }],
      /**
       * Break After
       * @see https://tailwindcss.com/docs/break-after
       */
      "break-after": [{
        "break-after": getBreaks()
      }],
      /**
       * Break Before
       * @see https://tailwindcss.com/docs/break-before
       */
      "break-before": [{
        "break-before": getBreaks()
      }],
      /**
       * Break Inside
       * @see https://tailwindcss.com/docs/break-inside
       */
      "break-inside": [{
        "break-inside": ["auto", "avoid", "avoid-page", "avoid-column"]
      }],
      /**
       * Box Decoration Break
       * @see https://tailwindcss.com/docs/box-decoration-break
       */
      "box-decoration": [{
        "box-decoration": ["slice", "clone"]
      }],
      /**
       * Box Sizing
       * @see https://tailwindcss.com/docs/box-sizing
       */
      box: [{
        box: ["border", "content"]
      }],
      /**
       * Display
       * @see https://tailwindcss.com/docs/display
       */
      display: ["block", "inline-block", "inline", "flex", "inline-flex", "table", "inline-table", "table-caption", "table-cell", "table-column", "table-column-group", "table-footer-group", "table-header-group", "table-row-group", "table-row", "flow-root", "grid", "inline-grid", "contents", "list-item", "hidden"],
      /**
       * Floats
       * @see https://tailwindcss.com/docs/float
       */
      float: [{
        float: ["right", "left", "none", "start", "end"]
      }],
      /**
       * Clear
       * @see https://tailwindcss.com/docs/clear
       */
      clear: [{
        clear: ["left", "right", "both", "none", "start", "end"]
      }],
      /**
       * Isolation
       * @see https://tailwindcss.com/docs/isolation
       */
      isolation: ["isolate", "isolation-auto"],
      /**
       * Object Fit
       * @see https://tailwindcss.com/docs/object-fit
       */
      "object-fit": [{
        object: ["contain", "cover", "fill", "none", "scale-down"]
      }],
      /**
       * Object Position
       * @see https://tailwindcss.com/docs/object-position
       */
      "object-position": [{
        object: [...getPositions(), isArbitraryValue]
      }],
      /**
       * Overflow
       * @see https://tailwindcss.com/docs/overflow
       */
      overflow: [{
        overflow: getOverflow()
      }],
      /**
       * Overflow X
       * @see https://tailwindcss.com/docs/overflow
       */
      "overflow-x": [{
        "overflow-x": getOverflow()
      }],
      /**
       * Overflow Y
       * @see https://tailwindcss.com/docs/overflow
       */
      "overflow-y": [{
        "overflow-y": getOverflow()
      }],
      /**
       * Overscroll Behavior
       * @see https://tailwindcss.com/docs/overscroll-behavior
       */
      overscroll: [{
        overscroll: getOverscroll()
      }],
      /**
       * Overscroll Behavior X
       * @see https://tailwindcss.com/docs/overscroll-behavior
       */
      "overscroll-x": [{
        "overscroll-x": getOverscroll()
      }],
      /**
       * Overscroll Behavior Y
       * @see https://tailwindcss.com/docs/overscroll-behavior
       */
      "overscroll-y": [{
        "overscroll-y": getOverscroll()
      }],
      /**
       * Position
       * @see https://tailwindcss.com/docs/position
       */
      position: ["static", "fixed", "absolute", "relative", "sticky"],
      /**
       * Top / Right / Bottom / Left
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      inset: [{
        inset: [inset]
      }],
      /**
       * Right / Left
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      "inset-x": [{
        "inset-x": [inset]
      }],
      /**
       * Top / Bottom
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      "inset-y": [{
        "inset-y": [inset]
      }],
      /**
       * Start
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      start: [{
        start: [inset]
      }],
      /**
       * End
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      end: [{
        end: [inset]
      }],
      /**
       * Top
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      top: [{
        top: [inset]
      }],
      /**
       * Right
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      right: [{
        right: [inset]
      }],
      /**
       * Bottom
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      bottom: [{
        bottom: [inset]
      }],
      /**
       * Left
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      left: [{
        left: [inset]
      }],
      /**
       * Visibility
       * @see https://tailwindcss.com/docs/visibility
       */
      visibility: ["visible", "invisible", "collapse"],
      /**
       * Z-Index
       * @see https://tailwindcss.com/docs/z-index
       */
      z: [{
        z: ["auto", isInteger, isArbitraryValue]
      }],
      // Flexbox and Grid
      /**
       * Flex Basis
       * @see https://tailwindcss.com/docs/flex-basis
       */
      basis: [{
        basis: getSpacingWithAutoAndArbitrary()
      }],
      /**
       * Flex Direction
       * @see https://tailwindcss.com/docs/flex-direction
       */
      "flex-direction": [{
        flex: ["row", "row-reverse", "col", "col-reverse"]
      }],
      /**
       * Flex Wrap
       * @see https://tailwindcss.com/docs/flex-wrap
       */
      "flex-wrap": [{
        flex: ["wrap", "wrap-reverse", "nowrap"]
      }],
      /**
       * Flex
       * @see https://tailwindcss.com/docs/flex
       */
      flex: [{
        flex: ["1", "auto", "initial", "none", isArbitraryValue]
      }],
      /**
       * Flex Grow
       * @see https://tailwindcss.com/docs/flex-grow
       */
      grow: [{
        grow: getZeroAndEmpty()
      }],
      /**
       * Flex Shrink
       * @see https://tailwindcss.com/docs/flex-shrink
       */
      shrink: [{
        shrink: getZeroAndEmpty()
      }],
      /**
       * Order
       * @see https://tailwindcss.com/docs/order
       */
      order: [{
        order: ["first", "last", "none", isInteger, isArbitraryValue]
      }],
      /**
       * Grid Template Columns
       * @see https://tailwindcss.com/docs/grid-template-columns
       */
      "grid-cols": [{
        "grid-cols": [isAny]
      }],
      /**
       * Grid Column Start / End
       * @see https://tailwindcss.com/docs/grid-column
       */
      "col-start-end": [{
        col: ["auto", {
          span: ["full", isInteger, isArbitraryValue]
        }, isArbitraryValue]
      }],
      /**
       * Grid Column Start
       * @see https://tailwindcss.com/docs/grid-column
       */
      "col-start": [{
        "col-start": getNumberWithAutoAndArbitrary()
      }],
      /**
       * Grid Column End
       * @see https://tailwindcss.com/docs/grid-column
       */
      "col-end": [{
        "col-end": getNumberWithAutoAndArbitrary()
      }],
      /**
       * Grid Template Rows
       * @see https://tailwindcss.com/docs/grid-template-rows
       */
      "grid-rows": [{
        "grid-rows": [isAny]
      }],
      /**
       * Grid Row Start / End
       * @see https://tailwindcss.com/docs/grid-row
       */
      "row-start-end": [{
        row: ["auto", {
          span: [isInteger, isArbitraryValue]
        }, isArbitraryValue]
      }],
      /**
       * Grid Row Start
       * @see https://tailwindcss.com/docs/grid-row
       */
      "row-start": [{
        "row-start": getNumberWithAutoAndArbitrary()
      }],
      /**
       * Grid Row End
       * @see https://tailwindcss.com/docs/grid-row
       */
      "row-end": [{
        "row-end": getNumberWithAutoAndArbitrary()
      }],
      /**
       * Grid Auto Flow
       * @see https://tailwindcss.com/docs/grid-auto-flow
       */
      "grid-flow": [{
        "grid-flow": ["row", "col", "dense", "row-dense", "col-dense"]
      }],
      /**
       * Grid Auto Columns
       * @see https://tailwindcss.com/docs/grid-auto-columns
       */
      "auto-cols": [{
        "auto-cols": ["auto", "min", "max", "fr", isArbitraryValue]
      }],
      /**
       * Grid Auto Rows
       * @see https://tailwindcss.com/docs/grid-auto-rows
       */
      "auto-rows": [{
        "auto-rows": ["auto", "min", "max", "fr", isArbitraryValue]
      }],
      /**
       * Gap
       * @see https://tailwindcss.com/docs/gap
       */
      gap: [{
        gap: [gap]
      }],
      /**
       * Gap X
       * @see https://tailwindcss.com/docs/gap
       */
      "gap-x": [{
        "gap-x": [gap]
      }],
      /**
       * Gap Y
       * @see https://tailwindcss.com/docs/gap
       */
      "gap-y": [{
        "gap-y": [gap]
      }],
      /**
       * Justify Content
       * @see https://tailwindcss.com/docs/justify-content
       */
      "justify-content": [{
        justify: ["normal", ...getAlign()]
      }],
      /**
       * Justify Items
       * @see https://tailwindcss.com/docs/justify-items
       */
      "justify-items": [{
        "justify-items": ["start", "end", "center", "stretch"]
      }],
      /**
       * Justify Self
       * @see https://tailwindcss.com/docs/justify-self
       */
      "justify-self": [{
        "justify-self": ["auto", "start", "end", "center", "stretch"]
      }],
      /**
       * Align Content
       * @see https://tailwindcss.com/docs/align-content
       */
      "align-content": [{
        content: ["normal", ...getAlign(), "baseline"]
      }],
      /**
       * Align Items
       * @see https://tailwindcss.com/docs/align-items
       */
      "align-items": [{
        items: ["start", "end", "center", "baseline", "stretch"]
      }],
      /**
       * Align Self
       * @see https://tailwindcss.com/docs/align-self
       */
      "align-self": [{
        self: ["auto", "start", "end", "center", "stretch", "baseline"]
      }],
      /**
       * Place Content
       * @see https://tailwindcss.com/docs/place-content
       */
      "place-content": [{
        "place-content": [...getAlign(), "baseline"]
      }],
      /**
       * Place Items
       * @see https://tailwindcss.com/docs/place-items
       */
      "place-items": [{
        "place-items": ["start", "end", "center", "baseline", "stretch"]
      }],
      /**
       * Place Self
       * @see https://tailwindcss.com/docs/place-self
       */
      "place-self": [{
        "place-self": ["auto", "start", "end", "center", "stretch"]
      }],
      // Spacing
      /**
       * Padding
       * @see https://tailwindcss.com/docs/padding
       */
      p: [{
        p: [padding]
      }],
      /**
       * Padding X
       * @see https://tailwindcss.com/docs/padding
       */
      px: [{
        px: [padding]
      }],
      /**
       * Padding Y
       * @see https://tailwindcss.com/docs/padding
       */
      py: [{
        py: [padding]
      }],
      /**
       * Padding Start
       * @see https://tailwindcss.com/docs/padding
       */
      ps: [{
        ps: [padding]
      }],
      /**
       * Padding End
       * @see https://tailwindcss.com/docs/padding
       */
      pe: [{
        pe: [padding]
      }],
      /**
       * Padding Top
       * @see https://tailwindcss.com/docs/padding
       */
      pt: [{
        pt: [padding]
      }],
      /**
       * Padding Right
       * @see https://tailwindcss.com/docs/padding
       */
      pr: [{
        pr: [padding]
      }],
      /**
       * Padding Bottom
       * @see https://tailwindcss.com/docs/padding
       */
      pb: [{
        pb: [padding]
      }],
      /**
       * Padding Left
       * @see https://tailwindcss.com/docs/padding
       */
      pl: [{
        pl: [padding]
      }],
      /**
       * Margin
       * @see https://tailwindcss.com/docs/margin
       */
      m: [{
        m: [margin]
      }],
      /**
       * Margin X
       * @see https://tailwindcss.com/docs/margin
       */
      mx: [{
        mx: [margin]
      }],
      /**
       * Margin Y
       * @see https://tailwindcss.com/docs/margin
       */
      my: [{
        my: [margin]
      }],
      /**
       * Margin Start
       * @see https://tailwindcss.com/docs/margin
       */
      ms: [{
        ms: [margin]
      }],
      /**
       * Margin End
       * @see https://tailwindcss.com/docs/margin
       */
      me: [{
        me: [margin]
      }],
      /**
       * Margin Top
       * @see https://tailwindcss.com/docs/margin
       */
      mt: [{
        mt: [margin]
      }],
      /**
       * Margin Right
       * @see https://tailwindcss.com/docs/margin
       */
      mr: [{
        mr: [margin]
      }],
      /**
       * Margin Bottom
       * @see https://tailwindcss.com/docs/margin
       */
      mb: [{
        mb: [margin]
      }],
      /**
       * Margin Left
       * @see https://tailwindcss.com/docs/margin
       */
      ml: [{
        ml: [margin]
      }],
      /**
       * Space Between X
       * @see https://tailwindcss.com/docs/space
       */
      "space-x": [{
        "space-x": [space]
      }],
      /**
       * Space Between X Reverse
       * @see https://tailwindcss.com/docs/space
       */
      "space-x-reverse": ["space-x-reverse"],
      /**
       * Space Between Y
       * @see https://tailwindcss.com/docs/space
       */
      "space-y": [{
        "space-y": [space]
      }],
      /**
       * Space Between Y Reverse
       * @see https://tailwindcss.com/docs/space
       */
      "space-y-reverse": ["space-y-reverse"],
      // Sizing
      /**
       * Width
       * @see https://tailwindcss.com/docs/width
       */
      w: [{
        w: ["auto", "min", "max", "fit", "svw", "lvw", "dvw", isArbitraryValue, spacing]
      }],
      /**
       * Min-Width
       * @see https://tailwindcss.com/docs/min-width
       */
      "min-w": [{
        "min-w": [isArbitraryValue, spacing, "min", "max", "fit"]
      }],
      /**
       * Max-Width
       * @see https://tailwindcss.com/docs/max-width
       */
      "max-w": [{
        "max-w": [isArbitraryValue, spacing, "none", "full", "min", "max", "fit", "prose", {
          screen: [isTshirtSize]
        }, isTshirtSize]
      }],
      /**
       * Height
       * @see https://tailwindcss.com/docs/height
       */
      h: [{
        h: [isArbitraryValue, spacing, "auto", "min", "max", "fit", "svh", "lvh", "dvh"]
      }],
      /**
       * Min-Height
       * @see https://tailwindcss.com/docs/min-height
       */
      "min-h": [{
        "min-h": [isArbitraryValue, spacing, "min", "max", "fit", "svh", "lvh", "dvh"]
      }],
      /**
       * Max-Height
       * @see https://tailwindcss.com/docs/max-height
       */
      "max-h": [{
        "max-h": [isArbitraryValue, spacing, "min", "max", "fit", "svh", "lvh", "dvh"]
      }],
      /**
       * Size
       * @see https://tailwindcss.com/docs/size
       */
      size: [{
        size: [isArbitraryValue, spacing, "auto", "min", "max", "fit"]
      }],
      // Typography
      /**
       * Font Size
       * @see https://tailwindcss.com/docs/font-size
       */
      "font-size": [{
        text: ["base", isTshirtSize, isArbitraryLength]
      }],
      /**
       * Font Smoothing
       * @see https://tailwindcss.com/docs/font-smoothing
       */
      "font-smoothing": ["antialiased", "subpixel-antialiased"],
      /**
       * Font Style
       * @see https://tailwindcss.com/docs/font-style
       */
      "font-style": ["italic", "not-italic"],
      /**
       * Font Weight
       * @see https://tailwindcss.com/docs/font-weight
       */
      "font-weight": [{
        font: ["thin", "extralight", "light", "normal", "medium", "semibold", "bold", "extrabold", "black", isArbitraryNumber]
      }],
      /**
       * Font Family
       * @see https://tailwindcss.com/docs/font-family
       */
      "font-family": [{
        font: [isAny]
      }],
      /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */
      "fvn-normal": ["normal-nums"],
      /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */
      "fvn-ordinal": ["ordinal"],
      /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */
      "fvn-slashed-zero": ["slashed-zero"],
      /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */
      "fvn-figure": ["lining-nums", "oldstyle-nums"],
      /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */
      "fvn-spacing": ["proportional-nums", "tabular-nums"],
      /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */
      "fvn-fraction": ["diagonal-fractions", "stacked-fractions"],
      /**
       * Letter Spacing
       * @see https://tailwindcss.com/docs/letter-spacing
       */
      tracking: [{
        tracking: ["tighter", "tight", "normal", "wide", "wider", "widest", isArbitraryValue]
      }],
      /**
       * Line Clamp
       * @see https://tailwindcss.com/docs/line-clamp
       */
      "line-clamp": [{
        "line-clamp": ["none", isNumber, isArbitraryNumber]
      }],
      /**
       * Line Height
       * @see https://tailwindcss.com/docs/line-height
       */
      leading: [{
        leading: ["none", "tight", "snug", "normal", "relaxed", "loose", isLength, isArbitraryValue]
      }],
      /**
       * List Style Image
       * @see https://tailwindcss.com/docs/list-style-image
       */
      "list-image": [{
        "list-image": ["none", isArbitraryValue]
      }],
      /**
       * List Style Type
       * @see https://tailwindcss.com/docs/list-style-type
       */
      "list-style-type": [{
        list: ["none", "disc", "decimal", isArbitraryValue]
      }],
      /**
       * List Style Position
       * @see https://tailwindcss.com/docs/list-style-position
       */
      "list-style-position": [{
        list: ["inside", "outside"]
      }],
      /**
       * Placeholder Color
       * @deprecated since Tailwind CSS v3.0.0
       * @see https://tailwindcss.com/docs/placeholder-color
       */
      "placeholder-color": [{
        placeholder: [colors]
      }],
      /**
       * Placeholder Opacity
       * @see https://tailwindcss.com/docs/placeholder-opacity
       */
      "placeholder-opacity": [{
        "placeholder-opacity": [opacity]
      }],
      /**
       * Text Alignment
       * @see https://tailwindcss.com/docs/text-align
       */
      "text-alignment": [{
        text: ["left", "center", "right", "justify", "start", "end"]
      }],
      /**
       * Text Color
       * @see https://tailwindcss.com/docs/text-color
       */
      "text-color": [{
        text: [colors]
      }],
      /**
       * Text Opacity
       * @see https://tailwindcss.com/docs/text-opacity
       */
      "text-opacity": [{
        "text-opacity": [opacity]
      }],
      /**
       * Text Decoration
       * @see https://tailwindcss.com/docs/text-decoration
       */
      "text-decoration": ["underline", "overline", "line-through", "no-underline"],
      /**
       * Text Decoration Style
       * @see https://tailwindcss.com/docs/text-decoration-style
       */
      "text-decoration-style": [{
        decoration: [...getLineStyles(), "wavy"]
      }],
      /**
       * Text Decoration Thickness
       * @see https://tailwindcss.com/docs/text-decoration-thickness
       */
      "text-decoration-thickness": [{
        decoration: ["auto", "from-font", isLength, isArbitraryLength]
      }],
      /**
       * Text Underline Offset
       * @see https://tailwindcss.com/docs/text-underline-offset
       */
      "underline-offset": [{
        "underline-offset": ["auto", isLength, isArbitraryValue]
      }],
      /**
       * Text Decoration Color
       * @see https://tailwindcss.com/docs/text-decoration-color
       */
      "text-decoration-color": [{
        decoration: [colors]
      }],
      /**
       * Text Transform
       * @see https://tailwindcss.com/docs/text-transform
       */
      "text-transform": ["uppercase", "lowercase", "capitalize", "normal-case"],
      /**
       * Text Overflow
       * @see https://tailwindcss.com/docs/text-overflow
       */
      "text-overflow": ["truncate", "text-ellipsis", "text-clip"],
      /**
       * Text Wrap
       * @see https://tailwindcss.com/docs/text-wrap
       */
      "text-wrap": [{
        text: ["wrap", "nowrap", "balance", "pretty"]
      }],
      /**
       * Text Indent
       * @see https://tailwindcss.com/docs/text-indent
       */
      indent: [{
        indent: getSpacingWithArbitrary()
      }],
      /**
       * Vertical Alignment
       * @see https://tailwindcss.com/docs/vertical-align
       */
      "vertical-align": [{
        align: ["baseline", "top", "middle", "bottom", "text-top", "text-bottom", "sub", "super", isArbitraryValue]
      }],
      /**
       * Whitespace
       * @see https://tailwindcss.com/docs/whitespace
       */
      whitespace: [{
        whitespace: ["normal", "nowrap", "pre", "pre-line", "pre-wrap", "break-spaces"]
      }],
      /**
       * Word Break
       * @see https://tailwindcss.com/docs/word-break
       */
      break: [{
        break: ["normal", "words", "all", "keep"]
      }],
      /**
       * Hyphens
       * @see https://tailwindcss.com/docs/hyphens
       */
      hyphens: [{
        hyphens: ["none", "manual", "auto"]
      }],
      /**
       * Content
       * @see https://tailwindcss.com/docs/content
       */
      content: [{
        content: ["none", isArbitraryValue]
      }],
      // Backgrounds
      /**
       * Background Attachment
       * @see https://tailwindcss.com/docs/background-attachment
       */
      "bg-attachment": [{
        bg: ["fixed", "local", "scroll"]
      }],
      /**
       * Background Clip
       * @see https://tailwindcss.com/docs/background-clip
       */
      "bg-clip": [{
        "bg-clip": ["border", "padding", "content", "text"]
      }],
      /**
       * Background Opacity
       * @deprecated since Tailwind CSS v3.0.0
       * @see https://tailwindcss.com/docs/background-opacity
       */
      "bg-opacity": [{
        "bg-opacity": [opacity]
      }],
      /**
       * Background Origin
       * @see https://tailwindcss.com/docs/background-origin
       */
      "bg-origin": [{
        "bg-origin": ["border", "padding", "content"]
      }],
      /**
       * Background Position
       * @see https://tailwindcss.com/docs/background-position
       */
      "bg-position": [{
        bg: [...getPositions(), isArbitraryPosition]
      }],
      /**
       * Background Repeat
       * @see https://tailwindcss.com/docs/background-repeat
       */
      "bg-repeat": [{
        bg: ["no-repeat", {
          repeat: ["", "x", "y", "round", "space"]
        }]
      }],
      /**
       * Background Size
       * @see https://tailwindcss.com/docs/background-size
       */
      "bg-size": [{
        bg: ["auto", "cover", "contain", isArbitrarySize]
      }],
      /**
       * Background Image
       * @see https://tailwindcss.com/docs/background-image
       */
      "bg-image": [{
        bg: ["none", {
          "gradient-to": ["t", "tr", "r", "br", "b", "bl", "l", "tl"]
        }, isArbitraryImage]
      }],
      /**
       * Background Color
       * @see https://tailwindcss.com/docs/background-color
       */
      "bg-color": [{
        bg: [colors]
      }],
      /**
       * Gradient Color Stops From Position
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */
      "gradient-from-pos": [{
        from: [gradientColorStopPositions]
      }],
      /**
       * Gradient Color Stops Via Position
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */
      "gradient-via-pos": [{
        via: [gradientColorStopPositions]
      }],
      /**
       * Gradient Color Stops To Position
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */
      "gradient-to-pos": [{
        to: [gradientColorStopPositions]
      }],
      /**
       * Gradient Color Stops From
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */
      "gradient-from": [{
        from: [gradientColorStops]
      }],
      /**
       * Gradient Color Stops Via
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */
      "gradient-via": [{
        via: [gradientColorStops]
      }],
      /**
       * Gradient Color Stops To
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */
      "gradient-to": [{
        to: [gradientColorStops]
      }],
      // Borders
      /**
       * Border Radius
       * @see https://tailwindcss.com/docs/border-radius
       */
      rounded: [{
        rounded: [borderRadius]
      }],
      /**
       * Border Radius Start
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-s": [{
        "rounded-s": [borderRadius]
      }],
      /**
       * Border Radius End
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-e": [{
        "rounded-e": [borderRadius]
      }],
      /**
       * Border Radius Top
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-t": [{
        "rounded-t": [borderRadius]
      }],
      /**
       * Border Radius Right
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-r": [{
        "rounded-r": [borderRadius]
      }],
      /**
       * Border Radius Bottom
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-b": [{
        "rounded-b": [borderRadius]
      }],
      /**
       * Border Radius Left
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-l": [{
        "rounded-l": [borderRadius]
      }],
      /**
       * Border Radius Start Start
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-ss": [{
        "rounded-ss": [borderRadius]
      }],
      /**
       * Border Radius Start End
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-se": [{
        "rounded-se": [borderRadius]
      }],
      /**
       * Border Radius End End
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-ee": [{
        "rounded-ee": [borderRadius]
      }],
      /**
       * Border Radius End Start
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-es": [{
        "rounded-es": [borderRadius]
      }],
      /**
       * Border Radius Top Left
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-tl": [{
        "rounded-tl": [borderRadius]
      }],
      /**
       * Border Radius Top Right
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-tr": [{
        "rounded-tr": [borderRadius]
      }],
      /**
       * Border Radius Bottom Right
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-br": [{
        "rounded-br": [borderRadius]
      }],
      /**
       * Border Radius Bottom Left
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-bl": [{
        "rounded-bl": [borderRadius]
      }],
      /**
       * Border Width
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w": [{
        border: [borderWidth]
      }],
      /**
       * Border Width X
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-x": [{
        "border-x": [borderWidth]
      }],
      /**
       * Border Width Y
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-y": [{
        "border-y": [borderWidth]
      }],
      /**
       * Border Width Start
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-s": [{
        "border-s": [borderWidth]
      }],
      /**
       * Border Width End
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-e": [{
        "border-e": [borderWidth]
      }],
      /**
       * Border Width Top
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-t": [{
        "border-t": [borderWidth]
      }],
      /**
       * Border Width Right
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-r": [{
        "border-r": [borderWidth]
      }],
      /**
       * Border Width Bottom
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-b": [{
        "border-b": [borderWidth]
      }],
      /**
       * Border Width Left
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-l": [{
        "border-l": [borderWidth]
      }],
      /**
       * Border Opacity
       * @see https://tailwindcss.com/docs/border-opacity
       */
      "border-opacity": [{
        "border-opacity": [opacity]
      }],
      /**
       * Border Style
       * @see https://tailwindcss.com/docs/border-style
       */
      "border-style": [{
        border: [...getLineStyles(), "hidden"]
      }],
      /**
       * Divide Width X
       * @see https://tailwindcss.com/docs/divide-width
       */
      "divide-x": [{
        "divide-x": [borderWidth]
      }],
      /**
       * Divide Width X Reverse
       * @see https://tailwindcss.com/docs/divide-width
       */
      "divide-x-reverse": ["divide-x-reverse"],
      /**
       * Divide Width Y
       * @see https://tailwindcss.com/docs/divide-width
       */
      "divide-y": [{
        "divide-y": [borderWidth]
      }],
      /**
       * Divide Width Y Reverse
       * @see https://tailwindcss.com/docs/divide-width
       */
      "divide-y-reverse": ["divide-y-reverse"],
      /**
       * Divide Opacity
       * @see https://tailwindcss.com/docs/divide-opacity
       */
      "divide-opacity": [{
        "divide-opacity": [opacity]
      }],
      /**
       * Divide Style
       * @see https://tailwindcss.com/docs/divide-style
       */
      "divide-style": [{
        divide: getLineStyles()
      }],
      /**
       * Border Color
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color": [{
        border: [borderColor]
      }],
      /**
       * Border Color X
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-x": [{
        "border-x": [borderColor]
      }],
      /**
       * Border Color Y
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-y": [{
        "border-y": [borderColor]
      }],
      /**
       * Border Color S
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-s": [{
        "border-s": [borderColor]
      }],
      /**
       * Border Color E
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-e": [{
        "border-e": [borderColor]
      }],
      /**
       * Border Color Top
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-t": [{
        "border-t": [borderColor]
      }],
      /**
       * Border Color Right
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-r": [{
        "border-r": [borderColor]
      }],
      /**
       * Border Color Bottom
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-b": [{
        "border-b": [borderColor]
      }],
      /**
       * Border Color Left
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-l": [{
        "border-l": [borderColor]
      }],
      /**
       * Divide Color
       * @see https://tailwindcss.com/docs/divide-color
       */
      "divide-color": [{
        divide: [borderColor]
      }],
      /**
       * Outline Style
       * @see https://tailwindcss.com/docs/outline-style
       */
      "outline-style": [{
        outline: ["", ...getLineStyles()]
      }],
      /**
       * Outline Offset
       * @see https://tailwindcss.com/docs/outline-offset
       */
      "outline-offset": [{
        "outline-offset": [isLength, isArbitraryValue]
      }],
      /**
       * Outline Width
       * @see https://tailwindcss.com/docs/outline-width
       */
      "outline-w": [{
        outline: [isLength, isArbitraryLength]
      }],
      /**
       * Outline Color
       * @see https://tailwindcss.com/docs/outline-color
       */
      "outline-color": [{
        outline: [colors]
      }],
      /**
       * Ring Width
       * @see https://tailwindcss.com/docs/ring-width
       */
      "ring-w": [{
        ring: getLengthWithEmptyAndArbitrary()
      }],
      /**
       * Ring Width Inset
       * @see https://tailwindcss.com/docs/ring-width
       */
      "ring-w-inset": ["ring-inset"],
      /**
       * Ring Color
       * @see https://tailwindcss.com/docs/ring-color
       */
      "ring-color": [{
        ring: [colors]
      }],
      /**
       * Ring Opacity
       * @see https://tailwindcss.com/docs/ring-opacity
       */
      "ring-opacity": [{
        "ring-opacity": [opacity]
      }],
      /**
       * Ring Offset Width
       * @see https://tailwindcss.com/docs/ring-offset-width
       */
      "ring-offset-w": [{
        "ring-offset": [isLength, isArbitraryLength]
      }],
      /**
       * Ring Offset Color
       * @see https://tailwindcss.com/docs/ring-offset-color
       */
      "ring-offset-color": [{
        "ring-offset": [colors]
      }],
      // Effects
      /**
       * Box Shadow
       * @see https://tailwindcss.com/docs/box-shadow
       */
      shadow: [{
        shadow: ["", "inner", "none", isTshirtSize, isArbitraryShadow]
      }],
      /**
       * Box Shadow Color
       * @see https://tailwindcss.com/docs/box-shadow-color
       */
      "shadow-color": [{
        shadow: [isAny]
      }],
      /**
       * Opacity
       * @see https://tailwindcss.com/docs/opacity
       */
      opacity: [{
        opacity: [opacity]
      }],
      /**
       * Mix Blend Mode
       * @see https://tailwindcss.com/docs/mix-blend-mode
       */
      "mix-blend": [{
        "mix-blend": [...getBlendModes(), "plus-lighter", "plus-darker"]
      }],
      /**
       * Background Blend Mode
       * @see https://tailwindcss.com/docs/background-blend-mode
       */
      "bg-blend": [{
        "bg-blend": getBlendModes()
      }],
      // Filters
      /**
       * Filter
       * @deprecated since Tailwind CSS v3.0.0
       * @see https://tailwindcss.com/docs/filter
       */
      filter: [{
        filter: ["", "none"]
      }],
      /**
       * Blur
       * @see https://tailwindcss.com/docs/blur
       */
      blur: [{
        blur: [blur]
      }],
      /**
       * Brightness
       * @see https://tailwindcss.com/docs/brightness
       */
      brightness: [{
        brightness: [brightness]
      }],
      /**
       * Contrast
       * @see https://tailwindcss.com/docs/contrast
       */
      contrast: [{
        contrast: [contrast]
      }],
      /**
       * Drop Shadow
       * @see https://tailwindcss.com/docs/drop-shadow
       */
      "drop-shadow": [{
        "drop-shadow": ["", "none", isTshirtSize, isArbitraryValue]
      }],
      /**
       * Grayscale
       * @see https://tailwindcss.com/docs/grayscale
       */
      grayscale: [{
        grayscale: [grayscale]
      }],
      /**
       * Hue Rotate
       * @see https://tailwindcss.com/docs/hue-rotate
       */
      "hue-rotate": [{
        "hue-rotate": [hueRotate]
      }],
      /**
       * Invert
       * @see https://tailwindcss.com/docs/invert
       */
      invert: [{
        invert: [invert]
      }],
      /**
       * Saturate
       * @see https://tailwindcss.com/docs/saturate
       */
      saturate: [{
        saturate: [saturate]
      }],
      /**
       * Sepia
       * @see https://tailwindcss.com/docs/sepia
       */
      sepia: [{
        sepia: [sepia]
      }],
      /**
       * Backdrop Filter
       * @deprecated since Tailwind CSS v3.0.0
       * @see https://tailwindcss.com/docs/backdrop-filter
       */
      "backdrop-filter": [{
        "backdrop-filter": ["", "none"]
      }],
      /**
       * Backdrop Blur
       * @see https://tailwindcss.com/docs/backdrop-blur
       */
      "backdrop-blur": [{
        "backdrop-blur": [blur]
      }],
      /**
       * Backdrop Brightness
       * @see https://tailwindcss.com/docs/backdrop-brightness
       */
      "backdrop-brightness": [{
        "backdrop-brightness": [brightness]
      }],
      /**
       * Backdrop Contrast
       * @see https://tailwindcss.com/docs/backdrop-contrast
       */
      "backdrop-contrast": [{
        "backdrop-contrast": [contrast]
      }],
      /**
       * Backdrop Grayscale
       * @see https://tailwindcss.com/docs/backdrop-grayscale
       */
      "backdrop-grayscale": [{
        "backdrop-grayscale": [grayscale]
      }],
      /**
       * Backdrop Hue Rotate
       * @see https://tailwindcss.com/docs/backdrop-hue-rotate
       */
      "backdrop-hue-rotate": [{
        "backdrop-hue-rotate": [hueRotate]
      }],
      /**
       * Backdrop Invert
       * @see https://tailwindcss.com/docs/backdrop-invert
       */
      "backdrop-invert": [{
        "backdrop-invert": [invert]
      }],
      /**
       * Backdrop Opacity
       * @see https://tailwindcss.com/docs/backdrop-opacity
       */
      "backdrop-opacity": [{
        "backdrop-opacity": [opacity]
      }],
      /**
       * Backdrop Saturate
       * @see https://tailwindcss.com/docs/backdrop-saturate
       */
      "backdrop-saturate": [{
        "backdrop-saturate": [saturate]
      }],
      /**
       * Backdrop Sepia
       * @see https://tailwindcss.com/docs/backdrop-sepia
       */
      "backdrop-sepia": [{
        "backdrop-sepia": [sepia]
      }],
      // Tables
      /**
       * Border Collapse
       * @see https://tailwindcss.com/docs/border-collapse
       */
      "border-collapse": [{
        border: ["collapse", "separate"]
      }],
      /**
       * Border Spacing
       * @see https://tailwindcss.com/docs/border-spacing
       */
      "border-spacing": [{
        "border-spacing": [borderSpacing]
      }],
      /**
       * Border Spacing X
       * @see https://tailwindcss.com/docs/border-spacing
       */
      "border-spacing-x": [{
        "border-spacing-x": [borderSpacing]
      }],
      /**
       * Border Spacing Y
       * @see https://tailwindcss.com/docs/border-spacing
       */
      "border-spacing-y": [{
        "border-spacing-y": [borderSpacing]
      }],
      /**
       * Table Layout
       * @see https://tailwindcss.com/docs/table-layout
       */
      "table-layout": [{
        table: ["auto", "fixed"]
      }],
      /**
       * Caption Side
       * @see https://tailwindcss.com/docs/caption-side
       */
      caption: [{
        caption: ["top", "bottom"]
      }],
      // Transitions and Animation
      /**
       * Tranisition Property
       * @see https://tailwindcss.com/docs/transition-property
       */
      transition: [{
        transition: ["none", "all", "", "colors", "opacity", "shadow", "transform", isArbitraryValue]
      }],
      /**
       * Transition Duration
       * @see https://tailwindcss.com/docs/transition-duration
       */
      duration: [{
        duration: getNumberAndArbitrary()
      }],
      /**
       * Transition Timing Function
       * @see https://tailwindcss.com/docs/transition-timing-function
       */
      ease: [{
        ease: ["linear", "in", "out", "in-out", isArbitraryValue]
      }],
      /**
       * Transition Delay
       * @see https://tailwindcss.com/docs/transition-delay
       */
      delay: [{
        delay: getNumberAndArbitrary()
      }],
      /**
       * Animation
       * @see https://tailwindcss.com/docs/animation
       */
      animate: [{
        animate: ["none", "spin", "ping", "pulse", "bounce", isArbitraryValue]
      }],
      // Transforms
      /**
       * Transform
       * @see https://tailwindcss.com/docs/transform
       */
      transform: [{
        transform: ["", "gpu", "none"]
      }],
      /**
       * Scale
       * @see https://tailwindcss.com/docs/scale
       */
      scale: [{
        scale: [scale]
      }],
      /**
       * Scale X
       * @see https://tailwindcss.com/docs/scale
       */
      "scale-x": [{
        "scale-x": [scale]
      }],
      /**
       * Scale Y
       * @see https://tailwindcss.com/docs/scale
       */
      "scale-y": [{
        "scale-y": [scale]
      }],
      /**
       * Rotate
       * @see https://tailwindcss.com/docs/rotate
       */
      rotate: [{
        rotate: [isInteger, isArbitraryValue]
      }],
      /**
       * Translate X
       * @see https://tailwindcss.com/docs/translate
       */
      "translate-x": [{
        "translate-x": [translate]
      }],
      /**
       * Translate Y
       * @see https://tailwindcss.com/docs/translate
       */
      "translate-y": [{
        "translate-y": [translate]
      }],
      /**
       * Skew X
       * @see https://tailwindcss.com/docs/skew
       */
      "skew-x": [{
        "skew-x": [skew]
      }],
      /**
       * Skew Y
       * @see https://tailwindcss.com/docs/skew
       */
      "skew-y": [{
        "skew-y": [skew]
      }],
      /**
       * Transform Origin
       * @see https://tailwindcss.com/docs/transform-origin
       */
      "transform-origin": [{
        origin: ["center", "top", "top-right", "right", "bottom-right", "bottom", "bottom-left", "left", "top-left", isArbitraryValue]
      }],
      // Interactivity
      /**
       * Accent Color
       * @see https://tailwindcss.com/docs/accent-color
       */
      accent: [{
        accent: ["auto", colors]
      }],
      /**
       * Appearance
       * @see https://tailwindcss.com/docs/appearance
       */
      appearance: [{
        appearance: ["none", "auto"]
      }],
      /**
       * Cursor
       * @see https://tailwindcss.com/docs/cursor
       */
      cursor: [{
        cursor: ["auto", "default", "pointer", "wait", "text", "move", "help", "not-allowed", "none", "context-menu", "progress", "cell", "crosshair", "vertical-text", "alias", "copy", "no-drop", "grab", "grabbing", "all-scroll", "col-resize", "row-resize", "n-resize", "e-resize", "s-resize", "w-resize", "ne-resize", "nw-resize", "se-resize", "sw-resize", "ew-resize", "ns-resize", "nesw-resize", "nwse-resize", "zoom-in", "zoom-out", isArbitraryValue]
      }],
      /**
       * Caret Color
       * @see https://tailwindcss.com/docs/just-in-time-mode#caret-color-utilities
       */
      "caret-color": [{
        caret: [colors]
      }],
      /**
       * Pointer Events
       * @see https://tailwindcss.com/docs/pointer-events
       */
      "pointer-events": [{
        "pointer-events": ["none", "auto"]
      }],
      /**
       * Resize
       * @see https://tailwindcss.com/docs/resize
       */
      resize: [{
        resize: ["none", "y", "x", ""]
      }],
      /**
       * Scroll Behavior
       * @see https://tailwindcss.com/docs/scroll-behavior
       */
      "scroll-behavior": [{
        scroll: ["auto", "smooth"]
      }],
      /**
       * Scroll Margin
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-m": [{
        "scroll-m": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Margin X
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-mx": [{
        "scroll-mx": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Margin Y
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-my": [{
        "scroll-my": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Margin Start
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-ms": [{
        "scroll-ms": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Margin End
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-me": [{
        "scroll-me": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Margin Top
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-mt": [{
        "scroll-mt": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Margin Right
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-mr": [{
        "scroll-mr": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Margin Bottom
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-mb": [{
        "scroll-mb": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Margin Left
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-ml": [{
        "scroll-ml": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Padding
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-p": [{
        "scroll-p": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Padding X
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-px": [{
        "scroll-px": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Padding Y
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-py": [{
        "scroll-py": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Padding Start
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-ps": [{
        "scroll-ps": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Padding End
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-pe": [{
        "scroll-pe": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Padding Top
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-pt": [{
        "scroll-pt": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Padding Right
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-pr": [{
        "scroll-pr": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Padding Bottom
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-pb": [{
        "scroll-pb": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Padding Left
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-pl": [{
        "scroll-pl": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Snap Align
       * @see https://tailwindcss.com/docs/scroll-snap-align
       */
      "snap-align": [{
        snap: ["start", "end", "center", "align-none"]
      }],
      /**
       * Scroll Snap Stop
       * @see https://tailwindcss.com/docs/scroll-snap-stop
       */
      "snap-stop": [{
        snap: ["normal", "always"]
      }],
      /**
       * Scroll Snap Type
       * @see https://tailwindcss.com/docs/scroll-snap-type
       */
      "snap-type": [{
        snap: ["none", "x", "y", "both"]
      }],
      /**
       * Scroll Snap Type Strictness
       * @see https://tailwindcss.com/docs/scroll-snap-type
       */
      "snap-strictness": [{
        snap: ["mandatory", "proximity"]
      }],
      /**
       * Touch Action
       * @see https://tailwindcss.com/docs/touch-action
       */
      touch: [{
        touch: ["auto", "none", "manipulation"]
      }],
      /**
       * Touch Action X
       * @see https://tailwindcss.com/docs/touch-action
       */
      "touch-x": [{
        "touch-pan": ["x", "left", "right"]
      }],
      /**
       * Touch Action Y
       * @see https://tailwindcss.com/docs/touch-action
       */
      "touch-y": [{
        "touch-pan": ["y", "up", "down"]
      }],
      /**
       * Touch Action Pinch Zoom
       * @see https://tailwindcss.com/docs/touch-action
       */
      "touch-pz": ["touch-pinch-zoom"],
      /**
       * User Select
       * @see https://tailwindcss.com/docs/user-select
       */
      select: [{
        select: ["none", "text", "all", "auto"]
      }],
      /**
       * Will Change
       * @see https://tailwindcss.com/docs/will-change
       */
      "will-change": [{
        "will-change": ["auto", "scroll", "contents", "transform", isArbitraryValue]
      }],
      // SVG
      /**
       * Fill
       * @see https://tailwindcss.com/docs/fill
       */
      fill: [{
        fill: [colors, "none"]
      }],
      /**
       * Stroke Width
       * @see https://tailwindcss.com/docs/stroke-width
       */
      "stroke-w": [{
        stroke: [isLength, isArbitraryLength, isArbitraryNumber]
      }],
      /**
       * Stroke
       * @see https://tailwindcss.com/docs/stroke
       */
      stroke: [{
        stroke: [colors, "none"]
      }],
      // Accessibility
      /**
       * Screen Readers
       * @see https://tailwindcss.com/docs/screen-readers
       */
      sr: ["sr-only", "not-sr-only"],
      /**
       * Forced Color Adjust
       * @see https://tailwindcss.com/docs/forced-color-adjust
       */
      "forced-color-adjust": [{
        "forced-color-adjust": ["auto", "none"]
      }]
    },
    conflictingClassGroups: {
      overflow: ["overflow-x", "overflow-y"],
      overscroll: ["overscroll-x", "overscroll-y"],
      inset: ["inset-x", "inset-y", "start", "end", "top", "right", "bottom", "left"],
      "inset-x": ["right", "left"],
      "inset-y": ["top", "bottom"],
      flex: ["basis", "grow", "shrink"],
      gap: ["gap-x", "gap-y"],
      p: ["px", "py", "ps", "pe", "pt", "pr", "pb", "pl"],
      px: ["pr", "pl"],
      py: ["pt", "pb"],
      m: ["mx", "my", "ms", "me", "mt", "mr", "mb", "ml"],
      mx: ["mr", "ml"],
      my: ["mt", "mb"],
      size: ["w", "h"],
      "font-size": ["leading"],
      "fvn-normal": ["fvn-ordinal", "fvn-slashed-zero", "fvn-figure", "fvn-spacing", "fvn-fraction"],
      "fvn-ordinal": ["fvn-normal"],
      "fvn-slashed-zero": ["fvn-normal"],
      "fvn-figure": ["fvn-normal"],
      "fvn-spacing": ["fvn-normal"],
      "fvn-fraction": ["fvn-normal"],
      "line-clamp": ["display", "overflow"],
      rounded: ["rounded-s", "rounded-e", "rounded-t", "rounded-r", "rounded-b", "rounded-l", "rounded-ss", "rounded-se", "rounded-ee", "rounded-es", "rounded-tl", "rounded-tr", "rounded-br", "rounded-bl"],
      "rounded-s": ["rounded-ss", "rounded-es"],
      "rounded-e": ["rounded-se", "rounded-ee"],
      "rounded-t": ["rounded-tl", "rounded-tr"],
      "rounded-r": ["rounded-tr", "rounded-br"],
      "rounded-b": ["rounded-br", "rounded-bl"],
      "rounded-l": ["rounded-tl", "rounded-bl"],
      "border-spacing": ["border-spacing-x", "border-spacing-y"],
      "border-w": ["border-w-s", "border-w-e", "border-w-t", "border-w-r", "border-w-b", "border-w-l"],
      "border-w-x": ["border-w-r", "border-w-l"],
      "border-w-y": ["border-w-t", "border-w-b"],
      "border-color": ["border-color-s", "border-color-e", "border-color-t", "border-color-r", "border-color-b", "border-color-l"],
      "border-color-x": ["border-color-r", "border-color-l"],
      "border-color-y": ["border-color-t", "border-color-b"],
      "scroll-m": ["scroll-mx", "scroll-my", "scroll-ms", "scroll-me", "scroll-mt", "scroll-mr", "scroll-mb", "scroll-ml"],
      "scroll-mx": ["scroll-mr", "scroll-ml"],
      "scroll-my": ["scroll-mt", "scroll-mb"],
      "scroll-p": ["scroll-px", "scroll-py", "scroll-ps", "scroll-pe", "scroll-pt", "scroll-pr", "scroll-pb", "scroll-pl"],
      "scroll-px": ["scroll-pr", "scroll-pl"],
      "scroll-py": ["scroll-pt", "scroll-pb"],
      touch: ["touch-x", "touch-y", "touch-pz"],
      "touch-x": ["touch"],
      "touch-y": ["touch"],
      "touch-pz": ["touch"]
    },
    conflictingClassGroupModifiers: {
      "font-size": ["leading"]
    }
  };
};
var twMerge = /* @__PURE__ */ createTailwindMerge(getDefaultConfig);

// src/lib/utils.ts
function cn(...inputs) {
  return twMerge(clsx(inputs));
}

// src/core/viewportDesktopSite.ts
var MOBILE_DESKTOP_SITE_KEY = "copanel_mobile_desktop_site";
function isMobileDesktopSiteEnabled() {
  try {
    return localStorage.getItem(MOBILE_DESKTOP_SITE_KEY) === "1";
  } catch {
    return false;
  }
}
function isLayoutViewportWide(innerWidth = window.innerWidth) {
  return isMobileDesktopSiteEnabled() || innerWidth >= 1024;
}

// src/core/shell/WindowViewportContext.tsx
import { createContext as createContext2, useContext as useContext2, useRef } from "react";
import { jsx as jsx2 } from "react/jsx-runtime";
var WindowViewportContext = createContext2(null);
function useWindowViewport() {
  return useContext2(WindowViewportContext);
}
function useIsWindowedModule() {
  return useWindowViewport()?.isWindowed === true;
}

// src/core/shell/ModuleViewport.tsx
import { jsx as jsx3 } from "react/jsx-runtime";
function ModuleViewport({ children, className, constrained = false }) {
  const { theme } = useAppShellContext();
  const isWindowed = useIsWindowedModule();
  const isDark = theme === "dark";
  const isClassicMobile = !isWindowed && !isLayoutViewportWide();
  return /* @__PURE__ */ jsx3(
    "div",
    {
      className: cn(
        "flex flex-col transition-colors duration-200",
        isWindowed ? "h-full min-h-0" : isClassicMobile ? "min-h-0" : "min-h-screen",
        isDark ? "bg-slate-950 text-slate-100" : "bg-slate-50 text-slate-900",
        !isWindowed && constrained && "mx-auto max-w-7xl",
        className
      ),
      children
    }
  );
}

// src/core/shell/ModuleSidebarLayout.tsx
import { useEffect, useState } from "react";
import * as Icons from "lucide-react";
import { jsx as jsx4, jsxs } from "react/jsx-runtime";
function ModuleSidebarLayout({
  isDark,
  sidebar,
  children,
  mobileTitle,
  className
}) {
  const isWindowed = useIsWindowedModule();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [viewportWide, setViewportWide] = useState(() => isLayoutViewportWide());
  useEffect(() => {
    const onResize = () => setViewportWide(isLayoutViewportWide());
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  }, []);
  const useDrawer = !isWindowed && !viewportWide;
  useEffect(() => {
    if (viewportWide) setSidebarOpen(false);
  }, [viewportWide]);
  const closeSidebar = () => setSidebarOpen(false);
  if (!useDrawer) {
    return /* @__PURE__ */ jsxs("div", { className: cn("flex h-full min-h-0 flex-1 overflow-hidden", className), children: [
      sidebar,
      /* @__PURE__ */ jsx4("div", { className: "flex min-h-0 min-w-0 flex-1 flex-col overflow-hidden", children })
    ] });
  }
  return /* @__PURE__ */ jsxs("div", { className: cn("relative flex h-full min-h-0 flex-1 flex-col overflow-hidden", className), children: [
    /* @__PURE__ */ jsxs(
      "div",
      {
        className: cn(
          "flex shrink-0 items-center gap-2 border-b px-3 py-2.5",
          isDark ? "border-slate-800 bg-slate-950/90" : "border-slate-200 bg-white"
        ),
        children: [
          /* @__PURE__ */ jsx4(
            "button",
            {
              type: "button",
              onClick: () => setSidebarOpen(true),
              className: cn(
                "inline-flex items-center justify-center rounded-lg p-2",
                isDark ? "text-slate-200 hover:bg-slate-800" : "text-slate-700 hover:bg-slate-100"
              ),
              "aria-label": "Open module menu",
              children: /* @__PURE__ */ jsx4(Icons.PanelLeft, { className: "h-5 w-5" })
            }
          ),
          mobileTitle ? /* @__PURE__ */ jsx4("span", { className: cn("truncate text-sm font-semibold", isDark ? "text-slate-100" : "text-slate-900"), children: mobileTitle }) : null
        ]
      }
    ),
    sidebarOpen ? /* @__PURE__ */ jsx4(
      "button",
      {
        type: "button",
        className: "fixed inset-0 z-[60] bg-black/45",
        "aria-label": "Close module menu",
        onClick: closeSidebar
      }
    ) : null,
    /* @__PURE__ */ jsx4(
      "div",
      {
        className: cn(
          "fixed inset-y-0 left-0 z-[61] flex max-w-[min(85vw,280px)] transform shadow-xl transition-transform duration-200 ease-out",
          sidebarOpen ? "translate-x-0" : "-translate-x-full pointer-events-none"
        ),
        onClick: closeSidebar,
        children: sidebar
      }
    ),
    /* @__PURE__ */ jsx4("div", { className: "flex min-h-0 min-w-0 flex-1 flex-col overflow-hidden", children })
  ] });
}

// src/core/shell/WindowModal.tsx
import { createPortal } from "react-dom";
import * as Icons2 from "lucide-react";
import { jsx as jsx5, jsxs as jsxs2 } from "react/jsx-runtime";
var MAX_W = {
  sm: "max-w-sm",
  md: "max-w-md",
  lg: "max-w-lg",
  xl: "max-w-xl",
  "2xl": "max-w-2xl",
  "4xl": "max-w-4xl",
  "5xl": "max-w-5xl"
};
function WindowModal({
  open,
  onClose,
  children,
  title,
  className,
  maxWidth = "lg",
  closeOnBackdropClick = true
}) {
  const { theme } = useAppShellContext();
  const isDark = theme === "dark";
  const viewport = useWindowViewport();
  if (!open) return null;
  const overlay = /* @__PURE__ */ jsx5(
    "div",
    {
      className: cn(
        "z-[80] flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm",
        viewport?.isWindowed ? "absolute inset-0" : "fixed inset-0"
      ),
      onClick: closeOnBackdropClick ? onClose : void 0,
      children: /* @__PURE__ */ jsxs2(
        "div",
        {
          className: cn(
            "flex w-full flex-col overflow-hidden rounded-2xl border shadow-2xl",
            MAX_W[maxWidth],
            isDark ? "border-slate-700 bg-slate-900 text-slate-100" : "border-slate-200 bg-white text-slate-900",
            className
          ),
          onClick: (e) => e.stopPropagation(),
          children: [
            title && /* @__PURE__ */ jsxs2(
              "div",
              {
                className: cn(
                  "flex items-center justify-between border-b px-4 py-3",
                  isDark ? "border-slate-800" : "border-slate-200"
                ),
                children: [
                  /* @__PURE__ */ jsx5("h3", { className: "text-sm font-bold", children: title }),
                  /* @__PURE__ */ jsx5("button", { type: "button", onClick: onClose, className: "rounded-lg p-1 hover:bg-slate-800/50", "aria-label": "Close", children: /* @__PURE__ */ jsx5(Icons2.X, { className: "h-4 w-4" }) })
                ]
              }
            ),
            children
          ]
        }
      )
    }
  );
  if (viewport?.isWindowed && viewport.viewportRef.current) {
    return createPortal(overlay, viewport.viewportRef.current);
  }
  return createPortal(overlay, document.body);
}

// src/modules/download_manager/index.tsx
import * as Icons3 from "lucide-react";

// src/core/platform/api.ts
var PlatformError = class extends Error {
  constructor(code, message, status, details) {
    super(message);
    __publicField(this, "code");
    __publicField(this, "status");
    __publicField(this, "details");
    this.code = code;
    this.status = status;
    this.details = details;
  }
};
async function api(path, opts = {}) {
  const token = typeof window !== "undefined" ? localStorage.getItem("copanel_token") : null;
  const headers = {
    "Content-Type": "application/json",
    ...opts.headers || {}
  };
  if (token) headers["Authorization"] = `Bearer ${token}`;
  const init = {
    method: opts.method || "GET",
    headers,
    signal: opts.signal
  };
  if (opts.body !== void 0) {
    init.body = typeof opts.body === "string" ? opts.body : JSON.stringify(opts.body);
  }
  const res = await fetch(path, init);
  let body = null;
  const text = await res.text();
  if (text) {
    try {
      body = JSON.parse(text);
    } catch {
      body = text;
    }
  }
  if (opts.raw) {
    return body;
  }
  if (!res.ok) {
    const err = body && typeof body === "object" && body.error ? body.error : { code: `HTTP_${res.status}`, message: typeof body === "string" ? body : body?.detail || res.statusText };
    throw new PlatformError(err.code || `HTTP_${res.status}`, err.message || "Request failed", res.status, err.details);
  }
  if (body && typeof body === "object" && "status" in body) {
    if (body.status === "success") {
      return body.data !== void 0 ? body.data : body;
    }
    if (body.status === "error" && body.error) {
      throw new PlatformError(body.error.code, body.error.message, res.status, body.error.details);
    }
  }
  return body;
}

// src/core/platform/events.ts
var PLATFORM_SSE_DEGRADED_EVENT = "copanel-platform-sse-degraded";
var MIN_RETRY_MS = 2e3;
var MAX_RETRY_MS = 6e4;
var POLL_FALLBACK_AFTER_FAILURES = 3;
var EventHub = class {
  constructor() {
    __publicField(this, "source", null);
    __publicField(this, "handlers", /* @__PURE__ */ new Map());
    __publicField(this, "retryDelay", MIN_RETRY_MS);
    __publicField(this, "retryTimer", null);
    __publicField(this, "failureCount", 0);
  }
  on(topic, handler) {
    let set = this.handlers.get(topic);
    if (!set) {
      set = /* @__PURE__ */ new Set();
      this.handlers.set(topic, set);
    }
    set.add(handler);
    this.ensureConnected();
    return () => {
      set.delete(handler);
      if (set.size === 0) {
        this.handlers.delete(topic);
      }
      this.teardownIfIdle();
    };
  }
  emit(topic, payload) {
    const set = this.handlers.get(topic);
    if (set) {
      set.forEach((h) => {
        try {
          h(payload);
        } catch (err) {
          console.error("event handler failed", topic, err);
        }
      });
    }
  }
  buildUrl() {
    const token = localStorage.getItem("copanel_token");
    if (!token) return null;
    const params = new URLSearchParams({
      topics: "jobs,notifications",
      access_token: token
    });
    return `/api/platform/events?${params.toString()}`;
  }
  ensureConnected() {
    if (this.source) return;
    if (typeof document !== "undefined" && document.hidden) return;
    const url = this.buildUrl();
    if (!url) return;
    try {
      this.source = new EventSource(url, { withCredentials: false });
    } catch {
      this.scheduleRetry();
      return;
    }
    this.source.addEventListener("open", () => {
      this.failureCount = 0;
      this.retryDelay = MIN_RETRY_MS;
    });
    this.source.addEventListener("jobs", (e) => {
      this.onStreamMessage();
      this.parseAndEmit("jobs", e.data);
    });
    this.source.addEventListener("notifications", (e) => {
      this.onStreamMessage();
      this.parseAndEmit("notifications", e.data);
    });
    this.source.addEventListener("message", () => {
      this.onStreamMessage();
    });
    this.source.onerror = () => {
      this.failureCount += 1;
      this.source?.close();
      this.source = null;
      if (this.failureCount >= POLL_FALLBACK_AFTER_FAILURES) {
        window.dispatchEvent(new CustomEvent(PLATFORM_SSE_DEGRADED_EVENT));
      }
      this.scheduleRetry();
    };
  }
  onStreamMessage() {
    this.failureCount = 0;
    this.retryDelay = MIN_RETRY_MS;
  }
  parseAndEmit(topic, raw) {
    try {
      const msg = JSON.parse(raw);
      this.emit(topic, msg.payload || msg);
    } catch {
    }
  }
  scheduleRetry() {
    if (this.retryTimer) return;
    if (this.handlers.size === 0) return;
    const delay = this.retryDelay;
    this.retryDelay = Math.min(Math.round(this.retryDelay * 1.8), MAX_RETRY_MS);
    this.retryTimer = setTimeout(() => {
      this.retryTimer = null;
      this.ensureConnected();
    }, delay);
  }
  teardownIfIdle() {
    if (this.handlers.size > 0) return;
    if (this.retryTimer) {
      clearTimeout(this.retryTimer);
      this.retryTimer = null;
    }
    if (this.source) {
      this.source.close();
      this.source = null;
    }
    this.failureCount = 0;
    this.retryDelay = MIN_RETRY_MS;
  }
  /** Drop the SSE connection and open a new one if handlers exist and a token is present. */
  reconnect() {
    if (this.source) {
      this.source.close();
      this.source = null;
    }
    if (this.retryTimer) {
      clearTimeout(this.retryTimer);
      this.retryTimer = null;
    }
    this.failureCount = 0;
    this.retryDelay = MIN_RETRY_MS;
    if (this.handlers.size > 0) {
      this.ensureConnected();
    }
  }
};
var events = new EventHub();
function reconnectPlatformEvents() {
  events.reconnect();
}
if (typeof document !== "undefined") {
  document.addEventListener("visibilitychange", () => {
    if (!document.hidden) {
      reconnectPlatformEvents();
    }
  });
}

// src/core/platform/store.ts
import { useEffect as useEffect2, useState as useState2 } from "react";
function createStore(initial) {
  let state = initial;
  const listeners = /* @__PURE__ */ new Set();
  return {
    getState: () => state,
    setState: (updater) => {
      const patch = typeof updater === "function" ? updater(state) : updater;
      if (!patch || Object.keys(patch).length === 0) return;
      let changed = false;
      for (const key of Object.keys(patch)) {
        if (state[key] !== patch[key]) {
          changed = true;
          break;
        }
      }
      if (!changed) return;
      state = { ...state, ...patch };
      listeners.forEach((l) => l());
    },
    subscribe: (listener) => {
      listeners.add(listener);
      return () => listeners.delete(listener);
    }
  };
}

// src/core/platform/jobsStore.ts
var store = createStore({ jobs: {}, order: [], lastFetch: 0 });
function getCurrentLang() {
  return localStorage.getItem("copanel_lang") === "vi" ? "vi" : "en";
}
function pickLocalizedFromValue(value, lang) {
  if (!value) return void 0;
  if (typeof value === "string") return value;
  if (typeof value === "object") return value[lang] || value.en || value.vi || value.default;
  return void 0;
}
function resolveLocalizedField(src, baseKey, lang) {
  if (!src || typeof src !== "object") return void 0;
  const direct = pickLocalizedFromValue(src[baseKey], lang);
  if (direct) return direct;
  const fromMap = pickLocalizedFromValue(src[`${baseKey}_i18n`], lang);
  if (fromMap) return fromMap;
  const fromLangSpecific = src[`${baseKey}_${lang}`];
  if (typeof fromLangSpecific === "string" && fromLangSpecific) return fromLangSpecific;
  const fallbackEn = src[`${baseKey}_en`];
  if (typeof fallbackEn === "string" && fallbackEn) return fallbackEn;
  const fallbackVi = src[`${baseKey}_vi`];
  if (typeof fallbackVi === "string" && fallbackVi) return fallbackVi;
  return void 0;
}
function localizeJob(raw) {
  const lang = getCurrentLang();
  const payload = raw?.payload && typeof raw.payload === "object" ? raw.payload : {};
  return {
    ...raw,
    title: resolveLocalizedField(raw, "title", lang) || resolveLocalizedField(payload, "title", lang) || raw?.title || "",
    message: resolveLocalizedField(raw, "message", lang) || resolveLocalizedField(payload, "message", lang) || raw?.message,
    error: resolveLocalizedField(raw, "error", lang) || resolveLocalizedField(payload, "error", lang) || raw?.error || null
  };
}
function upsert(job) {
  const localized = localizeJob(job);
  store.setState((s) => {
    const next = { ...s.jobs, [localized.id]: { ...s.jobs[localized.id], ...localized } };
    let order = s.order;
    if (!order.includes(localized.id)) {
      order = [localized.id, ...order].slice(0, 200);
    }
    return { jobs: next, order };
  });
}
events.on("jobs", (msg) => {
  if (msg?.job) {
    upsert(msg.job);
    return;
  }
  if (msg?.job_id && msg?.event === "update") {
    const existing = store.getState().jobs[msg.job_id];
    if (existing) {
      upsert({
        ...existing,
        progress: msg.progress ?? existing.progress,
        message: msg.message ?? existing.message,
        status: msg.status ?? existing.status
      });
    }
  }
});

// src/core/platform/notificationsStore.ts
var store2 = createStore({ inbox: [], unread: 0, toasts: [] });
var TOAST_TTL_MS = 6e3;
function getCurrentLang2() {
  return localStorage.getItem("copanel_lang") === "vi" ? "vi" : "en";
}
function pickLocalizedFromValue2(value, lang) {
  if (!value) return void 0;
  if (typeof value === "string") return value;
  if (typeof value === "object") {
    return value[lang] || value.en || value.vi || value.default;
  }
  return void 0;
}
function resolveLocalizedField2(src, baseKey, lang) {
  if (!src || typeof src !== "object") return void 0;
  const direct = pickLocalizedFromValue2(src[baseKey], lang);
  if (direct) return direct;
  const fromMap = pickLocalizedFromValue2(src[`${baseKey}_i18n`], lang);
  if (fromMap) return fromMap;
  const fromLangSpecific = src[`${baseKey}_${lang}`];
  if (typeof fromLangSpecific === "string" && fromLangSpecific) return fromLangSpecific;
  const fallbackEn = src[`${baseKey}_en`];
  if (typeof fallbackEn === "string" && fallbackEn) return fallbackEn;
  const fallbackVi = src[`${baseKey}_vi`];
  if (typeof fallbackVi === "string" && fallbackVi) return fallbackVi;
  return void 0;
}
function localizeNotification(raw) {
  const lang = getCurrentLang2();
  const payload = raw?.payload && typeof raw.payload === "object" ? raw.payload : {};
  const title = resolveLocalizedField2(raw, "title", lang) || resolveLocalizedField2(payload, "title", lang) || (raw?.title || "");
  const body = resolveLocalizedField2(raw, "body", lang) || resolveLocalizedField2(payload, "body", lang) || raw?.body || null;
  return {
    ...raw,
    title,
    body
  };
}
function pushToast(t) {
  store2.setState((s) => ({ toasts: [t, ...s.toasts].slice(0, 6) }));
  if (t.ephemeral !== false) {
    setTimeout(() => {
      store2.setState((s) => ({ toasts: s.toasts.filter((x) => x.id !== t.id) }));
    }, TOAST_TTL_MS);
  }
}
events.on("notifications", (msg) => {
  if (msg?.event === "new" && msg.notification) {
    const n = localizeNotification(msg.notification);
    pushToast({ ...n, ephemeral: true });
    store2.setState((s) => ({
      inbox: [n, ...s.inbox].slice(0, 200),
      unread: s.unread + 1
    }));
  }
});

// src/modules/download_manager/index.tsx
import { Fragment, jsx as jsx6, jsxs as jsxs3 } from "react/jsx-runtime";
var FILTERS = [
  { key: "all", icon: "List" },
  { key: "downloading", icon: "Download" },
  { key: "completed", icon: "CheckCircle2" },
  { key: "active", icon: "Activity" },
  { key: "inactive", icon: "PauseCircle" },
  { key: "stopped", icon: "Square" }
];
function fmtBytes(n) {
  if (!n || n < 0) return "\u2014";
  const units = ["B", "KB", "MB", "GB", "TB"];
  let v = n;
  let i = 0;
  while (v >= 1024 && i < units.length - 1) {
    v /= 1024;
    i += 1;
  }
  return `${v.toFixed(i === 0 ? 0 : 2)} ${units[i]}`;
}
function fmtSpeed(bps) {
  if (!bps) return "\u2014";
  return `${fmtBytes(bps)}/s`;
}
function statusColor(status) {
  switch (status) {
    case "completed":
      return "text-emerald-500";
    case "downloading":
    case "connecting":
      return "text-blue-500";
    case "paused":
    case "stopped":
      return "text-amber-500";
    case "error":
      return "text-red-500";
    default:
      return "text-slate-500";
  }
}
function StatusIcon({ status }) {
  if (status === "completed") return /* @__PURE__ */ jsx6(Icons3.CheckCircle2, { className: "w-4 h-4 text-emerald-500" });
  if (status === "downloading" || status === "connecting")
    return /* @__PURE__ */ jsx6(Icons3.Loader2, { className: "w-4 h-4 text-blue-500 animate-spin" });
  if (status === "paused" || status === "stopped") return /* @__PURE__ */ jsx6(Icons3.PauseCircle, { className: "w-4 h-4 text-amber-500" });
  if (status === "error") return /* @__PURE__ */ jsx6(Icons3.AlertCircle, { className: "w-4 h-4 text-red-500" });
  return /* @__PURE__ */ jsx6(Icons3.Clock, { className: "w-4 h-4 text-slate-400" });
}
function DownloadManager() {
  const { theme, language } = useAppShellContext();
  const isDark = theme === "dark";
  const t = useMemo(
    () => language === "vi" ? {
      title: "Download Manager",
      subtitle: "Direct link, Google Drive, file hosting t\xF9y ch\u1EC9nh",
      search: "T\u1EEB kh\xF3a ho\u1EB7c URL",
      addUrl: "Th\xEAm URL",
      pause: "T\u1EA1m d\u1EEBng",
      resume: "Ti\u1EBFp t\u1EE5c",
      stop: "D\u1EEBng",
      delete: "X\xF3a",
      clearCompleted: "X\xF3a ho\xE0n t\u1EA5t",
      settings: "C\xE0i \u0111\u1EB7t",
      noTasks: "Ch\u01B0a c\xF3 t\xE1c v\u1EE5 t\u1EA3i.",
      colName: "T\xEAn t\u1EC7p",
      colSize: "K\xEDch th\u01B0\u1EDBc",
      colDownloaded: "\u0110\xE3 t\u1EA3i",
      colProgress: "Ti\u1EBFn \u0111\u1ED9",
      colSpeed: "T\u1ED1c \u0111\u1ED9 t\u1EA3i",
      colStatus: "Tr\u1EA1ng th\xE1i",
      colDest: "\u0110\xEDch",
      tabGeneral: "Chung",
      tabTransfer: "Truy\u1EC1n t\u1EA3i",
      filterAll: "T\u1EA5t c\u1EA3",
      filterDownloading: "\u0110ang t\u1EA3i",
      filterCompleted: "Ho\xE0n t\u1EA5t",
      filterActive: "\u0110ang ho\u1EA1t \u0111\u1ED9ng",
      filterInactive: "Kh\xF4ng ho\u1EA1t \u0111\u1ED9ng",
      filterStopped: "\u0110\xE3 d\u1EEBng",
      tempFolder: "Th\u01B0 m\u1EE5c t\u1EA1m",
      destFolder: "Th\u01B0 m\u1EE5c \u0111\xEDch",
      maxConcurrent: "T\u1EA3i \u0111\u1ED3ng th\u1EDDi t\u1ED1i \u0111a",
      watchedFolder: "Th\u01B0 m\u1EE5c theo d\xF5i torrent/NZB",
      watchedAutoDelete: "X\xF3a file torrent sau khi n\u1EA1p",
      googleApiKey: "Google API Key (folder listing)",
      fileHosting: "File Hosting",
      addHosting: "Th\xEAm hosting",
      curlTemplate: "M\u1EABu curl",
      apiResolve: "API resolve URL",
      urlPatterns: "M\u1EABu URL (m\u1ED7i d\xF2ng m\u1ED9t pattern)",
      save: "L\u01B0u",
      cancel: "H\u1EE7y",
      add: "Th\xEAm",
      urlPlaceholder: "https://... ho\u1EB7c link Google Drive",
      selectFolder: "Ch\u1ECDn",
      accounts: "T\xE0i kho\u1EA3n",
      addAccount: "Th\xEAm t\xE0i kho\u1EA3n",
      uploadTorrent: "T\u1EA3i l\xEAn .torrent",
      aria2Status: "aria2",
      speedDown: "T\u1ED1c \u0111\u1ED9 t\u1EA3i t\u1ED1i \u0111a (KB/s, 0=kh\xF4ng gi\u1EDBi h\u1EA1n)",
      speedUp: "T\u1ED1c \u0111\u1ED9 upload t\u1ED1i \u0111a (KB/s, 0=kh\xF4ng gi\u1EDBi h\u1EA1n)",
      googleOAuth: "Google OAuth",
      connectGoogle: "K\u1EBFt n\u1ED1i Google Drive",
      oauthClientId: "OAuth Client ID",
      oauthClientSecret: "OAuth Client Secret",
      oauthRedirect: "Redirect URI",
      aria2Rpc: "aria2 RPC",
      aria2Host: "RPC host",
      aria2Port: "RPC port",
      aria2Secret: "RPC secret",
      aria2AutoStart: "T\u1EF1 kh\u1EDFi \u0111\u1ED9ng aria2 khi m\u1EDF panel",
      aria2AutoStartHint: "CoPanel t\u1EF1 ch\u1EA1y aria2c v\u1EDBi RPC tr\xEAn localhost (c\u1EA7n cho BitTorrent).",
      manageAccounts: "Qu\u1EA3n l\xFD t\xE0i kho\u1EA3n",
      accountLabel: "Nh\xE3n",
      accountUser: "T\xEAn \u0111\u0103ng nh\u1EADp",
      accountPass: "M\u1EADt kh\u1EA9u",
      accountApiKey: "API key",
      accountCookie: "Cookie"
    } : {
      title: "Download Manager",
      subtitle: "Direct links, Google Drive, custom file hosting",
      search: "Keyword or URL",
      addUrl: "Add URL",
      pause: "Pause",
      resume: "Resume",
      stop: "Stop",
      delete: "Delete",
      clearCompleted: "Clear completed",
      settings: "Settings",
      noTasks: "No download tasks yet.",
      colName: "File name",
      colSize: "File size",
      colDownloaded: "Downloaded",
      colProgress: "Progress",
      colSpeed: "Download speed",
      colStatus: "Status",
      colDest: "Destination",
      tabGeneral: "General",
      tabTransfer: "Transfer",
      filterAll: "All Downloads",
      filterDownloading: "Downloading",
      filterCompleted: "Completed",
      filterActive: "Active",
      filterInactive: "Inactive",
      filterStopped: "Stopped",
      tempFolder: "Temporary location",
      destFolder: "Default destination",
      maxConcurrent: "Max concurrent downloads",
      watchedFolder: "Torrent/NZB watched folder",
      watchedAutoDelete: "Delete loaded torrent/NZB files",
      googleApiKey: "Google API Key (folder listing)",
      fileHosting: "File Hosting",
      addHosting: "Add hosting",
      curlTemplate: "curl template",
      apiResolve: "API resolve URL",
      urlPatterns: "URL patterns (one per line)",
      save: "Save",
      cancel: "Cancel",
      add: "Add",
      urlPlaceholder: "https://... or Google Drive link",
      selectFolder: "Browse",
      accounts: "Accounts",
      addAccount: "Add account",
      uploadTorrent: "Upload .torrent",
      aria2Status: "aria2",
      speedDown: "Max download (KB/s, 0=unlimited)",
      speedUp: "Max upload (KB/s, 0=unlimited)",
      googleOAuth: "Google OAuth",
      connectGoogle: "Connect Google Drive",
      oauthClientId: "OAuth Client ID",
      oauthClientSecret: "OAuth Client Secret",
      oauthRedirect: "Redirect URI",
      aria2Rpc: "aria2 RPC",
      aria2Host: "RPC host",
      aria2Port: "RPC port",
      aria2Secret: "RPC secret",
      aria2AutoStart: "Auto-start aria2 on panel load",
      aria2AutoStartHint: "CoPanel starts aria2c with RPC on localhost when BitTorrent support is needed.",
      manageAccounts: "Manage accounts",
      accountLabel: "Label",
      accountUser: "Username",
      accountPass: "Password",
      accountApiKey: "API key",
      accountCookie: "Cookie"
    },
    [language]
  );
  const filterLabels = {
    all: t.filterAll,
    downloading: t.filterDownloading,
    completed: t.filterCompleted,
    active: t.filterActive,
    inactive: t.filterInactive,
    stopped: t.filterStopped
  };
  const [filter, setFilter] = useState3("all");
  const [search, setSearch] = useState3("");
  const [tasks, setTasks] = useState3([]);
  const [selectedId, setSelectedId] = useState3(null);
  const [detailTab, setDetailTab] = useState3("general");
  const [loading, setLoading] = useState3(true);
  const [error, setError] = useState3(null);
  const [addOpen, setAddOpen] = useState3(false);
  const [addUrl, setAddUrl] = useState3("");
  const [detected, setDetected] = useState3(null);
  const [settingsOpen, setSettingsOpen] = useState3(false);
  const [settingsTab, setSettingsTab] = useState3("general");
  const [settings, setSettings] = useState3(null);
  const [settingsDraft, setSettingsDraft] = useState3({});
  const [hosting, setHosting] = useState3([]);
  const [hostingDraft, setHostingDraft] = useState3(null);
  const [accountDraft, setAccountDraft] = useState3(null);
  const [engineStatus, setEngineStatus] = useState3(null);
  const [oauthStatus, setOauthStatus] = useState3(null);
  const [oauthClientId, setOauthClientId] = useState3("");
  const [oauthClientSecret, setOauthClientSecret] = useState3("");
  const [oauthRedirect, setOauthRedirect] = useState3(`${typeof window !== "undefined" ? window.location.origin : ""}/api/download_manager/oauth/google/callback`);
  const torrentInputRef = useRef2(null);
  const [folderBrowse, setFolderBrowse] = useState3(null);
  const [folderTarget, setFolderTarget] = useState3(null);
  const selected = tasks.find((x) => x.id === selectedId) || null;
  const loadTasks = useCallback(async () => {
    try {
      const data = await api(`/api/download_manager/tasks?filter=${filter}&search=${encodeURIComponent(search)}`);
      setTasks(data || []);
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }, [filter, search]);
  const loadSettings = useCallback(async () => {
    const [s, h, eng, oauth] = await Promise.all([
      api("/api/download_manager/settings"),
      api("/api/download_manager/file-hosting"),
      api("/api/download_manager/engine/status"),
      api("/api/download_manager/oauth/google/status")
    ]);
    setSettings(s);
    setSettingsDraft(s);
    setHosting(h || []);
    setEngineStatus(eng);
    setOauthStatus(oauth);
  }, []);
  useEffect3(() => {
    loadTasks();
    api("/api/download_manager/engine/status").then(setEngineStatus).catch(() => {
    });
    const iv = setInterval(() => {
      loadTasks();
      api("/api/download_manager/engine/status").then(setEngineStatus).catch(() => {
      });
    }, 3e3);
    return () => clearInterval(iv);
  }, [loadTasks]);
  useEffect3(() => {
    function onOAuthMessage(ev) {
      if (!ev.data || ev.data.type !== "copanel_dm_google_oauth") return;
      if (ev.data.ok) {
        loadSettings();
        setError(null);
      } else {
        setError(ev.data.error || "Google OAuth failed");
      }
    }
    window.addEventListener("message", onOAuthMessage);
    return () => window.removeEventListener("message", onOAuthMessage);
  }, [loadSettings]);
  useEffect3(() => {
    if (addUrl.length > 8) {
      api("/api/download_manager/detect-url", {
        method: "POST",
        body: { url: addUrl }
      }).then(setDetected).catch(() => setDetected(null));
    } else {
      setDetected(null);
    }
  }, [addUrl]);
  async function handleAddTask() {
    if (!addUrl.trim()) return;
    setError(null);
    try {
      await api("/api/download_manager/tasks", { method: "POST", body: { url: addUrl.trim() } });
      setAddUrl("");
      setAddOpen(false);
      loadTasks();
    } catch (e) {
      setError(e.message);
    }
  }
  async function taskAction(action) {
    if (!selectedId) return;
    try {
      await api(`/api/download_manager/tasks/${selectedId}/${action}`, { method: "POST" });
      loadTasks();
    } catch (e) {
      setError(e.message);
    }
  }
  async function deleteSelected() {
    if (!selectedId) return;
    try {
      await api(`/api/download_manager/tasks/${selectedId}`, { method: "DELETE" });
      setSelectedId(null);
      loadTasks();
    } catch (e) {
      setError(e.message);
    }
  }
  async function clearCompleted() {
    try {
      await api("/api/download_manager/tasks/completed", { method: "DELETE" });
      loadTasks();
    } catch (e) {
      setError(e.message);
    }
  }
  async function saveSettings() {
    try {
      await api("/api/download_manager/settings", { method: "PUT", body: settingsDraft });
      await loadSettings();
      setSettingsOpen(false);
    } catch (e) {
      setError(e.message);
    }
  }
  async function openFolderPicker(target) {
    setFolderTarget(target);
    const path = target === "temp_folder" ? settingsDraft.temp_folder : target === "destination_folder" ? settingsDraft.destination_folder : settingsDraft.watched_folder;
    const data = await api(`/api/download_manager/folders/browse?path=${encodeURIComponent(path || "")}`);
    setFolderBrowse(data);
  }
  async function browseTo(path) {
    const data = await api(`/api/download_manager/folders/browse?path=${encodeURIComponent(path)}`);
    setFolderBrowse(data);
  }
  function pickFolder(path) {
    if (!folderTarget) return;
    setSettingsDraft((d) => ({ ...d, [folderTarget]: path }));
    setFolderBrowse(null);
    setFolderTarget(null);
  }
  async function handleTorrentUpload(file) {
    if (!file) return;
    setError(null);
    try {
      const token = localStorage.getItem("copanel_token");
      const form = new FormData();
      form.append("file", file);
      const res = await fetch("/api/download_manager/tasks/upload-torrent", {
        method: "POST",
        headers: token ? { Authorization: `Bearer ${token}` } : {},
        body: form
      });
      const body = await res.json();
      if (!res.ok || body.status === "error") {
        throw new Error(body.error?.message || "Upload failed");
      }
      loadTasks();
    } catch (e) {
      setError(e.message);
    }
  }
  async function startGoogleOAuth() {
    try {
      const result = await api("/api/download_manager/oauth/google/start", {
        method: "POST",
        body: {
          client_id: oauthClientId,
          client_secret: oauthClientSecret,
          redirect_uri: oauthRedirect
        }
      });
      window.open(result.auth_url, "copanel_google_oauth", "width=520,height=720");
    } catch (e) {
      setError(e.message);
    }
  }
  async function saveAccount() {
    if (!accountDraft?.profileId || !accountDraft.label.trim()) return;
    const payload = {
      label: accountDraft.label,
      username: accountDraft.username,
      password: accountDraft.password,
      api_key: accountDraft.api_key,
      cookie: accountDraft.cookie
    };
    try {
      if (accountDraft.account?.id) {
        await api(`/api/download_manager/file-hosting/${accountDraft.profileId}/accounts/${accountDraft.account.id}`, {
          method: "PUT",
          body: payload
        });
      } else {
        await api(`/api/download_manager/file-hosting/${accountDraft.profileId}/accounts`, {
          method: "POST",
          body: payload
        });
      }
      setAccountDraft(null);
      await loadSettings();
    } catch (e) {
      setError(e.message);
    }
  }
  async function saveHosting() {
    if (!hostingDraft?.name) return;
    const payload = {
      ...hostingDraft,
      url_patterns: hostingDraft.url_patterns ? String(hostingDraft.url_patterns).split("\n").map((s) => s.trim()).filter(Boolean) : hostingDraft.url_patterns || []
    };
    try {
      if (hostingDraft.id) {
        await api(`/api/download_manager/file-hosting/${hostingDraft.id}`, { method: "PUT", body: payload });
      } else {
        await api("/api/download_manager/file-hosting", { method: "POST", body: payload });
      }
      setHostingDraft(null);
      await loadSettings();
    } catch (e) {
      setError(e.message);
    }
  }
  const panel = isDark ? "bg-slate-900 border-slate-700" : "bg-white border-slate-200";
  const muted = isDark ? "text-slate-400" : "text-slate-500";
  const btn = isDark ? "bg-slate-800 hover:bg-slate-700 text-slate-200 border-slate-600" : "bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200";
  return /* @__PURE__ */ jsx6(ModuleViewport, { constrained: true, children: /* @__PURE__ */ jsxs3("div", { className: `flex flex-col h-full min-h-0 ${isDark ? "text-slate-100" : "text-slate-900"}`, children: [
    /* @__PURE__ */ jsxs3("div", { className: `px-4 py-3 border-b flex items-center justify-between ${isDark ? "border-slate-700" : "border-slate-200"}`, children: [
      /* @__PURE__ */ jsxs3("div", { children: [
        /* @__PURE__ */ jsx6("h1", { className: "text-xl font-semibold", children: t.title }),
        /* @__PURE__ */ jsx6("p", { className: `text-sm ${muted}`, children: t.subtitle })
      ] }),
      engineStatus && /* @__PURE__ */ jsxs3("div", { className: `text-xs px-2 py-1 rounded border ${engineStatus.aria2_available ? "border-emerald-500/40 text-emerald-500" : "border-amber-500/40 text-amber-500"}`, children: [
        t.aria2Status,
        ": ",
        engineStatus.aria2_available ? `v${engineStatus.version || "?"}` : engineStatus.message
      ] })
    ] }),
    /* @__PURE__ */ jsx6(
      "input",
      {
        ref: torrentInputRef,
        type: "file",
        accept: ".torrent",
        className: "hidden",
        onChange: (e) => {
          handleTorrentUpload(e.target.files?.[0] || null);
          e.target.value = "";
        }
      }
    ),
    error && /* @__PURE__ */ jsxs3("div", { className: "mx-4 mt-2 px-3 py-2 rounded bg-red-500/10 text-red-500 text-sm flex justify-between", children: [
      /* @__PURE__ */ jsx6("span", { children: error }),
      /* @__PURE__ */ jsx6("button", { type: "button", onClick: () => setError(null), children: /* @__PURE__ */ jsx6(Icons3.X, { className: "w-4 h-4" }) })
    ] }),
    /* @__PURE__ */ jsx6(
      ModuleSidebarLayout,
      {
        isDark,
        mobileTitle: t.title,
        sidebar: /* @__PURE__ */ jsxs3("aside", { className: `h-full w-52 shrink-0 border-r flex flex-col ${isDark ? "border-slate-700 bg-slate-900/50" : "border-slate-200 bg-slate-50"}`, children: [
          /* @__PURE__ */ jsx6("div", { className: "p-2", children: /* @__PURE__ */ jsx6(
            "input",
            {
              className: `w-full px-2 py-1.5 text-sm rounded border ${isDark ? "bg-slate-800 border-slate-600" : "bg-white border-slate-300"}`,
              placeholder: t.search,
              value: search,
              onChange: (e) => setSearch(e.target.value)
            }
          ) }),
          /* @__PURE__ */ jsx6("nav", { className: "flex-1 overflow-y-auto px-1", children: FILTERS.map(({ key, icon }) => {
            const Icon = Icons3[icon];
            return /* @__PURE__ */ jsxs3(
              "button",
              {
                type: "button",
                onClick: () => setFilter(key),
                className: `w-full flex items-center gap-2 px-3 py-2 text-sm rounded mb-0.5 ${filter === key ? isDark ? "bg-blue-600/30 text-blue-300" : "bg-blue-50 text-blue-700" : `hover:${isDark ? "bg-slate-800" : "bg-slate-100"}`}`,
                children: [
                  /* @__PURE__ */ jsx6(Icon, { className: "w-4 h-4" }),
                  filterLabels[key]
                ]
              },
              key
            );
          }) }),
          /* @__PURE__ */ jsx6("div", { className: `p-2 border-t ${isDark ? "border-slate-700" : "border-slate-200"}`, children: /* @__PURE__ */ jsxs3(
            "button",
            {
              type: "button",
              onClick: () => {
                loadSettings();
                setSettingsOpen(true);
              },
              className: `w-full flex items-center justify-center gap-2 px-3 py-2 text-sm rounded border ${btn}`,
              children: [
                /* @__PURE__ */ jsx6(Icons3.Settings, { className: "w-4 h-4" }),
                t.settings
              ]
            }
          ) })
        ] }),
        children: /* @__PURE__ */ jsxs3("div", { className: "flex-1 flex flex-col min-w-0", children: [
          /* @__PURE__ */ jsxs3("div", { className: `flex items-center gap-1 px-2 py-1.5 border-b flex-wrap ${isDark ? "border-slate-700" : "border-slate-200"}`, children: [
            /* @__PURE__ */ jsx6("button", { type: "button", onClick: () => setAddOpen(true), className: `p-2 rounded border ${btn}`, title: t.addUrl, children: /* @__PURE__ */ jsx6(Icons3.Plus, { className: "w-4 h-4" }) }),
            /* @__PURE__ */ jsx6("button", { type: "button", onClick: () => setAddOpen(true), className: `p-2 rounded border ${btn}`, title: t.addUrl, children: /* @__PURE__ */ jsx6(Icons3.Globe, { className: "w-4 h-4" }) }),
            /* @__PURE__ */ jsx6("button", { type: "button", onClick: () => torrentInputRef.current?.click(), className: `p-2 rounded border ${btn}`, title: t.uploadTorrent, children: /* @__PURE__ */ jsx6(Icons3.FileUp, { className: "w-4 h-4" }) }),
            /* @__PURE__ */ jsx6("div", { className: `w-px h-6 mx-1 ${isDark ? "bg-slate-700" : "bg-slate-200"}` }),
            /* @__PURE__ */ jsx6("button", { type: "button", disabled: !selectedId, onClick: () => taskAction("resume"), className: `p-2 rounded border ${btn} disabled:opacity-40`, children: /* @__PURE__ */ jsx6(Icons3.Play, { className: "w-4 h-4" }) }),
            /* @__PURE__ */ jsx6("button", { type: "button", disabled: !selectedId, onClick: () => taskAction("pause"), className: `p-2 rounded border ${btn} disabled:opacity-40`, children: /* @__PURE__ */ jsx6(Icons3.Pause, { className: "w-4 h-4" }) }),
            /* @__PURE__ */ jsx6("button", { type: "button", disabled: !selectedId, onClick: () => taskAction("stop"), className: `p-2 rounded border ${btn} disabled:opacity-40`, children: /* @__PURE__ */ jsx6(Icons3.Square, { className: "w-4 h-4" }) }),
            /* @__PURE__ */ jsx6("div", { className: `w-px h-6 mx-1 ${isDark ? "bg-slate-700" : "bg-slate-200"}` }),
            /* @__PURE__ */ jsx6("button", { type: "button", disabled: !selectedId, onClick: deleteSelected, className: `p-2 rounded border ${btn} disabled:opacity-40`, children: /* @__PURE__ */ jsx6(Icons3.Trash2, { className: "w-4 h-4" }) }),
            /* @__PURE__ */ jsx6("button", { type: "button", onClick: clearCompleted, className: `p-2 rounded border ${btn}`, children: /* @__PURE__ */ jsx6(Icons3.Eraser, { className: "w-4 h-4" }) })
          ] }),
          /* @__PURE__ */ jsx6("div", { className: "flex-1 overflow-auto min-h-0", children: loading && tasks.length === 0 ? /* @__PURE__ */ jsx6("div", { className: `p-8 text-center ${muted}`, children: /* @__PURE__ */ jsx6(Icons3.Loader2, { className: "w-6 h-6 animate-spin mx-auto mb-2" }) }) : tasks.length === 0 ? /* @__PURE__ */ jsx6("div", { className: `p-8 text-center ${muted}`, children: t.noTasks }) : /* @__PURE__ */ jsxs3("table", { className: "w-full text-sm", children: [
            /* @__PURE__ */ jsx6("thead", { className: `sticky top-0 ${isDark ? "bg-slate-800" : "bg-slate-100"}`, children: /* @__PURE__ */ jsxs3("tr", { children: [
              /* @__PURE__ */ jsx6("th", { className: "w-8 p-2" }),
              /* @__PURE__ */ jsx6("th", { className: "text-left p-2 font-medium", children: t.colName }),
              /* @__PURE__ */ jsx6("th", { className: "text-right p-2 font-medium w-24", children: t.colSize }),
              /* @__PURE__ */ jsx6("th", { className: "text-right p-2 font-medium w-24", children: t.colDownloaded }),
              /* @__PURE__ */ jsx6("th", { className: "text-left p-2 font-medium w-36", children: t.colProgress }),
              /* @__PURE__ */ jsx6("th", { className: "text-right p-2 font-medium w-28", children: t.colSpeed }),
              /* @__PURE__ */ jsx6("th", { className: "text-left p-2 font-medium w-28", children: t.colStatus }),
              /* @__PURE__ */ jsx6("th", { className: "text-left p-2 font-medium", children: t.colDest })
            ] }) }),
            /* @__PURE__ */ jsx6("tbody", { children: tasks.map((task) => /* @__PURE__ */ jsxs3(
              "tr",
              {
                onClick: () => setSelectedId(task.id),
                className: `cursor-pointer border-b ${selectedId === task.id ? isDark ? "bg-blue-900/30" : "bg-blue-50" : isDark ? "border-slate-800 hover:bg-slate-800/50" : "border-slate-100 hover:bg-slate-50"}`,
                children: [
                  /* @__PURE__ */ jsx6("td", { className: "p-2", children: /* @__PURE__ */ jsx6(StatusIcon, { status: task.status }) }),
                  /* @__PURE__ */ jsx6("td", { className: "p-2 truncate max-w-xs", title: task.name, children: task.name }),
                  /* @__PURE__ */ jsx6("td", { className: "p-2 text-right tabular-nums", children: fmtBytes(task.total_bytes) }),
                  /* @__PURE__ */ jsx6("td", { className: "p-2 text-right tabular-nums", children: fmtBytes(task.downloaded_bytes) }),
                  /* @__PURE__ */ jsx6("td", { className: "p-2", children: /* @__PURE__ */ jsxs3("div", { className: "flex items-center gap-2", children: [
                    /* @__PURE__ */ jsx6("div", { className: `flex-1 h-2 rounded-full overflow-hidden ${isDark ? "bg-slate-700" : "bg-slate-200"}`, children: /* @__PURE__ */ jsx6("div", { className: "h-full bg-blue-500 transition-all", style: { width: `${Math.min(100, task.progress || 0)}%` } }) }),
                    /* @__PURE__ */ jsxs3("span", { className: "text-xs tabular-nums w-12 text-right", children: [
                      (task.progress || 0).toFixed(1),
                      "%"
                    ] })
                  ] }) }),
                  /* @__PURE__ */ jsx6("td", { className: "p-2 text-right tabular-nums text-xs", children: fmtSpeed(task.download_speed) }),
                  /* @__PURE__ */ jsx6("td", { className: `p-2 capitalize text-xs ${statusColor(task.status)}`, children: task.status }),
                  /* @__PURE__ */ jsx6("td", { className: `p-2 truncate max-w-[10rem] text-xs ${muted}`, title: task.destination, children: task.destination })
                ]
              },
              task.id
            )) })
          ] }) }),
          selected && /* @__PURE__ */ jsxs3("div", { className: `h-44 shrink-0 border-t ${isDark ? "border-slate-700 bg-slate-900/80" : "border-slate-200 bg-slate-50"}`, children: [
            /* @__PURE__ */ jsx6("div", { className: "flex gap-4 px-4 pt-2 border-b border-transparent", children: [
              { key: "general", label: t.tabGeneral },
              { key: "transfer", label: t.tabTransfer }
            ].map(({ key, label }) => /* @__PURE__ */ jsx6(
              "button",
              {
                type: "button",
                onClick: () => setDetailTab(key),
                className: `pb-2 text-sm border-b-2 ${detailTab === key ? "border-blue-500 text-blue-500" : `border-transparent ${muted}`}`,
                children: label
              },
              key
            )) }),
            /* @__PURE__ */ jsx6("div", { className: "px-4 py-3 grid grid-cols-2 gap-x-8 gap-y-1 text-sm overflow-y-auto max-h-32", children: detailTab === "general" ? /* @__PURE__ */ jsxs3(Fragment, { children: [
              /* @__PURE__ */ jsx6(DetailRow, { label: t.colName, value: selected.name }),
              /* @__PURE__ */ jsx6(DetailRow, { label: t.colDest, value: selected.destination }),
              /* @__PURE__ */ jsx6(DetailRow, { label: t.colSize, value: fmtBytes(selected.total_bytes) }),
              /* @__PURE__ */ jsx6(DetailRow, { label: "URL", value: selected.source_url, mono: true }),
              /* @__PURE__ */ jsx6(DetailRow, { label: "Type", value: selected.source_type }),
              /* @__PURE__ */ jsx6(DetailRow, { label: "User", value: selected.created_by || "\u2014" }),
              /* @__PURE__ */ jsx6(DetailRow, { label: "Created", value: selected.created_at }),
              selected.error_message && /* @__PURE__ */ jsx6(DetailRow, { label: "Error", value: selected.error_message, error: true })
            ] }) : /* @__PURE__ */ jsxs3(Fragment, { children: [
              /* @__PURE__ */ jsx6(DetailRow, { label: t.colDownloaded, value: fmtBytes(selected.downloaded_bytes) }),
              /* @__PURE__ */ jsx6(DetailRow, { label: t.colSpeed, value: fmtSpeed(selected.download_speed) }),
              /* @__PURE__ */ jsx6(DetailRow, { label: "Upload", value: fmtSpeed(selected.upload_speed) }),
              /* @__PURE__ */ jsx6(DetailRow, { label: t.colProgress, value: `${(selected.progress || 0).toFixed(1)}%` }),
              /* @__PURE__ */ jsx6(DetailRow, { label: t.colStatus, value: selected.status }),
              /* @__PURE__ */ jsx6(DetailRow, { label: "Completed", value: selected.completed_at || "\u2014" })
            ] }) })
          ] })
        ] })
      }
    ),
    /* @__PURE__ */ jsx6(WindowModal, { open: addOpen, onClose: () => setAddOpen(false), title: t.addUrl, children: /* @__PURE__ */ jsxs3("div", { className: "p-4", children: [
      /* @__PURE__ */ jsx6(
        "input",
        {
          className: `w-full px-3 py-2 rounded border mb-2 ${isDark ? "bg-slate-800 border-slate-600" : "bg-white border-slate-300"}`,
          placeholder: t.urlPlaceholder,
          value: addUrl,
          onChange: (e) => setAddUrl(e.target.value),
          onKeyDown: (e) => e.key === "Enter" && handleAddTask()
        }
      ),
      detected && /* @__PURE__ */ jsxs3("p", { className: `text-xs mb-3 ${muted}`, children: [
        "Detected: ",
        /* @__PURE__ */ jsx6("span", { className: "font-medium", children: detected.source_type }),
        detected.file_hosting_name ? ` \u2192 ${detected.file_hosting_name}` : ""
      ] }),
      /* @__PURE__ */ jsxs3("div", { className: "flex justify-end gap-2", children: [
        /* @__PURE__ */ jsx6("button", { type: "button", onClick: () => setAddOpen(false), className: `px-4 py-2 rounded border ${btn}`, children: t.cancel }),
        /* @__PURE__ */ jsx6("button", { type: "button", onClick: handleAddTask, className: "px-4 py-2 rounded bg-blue-600 text-white hover:bg-blue-700", children: t.add })
      ] })
    ] }) }),
    settings && /* @__PURE__ */ jsxs3(WindowModal, { open: settingsOpen, onClose: () => setSettingsOpen(false), title: t.settings, maxWidth: "2xl", className: "max-w-3xl", children: [
      /* @__PURE__ */ jsxs3("div", { className: "p-4 flex gap-4 min-h-[360px]", children: [
        /* @__PURE__ */ jsx6("div", { className: `w-44 shrink-0 border-r pr-3 ${isDark ? "border-slate-700" : "border-slate-200"}`, children: ["general", "location", "file-hosting", "google", "aria2"].map((tab) => /* @__PURE__ */ jsx6(
          "button",
          {
            type: "button",
            onClick: () => setSettingsTab(tab),
            className: `block w-full text-left px-2 py-1.5 text-sm rounded mb-1 ${settingsTab === tab ? "bg-blue-600/20 text-blue-400" : muted}`,
            children: tab === "general" ? t.tabGeneral : tab === "location" ? t.destFolder : tab === "file-hosting" ? t.fileHosting : tab === "google" ? t.googleOAuth : t.aria2Rpc
          },
          tab
        )) }),
        /* @__PURE__ */ jsxs3("div", { className: "flex-1 overflow-y-auto pr-2", children: [
          settingsTab === "general" && /* @__PURE__ */ jsxs3("div", { className: "space-y-4", children: [
            /* @__PURE__ */ jsx6(Field, { label: t.tempFolder, children: /* @__PURE__ */ jsxs3("div", { className: "flex gap-2", children: [
              /* @__PURE__ */ jsx6(
                "input",
                {
                  className: `flex-1 px-2 py-1.5 text-sm rounded border ${isDark ? "bg-slate-800 border-slate-600" : ""}`,
                  value: settingsDraft.temp_folder || "",
                  onChange: (e) => setSettingsDraft((d) => ({ ...d, temp_folder: e.target.value }))
                }
              ),
              /* @__PURE__ */ jsx6("button", { type: "button", onClick: () => openFolderPicker("temp_folder"), className: `px-3 py-1.5 text-sm rounded border ${btn}`, children: t.selectFolder })
            ] }) }),
            /* @__PURE__ */ jsx6(Field, { label: t.maxConcurrent, children: /* @__PURE__ */ jsx6(
              "input",
              {
                type: "number",
                min: 1,
                max: 20,
                className: `w-24 px-2 py-1.5 text-sm rounded border ${isDark ? "bg-slate-800 border-slate-600" : ""}`,
                value: settingsDraft.max_concurrent ?? 3,
                onChange: (e) => setSettingsDraft((d) => ({ ...d, max_concurrent: Number(e.target.value) }))
              }
            ) }),
            /* @__PURE__ */ jsx6(Field, { label: t.speedDown, children: /* @__PURE__ */ jsx6(
              "input",
              {
                type: "number",
                min: 0,
                className: `w-32 px-2 py-1.5 text-sm rounded border ${isDark ? "bg-slate-800 border-slate-600" : ""}`,
                value: settingsDraft.max_download_speed_kbps ?? 0,
                onChange: (e) => setSettingsDraft((d) => ({ ...d, max_download_speed_kbps: Number(e.target.value) }))
              }
            ) }),
            /* @__PURE__ */ jsx6(Field, { label: t.speedUp, children: /* @__PURE__ */ jsx6(
              "input",
              {
                type: "number",
                min: 0,
                className: `w-32 px-2 py-1.5 text-sm rounded border ${isDark ? "bg-slate-800 border-slate-600" : ""}`,
                value: settingsDraft.max_upload_speed_kbps ?? 0,
                onChange: (e) => setSettingsDraft((d) => ({ ...d, max_upload_speed_kbps: Number(e.target.value) }))
              }
            ) }),
            /* @__PURE__ */ jsx6(Field, { label: t.googleApiKey, children: /* @__PURE__ */ jsx6(
              "input",
              {
                type: "password",
                placeholder: settings.google_api_key_set ? "\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022" : "",
                className: `w-full px-2 py-1.5 text-sm rounded border ${isDark ? "bg-slate-800 border-slate-600" : ""}`,
                onChange: (e) => setSettingsDraft((d) => ({ ...d, google_api_key: e.target.value }))
              }
            ) })
          ] }),
          settingsTab === "location" && /* @__PURE__ */ jsxs3("div", { className: "space-y-4", children: [
            /* @__PURE__ */ jsx6(Field, { label: t.destFolder, children: /* @__PURE__ */ jsxs3("div", { className: "flex gap-2", children: [
              /* @__PURE__ */ jsx6(
                "input",
                {
                  className: `flex-1 px-2 py-1.5 text-sm rounded border ${isDark ? "bg-slate-800 border-slate-600" : ""}`,
                  value: settingsDraft.destination_folder || "",
                  onChange: (e) => setSettingsDraft((d) => ({ ...d, destination_folder: e.target.value }))
                }
              ),
              /* @__PURE__ */ jsx6("button", { type: "button", onClick: () => openFolderPicker("destination_folder"), className: `px-3 py-1.5 text-sm rounded border ${btn}`, children: t.selectFolder })
            ] }) }),
            /* @__PURE__ */ jsx6(Field, { label: t.watchedFolder, children: /* @__PURE__ */ jsxs3("div", { className: "flex gap-2", children: [
              /* @__PURE__ */ jsx6(
                "input",
                {
                  className: `flex-1 px-2 py-1.5 text-sm rounded border ${isDark ? "bg-slate-800 border-slate-600" : ""}`,
                  value: settingsDraft.watched_folder || "",
                  onChange: (e) => setSettingsDraft((d) => ({ ...d, watched_folder: e.target.value }))
                }
              ),
              /* @__PURE__ */ jsx6("button", { type: "button", onClick: () => openFolderPicker("watched_folder"), className: `px-3 py-1.5 text-sm rounded border ${btn}`, children: t.selectFolder })
            ] }) }),
            /* @__PURE__ */ jsxs3("label", { className: "flex items-center gap-2 text-sm", children: [
              /* @__PURE__ */ jsx6(
                "input",
                {
                  type: "checkbox",
                  checked: !!settingsDraft.watched_auto_delete,
                  onChange: (e) => setSettingsDraft((d) => ({ ...d, watched_auto_delete: e.target.checked }))
                }
              ),
              t.watchedAutoDelete
            ] })
          ] }),
          settingsTab === "file-hosting" && /* @__PURE__ */ jsxs3("div", { className: "space-y-3", children: [
            /* @__PURE__ */ jsxs3(
              "button",
              {
                type: "button",
                onClick: () => setHostingDraft({
                  name: "",
                  type: "curl",
                  url_patterns: [],
                  enabled: true,
                  curl_template: "curl -L -o '{OUT}' -b '{COOKIE}' '{URL}'"
                }),
                className: "text-sm text-blue-500 hover:underline flex items-center gap-1",
                children: [
                  /* @__PURE__ */ jsx6(Icons3.Plus, { className: "w-4 h-4" }),
                  " ",
                  t.addHosting
                ]
              }
            ),
            hosting.map((p) => /* @__PURE__ */ jsxs3("div", { className: `p-3 rounded border ${panel}`, children: [
              /* @__PURE__ */ jsxs3("div", { className: "flex justify-between items-start", children: [
                /* @__PURE__ */ jsxs3("div", { children: [
                  /* @__PURE__ */ jsx6("div", { className: "font-medium", children: p.name }),
                  /* @__PURE__ */ jsxs3("div", { className: `text-xs ${muted}`, children: [
                    p.type,
                    " \xB7 ",
                    p.url_patterns.join(", ")
                  ] })
                ] }),
                /* @__PURE__ */ jsx6("button", { type: "button", onClick: () => setHostingDraft(p), className: "text-xs text-blue-500", children: "Edit" })
              ] }),
              (p.accounts?.length || 0) > 0 && /* @__PURE__ */ jsxs3("div", { className: `mt-2 text-xs ${muted}`, children: [
                t.accounts,
                ": ",
                p.accounts.map((a) => a.label).join(", ")
              ] }),
              /* @__PURE__ */ jsxs3(
                "button",
                {
                  type: "button",
                  onClick: () => setAccountDraft({
                    profileId: p.id,
                    label: "",
                    username: "",
                    password: "",
                    api_key: "",
                    cookie: ""
                  }),
                  className: "mt-2 text-xs text-blue-500 hover:underline",
                  children: [
                    "+ ",
                    t.addAccount
                  ]
                }
              )
            ] }, p.id)),
            accountDraft && /* @__PURE__ */ jsxs3("div", { className: `mt-4 p-4 rounded border space-y-2 ${panel}`, children: [
              /* @__PURE__ */ jsx6("div", { className: "text-sm font-medium", children: t.manageAccounts }),
              /* @__PURE__ */ jsx6("input", { className: `w-full px-2 py-1.5 text-sm rounded border ${isDark ? "bg-slate-800 border-slate-600" : ""}`, placeholder: t.accountLabel, value: accountDraft.label, onChange: (e) => setAccountDraft((d) => d && { ...d, label: e.target.value }) }),
              /* @__PURE__ */ jsx6("input", { className: `w-full px-2 py-1.5 text-sm rounded border ${isDark ? "bg-slate-800 border-slate-600" : ""}`, placeholder: t.accountUser, value: accountDraft.username, onChange: (e) => setAccountDraft((d) => d && { ...d, username: e.target.value }) }),
              /* @__PURE__ */ jsx6("input", { type: "password", className: `w-full px-2 py-1.5 text-sm rounded border ${isDark ? "bg-slate-800 border-slate-600" : ""}`, placeholder: t.accountPass, value: accountDraft.password, onChange: (e) => setAccountDraft((d) => d && { ...d, password: e.target.value }) }),
              /* @__PURE__ */ jsx6("input", { className: `w-full px-2 py-1.5 text-sm rounded border ${isDark ? "bg-slate-800 border-slate-600" : ""}`, placeholder: t.accountApiKey, value: accountDraft.api_key, onChange: (e) => setAccountDraft((d) => d && { ...d, api_key: e.target.value }) }),
              /* @__PURE__ */ jsx6("textarea", { className: `w-full px-2 py-1.5 text-sm rounded border h-16 ${isDark ? "bg-slate-800 border-slate-600" : ""}`, placeholder: t.accountCookie, value: accountDraft.cookie, onChange: (e) => setAccountDraft((d) => d && { ...d, cookie: e.target.value }) }),
              /* @__PURE__ */ jsxs3("div", { className: "flex gap-2", children: [
                /* @__PURE__ */ jsx6("button", { type: "button", onClick: () => setAccountDraft(null), className: `px-3 py-1.5 text-sm rounded border ${btn}`, children: t.cancel }),
                /* @__PURE__ */ jsx6("button", { type: "button", onClick: saveAccount, className: "px-3 py-1.5 text-sm rounded bg-blue-600 text-white", children: t.save })
              ] })
            ] }),
            hostingDraft && /* @__PURE__ */ jsxs3("div", { className: `mt-4 p-4 rounded border space-y-3 ${panel}`, children: [
              /* @__PURE__ */ jsx6(
                "input",
                {
                  className: `w-full px-2 py-1.5 text-sm rounded border ${isDark ? "bg-slate-800 border-slate-600" : ""}`,
                  placeholder: "Name (e.g. MEGA.nz)",
                  value: hostingDraft.name || "",
                  onChange: (e) => setHostingDraft((d) => ({ ...d, name: e.target.value }))
                }
              ),
              /* @__PURE__ */ jsxs3(
                "select",
                {
                  className: `w-full px-2 py-1.5 text-sm rounded border ${isDark ? "bg-slate-800 border-slate-600" : ""}`,
                  value: hostingDraft.type || "curl",
                  onChange: (e) => setHostingDraft((d) => ({ ...d, type: e.target.value })),
                  children: [
                    /* @__PURE__ */ jsx6("option", { value: "curl", children: "curl template" }),
                    /* @__PURE__ */ jsx6("option", { value: "api", children: "API resolve" })
                  ]
                }
              ),
              /* @__PURE__ */ jsx6(
                "textarea",
                {
                  className: `w-full px-2 py-1.5 text-sm rounded border h-20 ${isDark ? "bg-slate-800 border-slate-600" : ""}`,
                  placeholder: t.urlPatterns,
                  value: Array.isArray(hostingDraft.url_patterns) ? hostingDraft.url_patterns.join("\n") : "",
                  onChange: (e) => setHostingDraft((d) => ({
                    ...d,
                    url_patterns: e.target.value.split("\n").map((s) => s.trim()).filter(Boolean)
                  }))
                }
              ),
              hostingDraft.type === "curl" ? /* @__PURE__ */ jsx6(
                "textarea",
                {
                  className: `w-full px-2 py-1.5 text-sm font-mono text-xs rounded border h-24 ${isDark ? "bg-slate-800 border-slate-600" : ""}`,
                  placeholder: t.curlTemplate,
                  value: hostingDraft.curl_template || "",
                  onChange: (e) => setHostingDraft((d) => ({ ...d, curl_template: e.target.value }))
                }
              ) : /* @__PURE__ */ jsx6(
                "input",
                {
                  className: `w-full px-2 py-1.5 text-sm rounded border ${isDark ? "bg-slate-800 border-slate-600" : ""}`,
                  placeholder: t.apiResolve,
                  value: hostingDraft.api_config?.resolve_url || "",
                  onChange: (e) => setHostingDraft((d) => ({
                    ...d,
                    api_config: { ...d?.api_config || { method: "POST", headers: {}, body_template: "", download_url_field: "direct_link" }, resolve_url: e.target.value }
                  }))
                }
              ),
              /* @__PURE__ */ jsxs3("p", { className: `text-xs ${muted}`, children: [
                "Placeholders: ",
                "{URL}",
                " ",
                "{OUT}",
                " ",
                "{USER}",
                " ",
                "{PASS}",
                " ",
                "{API_KEY}",
                " ",
                "{COOKIE}"
              ] }),
              /* @__PURE__ */ jsxs3("div", { className: "flex gap-2", children: [
                /* @__PURE__ */ jsx6("button", { type: "button", onClick: () => setHostingDraft(null), className: `px-3 py-1.5 text-sm rounded border ${btn}`, children: t.cancel }),
                /* @__PURE__ */ jsx6("button", { type: "button", onClick: saveHosting, className: "px-3 py-1.5 text-sm rounded bg-blue-600 text-white", children: t.save })
              ] })
            ] })
          ] }),
          settingsTab === "google" && /* @__PURE__ */ jsxs3("div", { className: "space-y-4", children: [
            /* @__PURE__ */ jsx6("p", { className: `text-sm ${muted}`, children: oauthStatus?.connected || settings.google_oauth_connected ? "\u2713 Google Drive connected" : "Connect Google account for private files and folder listing without API key." }),
            /* @__PURE__ */ jsx6(Field, { label: t.oauthClientId, children: /* @__PURE__ */ jsx6("input", { className: `w-full px-2 py-1.5 text-sm rounded border ${isDark ? "bg-slate-800 border-slate-600" : ""}`, value: oauthClientId, onChange: (e) => setOauthClientId(e.target.value) }) }),
            /* @__PURE__ */ jsx6(Field, { label: t.oauthClientSecret, children: /* @__PURE__ */ jsx6("input", { type: "password", className: `w-full px-2 py-1.5 text-sm rounded border ${isDark ? "bg-slate-800 border-slate-600" : ""}`, value: oauthClientSecret, onChange: (e) => setOauthClientSecret(e.target.value) }) }),
            /* @__PURE__ */ jsx6(Field, { label: t.oauthRedirect, children: /* @__PURE__ */ jsx6("input", { className: `w-full px-2 py-1.5 text-sm rounded border ${isDark ? "bg-slate-800 border-slate-600" : ""}`, value: oauthRedirect, onChange: (e) => setOauthRedirect(e.target.value) }) }),
            /* @__PURE__ */ jsx6("button", { type: "button", onClick: startGoogleOAuth, className: "px-4 py-2 rounded bg-blue-600 text-white text-sm", children: t.connectGoogle })
          ] }),
          settingsTab === "aria2" && /* @__PURE__ */ jsxs3("div", { className: "space-y-4", children: [
            /* @__PURE__ */ jsxs3("p", { className: `text-sm ${muted}`, children: [
              t.aria2AutoStartHint,
              " Log:",
              " ",
              /* @__PURE__ */ jsx6("code", { className: "text-xs", children: "/opt/copanel/config/download_manager/aria2.log" })
            ] }),
            /* @__PURE__ */ jsxs3("label", { className: "flex items-center gap-2 text-sm cursor-pointer", children: [
              /* @__PURE__ */ jsx6(
                "input",
                {
                  type: "checkbox",
                  checked: settingsDraft.aria2_auto_start !== false,
                  onChange: (e) => setSettingsDraft((d) => ({ ...d, aria2_auto_start: e.target.checked }))
                }
              ),
              t.aria2AutoStart
            ] }),
            /* @__PURE__ */ jsx6(Field, { label: t.aria2Host, children: /* @__PURE__ */ jsx6("input", { className: `w-full px-2 py-1.5 text-sm rounded border ${isDark ? "bg-slate-800 border-slate-600" : ""}`, value: settingsDraft.aria2_rpc_host || "127.0.0.1", onChange: (e) => setSettingsDraft((d) => ({ ...d, aria2_rpc_host: e.target.value })) }) }),
            /* @__PURE__ */ jsx6(Field, { label: t.aria2Port, children: /* @__PURE__ */ jsx6("input", { type: "number", className: `w-32 px-2 py-1.5 text-sm rounded border ${isDark ? "bg-slate-800 border-slate-600" : ""}`, value: settingsDraft.aria2_rpc_port ?? 6800, onChange: (e) => setSettingsDraft((d) => ({ ...d, aria2_rpc_port: Number(e.target.value) })) }) }),
            /* @__PURE__ */ jsx6(Field, { label: t.aria2Secret, children: /* @__PURE__ */ jsx6("input", { type: "password", placeholder: settings.aria2_rpc_secret_set ? "\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022" : "", className: `w-full px-2 py-1.5 text-sm rounded border ${isDark ? "bg-slate-800 border-slate-600" : ""}`, onChange: (e) => setSettingsDraft((d) => ({ ...d, aria2_rpc_secret: e.target.value })) }) })
          ] })
        ] })
      ] }),
      settingsTab !== "file-hosting" && /* @__PURE__ */ jsxs3("div", { className: "flex justify-end gap-2 mt-4 pt-3 border-t border-slate-700/30", children: [
        /* @__PURE__ */ jsx6("button", { type: "button", onClick: () => setSettingsOpen(false), className: `px-4 py-2 rounded border ${btn}`, children: t.cancel }),
        /* @__PURE__ */ jsx6("button", { type: "button", onClick: saveSettings, className: "px-4 py-2 rounded bg-blue-600 text-white hover:bg-blue-700", children: t.save })
      ] })
    ] }),
    /* @__PURE__ */ jsx6(
      WindowModal,
      {
        open: !!folderBrowse,
        onClose: () => {
          setFolderBrowse(null);
          setFolderTarget(null);
        },
        title: t.selectFolder,
        children: folderBrowse && /* @__PURE__ */ jsxs3("div", { className: "p-4", children: [
          /* @__PURE__ */ jsx6("div", { className: `text-xs mb-2 font-mono ${muted}`, children: folderBrowse.current }),
          folderBrowse.parent && /* @__PURE__ */ jsxs3("button", { type: "button", onClick: () => browseTo(folderBrowse.parent), className: "text-sm text-blue-500 mb-2 flex items-center gap-1", children: [
            /* @__PURE__ */ jsx6(Icons3.ArrowUp, { className: "w-4 h-4" }),
            " .."
          ] }),
          /* @__PURE__ */ jsx6("div", { className: "max-h-48 overflow-y-auto border rounded mb-3", children: folderBrowse.entries.map((e) => /* @__PURE__ */ jsxs3(
            "button",
            {
              type: "button",
              onClick: () => browseTo(e.path),
              className: `w-full text-left px-3 py-1.5 text-sm flex items-center gap-2 hover:bg-blue-500/10`,
              children: [
                /* @__PURE__ */ jsx6(Icons3.Folder, { className: "w-4 h-4 text-amber-500" }),
                e.name
              ]
            },
            e.path
          )) }),
          /* @__PURE__ */ jsxs3("button", { type: "button", onClick: () => pickFolder(folderBrowse.current), className: "w-full py-2 rounded bg-blue-600 text-white text-sm", children: [
            t.selectFolder,
            ": ",
            folderBrowse.current
          ] })
        ] })
      }
    )
  ] }) });
}
function DetailRow({ label, value, mono, error }) {
  return /* @__PURE__ */ jsxs3("div", { className: "flex gap-2", children: [
    /* @__PURE__ */ jsxs3("span", { className: "text-slate-500 shrink-0 w-24", children: [
      label,
      ":"
    ] }),
    /* @__PURE__ */ jsx6("span", { className: `truncate ${mono ? "font-mono text-xs" : ""} ${error ? "text-red-500" : ""}`, title: value, children: value })
  ] });
}
function Field({ label, children }) {
  return /* @__PURE__ */ jsxs3("div", { children: [
    /* @__PURE__ */ jsx6("div", { className: "text-sm font-medium text-blue-500 mb-1", children: label }),
    children
  ] });
}
export {
  DownloadManager as default
};
