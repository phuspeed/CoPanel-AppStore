"""
Docker Manager Module
"""
