"""
SSL Manager Logic Layer
Handles Let's Encrypt / Certbot and custom private keys for Nginx virtual hosts.
"""
import os
import shutil
import subprocess
from pathlib import Path
from typing import List, Dict, Any, Optional

from core import sysexec
from core.paths import write_private_text
from core.validators import validate_domain

IS_WINDOWS = os.name == 'nt'


def _checked_domain(domain: str) -> str:
    return validate_domain(domain)


def _certbot(args: list, timeout: int = 180) -> subprocess.CompletedProcess:
    return sysexec.run(["certbot", *args], timeout=timeout, as_root=True)


def _reload_nginx() -> None:
    if not shutil.which("nginx"):
        return
    sysexec.run(["nginx", "-t"], timeout=30, as_root=True)
    sysexec.run(["systemctl", "reload", "nginx"], timeout=30, as_root=True)

class SSLManager:
    @staticmethod
    def get_cert_expiry(cert_path: Path) -> str:
        """Read fullchain.pem to get expiration date string."""
        if not cert_path.exists():
            return "N/A"
        try:
            # Use openssl command to read expiration date
            res = subprocess.run(["openssl", "x509", "-enddate", "-noout", "-in", str(cert_path)], capture_output=True, text=True)
            if res.returncode == 0:
                line = res.stdout.strip()
                if "notAfter=" in line:
                    return line.split("notAfter=")[1].strip()
        except Exception:
            pass
        return "N/A"

    @staticmethod
    def extract_domains_from_nginx(file_path: Path) -> List[str]:
        """Read Nginx configuration and return list of domain names found in server_name."""
        if not file_path.exists():
            return []
        extracted = []
        try:
            content = file_path.read_text(encoding="utf-8", errors="ignore")
            # Extract server_names
            import re
            server_names = re.findall(r'server_name\s+([^;]+);', content)
            for names in server_names:
                for name in names.split():
                    name = name.strip().lower()
                    if name and name not in ["default", "localhost", "copanel"] and not name.startswith("_"):
                        extracted.append(name)
        except Exception:
            pass

        # Fallback ONLY IF no domain was extracted from server_name
        if not extracted:
            fname = file_path.name
            if fname.endswith(".conf"):
                fname = fname[:-5]
            if fname not in ["default", "copanel"]:
                extracted.append(fname)

        return extracted

    @staticmethod
    def get_certificates() -> List[Dict[str, Any]]:
        """List all domains and their active SSL certificates."""
        import re
        domains = set()

        def clean_domain(d: str) -> str:
            d = d.strip().lower()
            if d.endswith(".conf"):
                d = d[:-5]
            # Strip leading *. or www.
            d = re.sub(r'^(www\.|\*\.)', '', d)
            # Strip Certbot numeric suffixes like -0001
            d = re.sub(r'-\d+$', '', d)
            return d

        # Find all domains from sites-available
        sites_dir = Path("/etc/nginx/sites-available") if not IS_WINDOWS else Path("./test_nginx/sites-available")
        if sites_dir.exists():
            for file in sites_dir.iterdir():
                if file.is_file() and file.name not in ["default", "copanel"]:
                    for d in SSLManager.extract_domains_from_nginx(file):
                        domains.add(clean_domain(d))

        # Find all domains from /etc/letsencrypt/live
        le_dir = Path("/etc/letsencrypt/live") if not IS_WINDOWS else Path("./test_nginx/letsencrypt/live")
        if le_dir.exists():
            for d_dir in le_dir.iterdir():
                if d_dir.is_dir() and d_dir.name not in ["README", ".git"]:
                    domains.add(clean_domain(d_dir.name))

        # Find all domains from /etc/nginx/ssl
        ssl_dir = Path("/etc/nginx/ssl") if not IS_WINDOWS else Path("./test_nginx/ssl")
        if ssl_dir.exists():
            for d_dir in ssl_dir.iterdir():
                if d_dir.is_dir():
                    domains.add(clean_domain(d_dir.name))

        def find_letsencrypt_cert(domain: str) -> Optional[Path]:
            base_dir = Path("/etc/letsencrypt/live") if not IS_WINDOWS else Path("./test_nginx/letsencrypt/live")
            if not base_dir.exists():
                return None
            p = base_dir / domain / "fullchain.pem"
            if p.exists():
                return p
            for item in base_dir.iterdir():
                if item.is_dir() and item.name.startswith(domain + "-") and (item / "fullchain.pem").exists():
                    return item / "fullchain.pem"
            return None

        def find_custom_cert(domain: str) -> Optional[Path]:
            base_dir = Path("/etc/nginx/ssl") if not IS_WINDOWS else Path("./test_nginx/ssl")
            if not base_dir.exists():
                return None
            p = base_dir / domain / "fullchain.pem"
            if p.exists():
                return p
            return None

        results = []
        seen_domains = set()
        for domain in domains:
            if not domain:
                continue

            cleaned = clean_domain(domain)
            if cleaned in seen_domains:
                continue

            cert_path_letsencrypt = find_letsencrypt_cert(cleaned)
            cert_path_custom = find_custom_cert(cleaned)

            ssl_active = False
            ssl_type = "None"
            expiry = "N/A"

            # Check LetsEncrypt
            if cert_path_letsencrypt and cert_path_letsencrypt.exists():
                ssl_active = True
                ssl_type = "Let's Encrypt"
                expiry = SSLManager.get_cert_expiry(cert_path_letsencrypt)
            # Check Custom
            elif cert_path_custom and cert_path_custom.exists():
                ssl_active = True
                ssl_type = "Custom"
                expiry = SSLManager.get_cert_expiry(cert_path_custom)

            results.append({
                "domain": cleaned,
                "active": ssl_active,
                "type": ssl_type,
                "expiry": expiry
            })
            seen_domains.add(cleaned)

        return results

    @staticmethod
    def renew_certificates() -> dict:
        """Renew all Let's Encrypt certificates using Certbot renew."""
        if IS_WINDOWS:
            return {"status": "success", "message": "All Let's Encrypt certificates successfully renewed (Mock Mode)."}

        if not shutil.which("certbot"):
            return {"status": "error", "message": "Certbot CLI is not installed on this server."}

        try:
            # Run certbot renew
            res = _certbot(["renew", "--non-interactive"])
            if res.returncode != 0:
                return {"status": "error", "message": f"Certbot renewal failed: {res.stderr or res.stdout}"}

            # Reload Nginx after a successful renewal
            _reload_nginx()

            return {"status": "success", "message": "All Let's Encrypt certificates successfully renewed and Nginx reloaded."}
        except Exception as e:
            return {"status": "error", "message": str(e)}

    @staticmethod
    def renew_domain(domain: str, force: bool = False) -> dict:
        """Renew a single Let's Encrypt certificate by domain name."""
        if IS_WINDOWS:
            return {"status": "success", "message": f"Renewed SSL for {domain} (Mock Mode)."}
        if not shutil.which("certbot"):
            return {"status": "error", "message": "Certbot CLI is not installed on this server."}
        try:
            domain = _checked_domain(domain)
        except ValueError as exc:
            return {"status": "error", "message": str(exc)}
        try:
            args = ["renew", "--cert-name", domain, "--non-interactive"]
            if force:
                args.append("--force-renewal")
            res = _certbot(args)
            if res.returncode != 0:
                return {"status": "error", "message": f"Certbot renewal failed: {res.stderr or res.stdout}"}
            _reload_nginx()
            return {"status": "success", "message": f"Certificate for {domain} renewed and Nginx reloaded."}
        except Exception as e:
            return {"status": "error", "message": str(e)}


    @staticmethod
    def issue_certbot(domain: str, email: str) -> dict:
        """Runs certbot CLI to issue a Let's Encrypt certificate for the target domain."""
        if IS_WINDOWS:
            return {"status": "success", "message": f"Issued Let's Encrypt SSL for {domain} (Mock Mode)."}

        # 1. Ensure certbot is installed
        if not shutil.which("certbot"):
            return {"status": "error", "message": "Certbot CLI is not installed on this server."}

        try:
            domain = _checked_domain(domain)
        except ValueError as exc:
            return {"status": "error", "message": str(exc)}

        try:
            # Generate cert via certbot
            res = _certbot([
                "certonly", "--nginx",
                "-d", domain,
                "-m", email,
                "--agree-tos", "--non-interactive",
            ])
            if res.returncode != 0:
                return {"status": "error", "message": f"Certbot execution failed: {res.stderr or res.stdout}"}

            # 2. Add to Nginx vhost
            cert_path = f"/etc/letsencrypt/live/{domain}/fullchain.pem"
            key_path = f"/etc/letsencrypt/live/{domain}/privkey.pem"
            SSLManager.enable_ssl_in_nginx_vhost(domain, cert_path, key_path)

            return {"status": "success", "message": f"Certbot issued certificate for {domain} and configured Nginx successfully."}
        except Exception as e:
            return {"status": "error", "message": str(e)}

    @staticmethod
    def install_custom_ssl(domain: str, private_key: str, certificate: str) -> dict:
        """Saves custom pasted certificates and private key files and updates Nginx configuration."""
        if not domain or not private_key or not certificate:
            return {"status": "error", "message": "Domain, Private Key, and Certificate are required fields."}
        try:
            domain = _checked_domain(domain)
        except ValueError as exc:
            return {"status": "error", "message": str(exc)}

        base = Path("/etc/nginx/ssl") if not IS_WINDOWS else Path("./test_nginx/ssl")
        ssl_dir = (base / domain).resolve()
        try:
            ssl_dir.relative_to(base.resolve())
        except ValueError:
            return {"status": "error", "message": "Certificate path escapes the SSL directory."}

        try:
            ssl_dir.mkdir(parents=True, exist_ok=True)
            fullchain_file = ssl_dir / "fullchain.pem"
            privkey_file = ssl_dir / "privkey.pem"

            fullchain_file.write_text(certificate.strip() + "\n", encoding="utf-8")
            write_private_text(privkey_file, private_key.strip() + "\n")

            # Update Nginx
            SSLManager.enable_ssl_in_nginx_vhost(domain, str(fullchain_file), str(privkey_file))

            return {"status": "success", "message": f"Custom SSL installed successfully for {domain}."}
        except Exception as e:
            return {"status": "error", "message": str(e)}

    @staticmethod
    def _search_vhost_dir(sites_dir: Path, domain: str) -> Optional[Path]:
        if not sites_dir.is_dir():
            return None
        for candidate in (f"{domain}.conf", domain):
            path = sites_dir / candidate
            if path.is_file():
                return path
        skip = {"default", "copanel", "default.conf", "php-fpm.conf", "ssl.conf"}
        for path in sites_dir.iterdir():
            if not path.is_file() or path.name in skip or path.name.endswith(".disabled"):
                continue
            try:
                content = path.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                continue
            if f"server_name {domain}" in content or f"server_name {domain} " in content:
                return path
        return None

    @staticmethod
    def find_nginx_vhost_path(domain: str) -> Optional[Path]:
        """Resolve the nginx vhost file (sites-available or conf.d)."""
        try:
            domain = _checked_domain(domain)
        except ValueError:
            return None
        directories: List[Path] = []
        if IS_WINDOWS:
            directories.append(Path("./test_nginx/sites-available"))
        else:
            try:
                from modules.web_manager.logic import get_nginx_paths

                paths = get_nginx_paths()
                directories.append(Path(paths.sites_available))
                conf_d = Path("/etc/nginx/conf.d")
                if conf_d not in directories:
                    directories.append(conf_d)
            except Exception:
                directories.append(Path("/etc/nginx/sites-available"))
                directories.append(Path("/etc/nginx/conf.d"))
        for sites_dir in directories:
            found = SSLManager._search_vhost_dir(sites_dir, domain)
            if found:
                return found
        return None

    @staticmethod
    def enable_ssl_in_nginx_vhost(domain: str, cert_path: str, key_path: str):
        vhost_path = SSLManager.find_nginx_vhost_path(domain)
        if not vhost_path or not vhost_path.exists():
            return

        content = vhost_path.read_text(encoding="utf-8")

        # If already has 443 ssl listener, don't duplicate
        if "listen 443 ssl;" in content:
            return

        import re
        ssl_directives = f"listen 443 ssl;\n    ssl_certificate {cert_path};\n    ssl_certificate_key {key_path};\n    ssl_protocols TLSv1.2 TLSv1.3;\n    ssl_prefer_server_ciphers on;"

        # Replace 'listen 80;' or similar listen directive
        if re.search(r'listen\s+[^;]+;', content):
            content = re.sub(r'listen\s+[^;]+;', ssl_directives, content, count=1)
        else:
            if f"server_name {domain};" in content:
                content = content.replace(f"server_name {domain};", f"server_name {domain};\n    {ssl_directives}")
            elif "server_name" in content:
                lines = content.splitlines()
                for idx, line in enumerate(lines):
                    if "server_name" in line:
                        lines[idx] = line + "\n    " + ssl_directives
                        break
                content = "\n".join(lines)

        # Now append the HTTP redirect block to the file
        redirect_block = f"\n\nserver {{\n    listen 80;\n    server_name {domain};\n    return 301 https://$host$request_uri;\n}}\n"
        content += redirect_block

        vhost_path.write_text(content, encoding="utf-8")

        if not IS_WINDOWS:
            _reload_nginx()
