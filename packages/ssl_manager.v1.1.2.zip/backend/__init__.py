# SSL Manager Module Init
