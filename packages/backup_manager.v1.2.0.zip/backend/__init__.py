# Backup Manager Module Init
