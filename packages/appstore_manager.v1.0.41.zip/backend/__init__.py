# AppStore Manager Module Init
