var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);

// src/modules/cloudflare_ddns/index.tsx
import { useCallback, useEffect as useEffect3, useState as useState3 } from "react";

// src/core/hooks/useAppShellContext.ts
import { useOutletContext } from "react-router-dom";

// src/core/shell/ShellContext.tsx
import { createContext, useContext } from "react";
import { jsx } from "react/jsx-runtime";
var ShellContext = createContext(null);
function useShellContext() {
  return useContext(ShellContext);
}

// src/core/hooks/useAppShellContext.ts
var FALLBACK = {
  theme: localStorage.getItem("copanel_theme") || "light",
  setTheme: () => {
  },
  language: localStorage.getItem("copanel_lang") || "en",
  setLanguage: () => {
  }
};
function useAppShellContext() {
  const shell = useShellContext();
  const outlet = useOutletContext();
  if (shell) return shell;
  if (outlet?.theme) {
    return {
      theme: outlet.theme,
      setTheme: outlet.setTheme ?? (() => {
      }),
      language: outlet.language ?? "en",
      setLanguage: outlet.setLanguage ?? (() => {
      })
    };
  }
  return FALLBACK;
}

// node_modules/clsx/dist/clsx.mjs
function r(e) {
  var t, f, n = "";
  if ("string" == typeof e || "number" == typeof e) n += e;
  else if ("object" == typeof e) if (Array.isArray(e)) {
    var o = e.length;
    for (t = 0; t < o; t++) e[t] && (f = r(e[t])) && (n && (n += " "), n += f);
  } else for (f in e) e[f] && (n && (n += " "), n += f);
  return n;
}
function clsx() {
  for (var e, t, f = 0, n = "", o = arguments.length; f < o; f++) (e = arguments[f]) && (t = r(e)) && (n && (n += " "), n += t);
  return n;
}

// node_modules/tailwind-merge/dist/bundle-mjs.mjs
var CLASS_PART_SEPARATOR = "-";
var createClassGroupUtils = (config) => {
  const classMap = createClassMap(config);
  const {
    conflictingClassGroups,
    conflictingClassGroupModifiers
  } = config;
  const getClassGroupId = (className) => {
    const classParts = className.split(CLASS_PART_SEPARATOR);
    if (classParts[0] === "" && classParts.length !== 1) {
      classParts.shift();
    }
    return getGroupRecursive(classParts, classMap) || getGroupIdForArbitraryProperty(className);
  };
  const getConflictingClassGroupIds = (classGroupId, hasPostfixModifier) => {
    const conflicts = conflictingClassGroups[classGroupId] || [];
    if (hasPostfixModifier && conflictingClassGroupModifiers[classGroupId]) {
      return [...conflicts, ...conflictingClassGroupModifiers[classGroupId]];
    }
    return conflicts;
  };
  return {
    getClassGroupId,
    getConflictingClassGroupIds
  };
};
var getGroupRecursive = (classParts, classPartObject) => {
  if (classParts.length === 0) {
    return classPartObject.classGroupId;
  }
  const currentClassPart = classParts[0];
  const nextClassPartObject = classPartObject.nextPart.get(currentClassPart);
  const classGroupFromNextClassPart = nextClassPartObject ? getGroupRecursive(classParts.slice(1), nextClassPartObject) : void 0;
  if (classGroupFromNextClassPart) {
    return classGroupFromNextClassPart;
  }
  if (classPartObject.validators.length === 0) {
    return void 0;
  }
  const classRest = classParts.join(CLASS_PART_SEPARATOR);
  return classPartObject.validators.find(({
    validator
  }) => validator(classRest))?.classGroupId;
};
var arbitraryPropertyRegex = /^\[(.+)\]$/;
var getGroupIdForArbitraryProperty = (className) => {
  if (arbitraryPropertyRegex.test(className)) {
    const arbitraryPropertyClassName = arbitraryPropertyRegex.exec(className)[1];
    const property = arbitraryPropertyClassName?.substring(0, arbitraryPropertyClassName.indexOf(":"));
    if (property) {
      return "arbitrary.." + property;
    }
  }
};
var createClassMap = (config) => {
  const {
    theme,
    prefix
  } = config;
  const classMap = {
    nextPart: /* @__PURE__ */ new Map(),
    validators: []
  };
  const prefixedClassGroupEntries = getPrefixedClassGroupEntries(Object.entries(config.classGroups), prefix);
  prefixedClassGroupEntries.forEach(([classGroupId, classGroup]) => {
    processClassesRecursively(classGroup, classMap, classGroupId, theme);
  });
  return classMap;
};
var processClassesRecursively = (classGroup, classPartObject, classGroupId, theme) => {
  classGroup.forEach((classDefinition) => {
    if (typeof classDefinition === "string") {
      const classPartObjectToEdit = classDefinition === "" ? classPartObject : getPart(classPartObject, classDefinition);
      classPartObjectToEdit.classGroupId = classGroupId;
      return;
    }
    if (typeof classDefinition === "function") {
      if (isThemeGetter(classDefinition)) {
        processClassesRecursively(classDefinition(theme), classPartObject, classGroupId, theme);
        return;
      }
      classPartObject.validators.push({
        validator: classDefinition,
        classGroupId
      });
      return;
    }
    Object.entries(classDefinition).forEach(([key, classGroup2]) => {
      processClassesRecursively(classGroup2, getPart(classPartObject, key), classGroupId, theme);
    });
  });
};
var getPart = (classPartObject, path) => {
  let currentClassPartObject = classPartObject;
  path.split(CLASS_PART_SEPARATOR).forEach((pathPart) => {
    if (!currentClassPartObject.nextPart.has(pathPart)) {
      currentClassPartObject.nextPart.set(pathPart, {
        nextPart: /* @__PURE__ */ new Map(),
        validators: []
      });
    }
    currentClassPartObject = currentClassPartObject.nextPart.get(pathPart);
  });
  return currentClassPartObject;
};
var isThemeGetter = (func) => func.isThemeGetter;
var getPrefixedClassGroupEntries = (classGroupEntries, prefix) => {
  if (!prefix) {
    return classGroupEntries;
  }
  return classGroupEntries.map(([classGroupId, classGroup]) => {
    const prefixedClassGroup = classGroup.map((classDefinition) => {
      if (typeof classDefinition === "string") {
        return prefix + classDefinition;
      }
      if (typeof classDefinition === "object") {
        return Object.fromEntries(Object.entries(classDefinition).map(([key, value]) => [prefix + key, value]));
      }
      return classDefinition;
    });
    return [classGroupId, prefixedClassGroup];
  });
};
var createLruCache = (maxCacheSize) => {
  if (maxCacheSize < 1) {
    return {
      get: () => void 0,
      set: () => {
      }
    };
  }
  let cacheSize = 0;
  let cache = /* @__PURE__ */ new Map();
  let previousCache = /* @__PURE__ */ new Map();
  const update = (key, value) => {
    cache.set(key, value);
    cacheSize++;
    if (cacheSize > maxCacheSize) {
      cacheSize = 0;
      previousCache = cache;
      cache = /* @__PURE__ */ new Map();
    }
  };
  return {
    get(key) {
      let value = cache.get(key);
      if (value !== void 0) {
        return value;
      }
      if ((value = previousCache.get(key)) !== void 0) {
        update(key, value);
        return value;
      }
    },
    set(key, value) {
      if (cache.has(key)) {
        cache.set(key, value);
      } else {
        update(key, value);
      }
    }
  };
};
var IMPORTANT_MODIFIER = "!";
var createParseClassName = (config) => {
  const {
    separator,
    experimentalParseClassName
  } = config;
  const isSeparatorSingleCharacter = separator.length === 1;
  const firstSeparatorCharacter = separator[0];
  const separatorLength = separator.length;
  const parseClassName = (className) => {
    const modifiers = [];
    let bracketDepth = 0;
    let modifierStart = 0;
    let postfixModifierPosition;
    for (let index = 0; index < className.length; index++) {
      let currentCharacter = className[index];
      if (bracketDepth === 0) {
        if (currentCharacter === firstSeparatorCharacter && (isSeparatorSingleCharacter || className.slice(index, index + separatorLength) === separator)) {
          modifiers.push(className.slice(modifierStart, index));
          modifierStart = index + separatorLength;
          continue;
        }
        if (currentCharacter === "/") {
          postfixModifierPosition = index;
          continue;
        }
      }
      if (currentCharacter === "[") {
        bracketDepth++;
      } else if (currentCharacter === "]") {
        bracketDepth--;
      }
    }
    const baseClassNameWithImportantModifier = modifiers.length === 0 ? className : className.substring(modifierStart);
    const hasImportantModifier = baseClassNameWithImportantModifier.startsWith(IMPORTANT_MODIFIER);
    const baseClassName = hasImportantModifier ? baseClassNameWithImportantModifier.substring(1) : baseClassNameWithImportantModifier;
    const maybePostfixModifierPosition = postfixModifierPosition && postfixModifierPosition > modifierStart ? postfixModifierPosition - modifierStart : void 0;
    return {
      modifiers,
      hasImportantModifier,
      baseClassName,
      maybePostfixModifierPosition
    };
  };
  if (experimentalParseClassName) {
    return (className) => experimentalParseClassName({
      className,
      parseClassName
    });
  }
  return parseClassName;
};
var sortModifiers = (modifiers) => {
  if (modifiers.length <= 1) {
    return modifiers;
  }
  const sortedModifiers = [];
  let unsortedModifiers = [];
  modifiers.forEach((modifier) => {
    const isArbitraryVariant = modifier[0] === "[";
    if (isArbitraryVariant) {
      sortedModifiers.push(...unsortedModifiers.sort(), modifier);
      unsortedModifiers = [];
    } else {
      unsortedModifiers.push(modifier);
    }
  });
  sortedModifiers.push(...unsortedModifiers.sort());
  return sortedModifiers;
};
var createConfigUtils = (config) => ({
  cache: createLruCache(config.cacheSize),
  parseClassName: createParseClassName(config),
  ...createClassGroupUtils(config)
});
var SPLIT_CLASSES_REGEX = /\s+/;
var mergeClassList = (classList, configUtils) => {
  const {
    parseClassName,
    getClassGroupId,
    getConflictingClassGroupIds
  } = configUtils;
  const classGroupsInConflict = [];
  const classNames = classList.trim().split(SPLIT_CLASSES_REGEX);
  let result = "";
  for (let index = classNames.length - 1; index >= 0; index -= 1) {
    const originalClassName = classNames[index];
    const {
      modifiers,
      hasImportantModifier,
      baseClassName,
      maybePostfixModifierPosition
    } = parseClassName(originalClassName);
    let hasPostfixModifier = Boolean(maybePostfixModifierPosition);
    let classGroupId = getClassGroupId(hasPostfixModifier ? baseClassName.substring(0, maybePostfixModifierPosition) : baseClassName);
    if (!classGroupId) {
      if (!hasPostfixModifier) {
        result = originalClassName + (result.length > 0 ? " " + result : result);
        continue;
      }
      classGroupId = getClassGroupId(baseClassName);
      if (!classGroupId) {
        result = originalClassName + (result.length > 0 ? " " + result : result);
        continue;
      }
      hasPostfixModifier = false;
    }
    const variantModifier = sortModifiers(modifiers).join(":");
    const modifierId = hasImportantModifier ? variantModifier + IMPORTANT_MODIFIER : variantModifier;
    const classId = modifierId + classGroupId;
    if (classGroupsInConflict.includes(classId)) {
      continue;
    }
    classGroupsInConflict.push(classId);
    const conflictGroups = getConflictingClassGroupIds(classGroupId, hasPostfixModifier);
    for (let i = 0; i < conflictGroups.length; ++i) {
      const group = conflictGroups[i];
      classGroupsInConflict.push(modifierId + group);
    }
    result = originalClassName + (result.length > 0 ? " " + result : result);
  }
  return result;
};
function twJoin() {
  let index = 0;
  let argument;
  let resolvedValue;
  let string = "";
  while (index < arguments.length) {
    if (argument = arguments[index++]) {
      if (resolvedValue = toValue(argument)) {
        string && (string += " ");
        string += resolvedValue;
      }
    }
  }
  return string;
}
var toValue = (mix) => {
  if (typeof mix === "string") {
    return mix;
  }
  let resolvedValue;
  let string = "";
  for (let k = 0; k < mix.length; k++) {
    if (mix[k]) {
      if (resolvedValue = toValue(mix[k])) {
        string && (string += " ");
        string += resolvedValue;
      }
    }
  }
  return string;
};
function createTailwindMerge(createConfigFirst, ...createConfigRest) {
  let configUtils;
  let cacheGet;
  let cacheSet;
  let functionToCall = initTailwindMerge;
  function initTailwindMerge(classList) {
    const config = createConfigRest.reduce((previousConfig, createConfigCurrent) => createConfigCurrent(previousConfig), createConfigFirst());
    configUtils = createConfigUtils(config);
    cacheGet = configUtils.cache.get;
    cacheSet = configUtils.cache.set;
    functionToCall = tailwindMerge;
    return tailwindMerge(classList);
  }
  function tailwindMerge(classList) {
    const cachedResult = cacheGet(classList);
    if (cachedResult) {
      return cachedResult;
    }
    const result = mergeClassList(classList, configUtils);
    cacheSet(classList, result);
    return result;
  }
  return function callTailwindMerge() {
    return functionToCall(twJoin.apply(null, arguments));
  };
}
var fromTheme = (key) => {
  const themeGetter = (theme) => theme[key] || [];
  themeGetter.isThemeGetter = true;
  return themeGetter;
};
var arbitraryValueRegex = /^\[(?:([a-z-]+):)?(.+)\]$/i;
var fractionRegex = /^\d+\/\d+$/;
var stringLengths = /* @__PURE__ */ new Set(["px", "full", "screen"]);
var tshirtUnitRegex = /^(\d+(\.\d+)?)?(xs|sm|md|lg|xl)$/;
var lengthUnitRegex = /\d+(%|px|r?em|[sdl]?v([hwib]|min|max)|pt|pc|in|cm|mm|cap|ch|ex|r?lh|cq(w|h|i|b|min|max))|\b(calc|min|max|clamp)\(.+\)|^0$/;
var colorFunctionRegex = /^(rgba?|hsla?|hwb|(ok)?(lab|lch)|color-mix)\(.+\)$/;
var shadowRegex = /^(inset_)?-?((\d+)?\.?(\d+)[a-z]+|0)_-?((\d+)?\.?(\d+)[a-z]+|0)/;
var imageRegex = /^(url|image|image-set|cross-fade|element|(repeating-)?(linear|radial|conic)-gradient)\(.+\)$/;
var isLength = (value) => isNumber(value) || stringLengths.has(value) || fractionRegex.test(value);
var isArbitraryLength = (value) => getIsArbitraryValue(value, "length", isLengthOnly);
var isNumber = (value) => Boolean(value) && !Number.isNaN(Number(value));
var isArbitraryNumber = (value) => getIsArbitraryValue(value, "number", isNumber);
var isInteger = (value) => Boolean(value) && Number.isInteger(Number(value));
var isPercent = (value) => value.endsWith("%") && isNumber(value.slice(0, -1));
var isArbitraryValue = (value) => arbitraryValueRegex.test(value);
var isTshirtSize = (value) => tshirtUnitRegex.test(value);
var sizeLabels = /* @__PURE__ */ new Set(["length", "size", "percentage"]);
var isArbitrarySize = (value) => getIsArbitraryValue(value, sizeLabels, isNever);
var isArbitraryPosition = (value) => getIsArbitraryValue(value, "position", isNever);
var imageLabels = /* @__PURE__ */ new Set(["image", "url"]);
var isArbitraryImage = (value) => getIsArbitraryValue(value, imageLabels, isImage);
var isArbitraryShadow = (value) => getIsArbitraryValue(value, "", isShadow);
var isAny = () => true;
var getIsArbitraryValue = (value, label, testValue) => {
  const result = arbitraryValueRegex.exec(value);
  if (result) {
    if (result[1]) {
      return typeof label === "string" ? result[1] === label : label.has(result[1]);
    }
    return testValue(result[2]);
  }
  return false;
};
var isLengthOnly = (value) => (
  // `colorFunctionRegex` check is necessary because color functions can have percentages in them which which would be incorrectly classified as lengths.
  // For example, `hsl(0 0% 0%)` would be classified as a length without this check.
  // I could also use lookbehind assertion in `lengthUnitRegex` but that isn't supported widely enough.
  lengthUnitRegex.test(value) && !colorFunctionRegex.test(value)
);
var isNever = () => false;
var isShadow = (value) => shadowRegex.test(value);
var isImage = (value) => imageRegex.test(value);
var getDefaultConfig = () => {
  const colors = fromTheme("colors");
  const spacing = fromTheme("spacing");
  const blur = fromTheme("blur");
  const brightness = fromTheme("brightness");
  const borderColor = fromTheme("borderColor");
  const borderRadius = fromTheme("borderRadius");
  const borderSpacing = fromTheme("borderSpacing");
  const borderWidth = fromTheme("borderWidth");
  const contrast = fromTheme("contrast");
  const grayscale = fromTheme("grayscale");
  const hueRotate = fromTheme("hueRotate");
  const invert = fromTheme("invert");
  const gap = fromTheme("gap");
  const gradientColorStops = fromTheme("gradientColorStops");
  const gradientColorStopPositions = fromTheme("gradientColorStopPositions");
  const inset = fromTheme("inset");
  const margin = fromTheme("margin");
  const opacity = fromTheme("opacity");
  const padding = fromTheme("padding");
  const saturate = fromTheme("saturate");
  const scale = fromTheme("scale");
  const sepia = fromTheme("sepia");
  const skew = fromTheme("skew");
  const space = fromTheme("space");
  const translate = fromTheme("translate");
  const getOverscroll = () => ["auto", "contain", "none"];
  const getOverflow = () => ["auto", "hidden", "clip", "visible", "scroll"];
  const getSpacingWithAutoAndArbitrary = () => ["auto", isArbitraryValue, spacing];
  const getSpacingWithArbitrary = () => [isArbitraryValue, spacing];
  const getLengthWithEmptyAndArbitrary = () => ["", isLength, isArbitraryLength];
  const getNumberWithAutoAndArbitrary = () => ["auto", isNumber, isArbitraryValue];
  const getPositions = () => ["bottom", "center", "left", "left-bottom", "left-top", "right", "right-bottom", "right-top", "top"];
  const getLineStyles = () => ["solid", "dashed", "dotted", "double", "none"];
  const getBlendModes = () => ["normal", "multiply", "screen", "overlay", "darken", "lighten", "color-dodge", "color-burn", "hard-light", "soft-light", "difference", "exclusion", "hue", "saturation", "color", "luminosity"];
  const getAlign = () => ["start", "end", "center", "between", "around", "evenly", "stretch"];
  const getZeroAndEmpty = () => ["", "0", isArbitraryValue];
  const getBreaks = () => ["auto", "avoid", "all", "avoid-page", "page", "left", "right", "column"];
  const getNumberAndArbitrary = () => [isNumber, isArbitraryValue];
  return {
    cacheSize: 500,
    separator: ":",
    theme: {
      colors: [isAny],
      spacing: [isLength, isArbitraryLength],
      blur: ["none", "", isTshirtSize, isArbitraryValue],
      brightness: getNumberAndArbitrary(),
      borderColor: [colors],
      borderRadius: ["none", "", "full", isTshirtSize, isArbitraryValue],
      borderSpacing: getSpacingWithArbitrary(),
      borderWidth: getLengthWithEmptyAndArbitrary(),
      contrast: getNumberAndArbitrary(),
      grayscale: getZeroAndEmpty(),
      hueRotate: getNumberAndArbitrary(),
      invert: getZeroAndEmpty(),
      gap: getSpacingWithArbitrary(),
      gradientColorStops: [colors],
      gradientColorStopPositions: [isPercent, isArbitraryLength],
      inset: getSpacingWithAutoAndArbitrary(),
      margin: getSpacingWithAutoAndArbitrary(),
      opacity: getNumberAndArbitrary(),
      padding: getSpacingWithArbitrary(),
      saturate: getNumberAndArbitrary(),
      scale: getNumberAndArbitrary(),
      sepia: getZeroAndEmpty(),
      skew: getNumberAndArbitrary(),
      space: getSpacingWithArbitrary(),
      translate: getSpacingWithArbitrary()
    },
    classGroups: {
      // Layout
      /**
       * Aspect Ratio
       * @see https://tailwindcss.com/docs/aspect-ratio
       */
      aspect: [{
        aspect: ["auto", "square", "video", isArbitraryValue]
      }],
      /**
       * Container
       * @see https://tailwindcss.com/docs/container
       */
      container: ["container"],
      /**
       * Columns
       * @see https://tailwindcss.com/docs/columns
       */
      columns: [{
        columns: [isTshirtSize]
      }],
      /**
       * Break After
       * @see https://tailwindcss.com/docs/break-after
       */
      "break-after": [{
        "break-after": getBreaks()
      }],
      /**
       * Break Before
       * @see https://tailwindcss.com/docs/break-before
       */
      "break-before": [{
        "break-before": getBreaks()
      }],
      /**
       * Break Inside
       * @see https://tailwindcss.com/docs/break-inside
       */
      "break-inside": [{
        "break-inside": ["auto", "avoid", "avoid-page", "avoid-column"]
      }],
      /**
       * Box Decoration Break
       * @see https://tailwindcss.com/docs/box-decoration-break
       */
      "box-decoration": [{
        "box-decoration": ["slice", "clone"]
      }],
      /**
       * Box Sizing
       * @see https://tailwindcss.com/docs/box-sizing
       */
      box: [{
        box: ["border", "content"]
      }],
      /**
       * Display
       * @see https://tailwindcss.com/docs/display
       */
      display: ["block", "inline-block", "inline", "flex", "inline-flex", "table", "inline-table", "table-caption", "table-cell", "table-column", "table-column-group", "table-footer-group", "table-header-group", "table-row-group", "table-row", "flow-root", "grid", "inline-grid", "contents", "list-item", "hidden"],
      /**
       * Floats
       * @see https://tailwindcss.com/docs/float
       */
      float: [{
        float: ["right", "left", "none", "start", "end"]
      }],
      /**
       * Clear
       * @see https://tailwindcss.com/docs/clear
       */
      clear: [{
        clear: ["left", "right", "both", "none", "start", "end"]
      }],
      /**
       * Isolation
       * @see https://tailwindcss.com/docs/isolation
       */
      isolation: ["isolate", "isolation-auto"],
      /**
       * Object Fit
       * @see https://tailwindcss.com/docs/object-fit
       */
      "object-fit": [{
        object: ["contain", "cover", "fill", "none", "scale-down"]
      }],
      /**
       * Object Position
       * @see https://tailwindcss.com/docs/object-position
       */
      "object-position": [{
        object: [...getPositions(), isArbitraryValue]
      }],
      /**
       * Overflow
       * @see https://tailwindcss.com/docs/overflow
       */
      overflow: [{
        overflow: getOverflow()
      }],
      /**
       * Overflow X
       * @see https://tailwindcss.com/docs/overflow
       */
      "overflow-x": [{
        "overflow-x": getOverflow()
      }],
      /**
       * Overflow Y
       * @see https://tailwindcss.com/docs/overflow
       */
      "overflow-y": [{
        "overflow-y": getOverflow()
      }],
      /**
       * Overscroll Behavior
       * @see https://tailwindcss.com/docs/overscroll-behavior
       */
      overscroll: [{
        overscroll: getOverscroll()
      }],
      /**
       * Overscroll Behavior X
       * @see https://tailwindcss.com/docs/overscroll-behavior
       */
      "overscroll-x": [{
        "overscroll-x": getOverscroll()
      }],
      /**
       * Overscroll Behavior Y
       * @see https://tailwindcss.com/docs/overscroll-behavior
       */
      "overscroll-y": [{
        "overscroll-y": getOverscroll()
      }],
      /**
       * Position
       * @see https://tailwindcss.com/docs/position
       */
      position: ["static", "fixed", "absolute", "relative", "sticky"],
      /**
       * Top / Right / Bottom / Left
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      inset: [{
        inset: [inset]
      }],
      /**
       * Right / Left
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      "inset-x": [{
        "inset-x": [inset]
      }],
      /**
       * Top / Bottom
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      "inset-y": [{
        "inset-y": [inset]
      }],
      /**
       * Start
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      start: [{
        start: [inset]
      }],
      /**
       * End
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      end: [{
        end: [inset]
      }],
      /**
       * Top
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      top: [{
        top: [inset]
      }],
      /**
       * Right
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      right: [{
        right: [inset]
      }],
      /**
       * Bottom
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      bottom: [{
        bottom: [inset]
      }],
      /**
       * Left
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      left: [{
        left: [inset]
      }],
      /**
       * Visibility
       * @see https://tailwindcss.com/docs/visibility
       */
      visibility: ["visible", "invisible", "collapse"],
      /**
       * Z-Index
       * @see https://tailwindcss.com/docs/z-index
       */
      z: [{
        z: ["auto", isInteger, isArbitraryValue]
      }],
      // Flexbox and Grid
      /**
       * Flex Basis
       * @see https://tailwindcss.com/docs/flex-basis
       */
      basis: [{
        basis: getSpacingWithAutoAndArbitrary()
      }],
      /**
       * Flex Direction
       * @see https://tailwindcss.com/docs/flex-direction
       */
      "flex-direction": [{
        flex: ["row", "row-reverse", "col", "col-reverse"]
      }],
      /**
       * Flex Wrap
       * @see https://tailwindcss.com/docs/flex-wrap
       */
      "flex-wrap": [{
        flex: ["wrap", "wrap-reverse", "nowrap"]
      }],
      /**
       * Flex
       * @see https://tailwindcss.com/docs/flex
       */
      flex: [{
        flex: ["1", "auto", "initial", "none", isArbitraryValue]
      }],
      /**
       * Flex Grow
       * @see https://tailwindcss.com/docs/flex-grow
       */
      grow: [{
        grow: getZeroAndEmpty()
      }],
      /**
       * Flex Shrink
       * @see https://tailwindcss.com/docs/flex-shrink
       */
      shrink: [{
        shrink: getZeroAndEmpty()
      }],
      /**
       * Order
       * @see https://tailwindcss.com/docs/order
       */
      order: [{
        order: ["first", "last", "none", isInteger, isArbitraryValue]
      }],
      /**
       * Grid Template Columns
       * @see https://tailwindcss.com/docs/grid-template-columns
       */
      "grid-cols": [{
        "grid-cols": [isAny]
      }],
      /**
       * Grid Column Start / End
       * @see https://tailwindcss.com/docs/grid-column
       */
      "col-start-end": [{
        col: ["auto", {
          span: ["full", isInteger, isArbitraryValue]
        }, isArbitraryValue]
      }],
      /**
       * Grid Column Start
       * @see https://tailwindcss.com/docs/grid-column
       */
      "col-start": [{
        "col-start": getNumberWithAutoAndArbitrary()
      }],
      /**
       * Grid Column End
       * @see https://tailwindcss.com/docs/grid-column
       */
      "col-end": [{
        "col-end": getNumberWithAutoAndArbitrary()
      }],
      /**
       * Grid Template Rows
       * @see https://tailwindcss.com/docs/grid-template-rows
       */
      "grid-rows": [{
        "grid-rows": [isAny]
      }],
      /**
       * Grid Row Start / End
       * @see https://tailwindcss.com/docs/grid-row
       */
      "row-start-end": [{
        row: ["auto", {
          span: [isInteger, isArbitraryValue]
        }, isArbitraryValue]
      }],
      /**
       * Grid Row Start
       * @see https://tailwindcss.com/docs/grid-row
       */
      "row-start": [{
        "row-start": getNumberWithAutoAndArbitrary()
      }],
      /**
       * Grid Row End
       * @see https://tailwindcss.com/docs/grid-row
       */
      "row-end": [{
        "row-end": getNumberWithAutoAndArbitrary()
      }],
      /**
       * Grid Auto Flow
       * @see https://tailwindcss.com/docs/grid-auto-flow
       */
      "grid-flow": [{
        "grid-flow": ["row", "col", "dense", "row-dense", "col-dense"]
      }],
      /**
       * Grid Auto Columns
       * @see https://tailwindcss.com/docs/grid-auto-columns
       */
      "auto-cols": [{
        "auto-cols": ["auto", "min", "max", "fr", isArbitraryValue]
      }],
      /**
       * Grid Auto Rows
       * @see https://tailwindcss.com/docs/grid-auto-rows
       */
      "auto-rows": [{
        "auto-rows": ["auto", "min", "max", "fr", isArbitraryValue]
      }],
      /**
       * Gap
       * @see https://tailwindcss.com/docs/gap
       */
      gap: [{
        gap: [gap]
      }],
      /**
       * Gap X
       * @see https://tailwindcss.com/docs/gap
       */
      "gap-x": [{
        "gap-x": [gap]
      }],
      /**
       * Gap Y
       * @see https://tailwindcss.com/docs/gap
       */
      "gap-y": [{
        "gap-y": [gap]
      }],
      /**
       * Justify Content
       * @see https://tailwindcss.com/docs/justify-content
       */
      "justify-content": [{
        justify: ["normal", ...getAlign()]
      }],
      /**
       * Justify Items
       * @see https://tailwindcss.com/docs/justify-items
       */
      "justify-items": [{
        "justify-items": ["start", "end", "center", "stretch"]
      }],
      /**
       * Justify Self
       * @see https://tailwindcss.com/docs/justify-self
       */
      "justify-self": [{
        "justify-self": ["auto", "start", "end", "center", "stretch"]
      }],
      /**
       * Align Content
       * @see https://tailwindcss.com/docs/align-content
       */
      "align-content": [{
        content: ["normal", ...getAlign(), "baseline"]
      }],
      /**
       * Align Items
       * @see https://tailwindcss.com/docs/align-items
       */
      "align-items": [{
        items: ["start", "end", "center", "baseline", "stretch"]
      }],
      /**
       * Align Self
       * @see https://tailwindcss.com/docs/align-self
       */
      "align-self": [{
        self: ["auto", "start", "end", "center", "stretch", "baseline"]
      }],
      /**
       * Place Content
       * @see https://tailwindcss.com/docs/place-content
       */
      "place-content": [{
        "place-content": [...getAlign(), "baseline"]
      }],
      /**
       * Place Items
       * @see https://tailwindcss.com/docs/place-items
       */
      "place-items": [{
        "place-items": ["start", "end", "center", "baseline", "stretch"]
      }],
      /**
       * Place Self
       * @see https://tailwindcss.com/docs/place-self
       */
      "place-self": [{
        "place-self": ["auto", "start", "end", "center", "stretch"]
      }],
      // Spacing
      /**
       * Padding
       * @see https://tailwindcss.com/docs/padding
       */
      p: [{
        p: [padding]
      }],
      /**
       * Padding X
       * @see https://tailwindcss.com/docs/padding
       */
      px: [{
        px: [padding]
      }],
      /**
       * Padding Y
       * @see https://tailwindcss.com/docs/padding
       */
      py: [{
        py: [padding]
      }],
      /**
       * Padding Start
       * @see https://tailwindcss.com/docs/padding
       */
      ps: [{
        ps: [padding]
      }],
      /**
       * Padding End
       * @see https://tailwindcss.com/docs/padding
       */
      pe: [{
        pe: [padding]
      }],
      /**
       * Padding Top
       * @see https://tailwindcss.com/docs/padding
       */
      pt: [{
        pt: [padding]
      }],
      /**
       * Padding Right
       * @see https://tailwindcss.com/docs/padding
       */
      pr: [{
        pr: [padding]
      }],
      /**
       * Padding Bottom
       * @see https://tailwindcss.com/docs/padding
       */
      pb: [{
        pb: [padding]
      }],
      /**
       * Padding Left
       * @see https://tailwindcss.com/docs/padding
       */
      pl: [{
        pl: [padding]
      }],
      /**
       * Margin
       * @see https://tailwindcss.com/docs/margin
       */
      m: [{
        m: [margin]
      }],
      /**
       * Margin X
       * @see https://tailwindcss.com/docs/margin
       */
      mx: [{
        mx: [margin]
      }],
      /**
       * Margin Y
       * @see https://tailwindcss.com/docs/margin
       */
      my: [{
        my: [margin]
      }],
      /**
       * Margin Start
       * @see https://tailwindcss.com/docs/margin
       */
      ms: [{
        ms: [margin]
      }],
      /**
       * Margin End
       * @see https://tailwindcss.com/docs/margin
       */
      me: [{
        me: [margin]
      }],
      /**
       * Margin Top
       * @see https://tailwindcss.com/docs/margin
       */
      mt: [{
        mt: [margin]
      }],
      /**
       * Margin Right
       * @see https://tailwindcss.com/docs/margin
       */
      mr: [{
        mr: [margin]
      }],
      /**
       * Margin Bottom
       * @see https://tailwindcss.com/docs/margin
       */
      mb: [{
        mb: [margin]
      }],
      /**
       * Margin Left
       * @see https://tailwindcss.com/docs/margin
       */
      ml: [{
        ml: [margin]
      }],
      /**
       * Space Between X
       * @see https://tailwindcss.com/docs/space
       */
      "space-x": [{
        "space-x": [space]
      }],
      /**
       * Space Between X Reverse
       * @see https://tailwindcss.com/docs/space
       */
      "space-x-reverse": ["space-x-reverse"],
      /**
       * Space Between Y
       * @see https://tailwindcss.com/docs/space
       */
      "space-y": [{
        "space-y": [space]
      }],
      /**
       * Space Between Y Reverse
       * @see https://tailwindcss.com/docs/space
       */
      "space-y-reverse": ["space-y-reverse"],
      // Sizing
      /**
       * Width
       * @see https://tailwindcss.com/docs/width
       */
      w: [{
        w: ["auto", "min", "max", "fit", "svw", "lvw", "dvw", isArbitraryValue, spacing]
      }],
      /**
       * Min-Width
       * @see https://tailwindcss.com/docs/min-width
       */
      "min-w": [{
        "min-w": [isArbitraryValue, spacing, "min", "max", "fit"]
      }],
      /**
       * Max-Width
       * @see https://tailwindcss.com/docs/max-width
       */
      "max-w": [{
        "max-w": [isArbitraryValue, spacing, "none", "full", "min", "max", "fit", "prose", {
          screen: [isTshirtSize]
        }, isTshirtSize]
      }],
      /**
       * Height
       * @see https://tailwindcss.com/docs/height
       */
      h: [{
        h: [isArbitraryValue, spacing, "auto", "min", "max", "fit", "svh", "lvh", "dvh"]
      }],
      /**
       * Min-Height
       * @see https://tailwindcss.com/docs/min-height
       */
      "min-h": [{
        "min-h": [isArbitraryValue, spacing, "min", "max", "fit", "svh", "lvh", "dvh"]
      }],
      /**
       * Max-Height
       * @see https://tailwindcss.com/docs/max-height
       */
      "max-h": [{
        "max-h": [isArbitraryValue, spacing, "min", "max", "fit", "svh", "lvh", "dvh"]
      }],
      /**
       * Size
       * @see https://tailwindcss.com/docs/size
       */
      size: [{
        size: [isArbitraryValue, spacing, "auto", "min", "max", "fit"]
      }],
      // Typography
      /**
       * Font Size
       * @see https://tailwindcss.com/docs/font-size
       */
      "font-size": [{
        text: ["base", isTshirtSize, isArbitraryLength]
      }],
      /**
       * Font Smoothing
       * @see https://tailwindcss.com/docs/font-smoothing
       */
      "font-smoothing": ["antialiased", "subpixel-antialiased"],
      /**
       * Font Style
       * @see https://tailwindcss.com/docs/font-style
       */
      "font-style": ["italic", "not-italic"],
      /**
       * Font Weight
       * @see https://tailwindcss.com/docs/font-weight
       */
      "font-weight": [{
        font: ["thin", "extralight", "light", "normal", "medium", "semibold", "bold", "extrabold", "black", isArbitraryNumber]
      }],
      /**
       * Font Family
       * @see https://tailwindcss.com/docs/font-family
       */
      "font-family": [{
        font: [isAny]
      }],
      /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */
      "fvn-normal": ["normal-nums"],
      /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */
      "fvn-ordinal": ["ordinal"],
      /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */
      "fvn-slashed-zero": ["slashed-zero"],
      /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */
      "fvn-figure": ["lining-nums", "oldstyle-nums"],
      /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */
      "fvn-spacing": ["proportional-nums", "tabular-nums"],
      /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */
      "fvn-fraction": ["diagonal-fractions", "stacked-fractions"],
      /**
       * Letter Spacing
       * @see https://tailwindcss.com/docs/letter-spacing
       */
      tracking: [{
        tracking: ["tighter", "tight", "normal", "wide", "wider", "widest", isArbitraryValue]
      }],
      /**
       * Line Clamp
       * @see https://tailwindcss.com/docs/line-clamp
       */
      "line-clamp": [{
        "line-clamp": ["none", isNumber, isArbitraryNumber]
      }],
      /**
       * Line Height
       * @see https://tailwindcss.com/docs/line-height
       */
      leading: [{
        leading: ["none", "tight", "snug", "normal", "relaxed", "loose", isLength, isArbitraryValue]
      }],
      /**
       * List Style Image
       * @see https://tailwindcss.com/docs/list-style-image
       */
      "list-image": [{
        "list-image": ["none", isArbitraryValue]
      }],
      /**
       * List Style Type
       * @see https://tailwindcss.com/docs/list-style-type
       */
      "list-style-type": [{
        list: ["none", "disc", "decimal", isArbitraryValue]
      }],
      /**
       * List Style Position
       * @see https://tailwindcss.com/docs/list-style-position
       */
      "list-style-position": [{
        list: ["inside", "outside"]
      }],
      /**
       * Placeholder Color
       * @deprecated since Tailwind CSS v3.0.0
       * @see https://tailwindcss.com/docs/placeholder-color
       */
      "placeholder-color": [{
        placeholder: [colors]
      }],
      /**
       * Placeholder Opacity
       * @see https://tailwindcss.com/docs/placeholder-opacity
       */
      "placeholder-opacity": [{
        "placeholder-opacity": [opacity]
      }],
      /**
       * Text Alignment
       * @see https://tailwindcss.com/docs/text-align
       */
      "text-alignment": [{
        text: ["left", "center", "right", "justify", "start", "end"]
      }],
      /**
       * Text Color
       * @see https://tailwindcss.com/docs/text-color
       */
      "text-color": [{
        text: [colors]
      }],
      /**
       * Text Opacity
       * @see https://tailwindcss.com/docs/text-opacity
       */
      "text-opacity": [{
        "text-opacity": [opacity]
      }],
      /**
       * Text Decoration
       * @see https://tailwindcss.com/docs/text-decoration
       */
      "text-decoration": ["underline", "overline", "line-through", "no-underline"],
      /**
       * Text Decoration Style
       * @see https://tailwindcss.com/docs/text-decoration-style
       */
      "text-decoration-style": [{
        decoration: [...getLineStyles(), "wavy"]
      }],
      /**
       * Text Decoration Thickness
       * @see https://tailwindcss.com/docs/text-decoration-thickness
       */
      "text-decoration-thickness": [{
        decoration: ["auto", "from-font", isLength, isArbitraryLength]
      }],
      /**
       * Text Underline Offset
       * @see https://tailwindcss.com/docs/text-underline-offset
       */
      "underline-offset": [{
        "underline-offset": ["auto", isLength, isArbitraryValue]
      }],
      /**
       * Text Decoration Color
       * @see https://tailwindcss.com/docs/text-decoration-color
       */
      "text-decoration-color": [{
        decoration: [colors]
      }],
      /**
       * Text Transform
       * @see https://tailwindcss.com/docs/text-transform
       */
      "text-transform": ["uppercase", "lowercase", "capitalize", "normal-case"],
      /**
       * Text Overflow
       * @see https://tailwindcss.com/docs/text-overflow
       */
      "text-overflow": ["truncate", "text-ellipsis", "text-clip"],
      /**
       * Text Wrap
       * @see https://tailwindcss.com/docs/text-wrap
       */
      "text-wrap": [{
        text: ["wrap", "nowrap", "balance", "pretty"]
      }],
      /**
       * Text Indent
       * @see https://tailwindcss.com/docs/text-indent
       */
      indent: [{
        indent: getSpacingWithArbitrary()
      }],
      /**
       * Vertical Alignment
       * @see https://tailwindcss.com/docs/vertical-align
       */
      "vertical-align": [{
        align: ["baseline", "top", "middle", "bottom", "text-top", "text-bottom", "sub", "super", isArbitraryValue]
      }],
      /**
       * Whitespace
       * @see https://tailwindcss.com/docs/whitespace
       */
      whitespace: [{
        whitespace: ["normal", "nowrap", "pre", "pre-line", "pre-wrap", "break-spaces"]
      }],
      /**
       * Word Break
       * @see https://tailwindcss.com/docs/word-break
       */
      break: [{
        break: ["normal", "words", "all", "keep"]
      }],
      /**
       * Hyphens
       * @see https://tailwindcss.com/docs/hyphens
       */
      hyphens: [{
        hyphens: ["none", "manual", "auto"]
      }],
      /**
       * Content
       * @see https://tailwindcss.com/docs/content
       */
      content: [{
        content: ["none", isArbitraryValue]
      }],
      // Backgrounds
      /**
       * Background Attachment
       * @see https://tailwindcss.com/docs/background-attachment
       */
      "bg-attachment": [{
        bg: ["fixed", "local", "scroll"]
      }],
      /**
       * Background Clip
       * @see https://tailwindcss.com/docs/background-clip
       */
      "bg-clip": [{
        "bg-clip": ["border", "padding", "content", "text"]
      }],
      /**
       * Background Opacity
       * @deprecated since Tailwind CSS v3.0.0
       * @see https://tailwindcss.com/docs/background-opacity
       */
      "bg-opacity": [{
        "bg-opacity": [opacity]
      }],
      /**
       * Background Origin
       * @see https://tailwindcss.com/docs/background-origin
       */
      "bg-origin": [{
        "bg-origin": ["border", "padding", "content"]
      }],
      /**
       * Background Position
       * @see https://tailwindcss.com/docs/background-position
       */
      "bg-position": [{
        bg: [...getPositions(), isArbitraryPosition]
      }],
      /**
       * Background Repeat
       * @see https://tailwindcss.com/docs/background-repeat
       */
      "bg-repeat": [{
        bg: ["no-repeat", {
          repeat: ["", "x", "y", "round", "space"]
        }]
      }],
      /**
       * Background Size
       * @see https://tailwindcss.com/docs/background-size
       */
      "bg-size": [{
        bg: ["auto", "cover", "contain", isArbitrarySize]
      }],
      /**
       * Background Image
       * @see https://tailwindcss.com/docs/background-image
       */
      "bg-image": [{
        bg: ["none", {
          "gradient-to": ["t", "tr", "r", "br", "b", "bl", "l", "tl"]
        }, isArbitraryImage]
      }],
      /**
       * Background Color
       * @see https://tailwindcss.com/docs/background-color
       */
      "bg-color": [{
        bg: [colors]
      }],
      /**
       * Gradient Color Stops From Position
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */
      "gradient-from-pos": [{
        from: [gradientColorStopPositions]
      }],
      /**
       * Gradient Color Stops Via Position
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */
      "gradient-via-pos": [{
        via: [gradientColorStopPositions]
      }],
      /**
       * Gradient Color Stops To Position
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */
      "gradient-to-pos": [{
        to: [gradientColorStopPositions]
      }],
      /**
       * Gradient Color Stops From
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */
      "gradient-from": [{
        from: [gradientColorStops]
      }],
      /**
       * Gradient Color Stops Via
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */
      "gradient-via": [{
        via: [gradientColorStops]
      }],
      /**
       * Gradient Color Stops To
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */
      "gradient-to": [{
        to: [gradientColorStops]
      }],
      // Borders
      /**
       * Border Radius
       * @see https://tailwindcss.com/docs/border-radius
       */
      rounded: [{
        rounded: [borderRadius]
      }],
      /**
       * Border Radius Start
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-s": [{
        "rounded-s": [borderRadius]
      }],
      /**
       * Border Radius End
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-e": [{
        "rounded-e": [borderRadius]
      }],
      /**
       * Border Radius Top
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-t": [{
        "rounded-t": [borderRadius]
      }],
      /**
       * Border Radius Right
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-r": [{
        "rounded-r": [borderRadius]
      }],
      /**
       * Border Radius Bottom
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-b": [{
        "rounded-b": [borderRadius]
      }],
      /**
       * Border Radius Left
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-l": [{
        "rounded-l": [borderRadius]
      }],
      /**
       * Border Radius Start Start
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-ss": [{
        "rounded-ss": [borderRadius]
      }],
      /**
       * Border Radius Start End
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-se": [{
        "rounded-se": [borderRadius]
      }],
      /**
       * Border Radius End End
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-ee": [{
        "rounded-ee": [borderRadius]
      }],
      /**
       * Border Radius End Start
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-es": [{
        "rounded-es": [borderRadius]
      }],
      /**
       * Border Radius Top Left
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-tl": [{
        "rounded-tl": [borderRadius]
      }],
      /**
       * Border Radius Top Right
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-tr": [{
        "rounded-tr": [borderRadius]
      }],
      /**
       * Border Radius Bottom Right
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-br": [{
        "rounded-br": [borderRadius]
      }],
      /**
       * Border Radius Bottom Left
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-bl": [{
        "rounded-bl": [borderRadius]
      }],
      /**
       * Border Width
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w": [{
        border: [borderWidth]
      }],
      /**
       * Border Width X
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-x": [{
        "border-x": [borderWidth]
      }],
      /**
       * Border Width Y
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-y": [{
        "border-y": [borderWidth]
      }],
      /**
       * Border Width Start
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-s": [{
        "border-s": [borderWidth]
      }],
      /**
       * Border Width End
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-e": [{
        "border-e": [borderWidth]
      }],
      /**
       * Border Width Top
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-t": [{
        "border-t": [borderWidth]
      }],
      /**
       * Border Width Right
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-r": [{
        "border-r": [borderWidth]
      }],
      /**
       * Border Width Bottom
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-b": [{
        "border-b": [borderWidth]
      }],
      /**
       * Border Width Left
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-l": [{
        "border-l": [borderWidth]
      }],
      /**
       * Border Opacity
       * @see https://tailwindcss.com/docs/border-opacity
       */
      "border-opacity": [{
        "border-opacity": [opacity]
      }],
      /**
       * Border Style
       * @see https://tailwindcss.com/docs/border-style
       */
      "border-style": [{
        border: [...getLineStyles(), "hidden"]
      }],
      /**
       * Divide Width X
       * @see https://tailwindcss.com/docs/divide-width
       */
      "divide-x": [{
        "divide-x": [borderWidth]
      }],
      /**
       * Divide Width X Reverse
       * @see https://tailwindcss.com/docs/divide-width
       */
      "divide-x-reverse": ["divide-x-reverse"],
      /**
       * Divide Width Y
       * @see https://tailwindcss.com/docs/divide-width
       */
      "divide-y": [{
        "divide-y": [borderWidth]
      }],
      /**
       * Divide Width Y Reverse
       * @see https://tailwindcss.com/docs/divide-width
       */
      "divide-y-reverse": ["divide-y-reverse"],
      /**
       * Divide Opacity
       * @see https://tailwindcss.com/docs/divide-opacity
       */
      "divide-opacity": [{
        "divide-opacity": [opacity]
      }],
      /**
       * Divide Style
       * @see https://tailwindcss.com/docs/divide-style
       */
      "divide-style": [{
        divide: getLineStyles()
      }],
      /**
       * Border Color
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color": [{
        border: [borderColor]
      }],
      /**
       * Border Color X
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-x": [{
        "border-x": [borderColor]
      }],
      /**
       * Border Color Y
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-y": [{
        "border-y": [borderColor]
      }],
      /**
       * Border Color S
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-s": [{
        "border-s": [borderColor]
      }],
      /**
       * Border Color E
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-e": [{
        "border-e": [borderColor]
      }],
      /**
       * Border Color Top
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-t": [{
        "border-t": [borderColor]
      }],
      /**
       * Border Color Right
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-r": [{
        "border-r": [borderColor]
      }],
      /**
       * Border Color Bottom
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-b": [{
        "border-b": [borderColor]
      }],
      /**
       * Border Color Left
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-l": [{
        "border-l": [borderColor]
      }],
      /**
       * Divide Color
       * @see https://tailwindcss.com/docs/divide-color
       */
      "divide-color": [{
        divide: [borderColor]
      }],
      /**
       * Outline Style
       * @see https://tailwindcss.com/docs/outline-style
       */
      "outline-style": [{
        outline: ["", ...getLineStyles()]
      }],
      /**
       * Outline Offset
       * @see https://tailwindcss.com/docs/outline-offset
       */
      "outline-offset": [{
        "outline-offset": [isLength, isArbitraryValue]
      }],
      /**
       * Outline Width
       * @see https://tailwindcss.com/docs/outline-width
       */
      "outline-w": [{
        outline: [isLength, isArbitraryLength]
      }],
      /**
       * Outline Color
       * @see https://tailwindcss.com/docs/outline-color
       */
      "outline-color": [{
        outline: [colors]
      }],
      /**
       * Ring Width
       * @see https://tailwindcss.com/docs/ring-width
       */
      "ring-w": [{
        ring: getLengthWithEmptyAndArbitrary()
      }],
      /**
       * Ring Width Inset
       * @see https://tailwindcss.com/docs/ring-width
       */
      "ring-w-inset": ["ring-inset"],
      /**
       * Ring Color
       * @see https://tailwindcss.com/docs/ring-color
       */
      "ring-color": [{
        ring: [colors]
      }],
      /**
       * Ring Opacity
       * @see https://tailwindcss.com/docs/ring-opacity
       */
      "ring-opacity": [{
        "ring-opacity": [opacity]
      }],
      /**
       * Ring Offset Width
       * @see https://tailwindcss.com/docs/ring-offset-width
       */
      "ring-offset-w": [{
        "ring-offset": [isLength, isArbitraryLength]
      }],
      /**
       * Ring Offset Color
       * @see https://tailwindcss.com/docs/ring-offset-color
       */
      "ring-offset-color": [{
        "ring-offset": [colors]
      }],
      // Effects
      /**
       * Box Shadow
       * @see https://tailwindcss.com/docs/box-shadow
       */
      shadow: [{
        shadow: ["", "inner", "none", isTshirtSize, isArbitraryShadow]
      }],
      /**
       * Box Shadow Color
       * @see https://tailwindcss.com/docs/box-shadow-color
       */
      "shadow-color": [{
        shadow: [isAny]
      }],
      /**
       * Opacity
       * @see https://tailwindcss.com/docs/opacity
       */
      opacity: [{
        opacity: [opacity]
      }],
      /**
       * Mix Blend Mode
       * @see https://tailwindcss.com/docs/mix-blend-mode
       */
      "mix-blend": [{
        "mix-blend": [...getBlendModes(), "plus-lighter", "plus-darker"]
      }],
      /**
       * Background Blend Mode
       * @see https://tailwindcss.com/docs/background-blend-mode
       */
      "bg-blend": [{
        "bg-blend": getBlendModes()
      }],
      // Filters
      /**
       * Filter
       * @deprecated since Tailwind CSS v3.0.0
       * @see https://tailwindcss.com/docs/filter
       */
      filter: [{
        filter: ["", "none"]
      }],
      /**
       * Blur
       * @see https://tailwindcss.com/docs/blur
       */
      blur: [{
        blur: [blur]
      }],
      /**
       * Brightness
       * @see https://tailwindcss.com/docs/brightness
       */
      brightness: [{
        brightness: [brightness]
      }],
      /**
       * Contrast
       * @see https://tailwindcss.com/docs/contrast
       */
      contrast: [{
        contrast: [contrast]
      }],
      /**
       * Drop Shadow
       * @see https://tailwindcss.com/docs/drop-shadow
       */
      "drop-shadow": [{
        "drop-shadow": ["", "none", isTshirtSize, isArbitraryValue]
      }],
      /**
       * Grayscale
       * @see https://tailwindcss.com/docs/grayscale
       */
      grayscale: [{
        grayscale: [grayscale]
      }],
      /**
       * Hue Rotate
       * @see https://tailwindcss.com/docs/hue-rotate
       */
      "hue-rotate": [{
        "hue-rotate": [hueRotate]
      }],
      /**
       * Invert
       * @see https://tailwindcss.com/docs/invert
       */
      invert: [{
        invert: [invert]
      }],
      /**
       * Saturate
       * @see https://tailwindcss.com/docs/saturate
       */
      saturate: [{
        saturate: [saturate]
      }],
      /**
       * Sepia
       * @see https://tailwindcss.com/docs/sepia
       */
      sepia: [{
        sepia: [sepia]
      }],
      /**
       * Backdrop Filter
       * @deprecated since Tailwind CSS v3.0.0
       * @see https://tailwindcss.com/docs/backdrop-filter
       */
      "backdrop-filter": [{
        "backdrop-filter": ["", "none"]
      }],
      /**
       * Backdrop Blur
       * @see https://tailwindcss.com/docs/backdrop-blur
       */
      "backdrop-blur": [{
        "backdrop-blur": [blur]
      }],
      /**
       * Backdrop Brightness
       * @see https://tailwindcss.com/docs/backdrop-brightness
       */
      "backdrop-brightness": [{
        "backdrop-brightness": [brightness]
      }],
      /**
       * Backdrop Contrast
       * @see https://tailwindcss.com/docs/backdrop-contrast
       */
      "backdrop-contrast": [{
        "backdrop-contrast": [contrast]
      }],
      /**
       * Backdrop Grayscale
       * @see https://tailwindcss.com/docs/backdrop-grayscale
       */
      "backdrop-grayscale": [{
        "backdrop-grayscale": [grayscale]
      }],
      /**
       * Backdrop Hue Rotate
       * @see https://tailwindcss.com/docs/backdrop-hue-rotate
       */
      "backdrop-hue-rotate": [{
        "backdrop-hue-rotate": [hueRotate]
      }],
      /**
       * Backdrop Invert
       * @see https://tailwindcss.com/docs/backdrop-invert
       */
      "backdrop-invert": [{
        "backdrop-invert": [invert]
      }],
      /**
       * Backdrop Opacity
       * @see https://tailwindcss.com/docs/backdrop-opacity
       */
      "backdrop-opacity": [{
        "backdrop-opacity": [opacity]
      }],
      /**
       * Backdrop Saturate
       * @see https://tailwindcss.com/docs/backdrop-saturate
       */
      "backdrop-saturate": [{
        "backdrop-saturate": [saturate]
      }],
      /**
       * Backdrop Sepia
       * @see https://tailwindcss.com/docs/backdrop-sepia
       */
      "backdrop-sepia": [{
        "backdrop-sepia": [sepia]
      }],
      // Tables
      /**
       * Border Collapse
       * @see https://tailwindcss.com/docs/border-collapse
       */
      "border-collapse": [{
        border: ["collapse", "separate"]
      }],
      /**
       * Border Spacing
       * @see https://tailwindcss.com/docs/border-spacing
       */
      "border-spacing": [{
        "border-spacing": [borderSpacing]
      }],
      /**
       * Border Spacing X
       * @see https://tailwindcss.com/docs/border-spacing
       */
      "border-spacing-x": [{
        "border-spacing-x": [borderSpacing]
      }],
      /**
       * Border Spacing Y
       * @see https://tailwindcss.com/docs/border-spacing
       */
      "border-spacing-y": [{
        "border-spacing-y": [borderSpacing]
      }],
      /**
       * Table Layout
       * @see https://tailwindcss.com/docs/table-layout
       */
      "table-layout": [{
        table: ["auto", "fixed"]
      }],
      /**
       * Caption Side
       * @see https://tailwindcss.com/docs/caption-side
       */
      caption: [{
        caption: ["top", "bottom"]
      }],
      // Transitions and Animation
      /**
       * Tranisition Property
       * @see https://tailwindcss.com/docs/transition-property
       */
      transition: [{
        transition: ["none", "all", "", "colors", "opacity", "shadow", "transform", isArbitraryValue]
      }],
      /**
       * Transition Duration
       * @see https://tailwindcss.com/docs/transition-duration
       */
      duration: [{
        duration: getNumberAndArbitrary()
      }],
      /**
       * Transition Timing Function
       * @see https://tailwindcss.com/docs/transition-timing-function
       */
      ease: [{
        ease: ["linear", "in", "out", "in-out", isArbitraryValue]
      }],
      /**
       * Transition Delay
       * @see https://tailwindcss.com/docs/transition-delay
       */
      delay: [{
        delay: getNumberAndArbitrary()
      }],
      /**
       * Animation
       * @see https://tailwindcss.com/docs/animation
       */
      animate: [{
        animate: ["none", "spin", "ping", "pulse", "bounce", isArbitraryValue]
      }],
      // Transforms
      /**
       * Transform
       * @see https://tailwindcss.com/docs/transform
       */
      transform: [{
        transform: ["", "gpu", "none"]
      }],
      /**
       * Scale
       * @see https://tailwindcss.com/docs/scale
       */
      scale: [{
        scale: [scale]
      }],
      /**
       * Scale X
       * @see https://tailwindcss.com/docs/scale
       */
      "scale-x": [{
        "scale-x": [scale]
      }],
      /**
       * Scale Y
       * @see https://tailwindcss.com/docs/scale
       */
      "scale-y": [{
        "scale-y": [scale]
      }],
      /**
       * Rotate
       * @see https://tailwindcss.com/docs/rotate
       */
      rotate: [{
        rotate: [isInteger, isArbitraryValue]
      }],
      /**
       * Translate X
       * @see https://tailwindcss.com/docs/translate
       */
      "translate-x": [{
        "translate-x": [translate]
      }],
      /**
       * Translate Y
       * @see https://tailwindcss.com/docs/translate
       */
      "translate-y": [{
        "translate-y": [translate]
      }],
      /**
       * Skew X
       * @see https://tailwindcss.com/docs/skew
       */
      "skew-x": [{
        "skew-x": [skew]
      }],
      /**
       * Skew Y
       * @see https://tailwindcss.com/docs/skew
       */
      "skew-y": [{
        "skew-y": [skew]
      }],
      /**
       * Transform Origin
       * @see https://tailwindcss.com/docs/transform-origin
       */
      "transform-origin": [{
        origin: ["center", "top", "top-right", "right", "bottom-right", "bottom", "bottom-left", "left", "top-left", isArbitraryValue]
      }],
      // Interactivity
      /**
       * Accent Color
       * @see https://tailwindcss.com/docs/accent-color
       */
      accent: [{
        accent: ["auto", colors]
      }],
      /**
       * Appearance
       * @see https://tailwindcss.com/docs/appearance
       */
      appearance: [{
        appearance: ["none", "auto"]
      }],
      /**
       * Cursor
       * @see https://tailwindcss.com/docs/cursor
       */
      cursor: [{
        cursor: ["auto", "default", "pointer", "wait", "text", "move", "help", "not-allowed", "none", "context-menu", "progress", "cell", "crosshair", "vertical-text", "alias", "copy", "no-drop", "grab", "grabbing", "all-scroll", "col-resize", "row-resize", "n-resize", "e-resize", "s-resize", "w-resize", "ne-resize", "nw-resize", "se-resize", "sw-resize", "ew-resize", "ns-resize", "nesw-resize", "nwse-resize", "zoom-in", "zoom-out", isArbitraryValue]
      }],
      /**
       * Caret Color
       * @see https://tailwindcss.com/docs/just-in-time-mode#caret-color-utilities
       */
      "caret-color": [{
        caret: [colors]
      }],
      /**
       * Pointer Events
       * @see https://tailwindcss.com/docs/pointer-events
       */
      "pointer-events": [{
        "pointer-events": ["none", "auto"]
      }],
      /**
       * Resize
       * @see https://tailwindcss.com/docs/resize
       */
      resize: [{
        resize: ["none", "y", "x", ""]
      }],
      /**
       * Scroll Behavior
       * @see https://tailwindcss.com/docs/scroll-behavior
       */
      "scroll-behavior": [{
        scroll: ["auto", "smooth"]
      }],
      /**
       * Scroll Margin
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-m": [{
        "scroll-m": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Margin X
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-mx": [{
        "scroll-mx": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Margin Y
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-my": [{
        "scroll-my": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Margin Start
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-ms": [{
        "scroll-ms": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Margin End
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-me": [{
        "scroll-me": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Margin Top
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-mt": [{
        "scroll-mt": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Margin Right
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-mr": [{
        "scroll-mr": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Margin Bottom
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-mb": [{
        "scroll-mb": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Margin Left
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-ml": [{
        "scroll-ml": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Padding
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-p": [{
        "scroll-p": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Padding X
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-px": [{
        "scroll-px": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Padding Y
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-py": [{
        "scroll-py": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Padding Start
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-ps": [{
        "scroll-ps": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Padding End
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-pe": [{
        "scroll-pe": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Padding Top
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-pt": [{
        "scroll-pt": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Padding Right
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-pr": [{
        "scroll-pr": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Padding Bottom
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-pb": [{
        "scroll-pb": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Padding Left
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-pl": [{
        "scroll-pl": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Snap Align
       * @see https://tailwindcss.com/docs/scroll-snap-align
       */
      "snap-align": [{
        snap: ["start", "end", "center", "align-none"]
      }],
      /**
       * Scroll Snap Stop
       * @see https://tailwindcss.com/docs/scroll-snap-stop
       */
      "snap-stop": [{
        snap: ["normal", "always"]
      }],
      /**
       * Scroll Snap Type
       * @see https://tailwindcss.com/docs/scroll-snap-type
       */
      "snap-type": [{
        snap: ["none", "x", "y", "both"]
      }],
      /**
       * Scroll Snap Type Strictness
       * @see https://tailwindcss.com/docs/scroll-snap-type
       */
      "snap-strictness": [{
        snap: ["mandatory", "proximity"]
      }],
      /**
       * Touch Action
       * @see https://tailwindcss.com/docs/touch-action
       */
      touch: [{
        touch: ["auto", "none", "manipulation"]
      }],
      /**
       * Touch Action X
       * @see https://tailwindcss.com/docs/touch-action
       */
      "touch-x": [{
        "touch-pan": ["x", "left", "right"]
      }],
      /**
       * Touch Action Y
       * @see https://tailwindcss.com/docs/touch-action
       */
      "touch-y": [{
        "touch-pan": ["y", "up", "down"]
      }],
      /**
       * Touch Action Pinch Zoom
       * @see https://tailwindcss.com/docs/touch-action
       */
      "touch-pz": ["touch-pinch-zoom"],
      /**
       * User Select
       * @see https://tailwindcss.com/docs/user-select
       */
      select: [{
        select: ["none", "text", "all", "auto"]
      }],
      /**
       * Will Change
       * @see https://tailwindcss.com/docs/will-change
       */
      "will-change": [{
        "will-change": ["auto", "scroll", "contents", "transform", isArbitraryValue]
      }],
      // SVG
      /**
       * Fill
       * @see https://tailwindcss.com/docs/fill
       */
      fill: [{
        fill: [colors, "none"]
      }],
      /**
       * Stroke Width
       * @see https://tailwindcss.com/docs/stroke-width
       */
      "stroke-w": [{
        stroke: [isLength, isArbitraryLength, isArbitraryNumber]
      }],
      /**
       * Stroke
       * @see https://tailwindcss.com/docs/stroke
       */
      stroke: [{
        stroke: [colors, "none"]
      }],
      // Accessibility
      /**
       * Screen Readers
       * @see https://tailwindcss.com/docs/screen-readers
       */
      sr: ["sr-only", "not-sr-only"],
      /**
       * Forced Color Adjust
       * @see https://tailwindcss.com/docs/forced-color-adjust
       */
      "forced-color-adjust": [{
        "forced-color-adjust": ["auto", "none"]
      }]
    },
    conflictingClassGroups: {
      overflow: ["overflow-x", "overflow-y"],
      overscroll: ["overscroll-x", "overscroll-y"],
      inset: ["inset-x", "inset-y", "start", "end", "top", "right", "bottom", "left"],
      "inset-x": ["right", "left"],
      "inset-y": ["top", "bottom"],
      flex: ["basis", "grow", "shrink"],
      gap: ["gap-x", "gap-y"],
      p: ["px", "py", "ps", "pe", "pt", "pr", "pb", "pl"],
      px: ["pr", "pl"],
      py: ["pt", "pb"],
      m: ["mx", "my", "ms", "me", "mt", "mr", "mb", "ml"],
      mx: ["mr", "ml"],
      my: ["mt", "mb"],
      size: ["w", "h"],
      "font-size": ["leading"],
      "fvn-normal": ["fvn-ordinal", "fvn-slashed-zero", "fvn-figure", "fvn-spacing", "fvn-fraction"],
      "fvn-ordinal": ["fvn-normal"],
      "fvn-slashed-zero": ["fvn-normal"],
      "fvn-figure": ["fvn-normal"],
      "fvn-spacing": ["fvn-normal"],
      "fvn-fraction": ["fvn-normal"],
      "line-clamp": ["display", "overflow"],
      rounded: ["rounded-s", "rounded-e", "rounded-t", "rounded-r", "rounded-b", "rounded-l", "rounded-ss", "rounded-se", "rounded-ee", "rounded-es", "rounded-tl", "rounded-tr", "rounded-br", "rounded-bl"],
      "rounded-s": ["rounded-ss", "rounded-es"],
      "rounded-e": ["rounded-se", "rounded-ee"],
      "rounded-t": ["rounded-tl", "rounded-tr"],
      "rounded-r": ["rounded-tr", "rounded-br"],
      "rounded-b": ["rounded-br", "rounded-bl"],
      "rounded-l": ["rounded-tl", "rounded-bl"],
      "border-spacing": ["border-spacing-x", "border-spacing-y"],
      "border-w": ["border-w-s", "border-w-e", "border-w-t", "border-w-r", "border-w-b", "border-w-l"],
      "border-w-x": ["border-w-r", "border-w-l"],
      "border-w-y": ["border-w-t", "border-w-b"],
      "border-color": ["border-color-s", "border-color-e", "border-color-t", "border-color-r", "border-color-b", "border-color-l"],
      "border-color-x": ["border-color-r", "border-color-l"],
      "border-color-y": ["border-color-t", "border-color-b"],
      "scroll-m": ["scroll-mx", "scroll-my", "scroll-ms", "scroll-me", "scroll-mt", "scroll-mr", "scroll-mb", "scroll-ml"],
      "scroll-mx": ["scroll-mr", "scroll-ml"],
      "scroll-my": ["scroll-mt", "scroll-mb"],
      "scroll-p": ["scroll-px", "scroll-py", "scroll-ps", "scroll-pe", "scroll-pt", "scroll-pr", "scroll-pb", "scroll-pl"],
      "scroll-px": ["scroll-pr", "scroll-pl"],
      "scroll-py": ["scroll-pt", "scroll-pb"],
      touch: ["touch-x", "touch-y", "touch-pz"],
      "touch-x": ["touch"],
      "touch-y": ["touch"],
      "touch-pz": ["touch"]
    },
    conflictingClassGroupModifiers: {
      "font-size": ["leading"]
    }
  };
};
var twMerge = /* @__PURE__ */ createTailwindMerge(getDefaultConfig);

// src/lib/utils.ts
function cn(...inputs) {
  return twMerge(clsx(inputs));
}

// src/core/viewportDesktopSite.ts
var MOBILE_DESKTOP_SITE_KEY = "copanel_mobile_desktop_site";
function isMobileDesktopSiteEnabled() {
  try {
    return localStorage.getItem(MOBILE_DESKTOP_SITE_KEY) === "1";
  } catch {
    return false;
  }
}
function isLayoutViewportWide(innerWidth = window.innerWidth) {
  return isMobileDesktopSiteEnabled() || innerWidth >= 1024;
}

// src/core/shell/WindowViewportContext.tsx
import { createContext as createContext2, useContext as useContext2, useRef } from "react";
import { jsx as jsx2 } from "react/jsx-runtime";
var WindowViewportContext = createContext2(null);
function useWindowViewport() {
  return useContext2(WindowViewportContext);
}
function useIsWindowedModule() {
  return useWindowViewport()?.isWindowed === true;
}

// src/core/shell/ModuleViewport.tsx
import { jsx as jsx3 } from "react/jsx-runtime";
function ModuleViewport({ children, className, constrained = false }) {
  const { theme } = useAppShellContext();
  const isWindowed = useIsWindowedModule();
  const isDark = theme === "dark";
  const isClassicMobile = !isWindowed && !isLayoutViewportWide();
  return /* @__PURE__ */ jsx3(
    "div",
    {
      className: cn(
        "flex flex-col transition-colors duration-200",
        isWindowed ? "h-full min-h-0" : isClassicMobile ? "min-h-0" : "min-h-screen",
        isDark ? "bg-slate-950 text-slate-100" : "bg-slate-50 text-slate-900",
        !isWindowed && constrained && "mx-auto max-w-7xl",
        className
      ),
      children
    }
  );
}

// src/core/shell/ModuleSidebarLayout.tsx
import { useEffect, useState } from "react";
import * as Icons from "lucide-react";
import { jsx as jsx4, jsxs } from "react/jsx-runtime";
function ModuleSidebarLayout({
  isDark,
  sidebar,
  children,
  mobileTitle,
  className
}) {
  const isWindowed = useIsWindowedModule();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [viewportWide, setViewportWide] = useState(() => isLayoutViewportWide());
  useEffect(() => {
    const onResize = () => setViewportWide(isLayoutViewportWide());
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  }, []);
  const useDrawer = !isWindowed && !viewportWide;
  useEffect(() => {
    if (viewportWide) setSidebarOpen(false);
  }, [viewportWide]);
  const closeSidebar = () => setSidebarOpen(false);
  if (!useDrawer) {
    return /* @__PURE__ */ jsxs("div", { className: cn("flex h-full min-h-0 flex-1 overflow-hidden", className), children: [
      sidebar,
      /* @__PURE__ */ jsx4("div", { className: "flex min-h-0 min-w-0 flex-1 flex-col overflow-hidden", children })
    ] });
  }
  return /* @__PURE__ */ jsxs("div", { className: cn("relative flex h-full min-h-0 flex-1 flex-col overflow-hidden", className), children: [
    /* @__PURE__ */ jsxs(
      "div",
      {
        className: cn(
          "flex shrink-0 items-center gap-2 border-b px-3 py-2.5",
          isDark ? "border-slate-800 bg-slate-950/90" : "border-slate-200 bg-white"
        ),
        children: [
          /* @__PURE__ */ jsx4(
            "button",
            {
              type: "button",
              onClick: () => setSidebarOpen(true),
              className: cn(
                "inline-flex items-center justify-center rounded-lg p-2",
                isDark ? "text-slate-200 hover:bg-slate-800" : "text-slate-700 hover:bg-slate-100"
              ),
              "aria-label": "Open module menu",
              children: /* @__PURE__ */ jsx4(Icons.PanelLeft, { className: "h-5 w-5" })
            }
          ),
          mobileTitle ? /* @__PURE__ */ jsx4("span", { className: cn("truncate text-sm font-semibold", isDark ? "text-slate-100" : "text-slate-900"), children: mobileTitle }) : null
        ]
      }
    ),
    sidebarOpen ? /* @__PURE__ */ jsx4(
      "button",
      {
        type: "button",
        className: "fixed inset-0 z-[60] bg-black/45",
        "aria-label": "Close module menu",
        onClick: closeSidebar
      }
    ) : null,
    /* @__PURE__ */ jsx4(
      "div",
      {
        className: cn(
          "fixed inset-y-0 left-0 z-[61] flex max-w-[min(85vw,280px)] transform shadow-xl transition-transform duration-200 ease-out",
          sidebarOpen ? "translate-x-0" : "-translate-x-full pointer-events-none"
        ),
        onClick: closeSidebar,
        children: sidebar
      }
    ),
    /* @__PURE__ */ jsx4("div", { className: "flex min-h-0 min-w-0 flex-1 flex-col overflow-hidden", children })
  ] });
}

// src/core/shell/WindowModal.tsx
import { createPortal } from "react-dom";
import * as Icons2 from "lucide-react";
import { jsx as jsx5, jsxs as jsxs2 } from "react/jsx-runtime";
var MAX_W = {
  sm: "max-w-sm",
  md: "max-w-md",
  lg: "max-w-lg",
  xl: "max-w-xl",
  "2xl": "max-w-2xl",
  "4xl": "max-w-4xl",
  "5xl": "max-w-5xl"
};
function WindowModal({
  open,
  onClose,
  children,
  title,
  className,
  maxWidth = "lg",
  closeOnBackdropClick = true
}) {
  const { theme } = useAppShellContext();
  const isDark = theme === "dark";
  const viewport = useWindowViewport();
  if (!open) return null;
  const overlay = /* @__PURE__ */ jsx5(
    "div",
    {
      className: cn(
        "z-[80] flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm",
        viewport?.isWindowed ? "absolute inset-0" : "fixed inset-0"
      ),
      onClick: closeOnBackdropClick ? onClose : void 0,
      children: /* @__PURE__ */ jsxs2(
        "div",
        {
          className: cn(
            "flex w-full flex-col overflow-hidden rounded-2xl border shadow-2xl",
            MAX_W[maxWidth],
            isDark ? "border-slate-700 bg-slate-900 text-slate-100" : "border-slate-200 bg-white text-slate-900",
            className
          ),
          onClick: (e) => e.stopPropagation(),
          children: [
            title && /* @__PURE__ */ jsxs2(
              "div",
              {
                className: cn(
                  "flex items-center justify-between border-b px-4 py-3",
                  isDark ? "border-slate-800" : "border-slate-200"
                ),
                children: [
                  /* @__PURE__ */ jsx5("h3", { className: "text-sm font-bold", children: title }),
                  /* @__PURE__ */ jsx5("button", { type: "button", onClick: onClose, className: "rounded-lg p-1 hover:bg-slate-800/50", "aria-label": "Close", children: /* @__PURE__ */ jsx5(Icons2.X, { className: "h-4 w-4" }) })
                ]
              }
            ),
            children
          ]
        }
      )
    }
  );
  if (viewport?.isWindowed && viewport.viewportRef.current) {
    return createPortal(overlay, viewport.viewportRef.current);
  }
  return createPortal(overlay, document.body);
}

// src/modules/cloudflare_ddns/index.tsx
import * as Icons3 from "lucide-react";

// src/core/platform/api.ts
var PlatformError = class extends Error {
  constructor(code, message, status, details) {
    super(message);
    __publicField(this, "code");
    __publicField(this, "status");
    __publicField(this, "details");
    this.code = code;
    this.status = status;
    this.details = details;
  }
};
async function api(path, opts = {}) {
  const token = typeof window !== "undefined" ? localStorage.getItem("copanel_token") : null;
  const headers = {
    "Content-Type": "application/json",
    ...opts.headers || {}
  };
  if (token) headers["Authorization"] = `Bearer ${token}`;
  const init = {
    method: opts.method || "GET",
    headers,
    signal: opts.signal
  };
  if (opts.body !== void 0) {
    init.body = typeof opts.body === "string" ? opts.body : JSON.stringify(opts.body);
  }
  const res = await fetch(path, init);
  let body = null;
  const text = await res.text();
  if (text) {
    try {
      body = JSON.parse(text);
    } catch {
      body = text;
    }
  }
  if (opts.raw) {
    return body;
  }
  if (!res.ok) {
    const err = body && typeof body === "object" && body.error ? body.error : { code: `HTTP_${res.status}`, message: typeof body === "string" ? body : body?.detail || res.statusText };
    throw new PlatformError(err.code || `HTTP_${res.status}`, err.message || "Request failed", res.status, err.details);
  }
  if (body && typeof body === "object" && "status" in body) {
    if (body.status === "success") {
      return body.data !== void 0 ? body.data : body;
    }
    if (body.status === "error" && body.error) {
      throw new PlatformError(body.error.code, body.error.message, res.status, body.error.details);
    }
  }
  return body;
}

// src/core/platform/events.ts
var PLATFORM_SSE_DEGRADED_EVENT = "copanel-platform-sse-degraded";
var MIN_RETRY_MS = 2e3;
var MAX_RETRY_MS = 6e4;
var POLL_FALLBACK_AFTER_FAILURES = 3;
var EventHub = class {
  constructor() {
    __publicField(this, "source", null);
    __publicField(this, "handlers", /* @__PURE__ */ new Map());
    __publicField(this, "retryDelay", MIN_RETRY_MS);
    __publicField(this, "retryTimer", null);
    __publicField(this, "failureCount", 0);
  }
  on(topic, handler) {
    let set = this.handlers.get(topic);
    if (!set) {
      set = /* @__PURE__ */ new Set();
      this.handlers.set(topic, set);
    }
    set.add(handler);
    this.ensureConnected();
    return () => {
      set.delete(handler);
      if (set.size === 0) {
        this.handlers.delete(topic);
      }
      this.teardownIfIdle();
    };
  }
  emit(topic, payload) {
    const set = this.handlers.get(topic);
    if (set) {
      set.forEach((h) => {
        try {
          h(payload);
        } catch (err) {
          console.error("event handler failed", topic, err);
        }
      });
    }
  }
  buildUrl() {
    const token = localStorage.getItem("copanel_token");
    if (!token) return null;
    const params = new URLSearchParams({
      topics: "jobs,notifications",
      access_token: token
    });
    return `/api/platform/events?${params.toString()}`;
  }
  ensureConnected() {
    if (this.source) return;
    if (typeof document !== "undefined" && document.hidden) return;
    const url = this.buildUrl();
    if (!url) return;
    try {
      this.source = new EventSource(url, { withCredentials: false });
    } catch {
      this.scheduleRetry();
      return;
    }
    this.source.addEventListener("open", () => {
      this.failureCount = 0;
      this.retryDelay = MIN_RETRY_MS;
    });
    this.source.addEventListener("jobs", (e) => {
      this.onStreamMessage();
      this.parseAndEmit("jobs", e.data);
    });
    this.source.addEventListener("notifications", (e) => {
      this.onStreamMessage();
      this.parseAndEmit("notifications", e.data);
    });
    this.source.addEventListener("message", () => {
      this.onStreamMessage();
    });
    this.source.onerror = () => {
      this.failureCount += 1;
      this.source?.close();
      this.source = null;
      if (this.failureCount >= POLL_FALLBACK_AFTER_FAILURES) {
        window.dispatchEvent(new CustomEvent(PLATFORM_SSE_DEGRADED_EVENT));
      }
      this.scheduleRetry();
    };
  }
  onStreamMessage() {
    this.failureCount = 0;
    this.retryDelay = MIN_RETRY_MS;
  }
  parseAndEmit(topic, raw) {
    try {
      const msg = JSON.parse(raw);
      this.emit(topic, msg.payload || msg);
    } catch {
    }
  }
  scheduleRetry() {
    if (this.retryTimer) return;
    if (this.handlers.size === 0) return;
    const delay = this.retryDelay;
    this.retryDelay = Math.min(Math.round(this.retryDelay * 1.8), MAX_RETRY_MS);
    this.retryTimer = setTimeout(() => {
      this.retryTimer = null;
      this.ensureConnected();
    }, delay);
  }
  teardownIfIdle() {
    if (this.handlers.size > 0) return;
    if (this.retryTimer) {
      clearTimeout(this.retryTimer);
      this.retryTimer = null;
    }
    if (this.source) {
      this.source.close();
      this.source = null;
    }
    this.failureCount = 0;
    this.retryDelay = MIN_RETRY_MS;
  }
  /** Drop the SSE connection and open a new one if handlers exist and a token is present. */
  reconnect() {
    if (this.source) {
      this.source.close();
      this.source = null;
    }
    if (this.retryTimer) {
      clearTimeout(this.retryTimer);
      this.retryTimer = null;
    }
    this.failureCount = 0;
    this.retryDelay = MIN_RETRY_MS;
    if (this.handlers.size > 0) {
      this.ensureConnected();
    }
  }
};
var events = new EventHub();
function reconnectPlatformEvents() {
  events.reconnect();
}
if (typeof document !== "undefined") {
  document.addEventListener("visibilitychange", () => {
    if (!document.hidden) {
      reconnectPlatformEvents();
    }
  });
}

// src/core/platform/store.ts
import { useEffect as useEffect2, useState as useState2 } from "react";
function createStore(initial) {
  let state = initial;
  const listeners = /* @__PURE__ */ new Set();
  return {
    getState: () => state,
    setState: (updater) => {
      const patch = typeof updater === "function" ? updater(state) : updater;
      if (!patch || Object.keys(patch).length === 0) return;
      let changed = false;
      for (const key of Object.keys(patch)) {
        if (state[key] !== patch[key]) {
          changed = true;
          break;
        }
      }
      if (!changed) return;
      state = { ...state, ...patch };
      listeners.forEach((l) => l());
    },
    subscribe: (listener) => {
      listeners.add(listener);
      return () => listeners.delete(listener);
    }
  };
}

// src/core/platform/jobsStore.ts
var store = createStore({ jobs: {}, order: [], lastFetch: 0 });
function getCurrentLang() {
  return localStorage.getItem("copanel_lang") === "vi" ? "vi" : "en";
}
function pickLocalizedFromValue(value, lang) {
  if (!value) return void 0;
  if (typeof value === "string") return value;
  if (typeof value === "object") return value[lang] || value.en || value.vi || value.default;
  return void 0;
}
function resolveLocalizedField(src, baseKey, lang) {
  if (!src || typeof src !== "object") return void 0;
  const direct = pickLocalizedFromValue(src[baseKey], lang);
  if (direct) return direct;
  const fromMap = pickLocalizedFromValue(src[`${baseKey}_i18n`], lang);
  if (fromMap) return fromMap;
  const fromLangSpecific = src[`${baseKey}_${lang}`];
  if (typeof fromLangSpecific === "string" && fromLangSpecific) return fromLangSpecific;
  const fallbackEn = src[`${baseKey}_en`];
  if (typeof fallbackEn === "string" && fallbackEn) return fallbackEn;
  const fallbackVi = src[`${baseKey}_vi`];
  if (typeof fallbackVi === "string" && fallbackVi) return fallbackVi;
  return void 0;
}
function localizeJob(raw) {
  const lang = getCurrentLang();
  const payload = raw?.payload && typeof raw.payload === "object" ? raw.payload : {};
  return {
    ...raw,
    title: resolveLocalizedField(raw, "title", lang) || resolveLocalizedField(payload, "title", lang) || raw?.title || "",
    message: resolveLocalizedField(raw, "message", lang) || resolveLocalizedField(payload, "message", lang) || raw?.message,
    error: resolveLocalizedField(raw, "error", lang) || resolveLocalizedField(payload, "error", lang) || raw?.error || null
  };
}
function upsert(job) {
  const localized = localizeJob(job);
  store.setState((s) => {
    const next = { ...s.jobs, [localized.id]: { ...s.jobs[localized.id], ...localized } };
    let order = s.order;
    if (!order.includes(localized.id)) {
      order = [localized.id, ...order].slice(0, 200);
    }
    return { jobs: next, order };
  });
}
events.on("jobs", (msg) => {
  if (msg?.job) {
    upsert(msg.job);
    return;
  }
  if (msg?.job_id && msg?.event === "update") {
    const existing = store.getState().jobs[msg.job_id];
    if (existing) {
      upsert({
        ...existing,
        progress: msg.progress ?? existing.progress,
        message: msg.message ?? existing.message,
        status: msg.status ?? existing.status
      });
    }
  }
});

// src/core/platform/notificationsStore.ts
var store2 = createStore({ inbox: [], unread: 0, toasts: [] });
var TOAST_TTL_MS = 6e3;
function getCurrentLang2() {
  return localStorage.getItem("copanel_lang") === "vi" ? "vi" : "en";
}
function pickLocalizedFromValue2(value, lang) {
  if (!value) return void 0;
  if (typeof value === "string") return value;
  if (typeof value === "object") {
    return value[lang] || value.en || value.vi || value.default;
  }
  return void 0;
}
function resolveLocalizedField2(src, baseKey, lang) {
  if (!src || typeof src !== "object") return void 0;
  const direct = pickLocalizedFromValue2(src[baseKey], lang);
  if (direct) return direct;
  const fromMap = pickLocalizedFromValue2(src[`${baseKey}_i18n`], lang);
  if (fromMap) return fromMap;
  const fromLangSpecific = src[`${baseKey}_${lang}`];
  if (typeof fromLangSpecific === "string" && fromLangSpecific) return fromLangSpecific;
  const fallbackEn = src[`${baseKey}_en`];
  if (typeof fallbackEn === "string" && fallbackEn) return fallbackEn;
  const fallbackVi = src[`${baseKey}_vi`];
  if (typeof fallbackVi === "string" && fallbackVi) return fallbackVi;
  return void 0;
}
function localizeNotification(raw) {
  const lang = getCurrentLang2();
  const payload = raw?.payload && typeof raw.payload === "object" ? raw.payload : {};
  const title = resolveLocalizedField2(raw, "title", lang) || resolveLocalizedField2(payload, "title", lang) || (raw?.title || "");
  const body = resolveLocalizedField2(raw, "body", lang) || resolveLocalizedField2(payload, "body", lang) || raw?.body || null;
  return {
    ...raw,
    title,
    body
  };
}
function pushToast(t) {
  store2.setState((s) => ({ toasts: [t, ...s.toasts].slice(0, 6) }));
  if (t.ephemeral !== false) {
    setTimeout(() => {
      store2.setState((s) => ({ toasts: s.toasts.filter((x) => x.id !== t.id) }));
    }, TOAST_TTL_MS);
  }
}
events.on("notifications", (msg) => {
  if (msg?.event === "new" && msg.notification) {
    const n = localizeNotification(msg.notification);
    pushToast({ ...n, ephemeral: true });
    store2.setState((s) => ({
      inbox: [n, ...s.inbox].slice(0, 200),
      unread: s.unread + 1
    }));
  }
});

// src/modules/cloudflare_ddns/index.tsx
import { Fragment, jsx as jsx6, jsxs as jsxs3 } from "react/jsx-runtime";
var RECORD_TYPES = ["A", "AAAA", "CNAME", "TXT", "MX", "NS"];
var EMPTY_DDNS = {
  name: "",
  record_name: "@",
  record_type: "A",
  proxied: false,
  ttl: 1,
  ip_source: "public",
  interface_name: "eth0",
  custom_ip_url: "",
  interval_minutes: 5,
  enabled: true
};
var COPY = {
  en: {
    category: "Network",
    title: "Cloudflare DDNS",
    subtitle: "Dynamic DNS updates, DNS record management, and Cloudflare Tunnel (cloudflared). Requires API Token with Zone:DNS:Edit and Account:Cloudflare Tunnel permissions.",
    tabs: { settings: "API", ddns: "DDNS", records: "DNS Records", tunnels: "Tunnel" },
    apiToken: "Cloudflare API Token",
    apiTokenHintBefore: "Create a token at ",
    apiTokenHintAfter: ". Permissions: Zone \u2192 DNS \u2192 Edit, Account \u2192 Cloudflare Tunnel \u2192 Edit.",
    tokenSaved: "Token saved:",
    tokenOptional: "(leave blank to keep current)",
    accountId: "Account ID (optional)",
    accountIdPlaceholder: "Auto-detect on verify",
    saveVerify: "Save & Verify",
    verifyAgain: "Verify again",
    tokenValid: "Token valid \xB7",
    accounts: "account(s)",
    cronTitle: "DDNS Cron",
    cronOk: "OK \u2014 crontab synced",
    cronCheck: "Needs attention",
    cronProfiles: "enabled profile(s) \xB7",
    cronIntervals: "interval(s)",
    cronDaemon: "daemon",
    cronRunning: "running",
    cronStopped: "stopped",
    cronPlayHint: "Play button = run once via API (not cron). Scheduled runs require enabled profiles and OS cron daemon.",
    cronNoLines: "No cron lines (disabled profiles or not synced).",
    cronSync: "Install cron & sync",
    cronMissingScript: "Missing run_update.py \u2014 upgrade module.",
    addDdns: "Add DDNS profile",
    selectZone: "Select zone",
    profileName: "Profile name",
    recordName: "Record (@, home, \u2026)",
    publicIp: "Public IP",
    networkIface: "Network interface",
    customUrl: "Custom URL",
    intervalMin: "Interval (minutes)",
    proxied: "Proxied (orange cloud)",
    add: "Add & update IP",
    ddnsProfiles: "DDNS profiles",
    pending: "pending",
    disabled: "disabled",
    every: "every",
    min: "min",
    lastRun: "Last run:",
    noProfiles: "No DDNS profiles yet.",
    runNow: "Run now",
    enable: "Enable",
    disable: "Disable",
    needZone: "Select a Cloudflare zone before adding a DDNS profile.",
    needProfileName: "Enter a profile name before adding.",
    zones: "Zones",
    noZones: "No zones loaded \u2014 configure API token first.",
    selectZoneRecords: "Select a zone to view/edit DNS records.",
    addRecord: "Add",
    noRecords: "No records.",
    proxiedLabel: "proxied",
    cloudflared: "cloudflared",
    installed: "Installed:",
    notInstalled: "cloudflared not installed. Install Cloudflare package before using Tunnel.",
    service: "Service:",
    tunnels: "Tunnels",
    selectTunnel: "Select a tunnel to configure ingress rules.",
    hostname: "hostname (e.g. app.example.com)",
    serviceUrl: "http://localhost:80",
    remove: "Remove",
    addRule: "+ Add rule",
    catchAll404: "+ Catch-all 404",
    saveConfig: "Save config.yml",
    installService: "Install systemd service",
    configPath: "Config saved at",
    configHint: 'After saving, run "Install systemd service" to register cloudflared (Linux).',
    noTunnels: "No tunnels yet.",
    confirmDeleteRecord: "Delete this DNS record?",
    confirmDeleteDdns: "Delete this DDNS profile?",
    confirmDeleteTunnel: "Delete this tunnel from Cloudflare?",
    cancel: "Cancel",
    delete: "Delete",
    needAccountId: "Account ID is missing. Open the API tab, click Save & Verify (or paste Account ID), then return here. Token needs Account \u2192 Cloudflare Tunnel \u2192 Edit.",
    api404: "Cloudflare DDNS API not found (404) \u2014 backend module not loaded. Run: systemctl restart copanel. Previously saved token remains at /var/lib/copanel/cloudflare_ddns.json unless manually deleted.",
    loadFailed: "Load failed",
    loadZonesFailed: "Failed to load zones",
    cronSyncFailed: "Cron sync failed",
    saveFailed: "Save failed",
    verifyFailed: "Verify failed",
    loadRecordsFailed: "Failed to load records",
    addRecordFailed: "Add record failed",
    deleteFailed: "Delete failed",
    createDdnsFailed: "Create DDNS failed",
    runFailed: "Run failed",
    updateFailed: "Update failed",
    createTunnelFailed: "Create tunnel failed",
    saveTunnelFailed: "Save tunnel config failed",
    installFailed: "Install service failed",
    deleteTunnelFailed: "Delete tunnel failed",
    loadTunnelsFailed: "Failed to load tunnels"
  },
  vi: {
    category: "Network",
    title: "Cloudflare DDNS",
    subtitle: "C\u1EADp nh\u1EADt IP \u0111\u1ED9ng l\xEAn Cloudflare DNS, qu\u1EA3n l\xFD b\u1EA3n ghi DNS, v\xE0 c\u1EA5u h\xECnh Cloudflare Tunnel (cloudflared). C\u1EA7n API Token v\u1EDBi quy\u1EC1n Zone:DNS:Edit v\xE0 Account:Cloudflare Tunnel.",
    tabs: { settings: "API", ddns: "DDNS", records: "DNS Records", tunnels: "Tunnel" },
    apiToken: "Cloudflare API Token",
    apiTokenHintBefore: "T\u1EA1o token t\u1EA1i ",
    apiTokenHintAfter: ". Quy\u1EC1n: Zone \u2192 DNS \u2192 Edit, Account \u2192 Cloudflare Tunnel \u2192 Edit.",
    tokenSaved: "Token \u0111\xE3 l\u01B0u:",
    tokenOptional: "(\u0111\u1EC3 tr\u1ED1ng n\u1EBFu kh\xF4ng \u0111\u1ED5i)",
    accountId: "Account ID (t\xF9y ch\u1ECDn)",
    accountIdPlaceholder: "Auto-detect khi verify",
    saveVerify: "L\u01B0u & Verify",
    verifyAgain: "Verify l\u1EA1i",
    tokenValid: "Token h\u1EE3p l\u1EC7 \xB7",
    accounts: "account(s)",
    cronTitle: "Cron DDNS",
    cronOk: "OK \u2014 crontab \u0111\xE3 sync",
    cronCheck: "C\u1EA7n ki\u1EC3m tra",
    cronProfiles: "profile b\u1EADt \xB7",
    cronIntervals: "interval",
    cronDaemon: "daemon",
    cronRunning: "\u0111ang ch\u1EA1y",
    cronStopped: "t\u1EAFt",
    cronPlayHint: "N\xFAt \u25B6 (Play) = ch\u1EA1y ngay m\u1ED9t l\u1EA7n qua API, kh\xF4ng ph\u1EE5 thu\u1ED9c cron. L\u1ECBch t\u1EF1 \u0111\u1ED9ng c\u1EA7n profile b\u1EADt v\xE0 daemon cron OS \u0111ang ch\u1EA1y.",
    cronNoLines: "Ch\u01B0a c\xF3 d\xF2ng cron (profile disabled ho\u1EB7c ch\u01B0a sync).",
    cronSync: "C\xE0i cron & sync",
    cronMissingScript: "Thi\u1EBFu run_update.py \u2014 c\u1EADp nh\u1EADt module l\xEAn b\u1EA3n m\u1EDBi.",
    addDdns: "Th\xEAm DDNS profile",
    selectZone: "Ch\u1ECDn zone",
    profileName: "T\xEAn profile",
    recordName: "Record (@, home, \u2026)",
    publicIp: "Public IP",
    networkIface: "Network interface",
    customUrl: "Custom URL",
    intervalMin: "Interval (ph\xFAt)",
    proxied: "Proxied (orange cloud)",
    add: "Th\xEAm & c\u1EADp nh\u1EADt IP",
    ddnsProfiles: "DDNS profiles",
    pending: "pending",
    disabled: "disabled",
    every: "m\u1ED7i",
    min: "p",
    lastRun: "L\u1EA7n ch\u1EA1y:",
    noProfiles: "Ch\u01B0a c\xF3 profile DDNS.",
    runNow: "Ch\u1EA1y ngay",
    enable: "B\u1EADt",
    disable: "T\u1EAFt",
    needZone: "Ch\u1ECDn zone Cloudflare tr\u01B0\u1EDBc khi th\xEAm DDNS profile.",
    needProfileName: "Nh\u1EADp t\xEAn profile tr\u01B0\u1EDBc khi th\xEAm.",
    zones: "Zones",
    noZones: "Ch\u01B0a load zones \u2014 c\u1EA5u h\xECnh API token tr\u01B0\u1EDBc.",
    selectZoneRecords: "Ch\u1ECDn zone \u0111\u1EC3 xem/s\u1EEDa DNS records.",
    addRecord: "Add",
    noRecords: "Kh\xF4ng c\xF3 record.",
    proxiedLabel: "proxied",
    cloudflared: "cloudflared",
    installed: "\u0110\xE3 c\xE0i:",
    notInstalled: "Ch\u01B0a c\xE0i cloudflared. C\xE0i t\u1EEB package Cloudflare tr\u01B0\u1EDBc khi d\xF9ng Tunnel.",
    service: "Service:",
    tunnels: "Tunnels",
    selectTunnel: "Ch\u1ECDn tunnel \u0111\u1EC3 c\u1EA5u h\xECnh ingress rules.",
    hostname: "hostname (vd: app.example.com)",
    serviceUrl: "http://localhost:80",
    remove: "X\xF3a",
    addRule: "+ Th\xEAm rule",
    catchAll404: "+ Catch-all 404",
    saveConfig: "L\u01B0u config.yml",
    installService: "C\xE0i systemd service",
    configPath: "Config l\u01B0u t\u1EA1i",
    configHint: 'Sau khi l\u01B0u, ch\u1EA1y "C\xE0i systemd service" \u0111\u1EC3 \u0111\u0103ng k\xFD cloudflared (Linux).',
    noTunnels: "Ch\u01B0a c\xF3 tunnel.",
    confirmDeleteRecord: "Delete this record?",
    confirmDeleteDdns: "Delete this DDNS profile?",
    confirmDeleteTunnel: "X\xF3a tunnel n\xE0y kh\u1ECFi Cloudflare?",
    cancel: "H\u1EE7y",
    delete: "X\xF3a",
    needAccountId: "Thi\u1EBFu Account ID. V\xE0o tab API, b\u1EA5m L\u01B0u & Verify (ho\u1EB7c d\xE1n Account ID), r\u1ED3i quay l\u1EA1i. Token c\u1EA7n quy\u1EC1n Account \u2192 Cloudflare Tunnel \u2192 Edit.",
    api404: "API Cloudflare DDNS kh\xF4ng t\xECm th\u1EA5y (404) \u2014 module backend ch\u01B0a load. Ch\u1EA1y: systemctl restart copanel. Token c\u1EA5u h\xECnh tr\u01B0\u1EDBc \u0111\xF3 v\u1EABn n\u1EB1m t\u1EA1i /var/lib/copanel/cloudflare_ddns.json tr\xEAn server (tr\u1EEB khi file b\u1ECB x\xF3a th\u1EE7 c\xF4ng).",
    loadFailed: "Load failed",
    loadZonesFailed: "Failed to load zones",
    cronSyncFailed: "Cron sync failed",
    saveFailed: "Save failed",
    verifyFailed: "Verify failed",
    loadRecordsFailed: "Failed to load records",
    addRecordFailed: "Add record failed",
    deleteFailed: "Delete failed",
    createDdnsFailed: "Create DDNS failed",
    runFailed: "Run failed",
    updateFailed: "Update failed",
    createTunnelFailed: "Create tunnel failed",
    saveTunnelFailed: "Save tunnel config failed",
    installFailed: "Install service failed",
    deleteTunnelFailed: "Delete tunnel failed",
    loadTunnelsFailed: "Kh\xF4ng t\u1EA3i \u0111\u01B0\u1EE3c danh s\xE1ch tunnels"
  }
};
function fmtTime(ts) {
  if (!ts) return "\u2014";
  return new Date(ts * 1e3).toLocaleString();
}
function statusPill(status) {
  const s = (status || "").toLowerCase();
  if (s === "updated" || s === "created")
    return "bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300";
  if (s === "unchanged") return "bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-300";
  if (s === "error") return "bg-red-100 text-red-700 dark:bg-red-500/15 dark:text-red-300";
  return "bg-blue-100 text-blue-700 dark:bg-blue-500/15 dark:text-blue-300";
}
function CloudflareDdns() {
  const { theme, language } = useAppShellContext();
  const isDark = theme === "dark";
  const t = COPY[language === "vi" ? "vi" : "en"];
  const [tab, setTab] = useState3("settings");
  const [error, setError] = useState3(null);
  const [busy, setBusy] = useState3(false);
  const [confirm, setConfirm] = useState3(null);
  const [config, setConfig] = useState3(null);
  const [tokenInput, setTokenInput] = useState3("");
  const [accountId, setAccountId] = useState3("");
  const [verifyInfo, setVerifyInfo] = useState3(null);
  const [zones, setZones] = useState3([]);
  const [recordsZone, setRecordsZone] = useState3(null);
  const [records, setRecords] = useState3([]);
  const [recordDraft, setRecordDraft] = useState3({ type: "A", name: "@", content: "", ttl: 1, proxied: false });
  const [profiles, setProfiles] = useState3([]);
  const [cronStatus, setCronStatus] = useState3(null);
  const [ddnsDraft, setDdnsDraft] = useState3(EMPTY_DDNS);
  const [ddnsZone, setDdnsZone] = useState3(null);
  const [tunnels, setTunnels] = useState3([]);
  const [tunnelName, setTunnelName] = useState3("");
  const [activeTunnel, setActiveTunnel] = useState3(null);
  const [ingress, setIngress] = useState3([{ hostname: "", service: "http://localhost:80", path: "" }]);
  const [tunnelStatus, setTunnelStatus] = useState3(null);
  const panel = isDark ? "bg-slate-900/60 border-slate-700" : "bg-white border-slate-200";
  const muted = isDark ? "text-slate-400" : "text-slate-500";
  const inputCls = isDark ? "bg-slate-950/40 border-slate-700 text-slate-100" : "bg-white border-slate-200 text-slate-900";
  const btnSecondary = isDark ? "bg-slate-800 hover:bg-slate-700 text-slate-200 border-slate-600" : "bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200";
  const loadZones = useCallback(async () => {
    const list = await api("/api/cloudflare_ddns/zones");
    setZones(list || []);
    return list || [];
  }, []);
  const loadProfiles = useCallback(async () => {
    const list = await api("/api/cloudflare_ddns/ddns");
    setProfiles(list || []);
  }, []);
  const loadCronStatus = useCallback(async () => {
    const status = await api("/api/cloudflare_ddns/ddns/cron-status");
    setCronStatus(status);
  }, []);
  const loadTunnels = useCallback(async () => {
    const [list, status] = await Promise.all([
      api("/api/cloudflare_ddns/tunnels"),
      api("/api/cloudflare_ddns/tunnels/service/status")
    ]);
    setTunnels(list || []);
    setTunnelStatus(status);
  }, []);
  const applyVerifyResult = useCallback(async (verify) => {
    setVerifyInfo(verify);
    if (verify?.account_id) {
      setAccountId(verify.account_id);
    }
    try {
      const cfg = await api("/api/cloudflare_ddns/config");
      setConfig(cfg);
      if (cfg.account_id) setAccountId(cfg.account_id);
    } catch {
    }
  }, []);
  const refresh = useCallback(async () => {
    try {
      setError(null);
      const cfg = await api("/api/cloudflare_ddns/config");
      setConfig(cfg);
      setAccountId(cfg.account_id || "");
      if (cfg.api_token_set) {
        try {
          await loadZones();
        } catch (err) {
          setError(err?.message || t.loadZonesFailed);
        }
      } else {
        setZones([]);
      }
      await loadProfiles();
      await loadCronStatus();
      if (tab === "tunnels" && cfg.api_token_set) await loadTunnels();
    } catch (err) {
      const status = err?.status;
      const msg = err?.message || t.loadFailed;
      if (status === 404) {
        setError(t.api404);
      } else {
        setError(msg);
      }
    }
  }, [loadCronStatus, loadProfiles, loadTunnels, loadZones, tab, t.api404, t.loadFailed, t.loadZonesFailed]);
  useEffect3(() => {
    refresh();
  }, []);
  useEffect3(() => {
    if ((tab === "ddns" || tab === "records") && config?.api_token_set) {
      loadZones().catch((err) => setError(err?.message || t.loadZonesFailed));
    }
    if (tab === "ddns") {
      loadCronStatus().catch(() => void 0);
    }
    if (tab === "tunnels" && config?.api_token_set) {
      (async () => {
        try {
          if (!config.account_id) {
            try {
              const verify = await api("/api/cloudflare_ddns/config/verify", { method: "POST" });
              await applyVerifyResult(verify);
            } catch (err) {
              setError(err?.message || t.needAccountId);
              return;
            }
          }
          await loadTunnels();
          setError(null);
        } catch (err) {
          setError(err?.message || t.loadTunnelsFailed);
        }
      })();
    }
  }, [
    tab,
    config?.api_token_set,
    config?.account_id,
    applyVerifyResult,
    loadCronStatus,
    loadTunnels,
    loadZones,
    t.loadFailed,
    t.loadTunnelsFailed,
    t.loadZonesFailed,
    t.needAccountId
  ]);
  async function syncCron() {
    setBusy(true);
    try {
      await api("/api/cloudflare_ddns/ddns/cron-sync", { method: "POST" });
      setError(null);
      await loadCronStatus();
    } catch (err) {
      setError(err?.message || t.cronSyncFailed);
    } finally {
      setBusy(false);
    }
  }
  async function saveToken() {
    setBusy(true);
    try {
      const cfg = await api("/api/cloudflare_ddns/config", {
        method: "PUT",
        body: { api_token: tokenInput || void 0, account_id: accountId || void 0 }
      });
      setConfig(cfg);
      setAccountId(cfg.account_id || accountId);
      setTokenInput("");
      setError(null);
      const verify = await api("/api/cloudflare_ddns/config/verify", { method: "POST" });
      await applyVerifyResult(verify);
      await loadZones();
      await loadCronStatus();
    } catch (err) {
      setError(err?.message || t.saveFailed);
    } finally {
      setBusy(false);
    }
  }
  async function verifyToken() {
    setBusy(true);
    try {
      const verify = await api("/api/cloudflare_ddns/config/verify", { method: "POST" });
      await applyVerifyResult(verify);
      setError(null);
    } catch (err) {
      setError(err?.message || t.verifyFailed);
    } finally {
      setBusy(false);
    }
  }
  async function openRecordsZone(z) {
    setRecordsZone(z);
    try {
      const list = await api(`/api/cloudflare_ddns/zones/${z.id}/records`);
      setRecords(list || []);
      setError(null);
    } catch (err) {
      setError(err?.message || t.loadRecordsFailed);
    }
  }
  async function addRecord() {
    if (!recordsZone || !recordDraft.content.trim()) return;
    try {
      await api(`/api/cloudflare_ddns/zones/${recordsZone.id}/records`, {
        method: "POST",
        body: recordDraft
      });
      setRecordDraft({ ...recordDraft, content: "" });
      openRecordsZone(recordsZone);
    } catch (err) {
      setError(err?.message || t.addRecordFailed);
    }
  }
  async function deleteRecord(rid) {
    if (!recordsZone) return;
    try {
      await api(`/api/cloudflare_ddns/zones/${recordsZone.id}/records/${rid}`, { method: "DELETE" });
      openRecordsZone(recordsZone);
    } catch (err) {
      setError(err?.message || t.deleteFailed);
    }
  }
  async function createDdns() {
    if (!ddnsZone) {
      setError(t.needZone);
      return;
    }
    if (!ddnsDraft.name?.trim()) {
      setError(t.needProfileName);
      return;
    }
    const intervalRaw = Number(ddnsDraft.interval_minutes);
    const interval = Number.isFinite(intervalRaw) && intervalRaw >= 1 ? Math.min(1440, Math.floor(intervalRaw)) : 5;
    const recordName = (ddnsDraft.record_name || "@").trim() || "@";
    setBusy(true);
    try {
      const profile = await api("/api/cloudflare_ddns/ddns", {
        method: "POST",
        body: {
          name: ddnsDraft.name.trim(),
          zone_id: ddnsZone.id,
          zone_name: ddnsZone.name,
          record_name: recordName,
          record_type: ddnsDraft.record_type || "A",
          proxied: !!ddnsDraft.proxied,
          ttl: Number(ddnsDraft.ttl) > 0 ? Number(ddnsDraft.ttl) : 1,
          ip_source: ddnsDraft.ip_source || "public",
          interface_name: ddnsDraft.interface_name || "",
          custom_ip_url: ddnsDraft.custom_ip_url || "",
          interval_minutes: interval,
          enabled: ddnsDraft.enabled !== false
        }
      });
      setDdnsDraft({ ...EMPTY_DDNS });
      setError(null);
      try {
        await api(`/api/cloudflare_ddns/ddns/${profile.id}/run`, { method: "POST" });
      } catch (runErr) {
        setError(runErr?.message || t.runFailed);
      }
      await loadProfiles();
      await loadCronStatus();
    } catch (err) {
      setError(err?.message || t.createDdnsFailed);
    } finally {
      setBusy(false);
    }
  }
  async function runDdns(id) {
    try {
      await api(`/api/cloudflare_ddns/ddns/${id}/run`, { method: "POST" });
      await loadProfiles();
    } catch (err) {
      setError(err?.message || t.runFailed);
    }
  }
  async function toggleDdns(p) {
    try {
      await api(`/api/cloudflare_ddns/ddns/${p.id}`, {
        method: "PUT",
        body: { enabled: !p.enabled }
      });
      await loadProfiles();
      await loadCronStatus();
    } catch (err) {
      setError(err?.message || t.updateFailed);
    }
  }
  async function deleteDdns(id) {
    try {
      await api(`/api/cloudflare_ddns/ddns/${id}`, { method: "DELETE" });
      await loadProfiles();
      await loadCronStatus();
    } catch (err) {
      setError(err?.message || t.deleteFailed);
    }
  }
  async function createTunnel() {
    if (!tunnelName.trim()) return;
    try {
      await api("/api/cloudflare_ddns/tunnels", { method: "POST", body: { name: tunnelName.trim() } });
      setTunnelName("");
      await loadTunnels();
    } catch (err) {
      setError(err?.message || t.createTunnelFailed);
    }
  }
  async function openTunnel(tun) {
    setActiveTunnel(tun);
    try {
      const cfg = await api(`/api/cloudflare_ddns/tunnels/${tun.id}/config`);
      setIngress(
        cfg.ingress?.length ? cfg.ingress : [{ hostname: "", service: "http://localhost:80", path: "" }]
      );
    } catch {
      setIngress([{ hostname: "", service: "http://localhost:80", path: "" }]);
    }
  }
  async function saveTunnelConfig() {
    if (!activeTunnel) return;
    try {
      await api(`/api/cloudflare_ddns/tunnels/${activeTunnel.id}/config`, {
        method: "PUT",
        body: { tunnel_id: activeTunnel.id, tunnel_name: activeTunnel.name, ingress }
      });
      await loadTunnels();
      setError(null);
    } catch (err) {
      setError(err?.message || t.saveTunnelFailed);
    }
  }
  async function installTunnel() {
    if (!activeTunnel) return;
    try {
      const status = await api(`/api/cloudflare_ddns/tunnels/${activeTunnel.id}/install`, { method: "POST" });
      setTunnelStatus(status);
    } catch (err) {
      setError(err?.message || t.installFailed);
    }
  }
  async function deleteTunnel(id) {
    try {
      await api(`/api/cloudflare_ddns/tunnels/${id}`, { method: "DELETE" });
      if (activeTunnel?.id === id) setActiveTunnel(null);
      await loadTunnels();
    } catch (err) {
      setError(err?.message || t.deleteTunnelFailed);
    }
  }
  async function handleConfirmDelete() {
    if (!confirm) return;
    const { kind, id } = confirm;
    setConfirm(null);
    if (kind === "record") await deleteRecord(id);
    else if (kind === "ddns") await deleteDdns(id);
    else if (kind === "tunnel") await deleteTunnel(id);
  }
  const tabs = [
    { id: "settings", label: t.tabs.settings, icon: "Key" },
    { id: "ddns", label: t.tabs.ddns, icon: "RefreshCw" },
    { id: "records", label: t.tabs.records, icon: "Globe" },
    { id: "tunnels", label: t.tabs.tunnels, icon: "Route" }
  ];
  const confirmTitle = confirm?.kind === "record" ? t.confirmDeleteRecord : confirm?.kind === "ddns" ? t.confirmDeleteDdns : confirm?.kind === "tunnel" ? t.confirmDeleteTunnel : "";
  return /* @__PURE__ */ jsx6(ModuleViewport, { constrained: true, children: /* @__PURE__ */ jsxs3("div", { className: `flex flex-col h-full min-h-0 ${isDark ? "text-slate-100" : "text-slate-900"}`, children: [
    /* @__PURE__ */ jsxs3(
      "header",
      {
        className: `shrink-0 px-4 py-3 border-b flex items-center justify-between gap-4 ${isDark ? "border-slate-700" : "border-slate-200"}`,
        children: [
          /* @__PURE__ */ jsxs3("div", { className: "min-w-0", children: [
            /* @__PURE__ */ jsx6("p", { className: "text-[10px] uppercase tracking-widest text-orange-500 font-bold", children: t.category }),
            /* @__PURE__ */ jsx6("h1", { className: "text-lg font-semibold truncate", children: t.title }),
            /* @__PURE__ */ jsx6("p", { className: `text-xs mt-0.5 line-clamp-2 ${muted}`, children: t.subtitle })
          ] }),
          /* @__PURE__ */ jsx6(
            "button",
            {
              type: "button",
              onClick: () => refresh(),
              className: `shrink-0 p-2 rounded-lg border ${btnSecondary}`,
              title: "Refresh",
              children: /* @__PURE__ */ jsx6(Icons3.RefreshCw, { className: "w-4 h-4" })
            }
          )
        ]
      }
    ),
    error && /* @__PURE__ */ jsxs3("div", { className: "shrink-0 mx-4 mt-2 rounded-xl border border-red-200 bg-red-50 dark:bg-red-500/10 dark:border-red-500/30 px-4 py-3 text-sm text-red-600 dark:text-red-300 flex justify-between gap-2", children: [
      /* @__PURE__ */ jsx6("span", { children: error }),
      /* @__PURE__ */ jsx6("button", { type: "button", onClick: () => setError(null), className: "shrink-0", children: /* @__PURE__ */ jsx6(Icons3.X, { className: "w-4 h-4" }) })
    ] }),
    /* @__PURE__ */ jsx6(
      ModuleSidebarLayout,
      {
        isDark,
        mobileTitle: t.title,
        sidebar: /* @__PURE__ */ jsx6(
          "aside",
          {
            className: `h-full w-44 shrink-0 border-r flex flex-col ${isDark ? "border-slate-700 bg-slate-900/50" : "border-slate-200 bg-slate-50"}`,
            children: /* @__PURE__ */ jsx6("nav", { className: "flex-1 overflow-y-auto p-2 space-y-0.5", children: tabs.map((item) => {
              const Icon = Icons3[item.icon];
              const active = tab === item.id;
              return /* @__PURE__ */ jsxs3(
                "button",
                {
                  type: "button",
                  onClick: () => setTab(item.id),
                  className: `w-full flex items-center gap-2 px-3 py-2 text-sm rounded-lg transition ${active ? isDark ? "bg-orange-600/25 text-orange-300 font-semibold" : "bg-orange-50 text-orange-700 font-semibold" : `hover:${isDark ? "bg-slate-800" : "bg-slate-100"} ${muted}`}`,
                  children: [
                    /* @__PURE__ */ jsx6(Icon, { className: "w-4 h-4 shrink-0" }),
                    /* @__PURE__ */ jsx6("span", { className: "truncate", children: item.label })
                  ]
                },
                item.id
              );
            }) })
          }
        ),
        children: /* @__PURE__ */ jsxs3("main", { className: "flex-1 min-h-0 overflow-y-auto p-4", children: [
          tab === "settings" && /* @__PURE__ */ jsxs3("section", { className: `rounded-2xl border p-5 space-y-4 ${panel}`, children: [
            /* @__PURE__ */ jsx6("h2", { className: "text-sm font-bold", children: t.apiToken }),
            /* @__PURE__ */ jsxs3("p", { className: `text-xs ${muted}`, children: [
              t.apiTokenHintBefore,
              /* @__PURE__ */ jsx6(
                "a",
                {
                  href: "https://dash.cloudflare.com/profile/api-tokens",
                  target: "_blank",
                  rel: "noreferrer",
                  className: "text-orange-500 underline",
                  children: "Cloudflare Dashboard"
                }
              ),
              t.apiTokenHintAfter
            ] }),
            config?.api_token_set && /* @__PURE__ */ jsxs3("p", { className: "text-sm text-emerald-600 dark:text-emerald-400", children: [
              t.tokenSaved,
              " ",
              /* @__PURE__ */ jsx6("span", { className: "font-mono", children: config.api_token_hint }),
              config.account_name && /* @__PURE__ */ jsxs3(Fragment, { children: [
                " ",
                "\xB7 Account: ",
                /* @__PURE__ */ jsx6("strong", { children: config.account_name })
              ] })
            ] }),
            /* @__PURE__ */ jsxs3("div", { className: "grid gap-3 md:grid-cols-2", children: [
              /* @__PURE__ */ jsxs3("label", { className: `block text-xs font-semibold ${muted}`, children: [
                "API Token ",
                config?.api_token_set && t.tokenOptional,
                /* @__PURE__ */ jsx6(
                  "input",
                  {
                    type: "password",
                    value: tokenInput,
                    onChange: (e) => setTokenInput(e.target.value),
                    placeholder: "Cloudflare API Token",
                    className: `mt-1 w-full rounded-xl border px-3 py-2 text-sm font-mono ${inputCls}`
                  }
                )
              ] }),
              /* @__PURE__ */ jsxs3("label", { className: `block text-xs font-semibold ${muted}`, children: [
                t.accountId,
                /* @__PURE__ */ jsx6(
                  "input",
                  {
                    value: accountId,
                    onChange: (e) => setAccountId(e.target.value),
                    placeholder: t.accountIdPlaceholder,
                    className: `mt-1 w-full rounded-xl border px-3 py-2 text-sm font-mono ${inputCls}`
                  }
                )
              ] })
            ] }),
            /* @__PURE__ */ jsxs3("div", { className: "flex flex-wrap gap-2", children: [
              /* @__PURE__ */ jsx6(
                "button",
                {
                  type: "button",
                  onClick: saveToken,
                  disabled: busy,
                  className: "px-4 py-2 rounded-xl bg-orange-500 hover:bg-orange-400 text-white text-sm font-bold disabled:opacity-50",
                  children: t.saveVerify
                }
              ),
              /* @__PURE__ */ jsx6(
                "button",
                {
                  type: "button",
                  onClick: verifyToken,
                  disabled: busy || !config?.api_token_set,
                  className: `px-4 py-2 rounded-xl border text-sm font-semibold disabled:opacity-50 ${btnSecondary}`,
                  children: t.verifyAgain
                }
              )
            ] }),
            verifyInfo?.valid && /* @__PURE__ */ jsxs3("div", { className: `text-xs space-y-1 ${muted}`, children: [
              /* @__PURE__ */ jsxs3("p", { children: [
                t.tokenValid,
                " ",
                verifyInfo.accounts?.length || 0,
                " ",
                t.accounts
              ] }),
              /* @__PURE__ */ jsx6("ul", { className: "list-disc pl-4", children: (verifyInfo.accounts || []).map((a) => /* @__PURE__ */ jsxs3("li", { className: "font-mono", children: [
                a.name,
                " (",
                a.id,
                ")"
              ] }, a.id)) })
            ] })
          ] }),
          tab === "ddns" && /* @__PURE__ */ jsxs3("div", { className: "space-y-4", children: [
            cronStatus && /* @__PURE__ */ jsxs3(
              "section",
              {
                className: `rounded-2xl border p-4 text-xs ${cronStatus.sync_ok ? "border-emerald-200 bg-emerald-50 dark:border-emerald-900 dark:bg-emerald-950/30" : "border-amber-200 bg-amber-50 dark:border-amber-900 dark:bg-amber-950/30"}`,
                children: [
                  /* @__PURE__ */ jsx6("h2", { className: "text-sm font-bold mb-2", children: t.cronTitle }),
                  !cronStatus.supported && /* @__PURE__ */ jsx6("p", { children: cronStatus.message }),
                  cronStatus.supported && /* @__PURE__ */ jsxs3(Fragment, { children: [
                    /* @__PURE__ */ jsxs3("p", { children: [
                      /* @__PURE__ */ jsx6("strong", { children: cronStatus.sync_ok ? t.cronOk : t.cronCheck }),
                      " \xB7 ",
                      cronStatus.enabled_profiles,
                      " ",
                      t.cronProfiles,
                      " ",
                      cronStatus.intervals_minutes?.length || 0,
                      " ",
                      t.cronIntervals,
                      cronStatus.cron_daemon?.service && /* @__PURE__ */ jsxs3(Fragment, { children: [
                        " ",
                        "\xB7 ",
                        t.cronDaemon,
                        " ",
                        cronStatus.cron_daemon.service,
                        ":",
                        " ",
                        cronStatus.cron_service_active ? t.cronRunning : t.cronStopped
                      ] })
                    ] }),
                    /* @__PURE__ */ jsx6("p", { className: `mt-1 ${muted}`, children: t.cronPlayHint }),
                    (cronStatus.cron_entries || []).length > 0 ? /* @__PURE__ */ jsx6("ul", { className: "mt-2 font-mono space-y-1 text-[11px]", children: cronStatus.cron_entries.map((line, i) => /* @__PURE__ */ jsx6("li", { className: "break-all", children: line }, i)) }) : /* @__PURE__ */ jsx6("p", { className: `mt-1 ${muted}`, children: t.cronNoLines }),
                    !cronStatus.crontab_available && cronStatus.install_hint && /* @__PURE__ */ jsx6("p", { className: "mt-2 text-amber-800 dark:text-amber-200", children: cronStatus.install_hint }),
                    cronStatus.crontab_available && cronStatus.cron_service_active === false && cronStatus.install_hint && /* @__PURE__ */ jsx6("p", { className: "mt-2 text-amber-800 dark:text-amber-200", children: cronStatus.install_hint }),
                    !cronStatus.sync_ok && /* @__PURE__ */ jsx6(
                      "button",
                      {
                        type: "button",
                        onClick: syncCron,
                        disabled: busy,
                        className: "mt-3 px-3 py-1.5 rounded-lg bg-orange-600 hover:bg-orange-500 text-white text-xs font-bold disabled:opacity-50",
                        children: t.cronSync
                      }
                    ),
                    cronStatus.scheduler_sync?.message && /* @__PURE__ */ jsx6("p", { className: `mt-2 ${muted}`, children: cronStatus.scheduler_sync.message }),
                    !cronStatus.run_script_exists && /* @__PURE__ */ jsx6("p", { className: "mt-1 text-red-600", children: t.cronMissingScript }),
                    (cronStatus.log_files || []).map(
                      (lf) => lf.tail?.length > 0 && /* @__PURE__ */ jsxs3("details", { className: "mt-2", children: [
                        /* @__PURE__ */ jsxs3("summary", { className: "cursor-pointer", children: [
                          "Log ",
                          lf.interval_minutes,
                          "p \u2014 ",
                          lf.path
                        ] }),
                        /* @__PURE__ */ jsx6("pre", { className: "mt-1 whitespace-pre-wrap text-[10px] opacity-80", children: lf.tail.join("\n") })
                      ] }, lf.path)
                    )
                  ] })
                ]
              }
            ),
            /* @__PURE__ */ jsxs3("section", { className: `rounded-2xl border p-5 space-y-3 ${panel}`, children: [
              /* @__PURE__ */ jsx6("h2", { className: "text-sm font-bold", children: t.addDdns }),
              /* @__PURE__ */ jsxs3("div", { className: "grid gap-2 md:grid-cols-4", children: [
                /* @__PURE__ */ jsxs3(
                  "select",
                  {
                    value: ddnsZone?.id || "",
                    onChange: (e) => setDdnsZone(zones.find((z) => z.id === e.target.value) || null),
                    className: `rounded-xl border px-3 py-2 text-sm ${inputCls}`,
                    children: [
                      /* @__PURE__ */ jsx6("option", { value: "", children: t.selectZone }),
                      zones.map((z) => /* @__PURE__ */ jsx6("option", { value: z.id, children: z.name }, z.id))
                    ]
                  }
                ),
                /* @__PURE__ */ jsx6(
                  "input",
                  {
                    value: ddnsDraft.name || "",
                    onChange: (e) => setDdnsDraft({ ...ddnsDraft, name: e.target.value }),
                    placeholder: t.profileName,
                    className: `rounded-xl border px-3 py-2 text-sm ${inputCls}`
                  }
                ),
                /* @__PURE__ */ jsx6(
                  "input",
                  {
                    value: ddnsDraft.record_name ?? "@",
                    onChange: (e) => setDdnsDraft({ ...ddnsDraft, record_name: e.target.value }),
                    placeholder: t.recordName,
                    className: `rounded-xl border px-3 py-2 text-sm ${inputCls}`
                  }
                ),
                /* @__PURE__ */ jsxs3(
                  "select",
                  {
                    value: ddnsDraft.record_type || "A",
                    onChange: (e) => setDdnsDraft({ ...ddnsDraft, record_type: e.target.value }),
                    className: `rounded-xl border px-3 py-2 text-sm ${inputCls}`,
                    children: [
                      /* @__PURE__ */ jsx6("option", { value: "A", children: "A" }),
                      /* @__PURE__ */ jsx6("option", { value: "AAAA", children: "AAAA" })
                    ]
                  }
                )
              ] }),
              /* @__PURE__ */ jsxs3("div", { className: "grid gap-2 md:grid-cols-4", children: [
                /* @__PURE__ */ jsxs3(
                  "select",
                  {
                    value: ddnsDraft.ip_source || "public",
                    onChange: (e) => setDdnsDraft({ ...ddnsDraft, ip_source: e.target.value }),
                    className: `rounded-xl border px-3 py-2 text-sm ${inputCls}`,
                    children: [
                      /* @__PURE__ */ jsx6("option", { value: "public", children: t.publicIp }),
                      /* @__PURE__ */ jsx6("option", { value: "interface", children: t.networkIface }),
                      /* @__PURE__ */ jsx6("option", { value: "custom_url", children: t.customUrl })
                    ]
                  }
                ),
                ddnsDraft.ip_source === "interface" && /* @__PURE__ */ jsx6(
                  "input",
                  {
                    value: ddnsDraft.interface_name || "",
                    onChange: (e) => setDdnsDraft({ ...ddnsDraft, interface_name: e.target.value }),
                    placeholder: "eth0",
                    className: `rounded-xl border px-3 py-2 text-sm ${inputCls}`
                  }
                ),
                ddnsDraft.ip_source === "custom_url" && /* @__PURE__ */ jsx6(
                  "input",
                  {
                    value: ddnsDraft.custom_ip_url || "",
                    onChange: (e) => setDdnsDraft({ ...ddnsDraft, custom_ip_url: e.target.value }),
                    placeholder: "https://\u2026",
                    className: `md:col-span-2 rounded-xl border px-3 py-2 text-sm ${inputCls}`
                  }
                ),
                /* @__PURE__ */ jsx6(
                  "input",
                  {
                    type: "number",
                    min: 1,
                    max: 1440,
                    value: ddnsDraft.interval_minutes ?? 5,
                    onChange: (e) => {
                      const n = Number(e.target.value);
                      setDdnsDraft({
                        ...ddnsDraft,
                        interval_minutes: Number.isFinite(n) ? n : 5
                      });
                    },
                    placeholder: t.intervalMin,
                    className: `rounded-xl border px-3 py-2 text-sm ${inputCls}`
                  }
                ),
                /* @__PURE__ */ jsxs3("label", { className: "flex items-center gap-2 text-sm px-2", children: [
                  /* @__PURE__ */ jsx6(
                    "input",
                    {
                      type: "checkbox",
                      checked: !!ddnsDraft.proxied,
                      onChange: (e) => setDdnsDraft({ ...ddnsDraft, proxied: e.target.checked })
                    }
                  ),
                  t.proxied
                ] }),
                /* @__PURE__ */ jsx6(
                  "button",
                  {
                    type: "button",
                    onClick: createDdns,
                    disabled: busy,
                    className: "rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-sm font-bold px-4 py-2 disabled:opacity-50",
                    children: busy ? "\u2026" : t.add
                  }
                )
              ] })
            ] }),
            /* @__PURE__ */ jsxs3("section", { className: `rounded-2xl border p-5 ${panel}`, children: [
              /* @__PURE__ */ jsxs3("h2", { className: "text-sm font-bold mb-3", children: [
                t.ddnsProfiles,
                " (",
                profiles.length,
                ")"
              ] }),
              /* @__PURE__ */ jsxs3("ul", { className: `divide-y ${isDark ? "divide-slate-800" : "divide-slate-100"}`, children: [
                profiles.map((p) => /* @__PURE__ */ jsxs3("li", { className: "py-3 flex flex-col md:flex-row md:items-center gap-2 md:gap-4", children: [
                  /* @__PURE__ */ jsxs3("div", { className: "flex-1 min-w-0", children: [
                    /* @__PURE__ */ jsxs3("div", { className: "flex items-center gap-2 flex-wrap", children: [
                      /* @__PURE__ */ jsx6("span", { className: "font-semibold text-sm", children: p.name }),
                      /* @__PURE__ */ jsx6("span", { className: `text-[10px] uppercase tracking-wider px-2 py-0.5 rounded-full ${statusPill(p.last_status)}`, children: p.last_status || t.pending }),
                      !p.enabled && /* @__PURE__ */ jsx6("span", { className: "text-[10px] uppercase tracking-wider px-2 py-0.5 rounded-full bg-slate-100 text-slate-500 dark:bg-slate-800 dark:text-slate-400", children: t.disabled })
                    ] }),
                    /* @__PURE__ */ jsxs3("p", { className: `text-xs font-mono mt-1 ${muted}`, children: [
                      p.record_name,
                      ".",
                      p.zone_name,
                      " \xB7 ",
                      p.record_type,
                      " \xB7 ",
                      p.ip_source,
                      " \xB7 ",
                      t.every,
                      " ",
                      p.interval_minutes,
                      t.min
                    ] }),
                    /* @__PURE__ */ jsxs3("p", { className: `text-xs mt-0.5 ${muted}`, children: [
                      "IP: ",
                      p.last_ip || "\u2014",
                      " \xB7 ",
                      t.lastRun,
                      " ",
                      fmtTime(p.last_run),
                      p.last_error && /* @__PURE__ */ jsx6("span", { className: "text-red-500 ml-2", children: p.last_error })
                    ] })
                  ] }),
                  /* @__PURE__ */ jsxs3("div", { className: "flex items-center gap-2 shrink-0", children: [
                    /* @__PURE__ */ jsx6(
                      "button",
                      {
                        type: "button",
                        onClick: () => runDdns(p.id),
                        className: `p-2 rounded-lg border ${btnSecondary}`,
                        title: t.runNow,
                        children: /* @__PURE__ */ jsx6(Icons3.Play, { className: "w-4 h-4 text-emerald-500" })
                      }
                    ),
                    /* @__PURE__ */ jsx6(
                      "button",
                      {
                        type: "button",
                        onClick: () => toggleDdns(p),
                        className: `p-2 rounded-lg border ${btnSecondary}`,
                        title: p.enabled ? t.disable : t.enable,
                        children: p.enabled ? /* @__PURE__ */ jsx6(Icons3.Pause, { className: "w-4 h-4" }) : /* @__PURE__ */ jsx6(Icons3.PlayCircle, { className: "w-4 h-4" })
                      }
                    ),
                    /* @__PURE__ */ jsx6(
                      "button",
                      {
                        type: "button",
                        onClick: () => setConfirm({ kind: "ddns", id: p.id }),
                        className: "p-2 rounded-lg hover:bg-red-50 dark:hover:bg-red-500/10",
                        children: /* @__PURE__ */ jsx6(Icons3.Trash2, { className: "w-4 h-4 text-red-500" })
                      }
                    )
                  ] })
                ] }, p.id)),
                profiles.length === 0 && /* @__PURE__ */ jsx6("li", { className: `py-4 text-xs ${muted}`, children: t.noProfiles })
              ] })
            ] })
          ] }),
          tab === "records" && /* @__PURE__ */ jsxs3("div", { className: "grid grid-cols-1 lg:grid-cols-3 gap-4 min-h-0", children: [
            /* @__PURE__ */ jsxs3("aside", { className: `rounded-2xl border p-4 ${panel}`, children: [
              /* @__PURE__ */ jsx6("h2", { className: "text-sm font-bold mb-3", children: t.zones }),
              /* @__PURE__ */ jsxs3("ul", { className: "space-y-1 max-h-64 lg:max-h-none overflow-y-auto", children: [
                zones.map((z) => /* @__PURE__ */ jsx6("li", { children: /* @__PURE__ */ jsx6(
                  "button",
                  {
                    type: "button",
                    onClick: () => openRecordsZone(z),
                    className: `w-full text-left px-3 py-2 rounded-xl text-sm transition ${recordsZone?.id === z.id ? isDark ? "bg-orange-600/20 text-orange-300" : "bg-orange-50 text-orange-700" : isDark ? "hover:bg-slate-800" : "hover:bg-slate-100"}`,
                    children: z.name
                  }
                ) }, z.id)),
                zones.length === 0 && /* @__PURE__ */ jsx6("li", { className: `text-xs ${muted}`, children: t.noZones })
              ] })
            ] }),
            /* @__PURE__ */ jsx6("section", { className: `lg:col-span-2 rounded-2xl border p-4 ${panel}`, children: !recordsZone ? /* @__PURE__ */ jsx6("p", { className: `text-sm ${muted}`, children: t.selectZoneRecords }) : /* @__PURE__ */ jsxs3("div", { className: "space-y-4", children: [
              /* @__PURE__ */ jsx6("h2", { className: "text-base font-bold", children: recordsZone.name }),
              /* @__PURE__ */ jsxs3("div", { className: "grid grid-cols-2 md:grid-cols-6 gap-2", children: [
                /* @__PURE__ */ jsx6(
                  "select",
                  {
                    value: recordDraft.type,
                    onChange: (e) => setRecordDraft({ ...recordDraft, type: e.target.value }),
                    className: `rounded-xl border px-3 py-2 text-sm ${inputCls}`,
                    children: RECORD_TYPES.map((rt) => /* @__PURE__ */ jsx6("option", { children: rt }, rt))
                  }
                ),
                /* @__PURE__ */ jsx6(
                  "input",
                  {
                    value: recordDraft.name,
                    onChange: (e) => setRecordDraft({ ...recordDraft, name: e.target.value }),
                    placeholder: "name",
                    className: `rounded-xl border px-3 py-2 text-sm ${inputCls}`
                  }
                ),
                /* @__PURE__ */ jsx6(
                  "input",
                  {
                    value: recordDraft.content,
                    onChange: (e) => setRecordDraft({ ...recordDraft, content: e.target.value }),
                    placeholder: "content",
                    className: `md:col-span-2 rounded-xl border px-3 py-2 text-sm ${inputCls}`
                  }
                ),
                /* @__PURE__ */ jsx6(
                  "button",
                  {
                    type: "button",
                    onClick: addRecord,
                    className: "rounded-xl bg-emerald-600 text-white text-sm font-bold",
                    children: t.addRecord
                  }
                )
              ] }),
              /* @__PURE__ */ jsxs3("ul", { className: `divide-y ${isDark ? "divide-slate-800" : "divide-slate-100"}`, children: [
                records.map((r2) => /* @__PURE__ */ jsxs3("li", { className: "flex items-center justify-between py-2 text-sm gap-2", children: [
                  /* @__PURE__ */ jsxs3("div", { className: "min-w-0 flex-1", children: [
                    /* @__PURE__ */ jsx6("span", { className: "text-[10px] uppercase px-2 py-0.5 rounded-full bg-orange-100 text-orange-600 dark:bg-orange-500/15 dark:text-orange-300 mr-2", children: r2.type }),
                    /* @__PURE__ */ jsx6("span", { className: "font-mono", children: r2.name }),
                    /* @__PURE__ */ jsx6("span", { className: `mx-1 ${muted}`, children: "\u2192" }),
                    /* @__PURE__ */ jsx6("span", { className: "font-mono break-all", children: r2.content }),
                    r2.proxied && /* @__PURE__ */ jsx6("span", { className: "ml-2 text-[10px] text-orange-500", children: t.proxiedLabel })
                  ] }),
                  /* @__PURE__ */ jsx6(
                    "button",
                    {
                      type: "button",
                      onClick: () => setConfirm({ kind: "record", id: r2.id }),
                      className: "shrink-0 text-slate-400 hover:text-red-500",
                      children: /* @__PURE__ */ jsx6(Icons3.Trash2, { className: "w-4 h-4" })
                    }
                  )
                ] }, r2.id)),
                records.length === 0 && /* @__PURE__ */ jsx6("li", { className: `py-2 text-xs ${muted}`, children: t.noRecords })
              ] })
            ] }) })
          ] }),
          tab === "tunnels" && /* @__PURE__ */ jsxs3("div", { className: "grid grid-cols-1 lg:grid-cols-3 gap-4", children: [
            /* @__PURE__ */ jsxs3("aside", { className: "space-y-4", children: [
              /* @__PURE__ */ jsxs3("section", { className: `rounded-2xl border p-4 ${panel}`, children: [
                /* @__PURE__ */ jsx6("h2", { className: "text-sm font-bold mb-2", children: t.cloudflared }),
                /* @__PURE__ */ jsx6("p", { className: `text-xs ${muted}`, children: tunnelStatus?.installed ? /* @__PURE__ */ jsxs3(Fragment, { children: [
                  t.installed,
                  " ",
                  /* @__PURE__ */ jsx6("span", { className: "font-mono", children: tunnelStatus.cloudflared_path })
                ] }) : t.notInstalled }),
                tunnelStatus?.installed && /* @__PURE__ */ jsxs3("p", { className: "text-xs mt-1", children: [
                  t.service,
                  " ",
                  /* @__PURE__ */ jsx6("span", { className: tunnelStatus.active ? "text-emerald-500" : muted, children: tunnelStatus.message || "unknown" })
                ] })
              ] }),
              /* @__PURE__ */ jsxs3("section", { className: `rounded-2xl border p-4 ${panel}`, children: [
                /* @__PURE__ */ jsx6("h2", { className: "text-sm font-bold mb-3", children: t.tunnels }),
                /* @__PURE__ */ jsxs3("div", { className: "flex gap-2 mb-3", children: [
                  /* @__PURE__ */ jsx6(
                    "input",
                    {
                      value: tunnelName,
                      onChange: (e) => setTunnelName(e.target.value),
                      placeholder: "my-tunnel",
                      className: `flex-1 rounded-xl border px-3 py-2 text-sm ${inputCls}`
                    }
                  ),
                  /* @__PURE__ */ jsx6(
                    "button",
                    {
                      type: "button",
                      onClick: createTunnel,
                      className: "px-3 py-2 rounded-xl bg-orange-500 text-white text-xs font-bold",
                      children: "+"
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxs3("ul", { className: "space-y-1 max-h-48 overflow-y-auto", children: [
                  tunnels.map((tun) => /* @__PURE__ */ jsxs3("li", { className: "flex items-center gap-1", children: [
                    /* @__PURE__ */ jsxs3(
                      "button",
                      {
                        type: "button",
                        onClick: () => openTunnel(tun),
                        className: `flex-1 text-left px-3 py-2 rounded-xl text-sm transition ${activeTunnel?.id === tun.id ? isDark ? "bg-orange-600/20 text-orange-300" : "bg-orange-50 text-orange-700" : isDark ? "hover:bg-slate-800" : "hover:bg-slate-100"}`,
                        children: [
                          /* @__PURE__ */ jsx6("span", { className: "font-semibold", children: tun.name }),
                          /* @__PURE__ */ jsx6("span", { className: `block text-[10px] ${muted}`, children: tun.status })
                        ]
                      }
                    ),
                    /* @__PURE__ */ jsx6(
                      "button",
                      {
                        type: "button",
                        onClick: () => setConfirm({ kind: "tunnel", id: tun.id }),
                        className: "p-2 text-slate-400 hover:text-red-500",
                        children: /* @__PURE__ */ jsx6(Icons3.Trash2, { className: "w-4 h-4" })
                      }
                    )
                  ] }, tun.id)),
                  tunnels.length === 0 && /* @__PURE__ */ jsx6("li", { className: `text-xs ${muted}`, children: t.noTunnels })
                ] })
              ] })
            ] }),
            /* @__PURE__ */ jsx6("section", { className: `lg:col-span-2 rounded-2xl border p-4 ${panel}`, children: !activeTunnel ? /* @__PURE__ */ jsx6("p", { className: `text-sm ${muted}`, children: t.selectTunnel }) : /* @__PURE__ */ jsxs3("div", { className: "space-y-4", children: [
              /* @__PURE__ */ jsxs3("header", { className: "flex items-center justify-between", children: [
                /* @__PURE__ */ jsx6("h2", { className: "text-base font-bold", children: activeTunnel.name }),
                /* @__PURE__ */ jsx6("span", { className: `text-[10px] font-mono ${muted}`, children: activeTunnel.id })
              ] }),
              /* @__PURE__ */ jsxs3("div", { className: "space-y-2", children: [
                ingress.map((rule, idx) => /* @__PURE__ */ jsxs3("div", { className: "grid grid-cols-1 md:grid-cols-4 gap-2", children: [
                  /* @__PURE__ */ jsx6(
                    "input",
                    {
                      value: rule.hostname,
                      onChange: (e) => {
                        const next = [...ingress];
                        next[idx] = { ...rule, hostname: e.target.value };
                        setIngress(next);
                      },
                      placeholder: t.hostname,
                      className: `rounded-xl border px-3 py-2 text-sm ${inputCls}`
                    }
                  ),
                  /* @__PURE__ */ jsx6(
                    "input",
                    {
                      value: rule.service,
                      onChange: (e) => {
                        const next = [...ingress];
                        next[idx] = { ...rule, service: e.target.value };
                        setIngress(next);
                      },
                      placeholder: t.serviceUrl,
                      className: `md:col-span-2 rounded-xl border px-3 py-2 text-sm font-mono ${inputCls}`
                    }
                  ),
                  /* @__PURE__ */ jsx6(
                    "button",
                    {
                      type: "button",
                      onClick: () => setIngress(ingress.filter((_, i) => i !== idx)),
                      className: "text-red-500 text-sm",
                      disabled: ingress.length <= 1,
                      children: t.remove
                    }
                  )
                ] }, idx)),
                /* @__PURE__ */ jsx6(
                  "button",
                  {
                    type: "button",
                    onClick: () => setIngress([...ingress, { hostname: "", service: "http://localhost:8080", path: "" }]),
                    className: "text-xs text-orange-500 font-semibold",
                    children: t.addRule
                  }
                ),
                /* @__PURE__ */ jsx6(
                  "button",
                  {
                    type: "button",
                    onClick: () => setIngress([...ingress, { hostname: "", service: "http_status:404", path: "" }]),
                    className: `text-xs ml-3 ${muted}`,
                    children: t.catchAll404
                  }
                )
              ] }),
              /* @__PURE__ */ jsxs3("div", { className: "flex flex-wrap gap-2 pt-2", children: [
                /* @__PURE__ */ jsx6(
                  "button",
                  {
                    type: "button",
                    onClick: saveTunnelConfig,
                    className: "px-4 py-2 rounded-xl bg-emerald-600 text-white text-sm font-bold",
                    children: t.saveConfig
                  }
                ),
                /* @__PURE__ */ jsx6(
                  "button",
                  {
                    type: "button",
                    onClick: installTunnel,
                    className: "px-4 py-2 rounded-xl bg-orange-500 text-white text-sm font-bold",
                    children: t.installService
                  }
                )
              ] }),
              /* @__PURE__ */ jsxs3("p", { className: `text-xs ${muted}`, children: [
                t.configPath,
                " ",
                /* @__PURE__ */ jsxs3("span", { className: "font-mono", children: [
                  config?.config_dir,
                  "/config.yml"
                ] }),
                ". ",
                t.configHint
              ] })
            ] }) })
          ] })
        ] })
      }
    ),
    /* @__PURE__ */ jsx6(WindowModal, { open: !!confirm, onClose: () => setConfirm(null), title: confirmTitle, maxWidth: "sm", children: /* @__PURE__ */ jsxs3("div", { className: "p-4 flex justify-end gap-2", children: [
      /* @__PURE__ */ jsx6("button", { type: "button", onClick: () => setConfirm(null), className: `px-4 py-2 rounded-lg border text-sm ${btnSecondary}`, children: t.cancel }),
      /* @__PURE__ */ jsx6(
        "button",
        {
          type: "button",
          onClick: handleConfirmDelete,
          className: "px-4 py-2 rounded-lg bg-red-600 hover:bg-red-500 text-white text-sm font-bold",
          children: t.delete
        }
      )
    ] }) })
  ] }) });
}
export {
  CloudflareDdns as default
};
