# AppStore Manager Module Init
