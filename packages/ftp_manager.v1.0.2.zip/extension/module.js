var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);

// src/modules/ftp_manager/index.tsx
import { useCallback, useEffect as useEffect3, useMemo, useState as useState3 } from "react";
import { Link } from "react-router-dom";

// src/core/hooks/useAppShellContext.ts
import { useOutletContext } from "react-router-dom";

// src/core/shell/ShellContext.tsx
import { createContext, useContext } from "react";
import { jsx } from "react/jsx-runtime";
var ShellContext = createContext(null);
function useShellContext() {
  return useContext(ShellContext);
}

// src/core/hooks/useAppShellContext.ts
var FALLBACK = {
  theme: localStorage.getItem("copanel_theme") || "light",
  setTheme: () => {
  },
  language: localStorage.getItem("copanel_lang") || "en",
  setLanguage: () => {
  }
};
function useAppShellContext() {
  const shell = useShellContext();
  const outlet = useOutletContext();
  if (shell) return shell;
  if (outlet?.theme) {
    return {
      theme: outlet.theme,
      setTheme: outlet.setTheme ?? (() => {
      }),
      language: outlet.language ?? "en",
      setLanguage: outlet.setLanguage ?? (() => {
      })
    };
  }
  return FALLBACK;
}

// src/core/shell/WindowViewportContext.tsx
import { createContext as createContext2, useContext as useContext2, useRef } from "react";
import { jsx as jsx2 } from "react/jsx-runtime";
var WindowViewportContext = createContext2(null);
function useWindowViewport() {
  return useContext2(WindowViewportContext);
}
function useIsWindowedModule() {
  return useWindowViewport()?.isWindowed === true;
}

// node_modules/clsx/dist/clsx.mjs
function r(e) {
  var t, f, n = "";
  if ("string" == typeof e || "number" == typeof e) n += e;
  else if ("object" == typeof e) if (Array.isArray(e)) {
    var o = e.length;
    for (t = 0; t < o; t++) e[t] && (f = r(e[t])) && (n && (n += " "), n += f);
  } else for (f in e) e[f] && (n && (n += " "), n += f);
  return n;
}
function clsx() {
  for (var e, t, f = 0, n = "", o = arguments.length; f < o; f++) (e = arguments[f]) && (t = r(e)) && (n && (n += " "), n += t);
  return n;
}

// node_modules/tailwind-merge/dist/bundle-mjs.mjs
var CLASS_PART_SEPARATOR = "-";
var createClassGroupUtils = (config) => {
  const classMap = createClassMap(config);
  const {
    conflictingClassGroups,
    conflictingClassGroupModifiers
  } = config;
  const getClassGroupId = (className) => {
    const classParts = className.split(CLASS_PART_SEPARATOR);
    if (classParts[0] === "" && classParts.length !== 1) {
      classParts.shift();
    }
    return getGroupRecursive(classParts, classMap) || getGroupIdForArbitraryProperty(className);
  };
  const getConflictingClassGroupIds = (classGroupId, hasPostfixModifier) => {
    const conflicts = conflictingClassGroups[classGroupId] || [];
    if (hasPostfixModifier && conflictingClassGroupModifiers[classGroupId]) {
      return [...conflicts, ...conflictingClassGroupModifiers[classGroupId]];
    }
    return conflicts;
  };
  return {
    getClassGroupId,
    getConflictingClassGroupIds
  };
};
var getGroupRecursive = (classParts, classPartObject) => {
  if (classParts.length === 0) {
    return classPartObject.classGroupId;
  }
  const currentClassPart = classParts[0];
  const nextClassPartObject = classPartObject.nextPart.get(currentClassPart);
  const classGroupFromNextClassPart = nextClassPartObject ? getGroupRecursive(classParts.slice(1), nextClassPartObject) : void 0;
  if (classGroupFromNextClassPart) {
    return classGroupFromNextClassPart;
  }
  if (classPartObject.validators.length === 0) {
    return void 0;
  }
  const classRest = classParts.join(CLASS_PART_SEPARATOR);
  return classPartObject.validators.find(({
    validator
  }) => validator(classRest))?.classGroupId;
};
var arbitraryPropertyRegex = /^\[(.+)\]$/;
var getGroupIdForArbitraryProperty = (className) => {
  if (arbitraryPropertyRegex.test(className)) {
    const arbitraryPropertyClassName = arbitraryPropertyRegex.exec(className)[1];
    const property = arbitraryPropertyClassName?.substring(0, arbitraryPropertyClassName.indexOf(":"));
    if (property) {
      return "arbitrary.." + property;
    }
  }
};
var createClassMap = (config) => {
  const {
    theme,
    prefix
  } = config;
  const classMap = {
    nextPart: /* @__PURE__ */ new Map(),
    validators: []
  };
  const prefixedClassGroupEntries = getPrefixedClassGroupEntries(Object.entries(config.classGroups), prefix);
  prefixedClassGroupEntries.forEach(([classGroupId, classGroup]) => {
    processClassesRecursively(classGroup, classMap, classGroupId, theme);
  });
  return classMap;
};
var processClassesRecursively = (classGroup, classPartObject, classGroupId, theme) => {
  classGroup.forEach((classDefinition) => {
    if (typeof classDefinition === "string") {
      const classPartObjectToEdit = classDefinition === "" ? classPartObject : getPart(classPartObject, classDefinition);
      classPartObjectToEdit.classGroupId = classGroupId;
      return;
    }
    if (typeof classDefinition === "function") {
      if (isThemeGetter(classDefinition)) {
        processClassesRecursively(classDefinition(theme), classPartObject, classGroupId, theme);
        return;
      }
      classPartObject.validators.push({
        validator: classDefinition,
        classGroupId
      });
      return;
    }
    Object.entries(classDefinition).forEach(([key, classGroup2]) => {
      processClassesRecursively(classGroup2, getPart(classPartObject, key), classGroupId, theme);
    });
  });
};
var getPart = (classPartObject, path) => {
  let currentClassPartObject = classPartObject;
  path.split(CLASS_PART_SEPARATOR).forEach((pathPart) => {
    if (!currentClassPartObject.nextPart.has(pathPart)) {
      currentClassPartObject.nextPart.set(pathPart, {
        nextPart: /* @__PURE__ */ new Map(),
        validators: []
      });
    }
    currentClassPartObject = currentClassPartObject.nextPart.get(pathPart);
  });
  return currentClassPartObject;
};
var isThemeGetter = (func) => func.isThemeGetter;
var getPrefixedClassGroupEntries = (classGroupEntries, prefix) => {
  if (!prefix) {
    return classGroupEntries;
  }
  return classGroupEntries.map(([classGroupId, classGroup]) => {
    const prefixedClassGroup = classGroup.map((classDefinition) => {
      if (typeof classDefinition === "string") {
        return prefix + classDefinition;
      }
      if (typeof classDefinition === "object") {
        return Object.fromEntries(Object.entries(classDefinition).map(([key, value]) => [prefix + key, value]));
      }
      return classDefinition;
    });
    return [classGroupId, prefixedClassGroup];
  });
};
var createLruCache = (maxCacheSize) => {
  if (maxCacheSize < 1) {
    return {
      get: () => void 0,
      set: () => {
      }
    };
  }
  let cacheSize = 0;
  let cache = /* @__PURE__ */ new Map();
  let previousCache = /* @__PURE__ */ new Map();
  const update = (key, value) => {
    cache.set(key, value);
    cacheSize++;
    if (cacheSize > maxCacheSize) {
      cacheSize = 0;
      previousCache = cache;
      cache = /* @__PURE__ */ new Map();
    }
  };
  return {
    get(key) {
      let value = cache.get(key);
      if (value !== void 0) {
        return value;
      }
      if ((value = previousCache.get(key)) !== void 0) {
        update(key, value);
        return value;
      }
    },
    set(key, value) {
      if (cache.has(key)) {
        cache.set(key, value);
      } else {
        update(key, value);
      }
    }
  };
};
var IMPORTANT_MODIFIER = "!";
var createParseClassName = (config) => {
  const {
    separator,
    experimentalParseClassName
  } = config;
  const isSeparatorSingleCharacter = separator.length === 1;
  const firstSeparatorCharacter = separator[0];
  const separatorLength = separator.length;
  const parseClassName = (className) => {
    const modifiers = [];
    let bracketDepth = 0;
    let modifierStart = 0;
    let postfixModifierPosition;
    for (let index = 0; index < className.length; index++) {
      let currentCharacter = className[index];
      if (bracketDepth === 0) {
        if (currentCharacter === firstSeparatorCharacter && (isSeparatorSingleCharacter || className.slice(index, index + separatorLength) === separator)) {
          modifiers.push(className.slice(modifierStart, index));
          modifierStart = index + separatorLength;
          continue;
        }
        if (currentCharacter === "/") {
          postfixModifierPosition = index;
          continue;
        }
      }
      if (currentCharacter === "[") {
        bracketDepth++;
      } else if (currentCharacter === "]") {
        bracketDepth--;
      }
    }
    const baseClassNameWithImportantModifier = modifiers.length === 0 ? className : className.substring(modifierStart);
    const hasImportantModifier = baseClassNameWithImportantModifier.startsWith(IMPORTANT_MODIFIER);
    const baseClassName = hasImportantModifier ? baseClassNameWithImportantModifier.substring(1) : baseClassNameWithImportantModifier;
    const maybePostfixModifierPosition = postfixModifierPosition && postfixModifierPosition > modifierStart ? postfixModifierPosition - modifierStart : void 0;
    return {
      modifiers,
      hasImportantModifier,
      baseClassName,
      maybePostfixModifierPosition
    };
  };
  if (experimentalParseClassName) {
    return (className) => experimentalParseClassName({
      className,
      parseClassName
    });
  }
  return parseClassName;
};
var sortModifiers = (modifiers) => {
  if (modifiers.length <= 1) {
    return modifiers;
  }
  const sortedModifiers = [];
  let unsortedModifiers = [];
  modifiers.forEach((modifier) => {
    const isArbitraryVariant = modifier[0] === "[";
    if (isArbitraryVariant) {
      sortedModifiers.push(...unsortedModifiers.sort(), modifier);
      unsortedModifiers = [];
    } else {
      unsortedModifiers.push(modifier);
    }
  });
  sortedModifiers.push(...unsortedModifiers.sort());
  return sortedModifiers;
};
var createConfigUtils = (config) => ({
  cache: createLruCache(config.cacheSize),
  parseClassName: createParseClassName(config),
  ...createClassGroupUtils(config)
});
var SPLIT_CLASSES_REGEX = /\s+/;
var mergeClassList = (classList, configUtils) => {
  const {
    parseClassName,
    getClassGroupId,
    getConflictingClassGroupIds
  } = configUtils;
  const classGroupsInConflict = [];
  const classNames = classList.trim().split(SPLIT_CLASSES_REGEX);
  let result = "";
  for (let index = classNames.length - 1; index >= 0; index -= 1) {
    const originalClassName = classNames[index];
    const {
      modifiers,
      hasImportantModifier,
      baseClassName,
      maybePostfixModifierPosition
    } = parseClassName(originalClassName);
    let hasPostfixModifier = Boolean(maybePostfixModifierPosition);
    let classGroupId = getClassGroupId(hasPostfixModifier ? baseClassName.substring(0, maybePostfixModifierPosition) : baseClassName);
    if (!classGroupId) {
      if (!hasPostfixModifier) {
        result = originalClassName + (result.length > 0 ? " " + result : result);
        continue;
      }
      classGroupId = getClassGroupId(baseClassName);
      if (!classGroupId) {
        result = originalClassName + (result.length > 0 ? " " + result : result);
        continue;
      }
      hasPostfixModifier = false;
    }
    const variantModifier = sortModifiers(modifiers).join(":");
    const modifierId = hasImportantModifier ? variantModifier + IMPORTANT_MODIFIER : variantModifier;
    const classId = modifierId + classGroupId;
    if (classGroupsInConflict.includes(classId)) {
      continue;
    }
    classGroupsInConflict.push(classId);
    const conflictGroups = getConflictingClassGroupIds(classGroupId, hasPostfixModifier);
    for (let i = 0; i < conflictGroups.length; ++i) {
      const group = conflictGroups[i];
      classGroupsInConflict.push(modifierId + group);
    }
    result = originalClassName + (result.length > 0 ? " " + result : result);
  }
  return result;
};
function twJoin() {
  let index = 0;
  let argument;
  let resolvedValue;
  let string = "";
  while (index < arguments.length) {
    if (argument = arguments[index++]) {
      if (resolvedValue = toValue(argument)) {
        string && (string += " ");
        string += resolvedValue;
      }
    }
  }
  return string;
}
var toValue = (mix) => {
  if (typeof mix === "string") {
    return mix;
  }
  let resolvedValue;
  let string = "";
  for (let k = 0; k < mix.length; k++) {
    if (mix[k]) {
      if (resolvedValue = toValue(mix[k])) {
        string && (string += " ");
        string += resolvedValue;
      }
    }
  }
  return string;
};
function createTailwindMerge(createConfigFirst, ...createConfigRest) {
  let configUtils;
  let cacheGet;
  let cacheSet;
  let functionToCall = initTailwindMerge;
  function initTailwindMerge(classList) {
    const config = createConfigRest.reduce((previousConfig, createConfigCurrent) => createConfigCurrent(previousConfig), createConfigFirst());
    configUtils = createConfigUtils(config);
    cacheGet = configUtils.cache.get;
    cacheSet = configUtils.cache.set;
    functionToCall = tailwindMerge;
    return tailwindMerge(classList);
  }
  function tailwindMerge(classList) {
    const cachedResult = cacheGet(classList);
    if (cachedResult) {
      return cachedResult;
    }
    const result = mergeClassList(classList, configUtils);
    cacheSet(classList, result);
    return result;
  }
  return function callTailwindMerge() {
    return functionToCall(twJoin.apply(null, arguments));
  };
}
var fromTheme = (key) => {
  const themeGetter = (theme) => theme[key] || [];
  themeGetter.isThemeGetter = true;
  return themeGetter;
};
var arbitraryValueRegex = /^\[(?:([a-z-]+):)?(.+)\]$/i;
var fractionRegex = /^\d+\/\d+$/;
var stringLengths = /* @__PURE__ */ new Set(["px", "full", "screen"]);
var tshirtUnitRegex = /^(\d+(\.\d+)?)?(xs|sm|md|lg|xl)$/;
var lengthUnitRegex = /\d+(%|px|r?em|[sdl]?v([hwib]|min|max)|pt|pc|in|cm|mm|cap|ch|ex|r?lh|cq(w|h|i|b|min|max))|\b(calc|min|max|clamp)\(.+\)|^0$/;
var colorFunctionRegex = /^(rgba?|hsla?|hwb|(ok)?(lab|lch)|color-mix)\(.+\)$/;
var shadowRegex = /^(inset_)?-?((\d+)?\.?(\d+)[a-z]+|0)_-?((\d+)?\.?(\d+)[a-z]+|0)/;
var imageRegex = /^(url|image|image-set|cross-fade|element|(repeating-)?(linear|radial|conic)-gradient)\(.+\)$/;
var isLength = (value) => isNumber(value) || stringLengths.has(value) || fractionRegex.test(value);
var isArbitraryLength = (value) => getIsArbitraryValue(value, "length", isLengthOnly);
var isNumber = (value) => Boolean(value) && !Number.isNaN(Number(value));
var isArbitraryNumber = (value) => getIsArbitraryValue(value, "number", isNumber);
var isInteger = (value) => Boolean(value) && Number.isInteger(Number(value));
var isPercent = (value) => value.endsWith("%") && isNumber(value.slice(0, -1));
var isArbitraryValue = (value) => arbitraryValueRegex.test(value);
var isTshirtSize = (value) => tshirtUnitRegex.test(value);
var sizeLabels = /* @__PURE__ */ new Set(["length", "size", "percentage"]);
var isArbitrarySize = (value) => getIsArbitraryValue(value, sizeLabels, isNever);
var isArbitraryPosition = (value) => getIsArbitraryValue(value, "position", isNever);
var imageLabels = /* @__PURE__ */ new Set(["image", "url"]);
var isArbitraryImage = (value) => getIsArbitraryValue(value, imageLabels, isImage);
var isArbitraryShadow = (value) => getIsArbitraryValue(value, "", isShadow);
var isAny = () => true;
var getIsArbitraryValue = (value, label, testValue) => {
  const result = arbitraryValueRegex.exec(value);
  if (result) {
    if (result[1]) {
      return typeof label === "string" ? result[1] === label : label.has(result[1]);
    }
    return testValue(result[2]);
  }
  return false;
};
var isLengthOnly = (value) => (
  // `colorFunctionRegex` check is necessary because color functions can have percentages in them which which would be incorrectly classified as lengths.
  // For example, `hsl(0 0% 0%)` would be classified as a length without this check.
  // I could also use lookbehind assertion in `lengthUnitRegex` but that isn't supported widely enough.
  lengthUnitRegex.test(value) && !colorFunctionRegex.test(value)
);
var isNever = () => false;
var isShadow = (value) => shadowRegex.test(value);
var isImage = (value) => imageRegex.test(value);
var getDefaultConfig = () => {
  const colors = fromTheme("colors");
  const spacing = fromTheme("spacing");
  const blur = fromTheme("blur");
  const brightness = fromTheme("brightness");
  const borderColor = fromTheme("borderColor");
  const borderRadius = fromTheme("borderRadius");
  const borderSpacing = fromTheme("borderSpacing");
  const borderWidth = fromTheme("borderWidth");
  const contrast = fromTheme("contrast");
  const grayscale = fromTheme("grayscale");
  const hueRotate = fromTheme("hueRotate");
  const invert = fromTheme("invert");
  const gap = fromTheme("gap");
  const gradientColorStops = fromTheme("gradientColorStops");
  const gradientColorStopPositions = fromTheme("gradientColorStopPositions");
  const inset = fromTheme("inset");
  const margin = fromTheme("margin");
  const opacity = fromTheme("opacity");
  const padding = fromTheme("padding");
  const saturate = fromTheme("saturate");
  const scale = fromTheme("scale");
  const sepia = fromTheme("sepia");
  const skew = fromTheme("skew");
  const space = fromTheme("space");
  const translate = fromTheme("translate");
  const getOverscroll = () => ["auto", "contain", "none"];
  const getOverflow = () => ["auto", "hidden", "clip", "visible", "scroll"];
  const getSpacingWithAutoAndArbitrary = () => ["auto", isArbitraryValue, spacing];
  const getSpacingWithArbitrary = () => [isArbitraryValue, spacing];
  const getLengthWithEmptyAndArbitrary = () => ["", isLength, isArbitraryLength];
  const getNumberWithAutoAndArbitrary = () => ["auto", isNumber, isArbitraryValue];
  const getPositions = () => ["bottom", "center", "left", "left-bottom", "left-top", "right", "right-bottom", "right-top", "top"];
  const getLineStyles = () => ["solid", "dashed", "dotted", "double", "none"];
  const getBlendModes = () => ["normal", "multiply", "screen", "overlay", "darken", "lighten", "color-dodge", "color-burn", "hard-light", "soft-light", "difference", "exclusion", "hue", "saturation", "color", "luminosity"];
  const getAlign = () => ["start", "end", "center", "between", "around", "evenly", "stretch"];
  const getZeroAndEmpty = () => ["", "0", isArbitraryValue];
  const getBreaks = () => ["auto", "avoid", "all", "avoid-page", "page", "left", "right", "column"];
  const getNumberAndArbitrary = () => [isNumber, isArbitraryValue];
  return {
    cacheSize: 500,
    separator: ":",
    theme: {
      colors: [isAny],
      spacing: [isLength, isArbitraryLength],
      blur: ["none", "", isTshirtSize, isArbitraryValue],
      brightness: getNumberAndArbitrary(),
      borderColor: [colors],
      borderRadius: ["none", "", "full", isTshirtSize, isArbitraryValue],
      borderSpacing: getSpacingWithArbitrary(),
      borderWidth: getLengthWithEmptyAndArbitrary(),
      contrast: getNumberAndArbitrary(),
      grayscale: getZeroAndEmpty(),
      hueRotate: getNumberAndArbitrary(),
      invert: getZeroAndEmpty(),
      gap: getSpacingWithArbitrary(),
      gradientColorStops: [colors],
      gradientColorStopPositions: [isPercent, isArbitraryLength],
      inset: getSpacingWithAutoAndArbitrary(),
      margin: getSpacingWithAutoAndArbitrary(),
      opacity: getNumberAndArbitrary(),
      padding: getSpacingWithArbitrary(),
      saturate: getNumberAndArbitrary(),
      scale: getNumberAndArbitrary(),
      sepia: getZeroAndEmpty(),
      skew: getNumberAndArbitrary(),
      space: getSpacingWithArbitrary(),
      translate: getSpacingWithArbitrary()
    },
    classGroups: {
      // Layout
      /**
       * Aspect Ratio
       * @see https://tailwindcss.com/docs/aspect-ratio
       */
      aspect: [{
        aspect: ["auto", "square", "video", isArbitraryValue]
      }],
      /**
       * Container
       * @see https://tailwindcss.com/docs/container
       */
      container: ["container"],
      /**
       * Columns
       * @see https://tailwindcss.com/docs/columns
       */
      columns: [{
        columns: [isTshirtSize]
      }],
      /**
       * Break After
       * @see https://tailwindcss.com/docs/break-after
       */
      "break-after": [{
        "break-after": getBreaks()
      }],
      /**
       * Break Before
       * @see https://tailwindcss.com/docs/break-before
       */
      "break-before": [{
        "break-before": getBreaks()
      }],
      /**
       * Break Inside
       * @see https://tailwindcss.com/docs/break-inside
       */
      "break-inside": [{
        "break-inside": ["auto", "avoid", "avoid-page", "avoid-column"]
      }],
      /**
       * Box Decoration Break
       * @see https://tailwindcss.com/docs/box-decoration-break
       */
      "box-decoration": [{
        "box-decoration": ["slice", "clone"]
      }],
      /**
       * Box Sizing
       * @see https://tailwindcss.com/docs/box-sizing
       */
      box: [{
        box: ["border", "content"]
      }],
      /**
       * Display
       * @see https://tailwindcss.com/docs/display
       */
      display: ["block", "inline-block", "inline", "flex", "inline-flex", "table", "inline-table", "table-caption", "table-cell", "table-column", "table-column-group", "table-footer-group", "table-header-group", "table-row-group", "table-row", "flow-root", "grid", "inline-grid", "contents", "list-item", "hidden"],
      /**
       * Floats
       * @see https://tailwindcss.com/docs/float
       */
      float: [{
        float: ["right", "left", "none", "start", "end"]
      }],
      /**
       * Clear
       * @see https://tailwindcss.com/docs/clear
       */
      clear: [{
        clear: ["left", "right", "both", "none", "start", "end"]
      }],
      /**
       * Isolation
       * @see https://tailwindcss.com/docs/isolation
       */
      isolation: ["isolate", "isolation-auto"],
      /**
       * Object Fit
       * @see https://tailwindcss.com/docs/object-fit
       */
      "object-fit": [{
        object: ["contain", "cover", "fill", "none", "scale-down"]
      }],
      /**
       * Object Position
       * @see https://tailwindcss.com/docs/object-position
       */
      "object-position": [{
        object: [...getPositions(), isArbitraryValue]
      }],
      /**
       * Overflow
       * @see https://tailwindcss.com/docs/overflow
       */
      overflow: [{
        overflow: getOverflow()
      }],
      /**
       * Overflow X
       * @see https://tailwindcss.com/docs/overflow
       */
      "overflow-x": [{
        "overflow-x": getOverflow()
      }],
      /**
       * Overflow Y
       * @see https://tailwindcss.com/docs/overflow
       */
      "overflow-y": [{
        "overflow-y": getOverflow()
      }],
      /**
       * Overscroll Behavior
       * @see https://tailwindcss.com/docs/overscroll-behavior
       */
      overscroll: [{
        overscroll: getOverscroll()
      }],
      /**
       * Overscroll Behavior X
       * @see https://tailwindcss.com/docs/overscroll-behavior
       */
      "overscroll-x": [{
        "overscroll-x": getOverscroll()
      }],
      /**
       * Overscroll Behavior Y
       * @see https://tailwindcss.com/docs/overscroll-behavior
       */
      "overscroll-y": [{
        "overscroll-y": getOverscroll()
      }],
      /**
       * Position
       * @see https://tailwindcss.com/docs/position
       */
      position: ["static", "fixed", "absolute", "relative", "sticky"],
      /**
       * Top / Right / Bottom / Left
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      inset: [{
        inset: [inset]
      }],
      /**
       * Right / Left
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      "inset-x": [{
        "inset-x": [inset]
      }],
      /**
       * Top / Bottom
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      "inset-y": [{
        "inset-y": [inset]
      }],
      /**
       * Start
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      start: [{
        start: [inset]
      }],
      /**
       * End
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      end: [{
        end: [inset]
      }],
      /**
       * Top
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      top: [{
        top: [inset]
      }],
      /**
       * Right
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      right: [{
        right: [inset]
      }],
      /**
       * Bottom
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      bottom: [{
        bottom: [inset]
      }],
      /**
       * Left
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      left: [{
        left: [inset]
      }],
      /**
       * Visibility
       * @see https://tailwindcss.com/docs/visibility
       */
      visibility: ["visible", "invisible", "collapse"],
      /**
       * Z-Index
       * @see https://tailwindcss.com/docs/z-index
       */
      z: [{
        z: ["auto", isInteger, isArbitraryValue]
      }],
      // Flexbox and Grid
      /**
       * Flex Basis
       * @see https://tailwindcss.com/docs/flex-basis
       */
      basis: [{
        basis: getSpacingWithAutoAndArbitrary()
      }],
      /**
       * Flex Direction
       * @see https://tailwindcss.com/docs/flex-direction
       */
      "flex-direction": [{
        flex: ["row", "row-reverse", "col", "col-reverse"]
      }],
      /**
       * Flex Wrap
       * @see https://tailwindcss.com/docs/flex-wrap
       */
      "flex-wrap": [{
        flex: ["wrap", "wrap-reverse", "nowrap"]
      }],
      /**
       * Flex
       * @see https://tailwindcss.com/docs/flex
       */
      flex: [{
        flex: ["1", "auto", "initial", "none", isArbitraryValue]
      }],
      /**
       * Flex Grow
       * @see https://tailwindcss.com/docs/flex-grow
       */
      grow: [{
        grow: getZeroAndEmpty()
      }],
      /**
       * Flex Shrink
       * @see https://tailwindcss.com/docs/flex-shrink
       */
      shrink: [{
        shrink: getZeroAndEmpty()
      }],
      /**
       * Order
       * @see https://tailwindcss.com/docs/order
       */
      order: [{
        order: ["first", "last", "none", isInteger, isArbitraryValue]
      }],
      /**
       * Grid Template Columns
       * @see https://tailwindcss.com/docs/grid-template-columns
       */
      "grid-cols": [{
        "grid-cols": [isAny]
      }],
      /**
       * Grid Column Start / End
       * @see https://tailwindcss.com/docs/grid-column
       */
      "col-start-end": [{
        col: ["auto", {
          span: ["full", isInteger, isArbitraryValue]
        }, isArbitraryValue]
      }],
      /**
       * Grid Column Start
       * @see https://tailwindcss.com/docs/grid-column
       */
      "col-start": [{
        "col-start": getNumberWithAutoAndArbitrary()
      }],
      /**
       * Grid Column End
       * @see https://tailwindcss.com/docs/grid-column
       */
      "col-end": [{
        "col-end": getNumberWithAutoAndArbitrary()
      }],
      /**
       * Grid Template Rows
       * @see https://tailwindcss.com/docs/grid-template-rows
       */
      "grid-rows": [{
        "grid-rows": [isAny]
      }],
      /**
       * Grid Row Start / End
       * @see https://tailwindcss.com/docs/grid-row
       */
      "row-start-end": [{
        row: ["auto", {
          span: [isInteger, isArbitraryValue]
        }, isArbitraryValue]
      }],
      /**
       * Grid Row Start
       * @see https://tailwindcss.com/docs/grid-row
       */
      "row-start": [{
        "row-start": getNumberWithAutoAndArbitrary()
      }],
      /**
       * Grid Row End
       * @see https://tailwindcss.com/docs/grid-row
       */
      "row-end": [{
        "row-end": getNumberWithAutoAndArbitrary()
      }],
      /**
       * Grid Auto Flow
       * @see https://tailwindcss.com/docs/grid-auto-flow
       */
      "grid-flow": [{
        "grid-flow": ["row", "col", "dense", "row-dense", "col-dense"]
      }],
      /**
       * Grid Auto Columns
       * @see https://tailwindcss.com/docs/grid-auto-columns
       */
      "auto-cols": [{
        "auto-cols": ["auto", "min", "max", "fr", isArbitraryValue]
      }],
      /**
       * Grid Auto Rows
       * @see https://tailwindcss.com/docs/grid-auto-rows
       */
      "auto-rows": [{
        "auto-rows": ["auto", "min", "max", "fr", isArbitraryValue]
      }],
      /**
       * Gap
       * @see https://tailwindcss.com/docs/gap
       */
      gap: [{
        gap: [gap]
      }],
      /**
       * Gap X
       * @see https://tailwindcss.com/docs/gap
       */
      "gap-x": [{
        "gap-x": [gap]
      }],
      /**
       * Gap Y
       * @see https://tailwindcss.com/docs/gap
       */
      "gap-y": [{
        "gap-y": [gap]
      }],
      /**
       * Justify Content
       * @see https://tailwindcss.com/docs/justify-content
       */
      "justify-content": [{
        justify: ["normal", ...getAlign()]
      }],
      /**
       * Justify Items
       * @see https://tailwindcss.com/docs/justify-items
       */
      "justify-items": [{
        "justify-items": ["start", "end", "center", "stretch"]
      }],
      /**
       * Justify Self
       * @see https://tailwindcss.com/docs/justify-self
       */
      "justify-self": [{
        "justify-self": ["auto", "start", "end", "center", "stretch"]
      }],
      /**
       * Align Content
       * @see https://tailwindcss.com/docs/align-content
       */
      "align-content": [{
        content: ["normal", ...getAlign(), "baseline"]
      }],
      /**
       * Align Items
       * @see https://tailwindcss.com/docs/align-items
       */
      "align-items": [{
        items: ["start", "end", "center", "baseline", "stretch"]
      }],
      /**
       * Align Self
       * @see https://tailwindcss.com/docs/align-self
       */
      "align-self": [{
        self: ["auto", "start", "end", "center", "stretch", "baseline"]
      }],
      /**
       * Place Content
       * @see https://tailwindcss.com/docs/place-content
       */
      "place-content": [{
        "place-content": [...getAlign(), "baseline"]
      }],
      /**
       * Place Items
       * @see https://tailwindcss.com/docs/place-items
       */
      "place-items": [{
        "place-items": ["start", "end", "center", "baseline", "stretch"]
      }],
      /**
       * Place Self
       * @see https://tailwindcss.com/docs/place-self
       */
      "place-self": [{
        "place-self": ["auto", "start", "end", "center", "stretch"]
      }],
      // Spacing
      /**
       * Padding
       * @see https://tailwindcss.com/docs/padding
       */
      p: [{
        p: [padding]
      }],
      /**
       * Padding X
       * @see https://tailwindcss.com/docs/padding
       */
      px: [{
        px: [padding]
      }],
      /**
       * Padding Y
       * @see https://tailwindcss.com/docs/padding
       */
      py: [{
        py: [padding]
      }],
      /**
       * Padding Start
       * @see https://tailwindcss.com/docs/padding
       */
      ps: [{
        ps: [padding]
      }],
      /**
       * Padding End
       * @see https://tailwindcss.com/docs/padding
       */
      pe: [{
        pe: [padding]
      }],
      /**
       * Padding Top
       * @see https://tailwindcss.com/docs/padding
       */
      pt: [{
        pt: [padding]
      }],
      /**
       * Padding Right
       * @see https://tailwindcss.com/docs/padding
       */
      pr: [{
        pr: [padding]
      }],
      /**
       * Padding Bottom
       * @see https://tailwindcss.com/docs/padding
       */
      pb: [{
        pb: [padding]
      }],
      /**
       * Padding Left
       * @see https://tailwindcss.com/docs/padding
       */
      pl: [{
        pl: [padding]
      }],
      /**
       * Margin
       * @see https://tailwindcss.com/docs/margin
       */
      m: [{
        m: [margin]
      }],
      /**
       * Margin X
       * @see https://tailwindcss.com/docs/margin
       */
      mx: [{
        mx: [margin]
      }],
      /**
       * Margin Y
       * @see https://tailwindcss.com/docs/margin
       */
      my: [{
        my: [margin]
      }],
      /**
       * Margin Start
       * @see https://tailwindcss.com/docs/margin
       */
      ms: [{
        ms: [margin]
      }],
      /**
       * Margin End
       * @see https://tailwindcss.com/docs/margin
       */
      me: [{
        me: [margin]
      }],
      /**
       * Margin Top
       * @see https://tailwindcss.com/docs/margin
       */
      mt: [{
        mt: [margin]
      }],
      /**
       * Margin Right
       * @see https://tailwindcss.com/docs/margin
       */
      mr: [{
        mr: [margin]
      }],
      /**
       * Margin Bottom
       * @see https://tailwindcss.com/docs/margin
       */
      mb: [{
        mb: [margin]
      }],
      /**
       * Margin Left
       * @see https://tailwindcss.com/docs/margin
       */
      ml: [{
        ml: [margin]
      }],
      /**
       * Space Between X
       * @see https://tailwindcss.com/docs/space
       */
      "space-x": [{
        "space-x": [space]
      }],
      /**
       * Space Between X Reverse
       * @see https://tailwindcss.com/docs/space
       */
      "space-x-reverse": ["space-x-reverse"],
      /**
       * Space Between Y
       * @see https://tailwindcss.com/docs/space
       */
      "space-y": [{
        "space-y": [space]
      }],
      /**
       * Space Between Y Reverse
       * @see https://tailwindcss.com/docs/space
       */
      "space-y-reverse": ["space-y-reverse"],
      // Sizing
      /**
       * Width
       * @see https://tailwindcss.com/docs/width
       */
      w: [{
        w: ["auto", "min", "max", "fit", "svw", "lvw", "dvw", isArbitraryValue, spacing]
      }],
      /**
       * Min-Width
       * @see https://tailwindcss.com/docs/min-width
       */
      "min-w": [{
        "min-w": [isArbitraryValue, spacing, "min", "max", "fit"]
      }],
      /**
       * Max-Width
       * @see https://tailwindcss.com/docs/max-width
       */
      "max-w": [{
        "max-w": [isArbitraryValue, spacing, "none", "full", "min", "max", "fit", "prose", {
          screen: [isTshirtSize]
        }, isTshirtSize]
      }],
      /**
       * Height
       * @see https://tailwindcss.com/docs/height
       */
      h: [{
        h: [isArbitraryValue, spacing, "auto", "min", "max", "fit", "svh", "lvh", "dvh"]
      }],
      /**
       * Min-Height
       * @see https://tailwindcss.com/docs/min-height
       */
      "min-h": [{
        "min-h": [isArbitraryValue, spacing, "min", "max", "fit", "svh", "lvh", "dvh"]
      }],
      /**
       * Max-Height
       * @see https://tailwindcss.com/docs/max-height
       */
      "max-h": [{
        "max-h": [isArbitraryValue, spacing, "min", "max", "fit", "svh", "lvh", "dvh"]
      }],
      /**
       * Size
       * @see https://tailwindcss.com/docs/size
       */
      size: [{
        size: [isArbitraryValue, spacing, "auto", "min", "max", "fit"]
      }],
      // Typography
      /**
       * Font Size
       * @see https://tailwindcss.com/docs/font-size
       */
      "font-size": [{
        text: ["base", isTshirtSize, isArbitraryLength]
      }],
      /**
       * Font Smoothing
       * @see https://tailwindcss.com/docs/font-smoothing
       */
      "font-smoothing": ["antialiased", "subpixel-antialiased"],
      /**
       * Font Style
       * @see https://tailwindcss.com/docs/font-style
       */
      "font-style": ["italic", "not-italic"],
      /**
       * Font Weight
       * @see https://tailwindcss.com/docs/font-weight
       */
      "font-weight": [{
        font: ["thin", "extralight", "light", "normal", "medium", "semibold", "bold", "extrabold", "black", isArbitraryNumber]
      }],
      /**
       * Font Family
       * @see https://tailwindcss.com/docs/font-family
       */
      "font-family": [{
        font: [isAny]
      }],
      /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */
      "fvn-normal": ["normal-nums"],
      /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */
      "fvn-ordinal": ["ordinal"],
      /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */
      "fvn-slashed-zero": ["slashed-zero"],
      /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */
      "fvn-figure": ["lining-nums", "oldstyle-nums"],
      /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */
      "fvn-spacing": ["proportional-nums", "tabular-nums"],
      /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */
      "fvn-fraction": ["diagonal-fractions", "stacked-fractions"],
      /**
       * Letter Spacing
       * @see https://tailwindcss.com/docs/letter-spacing
       */
      tracking: [{
        tracking: ["tighter", "tight", "normal", "wide", "wider", "widest", isArbitraryValue]
      }],
      /**
       * Line Clamp
       * @see https://tailwindcss.com/docs/line-clamp
       */
      "line-clamp": [{
        "line-clamp": ["none", isNumber, isArbitraryNumber]
      }],
      /**
       * Line Height
       * @see https://tailwindcss.com/docs/line-height
       */
      leading: [{
        leading: ["none", "tight", "snug", "normal", "relaxed", "loose", isLength, isArbitraryValue]
      }],
      /**
       * List Style Image
       * @see https://tailwindcss.com/docs/list-style-image
       */
      "list-image": [{
        "list-image": ["none", isArbitraryValue]
      }],
      /**
       * List Style Type
       * @see https://tailwindcss.com/docs/list-style-type
       */
      "list-style-type": [{
        list: ["none", "disc", "decimal", isArbitraryValue]
      }],
      /**
       * List Style Position
       * @see https://tailwindcss.com/docs/list-style-position
       */
      "list-style-position": [{
        list: ["inside", "outside"]
      }],
      /**
       * Placeholder Color
       * @deprecated since Tailwind CSS v3.0.0
       * @see https://tailwindcss.com/docs/placeholder-color
       */
      "placeholder-color": [{
        placeholder: [colors]
      }],
      /**
       * Placeholder Opacity
       * @see https://tailwindcss.com/docs/placeholder-opacity
       */
      "placeholder-opacity": [{
        "placeholder-opacity": [opacity]
      }],
      /**
       * Text Alignment
       * @see https://tailwindcss.com/docs/text-align
       */
      "text-alignment": [{
        text: ["left", "center", "right", "justify", "start", "end"]
      }],
      /**
       * Text Color
       * @see https://tailwindcss.com/docs/text-color
       */
      "text-color": [{
        text: [colors]
      }],
      /**
       * Text Opacity
       * @see https://tailwindcss.com/docs/text-opacity
       */
      "text-opacity": [{
        "text-opacity": [opacity]
      }],
      /**
       * Text Decoration
       * @see https://tailwindcss.com/docs/text-decoration
       */
      "text-decoration": ["underline", "overline", "line-through", "no-underline"],
      /**
       * Text Decoration Style
       * @see https://tailwindcss.com/docs/text-decoration-style
       */
      "text-decoration-style": [{
        decoration: [...getLineStyles(), "wavy"]
      }],
      /**
       * Text Decoration Thickness
       * @see https://tailwindcss.com/docs/text-decoration-thickness
       */
      "text-decoration-thickness": [{
        decoration: ["auto", "from-font", isLength, isArbitraryLength]
      }],
      /**
       * Text Underline Offset
       * @see https://tailwindcss.com/docs/text-underline-offset
       */
      "underline-offset": [{
        "underline-offset": ["auto", isLength, isArbitraryValue]
      }],
      /**
       * Text Decoration Color
       * @see https://tailwindcss.com/docs/text-decoration-color
       */
      "text-decoration-color": [{
        decoration: [colors]
      }],
      /**
       * Text Transform
       * @see https://tailwindcss.com/docs/text-transform
       */
      "text-transform": ["uppercase", "lowercase", "capitalize", "normal-case"],
      /**
       * Text Overflow
       * @see https://tailwindcss.com/docs/text-overflow
       */
      "text-overflow": ["truncate", "text-ellipsis", "text-clip"],
      /**
       * Text Wrap
       * @see https://tailwindcss.com/docs/text-wrap
       */
      "text-wrap": [{
        text: ["wrap", "nowrap", "balance", "pretty"]
      }],
      /**
       * Text Indent
       * @see https://tailwindcss.com/docs/text-indent
       */
      indent: [{
        indent: getSpacingWithArbitrary()
      }],
      /**
       * Vertical Alignment
       * @see https://tailwindcss.com/docs/vertical-align
       */
      "vertical-align": [{
        align: ["baseline", "top", "middle", "bottom", "text-top", "text-bottom", "sub", "super", isArbitraryValue]
      }],
      /**
       * Whitespace
       * @see https://tailwindcss.com/docs/whitespace
       */
      whitespace: [{
        whitespace: ["normal", "nowrap", "pre", "pre-line", "pre-wrap", "break-spaces"]
      }],
      /**
       * Word Break
       * @see https://tailwindcss.com/docs/word-break
       */
      break: [{
        break: ["normal", "words", "all", "keep"]
      }],
      /**
       * Hyphens
       * @see https://tailwindcss.com/docs/hyphens
       */
      hyphens: [{
        hyphens: ["none", "manual", "auto"]
      }],
      /**
       * Content
       * @see https://tailwindcss.com/docs/content
       */
      content: [{
        content: ["none", isArbitraryValue]
      }],
      // Backgrounds
      /**
       * Background Attachment
       * @see https://tailwindcss.com/docs/background-attachment
       */
      "bg-attachment": [{
        bg: ["fixed", "local", "scroll"]
      }],
      /**
       * Background Clip
       * @see https://tailwindcss.com/docs/background-clip
       */
      "bg-clip": [{
        "bg-clip": ["border", "padding", "content", "text"]
      }],
      /**
       * Background Opacity
       * @deprecated since Tailwind CSS v3.0.0
       * @see https://tailwindcss.com/docs/background-opacity
       */
      "bg-opacity": [{
        "bg-opacity": [opacity]
      }],
      /**
       * Background Origin
       * @see https://tailwindcss.com/docs/background-origin
       */
      "bg-origin": [{
        "bg-origin": ["border", "padding", "content"]
      }],
      /**
       * Background Position
       * @see https://tailwindcss.com/docs/background-position
       */
      "bg-position": [{
        bg: [...getPositions(), isArbitraryPosition]
      }],
      /**
       * Background Repeat
       * @see https://tailwindcss.com/docs/background-repeat
       */
      "bg-repeat": [{
        bg: ["no-repeat", {
          repeat: ["", "x", "y", "round", "space"]
        }]
      }],
      /**
       * Background Size
       * @see https://tailwindcss.com/docs/background-size
       */
      "bg-size": [{
        bg: ["auto", "cover", "contain", isArbitrarySize]
      }],
      /**
       * Background Image
       * @see https://tailwindcss.com/docs/background-image
       */
      "bg-image": [{
        bg: ["none", {
          "gradient-to": ["t", "tr", "r", "br", "b", "bl", "l", "tl"]
        }, isArbitraryImage]
      }],
      /**
       * Background Color
       * @see https://tailwindcss.com/docs/background-color
       */
      "bg-color": [{
        bg: [colors]
      }],
      /**
       * Gradient Color Stops From Position
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */
      "gradient-from-pos": [{
        from: [gradientColorStopPositions]
      }],
      /**
       * Gradient Color Stops Via Position
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */
      "gradient-via-pos": [{
        via: [gradientColorStopPositions]
      }],
      /**
       * Gradient Color Stops To Position
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */
      "gradient-to-pos": [{
        to: [gradientColorStopPositions]
      }],
      /**
       * Gradient Color Stops From
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */
      "gradient-from": [{
        from: [gradientColorStops]
      }],
      /**
       * Gradient Color Stops Via
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */
      "gradient-via": [{
        via: [gradientColorStops]
      }],
      /**
       * Gradient Color Stops To
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */
      "gradient-to": [{
        to: [gradientColorStops]
      }],
      // Borders
      /**
       * Border Radius
       * @see https://tailwindcss.com/docs/border-radius
       */
      rounded: [{
        rounded: [borderRadius]
      }],
      /**
       * Border Radius Start
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-s": [{
        "rounded-s": [borderRadius]
      }],
      /**
       * Border Radius End
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-e": [{
        "rounded-e": [borderRadius]
      }],
      /**
       * Border Radius Top
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-t": [{
        "rounded-t": [borderRadius]
      }],
      /**
       * Border Radius Right
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-r": [{
        "rounded-r": [borderRadius]
      }],
      /**
       * Border Radius Bottom
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-b": [{
        "rounded-b": [borderRadius]
      }],
      /**
       * Border Radius Left
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-l": [{
        "rounded-l": [borderRadius]
      }],
      /**
       * Border Radius Start Start
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-ss": [{
        "rounded-ss": [borderRadius]
      }],
      /**
       * Border Radius Start End
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-se": [{
        "rounded-se": [borderRadius]
      }],
      /**
       * Border Radius End End
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-ee": [{
        "rounded-ee": [borderRadius]
      }],
      /**
       * Border Radius End Start
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-es": [{
        "rounded-es": [borderRadius]
      }],
      /**
       * Border Radius Top Left
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-tl": [{
        "rounded-tl": [borderRadius]
      }],
      /**
       * Border Radius Top Right
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-tr": [{
        "rounded-tr": [borderRadius]
      }],
      /**
       * Border Radius Bottom Right
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-br": [{
        "rounded-br": [borderRadius]
      }],
      /**
       * Border Radius Bottom Left
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-bl": [{
        "rounded-bl": [borderRadius]
      }],
      /**
       * Border Width
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w": [{
        border: [borderWidth]
      }],
      /**
       * Border Width X
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-x": [{
        "border-x": [borderWidth]
      }],
      /**
       * Border Width Y
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-y": [{
        "border-y": [borderWidth]
      }],
      /**
       * Border Width Start
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-s": [{
        "border-s": [borderWidth]
      }],
      /**
       * Border Width End
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-e": [{
        "border-e": [borderWidth]
      }],
      /**
       * Border Width Top
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-t": [{
        "border-t": [borderWidth]
      }],
      /**
       * Border Width Right
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-r": [{
        "border-r": [borderWidth]
      }],
      /**
       * Border Width Bottom
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-b": [{
        "border-b": [borderWidth]
      }],
      /**
       * Border Width Left
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-l": [{
        "border-l": [borderWidth]
      }],
      /**
       * Border Opacity
       * @see https://tailwindcss.com/docs/border-opacity
       */
      "border-opacity": [{
        "border-opacity": [opacity]
      }],
      /**
       * Border Style
       * @see https://tailwindcss.com/docs/border-style
       */
      "border-style": [{
        border: [...getLineStyles(), "hidden"]
      }],
      /**
       * Divide Width X
       * @see https://tailwindcss.com/docs/divide-width
       */
      "divide-x": [{
        "divide-x": [borderWidth]
      }],
      /**
       * Divide Width X Reverse
       * @see https://tailwindcss.com/docs/divide-width
       */
      "divide-x-reverse": ["divide-x-reverse"],
      /**
       * Divide Width Y
       * @see https://tailwindcss.com/docs/divide-width
       */
      "divide-y": [{
        "divide-y": [borderWidth]
      }],
      /**
       * Divide Width Y Reverse
       * @see https://tailwindcss.com/docs/divide-width
       */
      "divide-y-reverse": ["divide-y-reverse"],
      /**
       * Divide Opacity
       * @see https://tailwindcss.com/docs/divide-opacity
       */
      "divide-opacity": [{
        "divide-opacity": [opacity]
      }],
      /**
       * Divide Style
       * @see https://tailwindcss.com/docs/divide-style
       */
      "divide-style": [{
        divide: getLineStyles()
      }],
      /**
       * Border Color
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color": [{
        border: [borderColor]
      }],
      /**
       * Border Color X
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-x": [{
        "border-x": [borderColor]
      }],
      /**
       * Border Color Y
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-y": [{
        "border-y": [borderColor]
      }],
      /**
       * Border Color S
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-s": [{
        "border-s": [borderColor]
      }],
      /**
       * Border Color E
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-e": [{
        "border-e": [borderColor]
      }],
      /**
       * Border Color Top
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-t": [{
        "border-t": [borderColor]
      }],
      /**
       * Border Color Right
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-r": [{
        "border-r": [borderColor]
      }],
      /**
       * Border Color Bottom
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-b": [{
        "border-b": [borderColor]
      }],
      /**
       * Border Color Left
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-l": [{
        "border-l": [borderColor]
      }],
      /**
       * Divide Color
       * @see https://tailwindcss.com/docs/divide-color
       */
      "divide-color": [{
        divide: [borderColor]
      }],
      /**
       * Outline Style
       * @see https://tailwindcss.com/docs/outline-style
       */
      "outline-style": [{
        outline: ["", ...getLineStyles()]
      }],
      /**
       * Outline Offset
       * @see https://tailwindcss.com/docs/outline-offset
       */
      "outline-offset": [{
        "outline-offset": [isLength, isArbitraryValue]
      }],
      /**
       * Outline Width
       * @see https://tailwindcss.com/docs/outline-width
       */
      "outline-w": [{
        outline: [isLength, isArbitraryLength]
      }],
      /**
       * Outline Color
       * @see https://tailwindcss.com/docs/outline-color
       */
      "outline-color": [{
        outline: [colors]
      }],
      /**
       * Ring Width
       * @see https://tailwindcss.com/docs/ring-width
       */
      "ring-w": [{
        ring: getLengthWithEmptyAndArbitrary()
      }],
      /**
       * Ring Width Inset
       * @see https://tailwindcss.com/docs/ring-width
       */
      "ring-w-inset": ["ring-inset"],
      /**
       * Ring Color
       * @see https://tailwindcss.com/docs/ring-color
       */
      "ring-color": [{
        ring: [colors]
      }],
      /**
       * Ring Opacity
       * @see https://tailwindcss.com/docs/ring-opacity
       */
      "ring-opacity": [{
        "ring-opacity": [opacity]
      }],
      /**
       * Ring Offset Width
       * @see https://tailwindcss.com/docs/ring-offset-width
       */
      "ring-offset-w": [{
        "ring-offset": [isLength, isArbitraryLength]
      }],
      /**
       * Ring Offset Color
       * @see https://tailwindcss.com/docs/ring-offset-color
       */
      "ring-offset-color": [{
        "ring-offset": [colors]
      }],
      // Effects
      /**
       * Box Shadow
       * @see https://tailwindcss.com/docs/box-shadow
       */
      shadow: [{
        shadow: ["", "inner", "none", isTshirtSize, isArbitraryShadow]
      }],
      /**
       * Box Shadow Color
       * @see https://tailwindcss.com/docs/box-shadow-color
       */
      "shadow-color": [{
        shadow: [isAny]
      }],
      /**
       * Opacity
       * @see https://tailwindcss.com/docs/opacity
       */
      opacity: [{
        opacity: [opacity]
      }],
      /**
       * Mix Blend Mode
       * @see https://tailwindcss.com/docs/mix-blend-mode
       */
      "mix-blend": [{
        "mix-blend": [...getBlendModes(), "plus-lighter", "plus-darker"]
      }],
      /**
       * Background Blend Mode
       * @see https://tailwindcss.com/docs/background-blend-mode
       */
      "bg-blend": [{
        "bg-blend": getBlendModes()
      }],
      // Filters
      /**
       * Filter
       * @deprecated since Tailwind CSS v3.0.0
       * @see https://tailwindcss.com/docs/filter
       */
      filter: [{
        filter: ["", "none"]
      }],
      /**
       * Blur
       * @see https://tailwindcss.com/docs/blur
       */
      blur: [{
        blur: [blur]
      }],
      /**
       * Brightness
       * @see https://tailwindcss.com/docs/brightness
       */
      brightness: [{
        brightness: [brightness]
      }],
      /**
       * Contrast
       * @see https://tailwindcss.com/docs/contrast
       */
      contrast: [{
        contrast: [contrast]
      }],
      /**
       * Drop Shadow
       * @see https://tailwindcss.com/docs/drop-shadow
       */
      "drop-shadow": [{
        "drop-shadow": ["", "none", isTshirtSize, isArbitraryValue]
      }],
      /**
       * Grayscale
       * @see https://tailwindcss.com/docs/grayscale
       */
      grayscale: [{
        grayscale: [grayscale]
      }],
      /**
       * Hue Rotate
       * @see https://tailwindcss.com/docs/hue-rotate
       */
      "hue-rotate": [{
        "hue-rotate": [hueRotate]
      }],
      /**
       * Invert
       * @see https://tailwindcss.com/docs/invert
       */
      invert: [{
        invert: [invert]
      }],
      /**
       * Saturate
       * @see https://tailwindcss.com/docs/saturate
       */
      saturate: [{
        saturate: [saturate]
      }],
      /**
       * Sepia
       * @see https://tailwindcss.com/docs/sepia
       */
      sepia: [{
        sepia: [sepia]
      }],
      /**
       * Backdrop Filter
       * @deprecated since Tailwind CSS v3.0.0
       * @see https://tailwindcss.com/docs/backdrop-filter
       */
      "backdrop-filter": [{
        "backdrop-filter": ["", "none"]
      }],
      /**
       * Backdrop Blur
       * @see https://tailwindcss.com/docs/backdrop-blur
       */
      "backdrop-blur": [{
        "backdrop-blur": [blur]
      }],
      /**
       * Backdrop Brightness
       * @see https://tailwindcss.com/docs/backdrop-brightness
       */
      "backdrop-brightness": [{
        "backdrop-brightness": [brightness]
      }],
      /**
       * Backdrop Contrast
       * @see https://tailwindcss.com/docs/backdrop-contrast
       */
      "backdrop-contrast": [{
        "backdrop-contrast": [contrast]
      }],
      /**
       * Backdrop Grayscale
       * @see https://tailwindcss.com/docs/backdrop-grayscale
       */
      "backdrop-grayscale": [{
        "backdrop-grayscale": [grayscale]
      }],
      /**
       * Backdrop Hue Rotate
       * @see https://tailwindcss.com/docs/backdrop-hue-rotate
       */
      "backdrop-hue-rotate": [{
        "backdrop-hue-rotate": [hueRotate]
      }],
      /**
       * Backdrop Invert
       * @see https://tailwindcss.com/docs/backdrop-invert
       */
      "backdrop-invert": [{
        "backdrop-invert": [invert]
      }],
      /**
       * Backdrop Opacity
       * @see https://tailwindcss.com/docs/backdrop-opacity
       */
      "backdrop-opacity": [{
        "backdrop-opacity": [opacity]
      }],
      /**
       * Backdrop Saturate
       * @see https://tailwindcss.com/docs/backdrop-saturate
       */
      "backdrop-saturate": [{
        "backdrop-saturate": [saturate]
      }],
      /**
       * Backdrop Sepia
       * @see https://tailwindcss.com/docs/backdrop-sepia
       */
      "backdrop-sepia": [{
        "backdrop-sepia": [sepia]
      }],
      // Tables
      /**
       * Border Collapse
       * @see https://tailwindcss.com/docs/border-collapse
       */
      "border-collapse": [{
        border: ["collapse", "separate"]
      }],
      /**
       * Border Spacing
       * @see https://tailwindcss.com/docs/border-spacing
       */
      "border-spacing": [{
        "border-spacing": [borderSpacing]
      }],
      /**
       * Border Spacing X
       * @see https://tailwindcss.com/docs/border-spacing
       */
      "border-spacing-x": [{
        "border-spacing-x": [borderSpacing]
      }],
      /**
       * Border Spacing Y
       * @see https://tailwindcss.com/docs/border-spacing
       */
      "border-spacing-y": [{
        "border-spacing-y": [borderSpacing]
      }],
      /**
       * Table Layout
       * @see https://tailwindcss.com/docs/table-layout
       */
      "table-layout": [{
        table: ["auto", "fixed"]
      }],
      /**
       * Caption Side
       * @see https://tailwindcss.com/docs/caption-side
       */
      caption: [{
        caption: ["top", "bottom"]
      }],
      // Transitions and Animation
      /**
       * Tranisition Property
       * @see https://tailwindcss.com/docs/transition-property
       */
      transition: [{
        transition: ["none", "all", "", "colors", "opacity", "shadow", "transform", isArbitraryValue]
      }],
      /**
       * Transition Duration
       * @see https://tailwindcss.com/docs/transition-duration
       */
      duration: [{
        duration: getNumberAndArbitrary()
      }],
      /**
       * Transition Timing Function
       * @see https://tailwindcss.com/docs/transition-timing-function
       */
      ease: [{
        ease: ["linear", "in", "out", "in-out", isArbitraryValue]
      }],
      /**
       * Transition Delay
       * @see https://tailwindcss.com/docs/transition-delay
       */
      delay: [{
        delay: getNumberAndArbitrary()
      }],
      /**
       * Animation
       * @see https://tailwindcss.com/docs/animation
       */
      animate: [{
        animate: ["none", "spin", "ping", "pulse", "bounce", isArbitraryValue]
      }],
      // Transforms
      /**
       * Transform
       * @see https://tailwindcss.com/docs/transform
       */
      transform: [{
        transform: ["", "gpu", "none"]
      }],
      /**
       * Scale
       * @see https://tailwindcss.com/docs/scale
       */
      scale: [{
        scale: [scale]
      }],
      /**
       * Scale X
       * @see https://tailwindcss.com/docs/scale
       */
      "scale-x": [{
        "scale-x": [scale]
      }],
      /**
       * Scale Y
       * @see https://tailwindcss.com/docs/scale
       */
      "scale-y": [{
        "scale-y": [scale]
      }],
      /**
       * Rotate
       * @see https://tailwindcss.com/docs/rotate
       */
      rotate: [{
        rotate: [isInteger, isArbitraryValue]
      }],
      /**
       * Translate X
       * @see https://tailwindcss.com/docs/translate
       */
      "translate-x": [{
        "translate-x": [translate]
      }],
      /**
       * Translate Y
       * @see https://tailwindcss.com/docs/translate
       */
      "translate-y": [{
        "translate-y": [translate]
      }],
      /**
       * Skew X
       * @see https://tailwindcss.com/docs/skew
       */
      "skew-x": [{
        "skew-x": [skew]
      }],
      /**
       * Skew Y
       * @see https://tailwindcss.com/docs/skew
       */
      "skew-y": [{
        "skew-y": [skew]
      }],
      /**
       * Transform Origin
       * @see https://tailwindcss.com/docs/transform-origin
       */
      "transform-origin": [{
        origin: ["center", "top", "top-right", "right", "bottom-right", "bottom", "bottom-left", "left", "top-left", isArbitraryValue]
      }],
      // Interactivity
      /**
       * Accent Color
       * @see https://tailwindcss.com/docs/accent-color
       */
      accent: [{
        accent: ["auto", colors]
      }],
      /**
       * Appearance
       * @see https://tailwindcss.com/docs/appearance
       */
      appearance: [{
        appearance: ["none", "auto"]
      }],
      /**
       * Cursor
       * @see https://tailwindcss.com/docs/cursor
       */
      cursor: [{
        cursor: ["auto", "default", "pointer", "wait", "text", "move", "help", "not-allowed", "none", "context-menu", "progress", "cell", "crosshair", "vertical-text", "alias", "copy", "no-drop", "grab", "grabbing", "all-scroll", "col-resize", "row-resize", "n-resize", "e-resize", "s-resize", "w-resize", "ne-resize", "nw-resize", "se-resize", "sw-resize", "ew-resize", "ns-resize", "nesw-resize", "nwse-resize", "zoom-in", "zoom-out", isArbitraryValue]
      }],
      /**
       * Caret Color
       * @see https://tailwindcss.com/docs/just-in-time-mode#caret-color-utilities
       */
      "caret-color": [{
        caret: [colors]
      }],
      /**
       * Pointer Events
       * @see https://tailwindcss.com/docs/pointer-events
       */
      "pointer-events": [{
        "pointer-events": ["none", "auto"]
      }],
      /**
       * Resize
       * @see https://tailwindcss.com/docs/resize
       */
      resize: [{
        resize: ["none", "y", "x", ""]
      }],
      /**
       * Scroll Behavior
       * @see https://tailwindcss.com/docs/scroll-behavior
       */
      "scroll-behavior": [{
        scroll: ["auto", "smooth"]
      }],
      /**
       * Scroll Margin
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-m": [{
        "scroll-m": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Margin X
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-mx": [{
        "scroll-mx": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Margin Y
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-my": [{
        "scroll-my": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Margin Start
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-ms": [{
        "scroll-ms": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Margin End
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-me": [{
        "scroll-me": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Margin Top
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-mt": [{
        "scroll-mt": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Margin Right
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-mr": [{
        "scroll-mr": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Margin Bottom
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-mb": [{
        "scroll-mb": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Margin Left
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-ml": [{
        "scroll-ml": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Padding
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-p": [{
        "scroll-p": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Padding X
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-px": [{
        "scroll-px": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Padding Y
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-py": [{
        "scroll-py": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Padding Start
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-ps": [{
        "scroll-ps": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Padding End
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-pe": [{
        "scroll-pe": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Padding Top
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-pt": [{
        "scroll-pt": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Padding Right
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-pr": [{
        "scroll-pr": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Padding Bottom
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-pb": [{
        "scroll-pb": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Padding Left
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-pl": [{
        "scroll-pl": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Snap Align
       * @see https://tailwindcss.com/docs/scroll-snap-align
       */
      "snap-align": [{
        snap: ["start", "end", "center", "align-none"]
      }],
      /**
       * Scroll Snap Stop
       * @see https://tailwindcss.com/docs/scroll-snap-stop
       */
      "snap-stop": [{
        snap: ["normal", "always"]
      }],
      /**
       * Scroll Snap Type
       * @see https://tailwindcss.com/docs/scroll-snap-type
       */
      "snap-type": [{
        snap: ["none", "x", "y", "both"]
      }],
      /**
       * Scroll Snap Type Strictness
       * @see https://tailwindcss.com/docs/scroll-snap-type
       */
      "snap-strictness": [{
        snap: ["mandatory", "proximity"]
      }],
      /**
       * Touch Action
       * @see https://tailwindcss.com/docs/touch-action
       */
      touch: [{
        touch: ["auto", "none", "manipulation"]
      }],
      /**
       * Touch Action X
       * @see https://tailwindcss.com/docs/touch-action
       */
      "touch-x": [{
        "touch-pan": ["x", "left", "right"]
      }],
      /**
       * Touch Action Y
       * @see https://tailwindcss.com/docs/touch-action
       */
      "touch-y": [{
        "touch-pan": ["y", "up", "down"]
      }],
      /**
       * Touch Action Pinch Zoom
       * @see https://tailwindcss.com/docs/touch-action
       */
      "touch-pz": ["touch-pinch-zoom"],
      /**
       * User Select
       * @see https://tailwindcss.com/docs/user-select
       */
      select: [{
        select: ["none", "text", "all", "auto"]
      }],
      /**
       * Will Change
       * @see https://tailwindcss.com/docs/will-change
       */
      "will-change": [{
        "will-change": ["auto", "scroll", "contents", "transform", isArbitraryValue]
      }],
      // SVG
      /**
       * Fill
       * @see https://tailwindcss.com/docs/fill
       */
      fill: [{
        fill: [colors, "none"]
      }],
      /**
       * Stroke Width
       * @see https://tailwindcss.com/docs/stroke-width
       */
      "stroke-w": [{
        stroke: [isLength, isArbitraryLength, isArbitraryNumber]
      }],
      /**
       * Stroke
       * @see https://tailwindcss.com/docs/stroke
       */
      stroke: [{
        stroke: [colors, "none"]
      }],
      // Accessibility
      /**
       * Screen Readers
       * @see https://tailwindcss.com/docs/screen-readers
       */
      sr: ["sr-only", "not-sr-only"],
      /**
       * Forced Color Adjust
       * @see https://tailwindcss.com/docs/forced-color-adjust
       */
      "forced-color-adjust": [{
        "forced-color-adjust": ["auto", "none"]
      }]
    },
    conflictingClassGroups: {
      overflow: ["overflow-x", "overflow-y"],
      overscroll: ["overscroll-x", "overscroll-y"],
      inset: ["inset-x", "inset-y", "start", "end", "top", "right", "bottom", "left"],
      "inset-x": ["right", "left"],
      "inset-y": ["top", "bottom"],
      flex: ["basis", "grow", "shrink"],
      gap: ["gap-x", "gap-y"],
      p: ["px", "py", "ps", "pe", "pt", "pr", "pb", "pl"],
      px: ["pr", "pl"],
      py: ["pt", "pb"],
      m: ["mx", "my", "ms", "me", "mt", "mr", "mb", "ml"],
      mx: ["mr", "ml"],
      my: ["mt", "mb"],
      size: ["w", "h"],
      "font-size": ["leading"],
      "fvn-normal": ["fvn-ordinal", "fvn-slashed-zero", "fvn-figure", "fvn-spacing", "fvn-fraction"],
      "fvn-ordinal": ["fvn-normal"],
      "fvn-slashed-zero": ["fvn-normal"],
      "fvn-figure": ["fvn-normal"],
      "fvn-spacing": ["fvn-normal"],
      "fvn-fraction": ["fvn-normal"],
      "line-clamp": ["display", "overflow"],
      rounded: ["rounded-s", "rounded-e", "rounded-t", "rounded-r", "rounded-b", "rounded-l", "rounded-ss", "rounded-se", "rounded-ee", "rounded-es", "rounded-tl", "rounded-tr", "rounded-br", "rounded-bl"],
      "rounded-s": ["rounded-ss", "rounded-es"],
      "rounded-e": ["rounded-se", "rounded-ee"],
      "rounded-t": ["rounded-tl", "rounded-tr"],
      "rounded-r": ["rounded-tr", "rounded-br"],
      "rounded-b": ["rounded-br", "rounded-bl"],
      "rounded-l": ["rounded-tl", "rounded-bl"],
      "border-spacing": ["border-spacing-x", "border-spacing-y"],
      "border-w": ["border-w-s", "border-w-e", "border-w-t", "border-w-r", "border-w-b", "border-w-l"],
      "border-w-x": ["border-w-r", "border-w-l"],
      "border-w-y": ["border-w-t", "border-w-b"],
      "border-color": ["border-color-s", "border-color-e", "border-color-t", "border-color-r", "border-color-b", "border-color-l"],
      "border-color-x": ["border-color-r", "border-color-l"],
      "border-color-y": ["border-color-t", "border-color-b"],
      "scroll-m": ["scroll-mx", "scroll-my", "scroll-ms", "scroll-me", "scroll-mt", "scroll-mr", "scroll-mb", "scroll-ml"],
      "scroll-mx": ["scroll-mr", "scroll-ml"],
      "scroll-my": ["scroll-mt", "scroll-mb"],
      "scroll-p": ["scroll-px", "scroll-py", "scroll-ps", "scroll-pe", "scroll-pt", "scroll-pr", "scroll-pb", "scroll-pl"],
      "scroll-px": ["scroll-pr", "scroll-pl"],
      "scroll-py": ["scroll-pt", "scroll-pb"],
      touch: ["touch-x", "touch-y", "touch-pz"],
      "touch-x": ["touch"],
      "touch-y": ["touch"],
      "touch-pz": ["touch"]
    },
    conflictingClassGroupModifiers: {
      "font-size": ["leading"]
    }
  };
};
var twMerge = /* @__PURE__ */ createTailwindMerge(getDefaultConfig);

// src/lib/utils.ts
function cn(...inputs) {
  return twMerge(clsx(inputs));
}

// src/core/viewportDesktopSite.ts
var MOBILE_DESKTOP_SITE_KEY = "copanel_mobile_desktop_site";
function isMobileDesktopSiteEnabled() {
  try {
    return localStorage.getItem(MOBILE_DESKTOP_SITE_KEY) === "1";
  } catch {
    return false;
  }
}
function isLayoutViewportWide(innerWidth = window.innerWidth) {
  return isMobileDesktopSiteEnabled() || innerWidth >= 1024;
}

// src/core/shell/ModuleViewport.tsx
import { jsx as jsx3 } from "react/jsx-runtime";
function ModuleViewport({ children, className, constrained = false }) {
  const { theme } = useAppShellContext();
  const isWindowed = useIsWindowedModule();
  const isDark = theme === "dark";
  const isClassicMobile = !isWindowed && !isLayoutViewportWide();
  return /* @__PURE__ */ jsx3(
    "div",
    {
      className: cn(
        "flex flex-col transition-colors duration-200",
        isWindowed ? "h-full min-h-0" : isClassicMobile ? "min-h-0" : "min-h-screen",
        isDark ? "bg-slate-950 text-slate-100" : "bg-slate-50 text-slate-900",
        !isWindowed && constrained && "mx-auto max-w-7xl",
        className
      ),
      children
    }
  );
}

// src/core/shell/ModuleSidebarLayout.tsx
import { useEffect, useState } from "react";
import * as Icons from "lucide-react";
import { jsx as jsx4, jsxs } from "react/jsx-runtime";
function ModuleSidebarLayout({
  isDark,
  sidebar,
  children,
  mobileTitle,
  className
}) {
  const isWindowed = useIsWindowedModule();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [viewportWide, setViewportWide] = useState(() => isLayoutViewportWide());
  useEffect(() => {
    const onResize = () => setViewportWide(isLayoutViewportWide());
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  }, []);
  const useDrawer = !isWindowed && !viewportWide;
  useEffect(() => {
    if (viewportWide) setSidebarOpen(false);
  }, [viewportWide]);
  const closeSidebar = () => setSidebarOpen(false);
  if (!useDrawer) {
    return /* @__PURE__ */ jsxs("div", { className: cn("flex h-full min-h-0 flex-1 overflow-hidden", className), children: [
      sidebar,
      /* @__PURE__ */ jsx4("div", { className: "flex min-h-0 min-w-0 flex-1 flex-col overflow-hidden", children })
    ] });
  }
  return /* @__PURE__ */ jsxs("div", { className: cn("relative flex h-full min-h-0 flex-1 flex-col overflow-hidden", className), children: [
    /* @__PURE__ */ jsxs(
      "div",
      {
        className: cn(
          "flex shrink-0 items-center gap-2 border-b px-3 py-2.5",
          isDark ? "border-slate-800 bg-slate-950/90" : "border-slate-200 bg-white"
        ),
        children: [
          /* @__PURE__ */ jsx4(
            "button",
            {
              type: "button",
              onClick: () => setSidebarOpen(true),
              className: cn(
                "inline-flex items-center justify-center rounded-lg p-2",
                isDark ? "text-slate-200 hover:bg-slate-800" : "text-slate-700 hover:bg-slate-100"
              ),
              "aria-label": "Open module menu",
              children: /* @__PURE__ */ jsx4(Icons.PanelLeft, { className: "h-5 w-5" })
            }
          ),
          mobileTitle ? /* @__PURE__ */ jsx4("span", { className: cn("truncate text-sm font-semibold", isDark ? "text-slate-100" : "text-slate-900"), children: mobileTitle }) : null
        ]
      }
    ),
    sidebarOpen ? /* @__PURE__ */ jsx4(
      "button",
      {
        type: "button",
        className: "fixed inset-0 z-[60] bg-black/45",
        "aria-label": "Close module menu",
        onClick: closeSidebar
      }
    ) : null,
    /* @__PURE__ */ jsx4(
      "div",
      {
        className: cn(
          "fixed inset-y-0 left-0 z-[61] flex max-w-[min(85vw,280px)] transform shadow-xl transition-transform duration-200 ease-out",
          sidebarOpen ? "translate-x-0" : "-translate-x-full pointer-events-none"
        ),
        onClick: closeSidebar,
        children: sidebar
      }
    ),
    /* @__PURE__ */ jsx4("div", { className: "flex min-h-0 min-w-0 flex-1 flex-col overflow-hidden", children })
  ] });
}

// src/core/shell/WindowModal.tsx
import { createPortal } from "react-dom";
import * as Icons2 from "lucide-react";
import { jsx as jsx5, jsxs as jsxs2 } from "react/jsx-runtime";
var MAX_W = {
  sm: "max-w-sm",
  md: "max-w-md",
  lg: "max-w-lg",
  xl: "max-w-xl",
  "2xl": "max-w-2xl",
  "4xl": "max-w-4xl",
  "5xl": "max-w-5xl"
};
function WindowModal({
  open,
  onClose,
  children,
  title,
  className,
  maxWidth = "lg",
  closeOnBackdropClick = true
}) {
  const { theme } = useAppShellContext();
  const isDark = theme === "dark";
  const viewport = useWindowViewport();
  if (!open) return null;
  const overlay = /* @__PURE__ */ jsx5(
    "div",
    {
      className: cn(
        "z-[80] flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm",
        viewport?.isWindowed ? "absolute inset-0" : "fixed inset-0"
      ),
      onClick: closeOnBackdropClick ? onClose : void 0,
      children: /* @__PURE__ */ jsxs2(
        "div",
        {
          className: cn(
            "flex w-full flex-col overflow-hidden rounded-2xl border shadow-2xl",
            MAX_W[maxWidth],
            isDark ? "border-slate-700 bg-slate-900 text-slate-100" : "border-slate-200 bg-white text-slate-900",
            className
          ),
          onClick: (e) => e.stopPropagation(),
          children: [
            title && /* @__PURE__ */ jsxs2(
              "div",
              {
                className: cn(
                  "flex items-center justify-between border-b px-4 py-3",
                  isDark ? "border-slate-800" : "border-slate-200"
                ),
                children: [
                  /* @__PURE__ */ jsx5("h3", { className: "text-sm font-bold", children: title }),
                  /* @__PURE__ */ jsx5("button", { type: "button", onClick: onClose, className: "rounded-lg p-1 hover:bg-slate-800/50", "aria-label": "Close", children: /* @__PURE__ */ jsx5(Icons2.X, { className: "h-4 w-4" }) })
                ]
              }
            ),
            children
          ]
        }
      )
    }
  );
  if (viewport?.isWindowed && viewport.viewportRef.current) {
    return createPortal(overlay, viewport.viewportRef.current);
  }
  return createPortal(overlay, document.body);
}

// src/modules/ftp_manager/index.tsx
import * as Icons3 from "lucide-react";

// src/core/platform/api.ts
var PlatformError = class extends Error {
  constructor(code, message, status, details) {
    super(message);
    __publicField(this, "code");
    __publicField(this, "status");
    __publicField(this, "details");
    this.code = code;
    this.status = status;
    this.details = details;
  }
};
async function api(path, opts = {}) {
  const token = typeof window !== "undefined" ? localStorage.getItem("copanel_token") : null;
  const headers = {
    "Content-Type": "application/json",
    ...opts.headers || {}
  };
  if (token) headers["Authorization"] = `Bearer ${token}`;
  const init = {
    method: opts.method || "GET",
    headers,
    signal: opts.signal
  };
  if (opts.body !== void 0) {
    init.body = typeof opts.body === "string" ? opts.body : JSON.stringify(opts.body);
  }
  const res = await fetch(path, init);
  let body = null;
  const text = await res.text();
  if (text) {
    try {
      body = JSON.parse(text);
    } catch {
      body = text;
    }
  }
  if (opts.raw) {
    return body;
  }
  if (!res.ok) {
    const err = body && typeof body === "object" && body.error ? body.error : { code: `HTTP_${res.status}`, message: typeof body === "string" ? body : body?.detail || res.statusText };
    throw new PlatformError(err.code || `HTTP_${res.status}`, err.message || "Request failed", res.status, err.details);
  }
  if (body && typeof body === "object" && "status" in body) {
    if (body.status === "success") {
      return body.data !== void 0 ? body.data : body;
    }
    if (body.status === "error" && body.error) {
      throw new PlatformError(body.error.code, body.error.message, res.status, body.error.details);
    }
  }
  return body;
}

// src/core/platform/events.ts
var PLATFORM_SSE_DEGRADED_EVENT = "copanel-platform-sse-degraded";
var MIN_RETRY_MS = 2e3;
var MAX_RETRY_MS = 6e4;
var POLL_FALLBACK_AFTER_FAILURES = 3;
var EventHub = class {
  constructor() {
    __publicField(this, "source", null);
    __publicField(this, "handlers", /* @__PURE__ */ new Map());
    __publicField(this, "retryDelay", MIN_RETRY_MS);
    __publicField(this, "retryTimer", null);
    __publicField(this, "failureCount", 0);
  }
  on(topic, handler) {
    let set = this.handlers.get(topic);
    if (!set) {
      set = /* @__PURE__ */ new Set();
      this.handlers.set(topic, set);
    }
    set.add(handler);
    this.ensureConnected();
    return () => {
      set.delete(handler);
      if (set.size === 0) {
        this.handlers.delete(topic);
      }
      this.teardownIfIdle();
    };
  }
  emit(topic, payload) {
    const set = this.handlers.get(topic);
    if (set) {
      set.forEach((h) => {
        try {
          h(payload);
        } catch (err) {
          console.error("event handler failed", topic, err);
        }
      });
    }
  }
  buildUrl() {
    const token = localStorage.getItem("copanel_token");
    if (!token) return null;
    const params = new URLSearchParams({
      topics: "jobs,notifications",
      access_token: token
    });
    return `/api/platform/events?${params.toString()}`;
  }
  ensureConnected() {
    if (this.source) return;
    if (typeof document !== "undefined" && document.hidden) return;
    const url = this.buildUrl();
    if (!url) return;
    try {
      this.source = new EventSource(url, { withCredentials: false });
    } catch {
      this.scheduleRetry();
      return;
    }
    this.source.addEventListener("open", () => {
      this.failureCount = 0;
      this.retryDelay = MIN_RETRY_MS;
    });
    this.source.addEventListener("jobs", (e) => {
      this.onStreamMessage();
      this.parseAndEmit("jobs", e.data);
    });
    this.source.addEventListener("notifications", (e) => {
      this.onStreamMessage();
      this.parseAndEmit("notifications", e.data);
    });
    this.source.addEventListener("message", () => {
      this.onStreamMessage();
    });
    this.source.onerror = () => {
      this.failureCount += 1;
      this.source?.close();
      this.source = null;
      if (this.failureCount >= POLL_FALLBACK_AFTER_FAILURES) {
        window.dispatchEvent(new CustomEvent(PLATFORM_SSE_DEGRADED_EVENT));
      }
      this.scheduleRetry();
    };
  }
  onStreamMessage() {
    this.failureCount = 0;
    this.retryDelay = MIN_RETRY_MS;
  }
  parseAndEmit(topic, raw) {
    try {
      const msg = JSON.parse(raw);
      this.emit(topic, msg.payload || msg);
    } catch {
    }
  }
  scheduleRetry() {
    if (this.retryTimer) return;
    if (this.handlers.size === 0) return;
    const delay = this.retryDelay;
    this.retryDelay = Math.min(Math.round(this.retryDelay * 1.8), MAX_RETRY_MS);
    this.retryTimer = setTimeout(() => {
      this.retryTimer = null;
      this.ensureConnected();
    }, delay);
  }
  teardownIfIdle() {
    if (this.handlers.size > 0) return;
    if (this.retryTimer) {
      clearTimeout(this.retryTimer);
      this.retryTimer = null;
    }
    if (this.source) {
      this.source.close();
      this.source = null;
    }
    this.failureCount = 0;
    this.retryDelay = MIN_RETRY_MS;
  }
  /** Drop the SSE connection and open a new one if handlers exist and a token is present. */
  reconnect() {
    if (this.source) {
      this.source.close();
      this.source = null;
    }
    if (this.retryTimer) {
      clearTimeout(this.retryTimer);
      this.retryTimer = null;
    }
    this.failureCount = 0;
    this.retryDelay = MIN_RETRY_MS;
    if (this.handlers.size > 0) {
      this.ensureConnected();
    }
  }
};
var events = new EventHub();
function reconnectPlatformEvents() {
  events.reconnect();
}
if (typeof document !== "undefined") {
  document.addEventListener("visibilitychange", () => {
    if (!document.hidden) {
      reconnectPlatformEvents();
    }
  });
}

// src/core/platform/store.ts
import { useEffect as useEffect2, useState as useState2 } from "react";
function createStore(initial) {
  let state = initial;
  const listeners = /* @__PURE__ */ new Set();
  return {
    getState: () => state,
    setState: (updater) => {
      const patch = typeof updater === "function" ? updater(state) : updater;
      if (!patch || Object.keys(patch).length === 0) return;
      let changed = false;
      for (const key of Object.keys(patch)) {
        if (state[key] !== patch[key]) {
          changed = true;
          break;
        }
      }
      if (!changed) return;
      state = { ...state, ...patch };
      listeners.forEach((l) => l());
    },
    subscribe: (listener) => {
      listeners.add(listener);
      return () => listeners.delete(listener);
    }
  };
}

// src/core/platform/jobsStore.ts
var store = createStore({ jobs: {}, order: [], lastFetch: 0 });
function getCurrentLang() {
  return localStorage.getItem("copanel_lang") === "vi" ? "vi" : "en";
}
function pickLocalizedFromValue(value, lang) {
  if (!value) return void 0;
  if (typeof value === "string") return value;
  if (typeof value === "object") return value[lang] || value.en || value.vi || value.default;
  return void 0;
}
function resolveLocalizedField(src, baseKey, lang) {
  if (!src || typeof src !== "object") return void 0;
  const direct = pickLocalizedFromValue(src[baseKey], lang);
  if (direct) return direct;
  const fromMap = pickLocalizedFromValue(src[`${baseKey}_i18n`], lang);
  if (fromMap) return fromMap;
  const fromLangSpecific = src[`${baseKey}_${lang}`];
  if (typeof fromLangSpecific === "string" && fromLangSpecific) return fromLangSpecific;
  const fallbackEn = src[`${baseKey}_en`];
  if (typeof fallbackEn === "string" && fallbackEn) return fallbackEn;
  const fallbackVi = src[`${baseKey}_vi`];
  if (typeof fallbackVi === "string" && fallbackVi) return fallbackVi;
  return void 0;
}
function localizeJob(raw) {
  const lang = getCurrentLang();
  const payload = raw?.payload && typeof raw.payload === "object" ? raw.payload : {};
  return {
    ...raw,
    title: resolveLocalizedField(raw, "title", lang) || resolveLocalizedField(payload, "title", lang) || raw?.title || "",
    message: resolveLocalizedField(raw, "message", lang) || resolveLocalizedField(payload, "message", lang) || raw?.message,
    error: resolveLocalizedField(raw, "error", lang) || resolveLocalizedField(payload, "error", lang) || raw?.error || null
  };
}
function upsert(job) {
  const localized = localizeJob(job);
  store.setState((s) => {
    const next = { ...s.jobs, [localized.id]: { ...s.jobs[localized.id], ...localized } };
    let order = s.order;
    if (!order.includes(localized.id)) {
      order = [localized.id, ...order].slice(0, 200);
    }
    return { jobs: next, order };
  });
}
events.on("jobs", (msg) => {
  if (msg?.job) {
    upsert(msg.job);
    return;
  }
  if (msg?.job_id && msg?.event === "update") {
    const existing = store.getState().jobs[msg.job_id];
    if (existing) {
      upsert({
        ...existing,
        progress: msg.progress ?? existing.progress,
        message: msg.message ?? existing.message,
        status: msg.status ?? existing.status
      });
    }
  }
});

// src/core/platform/notificationsStore.ts
var store2 = createStore({ inbox: [], unread: 0, toasts: [] });
var TOAST_TTL_MS = 6e3;
function getCurrentLang2() {
  return localStorage.getItem("copanel_lang") === "vi" ? "vi" : "en";
}
function pickLocalizedFromValue2(value, lang) {
  if (!value) return void 0;
  if (typeof value === "string") return value;
  if (typeof value === "object") {
    return value[lang] || value.en || value.vi || value.default;
  }
  return void 0;
}
function resolveLocalizedField2(src, baseKey, lang) {
  if (!src || typeof src !== "object") return void 0;
  const direct = pickLocalizedFromValue2(src[baseKey], lang);
  if (direct) return direct;
  const fromMap = pickLocalizedFromValue2(src[`${baseKey}_i18n`], lang);
  if (fromMap) return fromMap;
  const fromLangSpecific = src[`${baseKey}_${lang}`];
  if (typeof fromLangSpecific === "string" && fromLangSpecific) return fromLangSpecific;
  const fallbackEn = src[`${baseKey}_en`];
  if (typeof fallbackEn === "string" && fallbackEn) return fallbackEn;
  const fallbackVi = src[`${baseKey}_vi`];
  if (typeof fallbackVi === "string" && fallbackVi) return fallbackVi;
  return void 0;
}
function localizeNotification(raw) {
  const lang = getCurrentLang2();
  const payload = raw?.payload && typeof raw.payload === "object" ? raw.payload : {};
  const title = resolveLocalizedField2(raw, "title", lang) || resolveLocalizedField2(payload, "title", lang) || (raw?.title || "");
  const body = resolveLocalizedField2(raw, "body", lang) || resolveLocalizedField2(payload, "body", lang) || raw?.body || null;
  return {
    ...raw,
    title,
    body
  };
}
function pushToast(t) {
  store2.setState((s) => ({ toasts: [t, ...s.toasts].slice(0, 6) }));
  if (t.ephemeral !== false) {
    setTimeout(() => {
      store2.setState((s) => ({ toasts: s.toasts.filter((x) => x.id !== t.id) }));
    }, TOAST_TTL_MS);
  }
}
events.on("notifications", (msg) => {
  if (msg?.event === "new" && msg.notification) {
    const n = localizeNotification(msg.notification);
    pushToast({ ...n, ephemeral: true });
    store2.setState((s) => ({
      inbox: [n, ...s.inbox].slice(0, 200),
      unread: s.unread + 1
    }));
  }
});

// src/modules/ftp_manager/i18n.ts
var en = {
  title: "FTP Manager",
  subtitle: "External FTP \xB7 FTPS \xB7 SFTP",
  connections: "Connections",
  add: "Add connection",
  addShort: "Add",
  edit: "Edit",
  delete: "Delete",
  test: "Test",
  save: "Save",
  cancel: "Cancel",
  label: "Name",
  protocol: "Protocol",
  host: "Host",
  port: "Port",
  username: "Username",
  password: "Password",
  authType: "Authentication",
  authPassword: "Password",
  authKeyPath: "SSH key path",
  authKeyBlob: "Paste private key",
  keyPath: "Private key path",
  keyBlob: "Private key (PEM)",
  remoteRoot: "Remote root",
  passive: "Passive mode (FTP)",
  timeout: "Timeout (seconds)",
  advanced: "Advanced",
  passwordKeep: "Leave blank to keep current password",
  keyKeep: "Leave blank to keep current key",
  emptyTitle: "No connections yet",
  emptyHint: "Add an FTP or SFTP server to browse and transfer files.",
  emptySidebar: "No connections",
  browse: "Remote files",
  refresh: "Refresh",
  mkdir: "New folder",
  rename: "Rename",
  deleteItem: "Delete",
  upload: "Upload",
  download: "Download",
  localPath: "Local path",
  remotePath: "Remote path",
  transferJob: "Start transfer",
  openFileManager: "Open File Manager",
  testing: "Testing\u2026",
  saving: "Saving\u2026",
  loading: "Loading\u2026",
  testOk: "Connection OK",
  testFail: "Connection failed",
  confirmDelete: "Delete this connection?",
  confirmDeleteItem: "Delete this remote item?",
  namePrompt: "Folder name",
  renamePrompt: "New name",
  selectHint: "Select a connection from the list",
  path: "Path",
  size: "Size",
  modified: "Modified",
  name: "Name",
  type: "Type",
  folder: "Folder",
  file: "File",
  jobQueued: "Queued in Task Center",
  noItems: "This folder is empty",
  overwrite: "Overwrite if exists",
  saved: "Saved"
};
var vi = {
  title: "FTP Manager",
  subtitle: "FTP \xB7 FTPS \xB7 SFTP b\xEAn ngo\xE0i",
  connections: "K\u1EBFt n\u1ED1i",
  add: "Th\xEAm k\u1EBFt n\u1ED1i",
  addShort: "Th\xEAm",
  edit: "S\u1EEDa",
  delete: "X\xF3a",
  test: "Ki\u1EC3m tra",
  save: "L\u01B0u",
  cancel: "H\u1EE7y",
  label: "T\xEAn",
  protocol: "Giao th\u1EE9c",
  host: "M\xE1y ch\u1EE7",
  port: "C\u1ED5ng",
  username: "T\xE0i kho\u1EA3n",
  password: "M\u1EADt kh\u1EA9u",
  authType: "X\xE1c th\u1EF1c",
  authPassword: "M\u1EADt kh\u1EA9u",
  authKeyPath: "\u0110\u01B0\u1EDDng d\u1EABn SSH key",
  authKeyBlob: "D\xE1n private key",
  keyPath: "\u0110\u01B0\u1EDDng d\u1EABn private key",
  keyBlob: "Private key (PEM)",
  remoteRoot: "Th\u01B0 m\u1EE5c g\u1ED1c remote",
  passive: "Ch\u1EBF \u0111\u1ED9 Passive (FTP)",
  timeout: "Timeout (gi\xE2y)",
  advanced: "N\xE2ng cao",
  passwordKeep: "\u0110\u1EC3 tr\u1ED1ng \u0111\u1EC3 gi\u1EEF m\u1EADt kh\u1EA9u hi\u1EC7n t\u1EA1i",
  keyKeep: "\u0110\u1EC3 tr\u1ED1ng \u0111\u1EC3 gi\u1EEF key hi\u1EC7n t\u1EA1i",
  emptyTitle: "Ch\u01B0a c\xF3 k\u1EBFt n\u1ED1i",
  emptyHint: "Th\xEAm m\xE1y ch\u1EE7 FTP ho\u1EB7c SFTP \u0111\u1EC3 duy\u1EC7t v\xE0 chuy\u1EC3n file.",
  emptySidebar: "Ch\u01B0a c\xF3 k\u1EBFt n\u1ED1i",
  browse: "File remote",
  refresh: "T\u1EA3i l\u1EA1i",
  mkdir: "Th\u01B0 m\u1EE5c m\u1EDBi",
  rename: "\u0110\u1ED5i t\xEAn",
  deleteItem: "X\xF3a",
  upload: "Upload",
  download: "Download",
  localPath: "\u0110\u01B0\u1EDDng d\u1EABn local",
  remotePath: "\u0110\u01B0\u1EDDng d\u1EABn remote",
  transferJob: "B\u1EAFt \u0111\u1EA7u chuy\u1EC3n",
  openFileManager: "M\u1EDF File Manager",
  testing: "\u0110ang ki\u1EC3m tra\u2026",
  saving: "\u0110ang l\u01B0u\u2026",
  loading: "\u0110ang t\u1EA3i\u2026",
  testOk: "K\u1EBFt n\u1ED1i th\xE0nh c\xF4ng",
  testFail: "K\u1EBFt n\u1ED1i th\u1EA5t b\u1EA1i",
  confirmDelete: "X\xF3a k\u1EBFt n\u1ED1i n\xE0y?",
  confirmDeleteItem: "X\xF3a m\u1EE5c remote n\xE0y?",
  namePrompt: "T\xEAn th\u01B0 m\u1EE5c",
  renamePrompt: "T\xEAn m\u1EDBi",
  selectHint: "Ch\u1ECDn m\u1ED9t k\u1EBFt n\u1ED1i b\xEAn tr\xE1i",
  path: "\u0110\u01B0\u1EDDng d\u1EABn",
  size: "K\xEDch th\u01B0\u1EDBc",
  modified: "S\u1EEDa \u0111\u1ED5i",
  name: "T\xEAn",
  type: "Lo\u1EA1i",
  folder: "Th\u01B0 m\u1EE5c",
  file: "T\u1EC7p",
  jobQueued: "\u0110\xE3 \u0111\u01B0a v\xE0o Task Center",
  noItems: "Th\u01B0 m\u1EE5c tr\u1ED1ng",
  overwrite: "Ghi \u0111\xE8 n\u1EBFu t\u1ED3n t\u1EA1i",
  saved: "\u0110\xE3 l\u01B0u"
};
var TEXT = { en, vi };

// src/modules/ftp_manager/index.tsx
import { Fragment, jsx as jsx6, jsxs as jsxs3 } from "react/jsx-runtime";
var emptyForm = () => ({
  label: "",
  protocol: "sftp",
  host: "",
  port: "22",
  username: "",
  auth_type: "password",
  password: "",
  key_path: "",
  key_blob: "",
  remote_root: "/",
  passive: true,
  timeout: "30"
});
function formFromConn(c) {
  return {
    label: c.label,
    protocol: c.protocol,
    host: c.host,
    port: String(c.port),
    username: c.username,
    auth_type: c.auth_type || "password",
    password: "",
    key_path: "",
    key_blob: "",
    remote_root: c.remote_root || "/",
    passive: c.passive,
    timeout: String(c.timeout || 30)
  };
}
function defaultPort(protocol) {
  return protocol === "sftp" ? "22" : "21";
}
function formatBytes(n) {
  if (!n) return "\u2014";
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  if (n < 1024 * 1024 * 1024) return `${(n / (1024 * 1024)).toFixed(1)} MB`;
  return `${(n / (1024 * 1024 * 1024)).toFixed(2)} GB`;
}
function formatTime(ts) {
  if (!ts) return "\u2014";
  try {
    return new Date(ts * 1e3).toLocaleString();
  } catch {
    return "\u2014";
  }
}
function FtpManager() {
  const { theme, language } = useAppShellContext();
  const isDark = theme === "dark";
  const lang = language === "vi" ? "vi" : "en";
  const tr = TEXT[lang];
  const windowed = useIsWindowedModule();
  const [connections, setConnections] = useState3([]);
  const [selectedId, setSelectedId] = useState3(null);
  const [remotePath, setRemotePath] = useState3("/");
  const [items, setItems] = useState3([]);
  const [selectedItem, setSelectedItem] = useState3(null);
  const [loadingList, setLoadingList] = useState3(true);
  const [loadingBrowse, setLoadingBrowse] = useState3(false);
  const [busy, setBusy] = useState3(false);
  const [error, setError] = useState3(null);
  const [msg, setMsg] = useState3(null);
  const [editorOpen, setEditorOpen] = useState3(false);
  const [editingId, setEditingId] = useState3(null);
  const [form, setForm] = useState3(emptyForm());
  const [showAdvanced, setShowAdvanced] = useState3(false);
  const [transferOpen, setTransferOpen] = useState3(false);
  const [transferDir, setTransferDir] = useState3("download");
  const [localPath, setLocalPath] = useState3("/tmp");
  const [overwrite, setOverwrite] = useState3(true);
  const [confirmOpen, setConfirmOpen] = useState3(false);
  const [confirmKind, setConfirmKind] = useState3("connection");
  const selected = useMemo(
    () => connections.find((c) => c.id === selectedId) || null,
    [connections, selectedId]
  );
  const loadConnections = useCallback(async (preferId) => {
    setLoadingList(true);
    setError(null);
    try {
      const data = await api("/api/ftp_manager/connections");
      const list = Array.isArray(data) ? data : [];
      setConnections(list);
      setSelectedId((prev) => {
        if (preferId != null && list.some((c) => c.id === preferId)) return preferId;
        if (prev != null && list.some((c) => c.id === prev)) return prev;
        return list.length > 0 ? list[0].id : null;
      });
    } catch (e) {
      setError(e?.message || String(e));
      setConnections([]);
    } finally {
      setLoadingList(false);
    }
  }, []);
  const browse = useCallback(async (connId, path) => {
    setLoadingBrowse(true);
    setError(null);
    setSelectedItem(null);
    try {
      const data = await api(
        `/api/ftp_manager/connections/${connId}/list?path=${encodeURIComponent(path)}`
      );
      setRemotePath(data.path || path || "/");
      setItems(Array.isArray(data.items) ? data.items : []);
    } catch (e) {
      setError(e?.message || String(e));
      setItems([]);
    } finally {
      setLoadingBrowse(false);
    }
  }, []);
  useEffect3(() => {
    loadConnections();
  }, [loadConnections]);
  useEffect3(() => {
    if (selectedId != null) {
      const root = connections.find((c) => c.id === selectedId)?.remote_root || "/";
      browse(selectedId, root);
    } else {
      setItems([]);
      setRemotePath("/");
    }
  }, [selectedId]);
  const crumbs = useMemo(() => {
    const parts = remotePath.split("/").filter(Boolean);
    const out = [{ label: "/", path: "/" }];
    let acc = "";
    for (const p of parts) {
      acc += `/${p}`;
      out.push({ label: p, path: acc });
    }
    return out;
  }, [remotePath]);
  const openCreate = () => {
    setEditingId(null);
    setForm(emptyForm());
    setShowAdvanced(false);
    setEditorOpen(true);
    setMsg(null);
    setError(null);
  };
  const openEdit = (c) => {
    setEditingId(c.id);
    setForm(formFromConn(c));
    setShowAdvanced(false);
    setEditorOpen(true);
    setMsg(null);
    setError(null);
  };
  const onProtocolChange = (protocol) => {
    setForm((f) => ({
      ...f,
      protocol,
      port: f.port === "21" || f.port === "22" || !f.port ? defaultPort(protocol) : f.port,
      auth_type: protocol === "sftp" ? f.auth_type : "password"
    }));
  };
  const saveConnection = async () => {
    setBusy(true);
    setError(null);
    setMsg(null);
    try {
      const payload = {
        label: form.label.trim(),
        protocol: form.protocol,
        host: form.host.trim(),
        port: Number(form.port) || 0,
        username: form.username.trim(),
        auth_type: form.auth_type,
        remote_root: form.remote_root.trim() || "/",
        passive: form.passive,
        timeout: Number(form.timeout) || 30
      };
      if (form.password) payload.password = form.password;
      if (form.auth_type === "key_path" && form.key_path) payload.key_path = form.key_path;
      if (form.auth_type === "key_blob" && form.key_blob) payload.key_blob = form.key_blob;
      let newId = editingId;
      if (editingId == null) {
        const created = await api("/api/ftp_manager/connections", {
          method: "POST",
          body: payload
        });
        newId = created.id;
      } else {
        await api(`/api/ftp_manager/connections/${editingId}`, {
          method: "PATCH",
          body: payload
        });
      }
      setEditorOpen(false);
      await loadConnections(newId);
      setMsg(tr.saved);
    } catch (e) {
      setError(e?.message || String(e));
    } finally {
      setBusy(false);
    }
  };
  const testConnection = async (id) => {
    setBusy(true);
    setError(null);
    setMsg(null);
    try {
      if (id != null) {
        await api(`/api/ftp_manager/connections/${id}/test`, { method: "POST", body: {} });
      } else {
        await api("/api/ftp_manager/connections/test", {
          method: "POST",
          body: {
            protocol: form.protocol,
            host: form.host.trim(),
            port: Number(form.port) || 0,
            username: form.username.trim(),
            auth_type: form.auth_type,
            password: form.password || void 0,
            key_path: form.key_path || void 0,
            key_blob: form.key_blob || void 0,
            remote_root: form.remote_root || "/",
            passive: form.passive,
            timeout: Number(form.timeout) || 30
          }
        });
      }
      setMsg(tr.testOk);
    } catch (e) {
      setError(e?.message || tr.testFail);
    } finally {
      setBusy(false);
    }
  };
  const doDeleteConnection = async () => {
    if (selectedId == null) return;
    setBusy(true);
    try {
      await api(`/api/ftp_manager/connections/${selectedId}`, { method: "DELETE" });
      setSelectedId(null);
      setConfirmOpen(false);
      await loadConnections(null);
    } catch (e) {
      setError(e?.message || String(e));
    } finally {
      setBusy(false);
    }
  };
  const doMkdir = async () => {
    if (selectedId == null) return;
    const name = window.prompt(tr.namePrompt);
    if (!name || !name.trim()) return;
    const path = `${remotePath.replace(/\/$/, "")}/${name.trim()}`;
    setBusy(true);
    try {
      await api(`/api/ftp_manager/connections/${selectedId}/mkdir`, {
        method: "POST",
        body: { path }
      });
      await browse(selectedId, remotePath);
    } catch (e) {
      setError(e?.message || String(e));
    } finally {
      setBusy(false);
    }
  };
  const doRename = async () => {
    if (selectedId == null || !selectedItem) return;
    const name = window.prompt(tr.renamePrompt, selectedItem.name);
    if (!name || !name.trim() || name.trim() === selectedItem.name) return;
    setBusy(true);
    try {
      await api(`/api/ftp_manager/connections/${selectedId}/rename`, {
        method: "POST",
        body: { path: selectedItem.path, new_name: name.trim() }
      });
      await browse(selectedId, remotePath);
    } catch (e) {
      setError(e?.message || String(e));
    } finally {
      setBusy(false);
    }
  };
  const doDeleteItem = async () => {
    if (selectedId == null || !selectedItem) return;
    setBusy(true);
    try {
      await api(`/api/ftp_manager/connections/${selectedId}/delete`, {
        method: "POST",
        body: { path: selectedItem.path, recursive: selectedItem.is_dir }
      });
      setConfirmOpen(false);
      setSelectedItem(null);
      await browse(selectedId, remotePath);
    } catch (e) {
      setError(e?.message || String(e));
    } finally {
      setBusy(false);
    }
  };
  const startTransfer = async () => {
    if (selectedId == null) return;
    const remote = selectedItem?.path || remotePath;
    setBusy(true);
    setError(null);
    setMsg(null);
    try {
      const data = await api("/api/ftp_manager/transfer_job", {
        method: "POST",
        body: {
          connection_id: selectedId,
          direction: transferDir,
          remote_path: remote,
          local_path: localPath.trim(),
          overwrite
        }
      });
      setTransferOpen(false);
      setMsg(`${tr.jobQueued}: ${data.job_id}`);
    } catch (e) {
      setError(e?.message || String(e));
    } finally {
      setBusy(false);
    }
  };
  const fieldClass = cn(
    "w-full rounded-lg border px-3 py-2 text-sm outline-none transition",
    "focus:ring-2 focus:ring-sky-500/30 focus:border-sky-500",
    isDark ? "border-slate-700 bg-slate-900 text-slate-100" : "border-slate-300 bg-white text-slate-900"
  );
  const labelClass = cn("mb-1.5 block text-xs font-medium", isDark ? "text-slate-400" : "text-slate-500");
  const btnPrimary = cn(
    "inline-flex items-center justify-center gap-1.5 rounded-lg px-3 py-2 text-sm font-medium text-white",
    "bg-sky-600 hover:bg-sky-500 disabled:opacity-50"
  );
  const btnGhost = cn(
    "inline-flex items-center justify-center gap-1.5 rounded-lg px-3 py-2 text-sm font-medium border",
    isDark ? "border-slate-700 text-slate-200 hover:bg-slate-800" : "border-slate-300 text-slate-700 hover:bg-slate-50"
  );
  const btnIcon = cn(
    "inline-flex h-8 w-8 items-center justify-center rounded-lg border",
    isDark ? "border-slate-700 text-slate-300 hover:bg-slate-800" : "border-slate-300 text-slate-600 hover:bg-slate-50"
  );
  const sidebar = /* @__PURE__ */ jsxs3(
    "aside",
    {
      className: cn(
        "flex h-full w-[220px] shrink-0 flex-col border-r",
        isDark ? "border-slate-800 bg-slate-950/90" : "border-slate-200 bg-slate-50/95"
      ),
      children: [
        /* @__PURE__ */ jsxs3(
          "div",
          {
            className: cn(
              "flex shrink-0 items-center justify-between gap-2 border-b px-3 py-3",
              isDark ? "border-slate-800" : "border-slate-200"
            ),
            children: [
              /* @__PURE__ */ jsxs3("div", { className: "min-w-0", children: [
                /* @__PURE__ */ jsx6("div", { className: "truncate text-sm font-semibold", children: tr.title }),
                /* @__PURE__ */ jsx6("div", { className: cn("truncate text-[11px]", isDark ? "text-slate-500" : "text-slate-400"), children: tr.subtitle })
              ] }),
              /* @__PURE__ */ jsx6(
                "button",
                {
                  type: "button",
                  title: tr.add,
                  onClick: openCreate,
                  className: "flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-sky-600 text-white hover:bg-sky-500",
                  children: /* @__PURE__ */ jsx6(Icons3.Plus, { className: "h-4 w-4" })
                }
              )
            ]
          }
        ),
        /* @__PURE__ */ jsxs3("nav", { className: "min-h-0 flex-1 space-y-0.5 overflow-y-auto p-2", children: [
          loadingList && /* @__PURE__ */ jsxs3("div", { className: cn("flex items-center gap-2 px-2 py-3 text-xs", isDark ? "text-slate-500" : "text-slate-400"), children: [
            /* @__PURE__ */ jsx6(Icons3.Loader2, { className: "h-3.5 w-3.5 animate-spin" }),
            tr.loading
          ] }),
          !loadingList && connections.length === 0 && /* @__PURE__ */ jsx6("p", { className: cn("px-2 py-6 text-center text-[11px] leading-relaxed", isDark ? "text-slate-500" : "text-slate-400"), children: tr.emptySidebar }),
          !loadingList && connections.map((c) => {
            const active = c.id === selectedId;
            return /* @__PURE__ */ jsxs3(
              "button",
              {
                type: "button",
                onClick: () => setSelectedId(c.id),
                className: cn(
                  "flex w-full items-center gap-2 rounded-lg px-2.5 py-2.5 text-left text-xs transition",
                  active ? isDark ? "bg-slate-800 text-white" : "bg-white text-slate-900 shadow-sm" : isDark ? "text-slate-300 hover:bg-slate-900/70" : "text-slate-700 hover:bg-white/80"
                ),
                children: [
                  /* @__PURE__ */ jsx6(
                    Icons3.HardDrive,
                    {
                      className: cn("h-4 w-4 shrink-0", active ? "text-sky-500" : "text-slate-400")
                    }
                  ),
                  /* @__PURE__ */ jsxs3("span", { className: "min-w-0 flex-1", children: [
                    /* @__PURE__ */ jsx6("span", { className: "block truncate font-medium", children: c.label }),
                    /* @__PURE__ */ jsxs3("span", { className: cn("block truncate", isDark ? "text-slate-500" : "text-slate-400"), children: [
                      c.protocol.toUpperCase(),
                      " \xB7 ",
                      c.host
                    ] })
                  ] })
                ]
              },
              c.id
            );
          })
        ] })
      ]
    }
  );
  const banner = error || msg ? /* @__PURE__ */ jsxs3(
    "div",
    {
      className: cn(
        "mx-4 mt-3 flex shrink-0 items-center gap-2 rounded-xl border px-3 py-2 text-xs",
        error ? "border-red-500/30 bg-red-500/10 text-red-500" : "border-emerald-500/30 bg-emerald-500/10 text-emerald-600"
      ),
      children: [
        error ? /* @__PURE__ */ jsx6(Icons3.AlertTriangle, { className: "h-4 w-4 shrink-0" }) : /* @__PURE__ */ jsx6(Icons3.CheckCircle2, { className: "h-4 w-4 shrink-0" }),
        /* @__PURE__ */ jsx6("span", { className: "min-w-0 flex-1", children: error || msg }),
        /* @__PURE__ */ jsx6("button", { type: "button", className: "opacity-60 hover:opacity-100", onClick: () => {
          setError(null);
          setMsg(null);
        }, children: /* @__PURE__ */ jsx6(Icons3.X, { className: "h-3.5 w-3.5" }) })
      ]
    }
  ) : null;
  return /* @__PURE__ */ jsxs3(ModuleViewport, { constrained: true, className: "overflow-hidden", children: [
    /* @__PURE__ */ jsx6(
      ModuleSidebarLayout,
      {
        isDark,
        mobileTitle: tr.title,
        className: cn("min-h-0", isDark ? "text-slate-100" : "text-slate-900"),
        sidebar,
        children: /* @__PURE__ */ jsxs3("div", { className: "flex h-full min-h-0 flex-col overflow-hidden", children: [
          banner,
          !selected ? /* @__PURE__ */ jsxs3("div", { className: "flex min-h-0 flex-1 flex-col items-center justify-center gap-4 px-6 text-center", children: [
            /* @__PURE__ */ jsx6(
              "div",
              {
                className: cn(
                  "flex h-14 w-14 items-center justify-center rounded-2xl",
                  isDark ? "bg-slate-800" : "bg-slate-100"
                ),
                children: /* @__PURE__ */ jsx6(Icons3.Server, { className: cn("h-7 w-7", isDark ? "text-slate-400" : "text-slate-500") })
              }
            ),
            /* @__PURE__ */ jsxs3("div", { className: "max-w-sm space-y-1.5", children: [
              /* @__PURE__ */ jsx6("h2", { className: "text-base font-semibold", children: tr.emptyTitle }),
              /* @__PURE__ */ jsx6("p", { className: cn("text-sm", isDark ? "text-slate-400" : "text-slate-500"), children: tr.emptyHint })
            ] }),
            /* @__PURE__ */ jsxs3("button", { type: "button", className: btnPrimary, onClick: openCreate, children: [
              /* @__PURE__ */ jsx6(Icons3.Plus, { className: "h-4 w-4" }),
              tr.add
            ] })
          ] }) : /* @__PURE__ */ jsxs3(Fragment, { children: [
            /* @__PURE__ */ jsxs3(
              "header",
              {
                className: cn(
                  "flex shrink-0 flex-wrap items-center gap-2 border-b px-4 py-3",
                  isDark ? "border-slate-800" : "border-slate-200"
                ),
                children: [
                  /* @__PURE__ */ jsxs3("div", { className: "min-w-0 flex-1", children: [
                    /* @__PURE__ */ jsx6("h1", { className: "truncate text-base font-semibold", children: selected.label }),
                    /* @__PURE__ */ jsxs3("p", { className: cn("truncate text-xs", isDark ? "text-slate-500" : "text-slate-400"), children: [
                      selected.protocol.toUpperCase(),
                      "://",
                      selected.username,
                      "@",
                      selected.host,
                      ":",
                      selected.port
                    ] })
                  ] }),
                  /* @__PURE__ */ jsxs3("div", { className: "flex flex-wrap gap-1.5", children: [
                    /* @__PURE__ */ jsxs3("button", { type: "button", className: btnGhost, disabled: busy, onClick: () => testConnection(selected.id), children: [
                      /* @__PURE__ */ jsx6(Icons3.ShieldCheck, { className: "h-4 w-4" }),
                      busy ? tr.testing : tr.test
                    ] }),
                    /* @__PURE__ */ jsxs3("button", { type: "button", className: btnGhost, onClick: () => openEdit(selected), children: [
                      /* @__PURE__ */ jsx6(Icons3.Pencil, { className: "h-4 w-4" }),
                      tr.edit
                    ] }),
                    /* @__PURE__ */ jsxs3(
                      "button",
                      {
                        type: "button",
                        className: btnGhost,
                        onClick: () => {
                          setConfirmKind("connection");
                          setConfirmOpen(true);
                        },
                        children: [
                          /* @__PURE__ */ jsx6(Icons3.Trash2, { className: "h-4 w-4" }),
                          tr.delete
                        ]
                      }
                    )
                  ] })
                ]
              }
            ),
            /* @__PURE__ */ jsxs3(
              "div",
              {
                className: cn(
                  "flex shrink-0 flex-wrap items-center gap-1.5 border-b px-3 py-2",
                  isDark ? "border-slate-800" : "border-slate-200"
                ),
                children: [
                  /* @__PURE__ */ jsx6("div", { className: "flex min-w-0 flex-1 flex-wrap items-center gap-0.5 text-sm", children: crumbs.map((c, i) => /* @__PURE__ */ jsxs3("span", { className: "inline-flex items-center gap-0.5", children: [
                    i > 0 && /* @__PURE__ */ jsx6(Icons3.ChevronRight, { className: "h-3.5 w-3.5 opacity-40" }),
                    /* @__PURE__ */ jsx6(
                      "button",
                      {
                        type: "button",
                        className: cn(
                          "rounded px-1.5 py-0.5 hover:text-sky-500",
                          i === crumbs.length - 1 && "font-medium"
                        ),
                        onClick: () => browse(selected.id, c.path),
                        children: c.label
                      }
                    )
                  ] }, c.path)) }),
                  /* @__PURE__ */ jsx6("button", { type: "button", className: btnIcon, title: tr.refresh, disabled: loadingBrowse, onClick: () => browse(selected.id, remotePath), children: /* @__PURE__ */ jsx6(Icons3.RefreshCw, { className: cn("h-4 w-4", loadingBrowse && "animate-spin") }) }),
                  /* @__PURE__ */ jsx6("button", { type: "button", className: btnIcon, title: tr.mkdir, onClick: doMkdir, children: /* @__PURE__ */ jsx6(Icons3.FolderPlus, { className: "h-4 w-4" }) }),
                  /* @__PURE__ */ jsx6("button", { type: "button", className: btnIcon, title: tr.rename, disabled: !selectedItem, onClick: doRename, children: /* @__PURE__ */ jsx6(Icons3.TextCursorInput, { className: "h-4 w-4" }) }),
                  /* @__PURE__ */ jsx6(
                    "button",
                    {
                      type: "button",
                      className: btnIcon,
                      title: tr.deleteItem,
                      disabled: !selectedItem,
                      onClick: () => {
                        setConfirmKind("item");
                        setConfirmOpen(true);
                      },
                      children: /* @__PURE__ */ jsx6(Icons3.Trash2, { className: "h-4 w-4" })
                    }
                  ),
                  /* @__PURE__ */ jsxs3(
                    "button",
                    {
                      type: "button",
                      className: btnGhost,
                      onClick: () => {
                        setTransferDir("download");
                        setLocalPath("/tmp");
                        setTransferOpen(true);
                      },
                      children: [
                        /* @__PURE__ */ jsx6(Icons3.Download, { className: "h-4 w-4" }),
                        tr.download
                      ]
                    }
                  ),
                  /* @__PURE__ */ jsxs3(
                    "button",
                    {
                      type: "button",
                      className: btnPrimary,
                      onClick: () => {
                        setTransferDir("upload");
                        setLocalPath("/tmp");
                        setTransferOpen(true);
                      },
                      children: [
                        /* @__PURE__ */ jsx6(Icons3.Upload, { className: "h-4 w-4" }),
                        tr.upload
                      ]
                    }
                  )
                ]
              }
            ),
            /* @__PURE__ */ jsx6("div", { className: cn("min-h-0 flex-1 overflow-y-auto overscroll-contain", windowed ? "" : ""), children: /* @__PURE__ */ jsxs3("table", { className: "w-full text-left text-sm", children: [
              /* @__PURE__ */ jsx6(
                "thead",
                {
                  className: cn(
                    "sticky top-0 z-10 border-b text-[11px] uppercase tracking-wide",
                    isDark ? "border-slate-800 bg-slate-950 text-slate-500" : "border-slate-200 bg-slate-50 text-slate-400"
                  ),
                  children: /* @__PURE__ */ jsxs3("tr", { children: [
                    /* @__PURE__ */ jsx6("th", { className: "px-4 py-2.5 font-medium", children: tr.name }),
                    /* @__PURE__ */ jsx6("th", { className: "px-4 py-2.5 font-medium", children: tr.type }),
                    /* @__PURE__ */ jsx6("th", { className: "px-4 py-2.5 font-medium", children: tr.size }),
                    /* @__PURE__ */ jsx6("th", { className: "px-4 py-2.5 font-medium", children: tr.modified })
                  ] })
                }
              ),
              /* @__PURE__ */ jsxs3("tbody", { children: [
                remotePath !== "/" && /* @__PURE__ */ jsx6(
                  "tr",
                  {
                    className: cn(
                      "cursor-pointer border-b",
                      isDark ? "border-slate-800/80 hover:bg-slate-900" : "border-slate-100 hover:bg-slate-50"
                    ),
                    onDoubleClick: () => {
                      const parent = remotePath.replace(/\/+$/, "").split("/").slice(0, -1).join("/") || "/";
                      browse(selected.id, parent);
                    },
                    children: /* @__PURE__ */ jsx6("td", { className: "px-4 py-2.5", colSpan: 4, children: /* @__PURE__ */ jsxs3("span", { className: "inline-flex items-center gap-2 opacity-70", children: [
                      /* @__PURE__ */ jsx6(Icons3.CornerLeftUp, { className: "h-4 w-4" }),
                      ".."
                    ] }) })
                  }
                ),
                !loadingBrowse && items.length === 0 && /* @__PURE__ */ jsx6("tr", { children: /* @__PURE__ */ jsx6("td", { className: "px-4 py-10 text-center text-sm opacity-50", colSpan: 4, children: tr.noItems }) }),
                items.map((item) => {
                  const active = selectedItem?.path === item.path;
                  return /* @__PURE__ */ jsxs3(
                    "tr",
                    {
                      className: cn(
                        "cursor-pointer border-b",
                        isDark ? "border-slate-800/80" : "border-slate-100",
                        active ? "bg-sky-500/10" : isDark ? "hover:bg-slate-900" : "hover:bg-slate-50"
                      ),
                      onClick: () => setSelectedItem(item),
                      onDoubleClick: () => {
                        if (item.is_dir) browse(selected.id, item.path);
                      },
                      children: [
                        /* @__PURE__ */ jsx6("td", { className: "px-4 py-2.5", children: /* @__PURE__ */ jsxs3("span", { className: "inline-flex items-center gap-2", children: [
                          item.is_dir ? /* @__PURE__ */ jsx6(Icons3.Folder, { className: "h-4 w-4 text-amber-500" }) : /* @__PURE__ */ jsx6(Icons3.File, { className: "h-4 w-4 opacity-50" }),
                          item.name
                        ] }) }),
                        /* @__PURE__ */ jsx6("td", { className: "px-4 py-2.5 opacity-60", children: item.is_dir ? tr.folder : tr.file }),
                        /* @__PURE__ */ jsx6("td", { className: "px-4 py-2.5 opacity-60", children: item.is_dir ? "\u2014" : formatBytes(item.size) }),
                        /* @__PURE__ */ jsx6("td", { className: "px-4 py-2.5 opacity-60", children: formatTime(item.modified) })
                      ]
                    },
                    item.path
                  );
                })
              ] })
            ] }) }),
            /* @__PURE__ */ jsxs3(
              "div",
              {
                className: cn(
                  "flex shrink-0 items-center justify-between gap-2 border-t px-4 py-2 text-[11px]",
                  isDark ? "border-slate-800 text-slate-500" : "border-slate-200 text-slate-400"
                ),
                children: [
                  /* @__PURE__ */ jsxs3("span", { className: "truncate", children: [
                    tr.path,
                    ": ",
                    remotePath,
                    selectedItem ? ` \xB7 ${selectedItem.name}` : ""
                  ] }),
                  /* @__PURE__ */ jsxs3(Link, { to: "/file-manager", className: "inline-flex items-center gap-1 text-sky-500 hover:underline", children: [
                    /* @__PURE__ */ jsx6(Icons3.FolderOpen, { className: "h-3.5 w-3.5" }),
                    tr.openFileManager
                  ] })
                ]
              }
            )
          ] })
        ] })
      }
    ),
    /* @__PURE__ */ jsx6(
      WindowModal,
      {
        open: editorOpen,
        onClose: () => setEditorOpen(false),
        title: editingId == null ? tr.add : tr.edit,
        maxWidth: "lg",
        className: "max-h-[85vh]",
        children: /* @__PURE__ */ jsxs3("div", { className: "space-y-4 p-1", children: [
          /* @__PURE__ */ jsxs3("div", { className: "grid grid-cols-1 gap-3 sm:grid-cols-2", children: [
            /* @__PURE__ */ jsxs3("label", { className: "block sm:col-span-1", children: [
              /* @__PURE__ */ jsx6("span", { className: labelClass, children: tr.label }),
              /* @__PURE__ */ jsx6(
                "input",
                {
                  className: fieldClass,
                  autoComplete: "off",
                  value: form.label,
                  onChange: (e) => setForm({ ...form, label: e.target.value })
                }
              )
            ] }),
            /* @__PURE__ */ jsxs3("label", { className: "block sm:col-span-1", children: [
              /* @__PURE__ */ jsx6("span", { className: labelClass, children: tr.protocol }),
              /* @__PURE__ */ jsxs3(
                "select",
                {
                  className: fieldClass,
                  value: form.protocol,
                  onChange: (e) => onProtocolChange(e.target.value),
                  children: [
                    /* @__PURE__ */ jsx6("option", { value: "sftp", children: "SFTP" }),
                    /* @__PURE__ */ jsx6("option", { value: "ftp", children: "FTP" }),
                    /* @__PURE__ */ jsx6("option", { value: "ftps", children: "FTPS" })
                  ]
                }
              )
            ] }),
            /* @__PURE__ */ jsxs3("label", { className: "block sm:col-span-2", children: [
              /* @__PURE__ */ jsx6("span", { className: labelClass, children: tr.host }),
              /* @__PURE__ */ jsx6(
                "input",
                {
                  className: fieldClass,
                  autoComplete: "off",
                  value: form.host,
                  onChange: (e) => setForm({ ...form, host: e.target.value })
                }
              )
            ] }),
            /* @__PURE__ */ jsxs3("label", { className: "block", children: [
              /* @__PURE__ */ jsx6("span", { className: labelClass, children: tr.port }),
              /* @__PURE__ */ jsx6(
                "input",
                {
                  className: fieldClass,
                  autoComplete: "off",
                  inputMode: "numeric",
                  value: form.port,
                  onChange: (e) => setForm({ ...form, port: e.target.value })
                }
              )
            ] }),
            /* @__PURE__ */ jsxs3("label", { className: "block", children: [
              /* @__PURE__ */ jsx6("span", { className: labelClass, children: tr.username }),
              /* @__PURE__ */ jsx6(
                "input",
                {
                  className: fieldClass,
                  autoComplete: "off",
                  name: "ftp-username",
                  value: form.username,
                  onChange: (e) => setForm({ ...form, username: e.target.value })
                }
              )
            ] }),
            form.protocol === "sftp" && /* @__PURE__ */ jsxs3("label", { className: "block sm:col-span-2", children: [
              /* @__PURE__ */ jsx6("span", { className: labelClass, children: tr.authType }),
              /* @__PURE__ */ jsxs3(
                "select",
                {
                  className: fieldClass,
                  value: form.auth_type,
                  onChange: (e) => setForm({ ...form, auth_type: e.target.value }),
                  children: [
                    /* @__PURE__ */ jsx6("option", { value: "password", children: tr.authPassword }),
                    /* @__PURE__ */ jsx6("option", { value: "key_path", children: tr.authKeyPath }),
                    /* @__PURE__ */ jsx6("option", { value: "key_blob", children: tr.authKeyBlob })
                  ]
                }
              )
            ] }),
            (form.auth_type === "password" || form.protocol !== "sftp") && /* @__PURE__ */ jsxs3("label", { className: "block sm:col-span-2", children: [
              /* @__PURE__ */ jsx6("span", { className: labelClass, children: tr.password }),
              /* @__PURE__ */ jsx6(
                "input",
                {
                  type: "password",
                  className: fieldClass,
                  autoComplete: "new-password",
                  name: "ftp-password",
                  value: form.password,
                  placeholder: editingId != null ? tr.passwordKeep : "",
                  onChange: (e) => setForm({ ...form, password: e.target.value })
                }
              )
            ] }),
            form.protocol === "sftp" && form.auth_type === "key_path" && /* @__PURE__ */ jsxs3("label", { className: "block sm:col-span-2", children: [
              /* @__PURE__ */ jsx6("span", { className: labelClass, children: tr.keyPath }),
              /* @__PURE__ */ jsx6(
                "input",
                {
                  className: fieldClass,
                  autoComplete: "off",
                  value: form.key_path,
                  placeholder: editingId != null ? tr.keyKeep : "~/.ssh/id_ed25519",
                  onChange: (e) => setForm({ ...form, key_path: e.target.value })
                }
              )
            ] }),
            form.protocol === "sftp" && form.auth_type === "key_blob" && /* @__PURE__ */ jsxs3("label", { className: "block sm:col-span-2", children: [
              /* @__PURE__ */ jsx6("span", { className: labelClass, children: tr.keyBlob }),
              /* @__PURE__ */ jsx6(
                "textarea",
                {
                  className: cn(fieldClass, "min-h-[100px] font-mono text-xs"),
                  autoComplete: "off",
                  value: form.key_blob,
                  placeholder: editingId != null ? tr.keyKeep : "-----BEGIN OPENSSH PRIVATE KEY-----",
                  onChange: (e) => setForm({ ...form, key_blob: e.target.value })
                }
              )
            ] })
          ] }),
          /* @__PURE__ */ jsxs3(
            "button",
            {
              type: "button",
              className: cn(
                "flex w-full items-center gap-2 rounded-lg px-2 py-1.5 text-left text-xs font-medium",
                isDark ? "text-slate-400 hover:bg-slate-800" : "text-slate-500 hover:bg-slate-50"
              ),
              onClick: () => setShowAdvanced((v) => !v),
              children: [
                showAdvanced ? /* @__PURE__ */ jsx6(Icons3.ChevronDown, { className: "h-3.5 w-3.5" }) : /* @__PURE__ */ jsx6(Icons3.ChevronRight, { className: "h-3.5 w-3.5" }),
                tr.advanced
              ]
            }
          ),
          showAdvanced && /* @__PURE__ */ jsxs3("div", { className: "grid grid-cols-1 gap-3 sm:grid-cols-2", children: [
            /* @__PURE__ */ jsxs3("label", { className: "block", children: [
              /* @__PURE__ */ jsx6("span", { className: labelClass, children: tr.remoteRoot }),
              /* @__PURE__ */ jsx6(
                "input",
                {
                  className: fieldClass,
                  autoComplete: "off",
                  value: form.remote_root,
                  onChange: (e) => setForm({ ...form, remote_root: e.target.value })
                }
              )
            ] }),
            /* @__PURE__ */ jsxs3("label", { className: "block", children: [
              /* @__PURE__ */ jsx6("span", { className: labelClass, children: tr.timeout }),
              /* @__PURE__ */ jsx6(
                "input",
                {
                  className: fieldClass,
                  autoComplete: "off",
                  inputMode: "numeric",
                  value: form.timeout,
                  onChange: (e) => setForm({ ...form, timeout: e.target.value })
                }
              )
            ] }),
            form.protocol !== "sftp" && /* @__PURE__ */ jsxs3("label", { className: "flex items-center gap-2 text-sm sm:col-span-2", children: [
              /* @__PURE__ */ jsx6(
                "input",
                {
                  type: "checkbox",
                  checked: form.passive,
                  onChange: (e) => setForm({ ...form, passive: e.target.checked })
                }
              ),
              tr.passive
            ] })
          ] }),
          /* @__PURE__ */ jsxs3("div", { className: "flex flex-wrap justify-end gap-2 border-t pt-3", style: { borderColor: isDark ? "#1e293b" : "#e2e8f0" }, children: [
            /* @__PURE__ */ jsx6("button", { type: "button", className: btnGhost, onClick: () => setEditorOpen(false), children: tr.cancel }),
            /* @__PURE__ */ jsx6("button", { type: "button", className: btnGhost, disabled: busy || !form.host.trim() || !form.username.trim(), onClick: () => testConnection(), children: busy ? tr.testing : tr.test }),
            /* @__PURE__ */ jsx6(
              "button",
              {
                type: "button",
                className: btnPrimary,
                disabled: busy || !form.label.trim() || !form.host.trim() || !form.username.trim(),
                onClick: saveConnection,
                children: busy ? tr.saving : tr.save
              }
            )
          ] })
        ] })
      }
    ),
    /* @__PURE__ */ jsx6(
      WindowModal,
      {
        open: transferOpen,
        onClose: () => setTransferOpen(false),
        title: transferDir === "download" ? tr.download : tr.upload,
        maxWidth: "md",
        children: /* @__PURE__ */ jsxs3("div", { className: "space-y-3 p-1", children: [
          /* @__PURE__ */ jsxs3("label", { className: "block", children: [
            /* @__PURE__ */ jsx6("span", { className: labelClass, children: tr.remotePath }),
            /* @__PURE__ */ jsx6("input", { className: fieldClass, value: selectedItem?.path || remotePath, readOnly: true })
          ] }),
          /* @__PURE__ */ jsxs3("label", { className: "block", children: [
            /* @__PURE__ */ jsx6("span", { className: labelClass, children: tr.localPath }),
            /* @__PURE__ */ jsx6(
              "input",
              {
                className: fieldClass,
                autoComplete: "off",
                value: localPath,
                onChange: (e) => setLocalPath(e.target.value)
              }
            )
          ] }),
          /* @__PURE__ */ jsxs3("label", { className: "flex items-center gap-2 text-sm", children: [
            /* @__PURE__ */ jsx6("input", { type: "checkbox", checked: overwrite, onChange: (e) => setOverwrite(e.target.checked) }),
            tr.overwrite
          ] }),
          /* @__PURE__ */ jsxs3("div", { className: "flex justify-end gap-2 pt-2", children: [
            /* @__PURE__ */ jsx6("button", { type: "button", className: btnGhost, onClick: () => setTransferOpen(false), children: tr.cancel }),
            /* @__PURE__ */ jsxs3("button", { type: "button", className: btnPrimary, disabled: busy || !localPath.trim(), onClick: startTransfer, children: [
              /* @__PURE__ */ jsx6(Icons3.Play, { className: "h-4 w-4" }),
              tr.transferJob
            ] })
          ] })
        ] })
      }
    ),
    /* @__PURE__ */ jsx6(
      WindowModal,
      {
        open: confirmOpen,
        onClose: () => setConfirmOpen(false),
        title: confirmKind === "connection" ? tr.delete : tr.deleteItem,
        maxWidth: "sm",
        children: /* @__PURE__ */ jsxs3("div", { className: "space-y-4 p-1", children: [
          /* @__PURE__ */ jsx6("p", { className: cn("text-sm", isDark ? "text-slate-300" : "text-slate-600"), children: confirmKind === "connection" ? tr.confirmDelete : tr.confirmDeleteItem }),
          /* @__PURE__ */ jsxs3("div", { className: "flex justify-end gap-2", children: [
            /* @__PURE__ */ jsx6("button", { type: "button", className: btnGhost, onClick: () => setConfirmOpen(false), children: tr.cancel }),
            /* @__PURE__ */ jsx6(
              "button",
              {
                type: "button",
                className: cn(btnPrimary, "!bg-red-600 hover:!bg-red-500"),
                disabled: busy,
                onClick: () => confirmKind === "connection" ? doDeleteConnection() : doDeleteItem(),
                children: tr.delete
              }
            )
          ] })
        ] })
      }
    )
  ] });
}
export {
  FtpManager as default
};
