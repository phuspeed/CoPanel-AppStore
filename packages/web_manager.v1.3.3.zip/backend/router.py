"""
Web Manager Module Router
Nginx + Apache vhosts, stack bootstrap (LEMP/LAMP), PHP-FPM and DB service overview.
"""
import asyncio
import os
import shutil
import subprocess
import urllib.request
from typing import List, Dict, Any, Optional, Literal

from core.jobs import jobs

from fastapi import APIRouter, Depends, HTTPException
from core.auth import require_module
from core.paths import config_dir, write_private_text
from core.validators import (
    escape_mysql_literal,
    validate_db_username,
    validate_doc_root,
    validate_domain,
)
from pydantic import BaseModel, Field

from . import logic

router = APIRouter(dependencies=[Depends(require_module("web_manager"))])

IS_WINDOWS = logic.IS_WINDOWS
ensure_nginx_dirs = logic.ensure_nginx_dirs
parse_nginx_config = logic.parse_nginx_config
parse_apache_vhost = logic.parse_apache_vhost
sanitize_filename = logic.sanitize_filename
run_with_optional_sudo = logic.run_with_optional_sudo
detect_php_fpm_socket = logic.detect_php_fpm_socket
ensure_php_fpm_socket = logic.ensure_php_fpm_socket
repair_nginx_php_socket = logic.repair_nginx_php_socket
detect_apache_layout = logic.detect_apache_layout
list_apache_site_files = logic.list_apache_site_files
read_apache_site = logic.read_apache_site
is_apache_vhost_enabled = logic.is_apache_vhost_enabled
nginx_reload_test = logic.nginx_reload_test
apache_reload_test = logic.apache_reload_test
pkg_manager = logic.pkg_manager
is_nginx_proxy_config = logic.is_nginx_proxy_config
detect_site_auth = logic.detect_site_auth
strip_site_auth = logic.strip_site_auth
inject_site_auth = logic.inject_site_auth
write_site_htpasswd = logic.write_site_htpasswd
save_site_auth_meta = logic.save_site_auth_meta
read_site_auth_meta = logic.read_site_auth_meta
delete_site_auth_files = logic.delete_site_auth_files


def _nginx_paths():
    return ensure_nginx_dirs()


def _pkg_manager() -> Optional[str]:
    return pkg_manager()


def _pkg_installed(pkg_name: str) -> bool:
    pm = _pkg_manager()
    if not pm:
        return False
    try:
        if pm == "apt-get":
            res = subprocess.run(["dpkg-query", "-W", "-f=${Status}", pkg_name], capture_output=True, text=True)
            return "install ok installed" in (res.stdout or "")
        res = subprocess.run(["rpm", "-q", pkg_name], capture_output=True, text=True)
        return res.returncode == 0
    except Exception:
        return False

# Schemas
class CreateSiteRequest(BaseModel):
    filename: Optional[str] = None
    domain: str
    root: str
    port: Optional[int] = 80
    proxy_port: Optional[int] = None
    php_version: Optional[str] = None
    php_modules: Optional[List[str]] = None
    engine: Literal["nginx", "apache"] = "nginx"
    issue_ssl: bool = False
    ssl_email: Optional[str] = None

class ToggleSiteRequest(BaseModel):
    filename: str
    active: bool
    engine: Literal["nginx", "apache"] = "nginx"

class DeleteSiteRequest(BaseModel):
    filename: str
    engine: Literal["nginx", "apache"] = "nginx"

class SiteAuthRequest(BaseModel):
    enabled: bool = False
    username: Optional[str] = None
    password: Optional[str] = None

class UpdateSiteRequest(BaseModel):
    filename: str
    content: str
    engine: Literal["nginx", "apache"] = "nginx"
    auth: Optional[SiteAuthRequest] = None


class StackBootstrapRequest(BaseModel):
    preset: Literal["lemp", "lamp", "nginx_only", "apache_only", "php_mysql"] = Field(
        ..., description="lemp=nginx+php-fpm+mysql; lamp=apache+php+mysql; php_mysql=PHP-FPM variants + DB client libs"
    )
    php_version: Optional[str] = "8.2"



@router.get("/list")
async def list_sites() -> Dict[str, Any]:
    """List Nginx and Apache vhosts (unified list with engine field)."""
    try:
        sites: List[Dict[str, Any]] = []
        np = _nginx_paths()
        for filename in logic.list_nginx_site_filenames(np):
            file_path = logic.nginx_available_file(np, filename)
            if not os.path.isfile(file_path):
                continue
            with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
                content = f.read()
            parsed = parse_nginx_config(content)
            auth = detect_site_auth(content)
            meta = read_site_auth_meta(filename)
            is_active = logic.nginx_site_is_enabled(np, filename)
            sites.append(
                {
                    "filename": filename,
                    "domain": parsed["domain"],
                    "root": parsed["root"],
                    "active": is_active,
                    "content": content,
                    "engine": "nginx",
                    "is_proxy": is_nginx_proxy_config(content),
                    "auth_enabled": bool(auth.get("enabled")),
                    "auth_username": meta.get("username"),
                }
            )

        layout = detect_apache_layout()
        if layout:
            for filename in list_apache_site_files(layout):
                try:
                    _, content = read_apache_site(layout, filename)
                except Exception:
                    continue
                parsed = parse_apache_vhost(content)
                sites.append(
                    {
                        "filename": filename,
                        "domain": parsed["domain"],
                        "root": parsed["root"],
                        "active": is_apache_vhost_enabled(layout, filename),
                        "content": content,
                        "engine": "apache",
                    }
                )

        return {"status": "success", "sites": sites}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


def _apache_vhost_template(
    port: int,
    server_name_str: str,
    docroot: str,
    php_version: Optional[str],
    proxy_port: Optional[int],
    php_socket: Optional[str],
) -> str:
    parts = server_name_str.split()
    primary = parts[0] if parts else server_name_str
    aliases = parts[1:] if len(parts) > 1 else []
    alias_line = f"    ServerAlias {' '.join(aliases)}\n" if aliases else ""

    if proxy_port:
        return f"""<VirtualHost *:{port}>
    ServerName {primary}
{alias_line}    ProxyPreserveHost On
    ProxyPass / http://127.0.0.1:{proxy_port}/
    ProxyPassReverse / http://127.0.0.1:{proxy_port}/
</VirtualHost>
"""
    if php_version and php_socket:
        return f"""<VirtualHost *:{port}>
    ServerName {primary}
{alias_line}    DocumentRoot {docroot}
    <Directory {docroot}>
        AllowOverride All
        Require all granted
    </Directory>
    <FilesMatch \\.php$>
        SetHandler "proxy:unix:{php_socket}|fcgi://localhost"
    </FilesMatch>
</VirtualHost>
"""
    return f"""<VirtualHost *:{port}>
    ServerName {primary}
{alias_line}    DocumentRoot {docroot}
    <Directory {docroot}>
        AllowOverride All
        Require all granted
    </Directory>
</VirtualHost>
"""


def _restricted_doc_root(doc_root: str, user: Dict[str, Any]) -> str:
    """Non-superadmin: the document root must be inside the user's permitted folders."""
    if user.get("role") == "superadmin":
        return doc_root
    from modules.file_manager.router import check_safe_path

    return check_safe_path(doc_root, user)


@router.post("/create")
def create_site(
    req: CreateSiteRequest,
    user: Dict[str, Any] = Depends(require_module("web_manager")),
) -> Dict[str, Any]:
    """Create a new Nginx or Apache vhost from a basic template."""
    try:
        try:
            domain = validate_domain(req.domain)
            doc_root = validate_doc_root(req.root)
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        doc_root = _restricted_doc_root(doc_root, user)

        if req.issue_ssl:
            email = (req.ssl_email or "").strip()
            if not email or "@" not in email:
                raise HTTPException(
                    status_code=422,
                    detail="ssl_email is required when issue_ssl is true.",
                )
            if req.engine != "nginx":
                raise HTTPException(
                    status_code=400,
                    detail="Automatic Let's Encrypt SSL is only supported for Nginx sites.",
                )

        fname = req.filename
        if not fname or fname.strip() == "":
            fname = f"{domain}.conf"

        safe_filename = sanitize_filename(fname)

        server_name_str = domain
        if not domain.startswith("www.") and "." in domain and not domain.replace(".", "").isdigit():
            server_name_str += f" www.{domain}"

        try:
            if user.get("role") != "superadmin":
                # Restricted user: create without following symlinks; new
                # folders get the home owner via fd-based chown.
                try:
                    from core import safe_fs
                    from core.user_home import owner_for
                except ImportError:
                    raise HTTPException(status_code=503, detail="Update CoPanel to 1.1.15 or newer.")
                try:
                    safe_fs.makedirs(doc_root, owner_for(doc_root, user))
                except safe_fs.SymlinkRefused:
                    raise HTTPException(status_code=403, detail="Document root path contains a symbolic link.")
            else:
                os.makedirs(doc_root, exist_ok=True)
        except HTTPException:
            raise
        except Exception:
            pass

        if req.engine == "apache":
            layout = detect_apache_layout()
            if not layout:
                raise HTTPException(status_code=400, detail="Apache layout not detected on this system.")

            if layout.style == "debian" and layout.sites_available and layout.sites_enabled:
                file_path = os.path.join(layout.sites_available, safe_filename)
                enabled_path = os.path.join(layout.sites_enabled, safe_filename)
            elif layout.style == "rhel" and layout.conf_d:
                rhel_name = safe_filename if safe_filename.endswith(".conf") else f"{safe_filename}.conf"
                file_path = os.path.join(layout.conf_d, rhel_name)
                enabled_path = file_path
            else:
                raise HTTPException(status_code=400, detail="Unsupported Apache layout.")

            if os.path.exists(file_path):
                raise HTTPException(status_code=400, detail="Apache vhost file already exists.")

            php_sock = None
            if req.php_version:
                try:
                    php_sock = ensure_php_fpm_socket(req.php_version)
                except RuntimeError as exc:
                    raise HTTPException(status_code=400, detail=str(exc))

            template = _apache_vhost_template(
                req.port or 80,
                server_name_str,
                doc_root,
                req.php_version,
                req.proxy_port,
                php_sock,
            )

            with open(file_path, "w", encoding="utf-8") as f:
                f.write(template)

            if not IS_WINDOWS and layout.style == "debian":
                try:
                    if req.proxy_port:
                        subprocess.run(["sudo", "a2enmod", "proxy", "proxy_http", "headers"], capture_output=True, text=True)
                    elif req.php_version:
                        subprocess.run(["sudo", "a2enmod", "proxy", "proxy_fcgi", "setenvif"], capture_output=True, text=True)
                except Exception:
                    pass

            if layout.style == "debian" and layout.sites_enabled:
                if not os.path.exists(enabled_path):
                    try:
                        if IS_WINDOWS:
                            shutil.copy2(file_path, enabled_path)
                        else:
                            subprocess.run(["sudo", "a2ensite", safe_filename], check=True, capture_output=True, text=True)
                    except subprocess.CalledProcessError:
                        if os.path.exists(file_path):
                            os.remove(file_path)
                        raise HTTPException(status_code=400, detail="a2ensite failed; check site name and apache config.")

            if not IS_WINDOWS:
                try:
                    apache_reload_test(layout)
                except subprocess.CalledProcessError as e:
                    if layout.style == "debian":
                        try:
                            subprocess.run(["sudo", "a2dissite", safe_filename], capture_output=True, text=True)
                        except Exception:
                            pass
                    if os.path.exists(file_path):
                        try:
                            os.remove(file_path)
                        except Exception:
                            pass
                    raise HTTPException(
                        status_code=400,
                        detail=f"Apache configuration invalid: {e.stderr or e.stdout}",
                    )

            return {"status": "success", "message": "Apache vhost created and activated successfully.", "engine": "apache"}

        # ---- Nginx ----
        np = _nginx_paths()
        file_path = logic.nginx_available_file(np, safe_filename)
        enabled_path = logic.nginx_enabled_file(np, safe_filename)
        disabled_path = file_path + ".disabled"

        if os.path.exists(file_path) or os.path.exists(disabled_path):
            raise HTTPException(status_code=400, detail="Site configuration file already exists.")

        php_version = (req.php_version or "").strip() or None
        if php_version:
            try:
                php_version = logic.resolve_php_version(php_version)
            except RuntimeError as exc:
                raise HTTPException(status_code=400, detail=str(exc)) from exc
            if req.php_modules and not IS_WINDOWS:
                try:
                    logic.install_php_extensions(php_version, list(req.php_modules))
                except Exception as exc:
                    raise HTTPException(status_code=400, detail=str(exc)) from exc

        if req.proxy_port:
            template = f"""server {{
    listen {req.port};
    server_name {server_name_str};
    client_max_body_size 500M;

    location / {{
        proxy_pass http://127.0.0.1:{req.proxy_port};
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;

        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";

        proxy_connect_timeout 60s;
        proxy_send_timeout 600s;
        proxy_read_timeout 600s;
    }}
}}
"""
        elif php_version:
            try:
                sock = ensure_php_fpm_socket(php_version)
            except RuntimeError as exc:
                raise HTTPException(status_code=400, detail=str(exc))
            template = f"""server {{
    listen {req.port};
    server_name {server_name_str};
    root {doc_root};
    client_max_body_size 500M;

    index index.php index.html index.htm;

    location / {{
        try_files $uri $uri/ /index.php?$query_string;
    }}

    location ~ \\.php$ {{
        include fastcgi_params;
        fastcgi_pass unix:{sock};
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
        fastcgi_read_timeout 300;
    }}

    location ~ /\\.ht {{
        deny all;
    }}
}}
"""
        else:
            template = f"""server {{
    listen {req.port};
    server_name {server_name_str};
    root {doc_root};
    client_max_body_size 500M;

    index index.html index.htm;

    location / {{
        try_files $uri $uri/ =404;
    }}
}}
"""

        with open(file_path, "w", encoding="utf-8") as f:
            f.write(template)

        if np.style != "rhel":
            logic.enable_nginx_site(np, safe_filename)

        if not IS_WINDOWS:
            try:
                nginx_reload_test()
            except subprocess.CalledProcessError as e:
                logic.remove_nginx_site(np, safe_filename)
                raise HTTPException(
                    status_code=400,
                    detail=f"Nginx configuration invalid: {e.stderr}",
                )

        result: Dict[str, Any] = {
            "status": "success",
            "message": "Nginx site created and activated successfully.",
            "engine": "nginx",
        }

        # Optional Let's Encrypt SSL via Certbot (HTTP vhost must exist first).
        if req.issue_ssl:
            email = (req.ssl_email or "").strip()
            ssl_domain = domain
            try:
                from modules.ssl_manager.logic import SSLManager

                ssl_res = SSLManager.issue_certbot(ssl_domain, email)
            except Exception as ssl_exc:
                ssl_res = {"status": "error", "message": str(ssl_exc)}

            if ssl_res.get("status") == "success":
                result["ssl"] = {
                    "type": "letsencrypt",
                    "domain": ssl_domain,
                    "email": email,
                    "status": "active",
                }
                result["message"] = (
                    "Nginx site created and Let's Encrypt SSL issued successfully."
                )
            else:
                warning = ssl_res.get("message") or "SSL issuance failed"
                result["ssl"] = {
                    "type": "letsencrypt",
                    "domain": ssl_domain,
                    "email": email,
                    "status": "failed",
                    "error": warning,
                }
                result["message"] = (
                    "Nginx site created, but SSL issuance failed. "
                    f"You can retry from SSL Manager. Detail: {warning}"
                )
                result["warning"] = warning

        return result

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/toggle")
async def toggle_site(req: ToggleSiteRequest) -> Dict[str, Any]:
    """Enable or disable a Nginx site (symlink) or Apache vhost (a2ensite / rename)."""
    try:
        safe_filename = sanitize_filename(req.filename)

        if req.engine == "apache":
            layout = detect_apache_layout()
            if not layout:
                raise HTTPException(status_code=404, detail="Apache not available.")
            try:
                read_apache_site(layout, safe_filename)
            except Exception:
                raise HTTPException(status_code=404, detail="Apache vhost not found.")

            if layout.style == "debian":
                try:
                    if req.active:
                        subprocess.run(["sudo", "a2ensite", safe_filename], check=True, capture_output=True, text=True)
                    else:
                        subprocess.run(["sudo", "a2dissite", safe_filename], check=True, capture_output=True, text=True)
                except subprocess.CalledProcessError as e:
                    raise HTTPException(status_code=400, detail=(e.stderr or e.stdout or "a2en/a2dis failed.").strip())
            elif layout.style == "rhel" and layout.conf_d:
                base = os.path.join(layout.conf_d, safe_filename if safe_filename.endswith(".conf") else f"{safe_filename}.conf")
                off = base + ".off"
                try:
                    if req.active:
                        if os.path.isfile(off):
                            os.rename(off, base)
                        elif not os.path.isfile(base):
                            raise HTTPException(status_code=404, detail="Vhost conf missing.")
                    else:
                        if os.path.isfile(base):
                            os.rename(base, off)
                except HTTPException:
                    raise
                except Exception as e:
                    raise HTTPException(status_code=400, detail=str(e))

            if not IS_WINDOWS:
                try:
                    apache_reload_test(layout)
                except subprocess.CalledProcessError as e:
                    raise HTTPException(
                        status_code=400,
                        detail=f"Apache configuration invalid: {e.stderr or e.stdout}",
                    )
            return {"status": "success", "message": f"Apache site {'enabled' if req.active else 'disabled'} successfully."}

        np = _nginx_paths()
        available_path = logic.nginx_available_file(np, safe_filename)
        disabled_path = available_path + ".disabled"
        if not os.path.exists(available_path) and not (np.style == "rhel" and os.path.exists(disabled_path)):
            raise HTTPException(status_code=404, detail="Site configuration not found.")

        if req.active:
            logic.enable_nginx_site(np, safe_filename)
        else:
            logic.disable_nginx_site(np, safe_filename)

        if not IS_WINDOWS:
            try:
                nginx_reload_test()
            except subprocess.CalledProcessError as e:
                if req.active:
                    logic.disable_nginx_site(np, safe_filename)
                else:
                    logic.enable_nginx_site(np, safe_filename)
                raise HTTPException(
                    status_code=400,
                    detail=f"Nginx configuration invalid: {e.stderr}",
                )

        return {"status": "success", "message": f"Site {'enabled' if req.active else 'disabled'} successfully."}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/delete")
async def delete_site(req: DeleteSiteRequest) -> Dict[str, Any]:
    """Delete Nginx or Apache vhost configuration."""
    try:
        safe_filename = sanitize_filename(req.filename)

        if req.engine == "apache":
            layout = detect_apache_layout()
            if not layout:
                raise HTTPException(status_code=404, detail="Apache not available.")
            if layout.style == "debian" and layout.sites_available and layout.sites_enabled:
                enabled_path = os.path.join(layout.sites_enabled, safe_filename)
                available_path = os.path.join(layout.sites_available, safe_filename)
                if os.path.exists(enabled_path):
                    if os.path.islink(enabled_path):
                        os.unlink(enabled_path)
                    else:
                        os.remove(enabled_path)
                try:
                    subprocess.run(["sudo", "a2dissite", safe_filename], capture_output=True, text=True)
                except Exception:
                    pass
                if os.path.exists(available_path):
                    os.remove(available_path)
            elif layout.style == "rhel" and layout.conf_d:
                base = os.path.join(
                    layout.conf_d,
                    safe_filename if safe_filename.endswith(".conf") else f"{safe_filename}.conf",
                )
                for path in (base, base + ".off"):
                    if os.path.isfile(path):
                        os.remove(path)
            if not IS_WINDOWS:
                try:
                    apache_reload_test(layout)
                except Exception:
                    pass
            return {"status": "success", "message": "Apache vhost removed."}

        np = _nginx_paths()
        logic.remove_nginx_site(np, safe_filename)
        delete_site_auth_files(safe_filename)

        if not IS_WINDOWS:
            try:
                from core import sysexec

                sysexec.run(["nginx", "-t"], timeout=30)
                sysexec.run(["systemctl", "reload", "nginx"], timeout=30, as_root=True)
            except Exception:
                pass

        return {"status": "success", "message": "Nginx site removed completely."}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/update")
async def update_site(req: UpdateSiteRequest) -> Dict[str, Any]:
    """Update Nginx or Apache vhost content, test syntax, and reload."""
    try:
        safe_filename = sanitize_filename(req.filename)

        if req.engine == "apache":
            layout = detect_apache_layout()
            if not layout:
                raise HTTPException(status_code=404, detail="Apache not available.")
            try:
                available_path, backup_content = read_apache_site(layout, safe_filename)
            except Exception:
                raise HTTPException(status_code=404, detail="Apache vhost not found.")

            with open(available_path, "w", encoding="utf-8") as f:
                f.write(req.content)

            if not IS_WINDOWS:
                try:
                    apache_reload_test(layout)
                except subprocess.CalledProcessError as e:
                    with open(available_path, "w", encoding="utf-8") as f:
                        f.write(backup_content)
                    raise HTTPException(
                        status_code=400,
                        detail=f"Apache configuration syntax error:\n{e.stderr or e.stdout}",
                    )
            return {"status": "success", "message": "Apache configuration saved and reloaded successfully."}

        np = _nginx_paths()
        available_path = logic.nginx_available_file(np, safe_filename)

        if not os.path.exists(available_path):
            raise HTTPException(status_code=404, detail="Site configuration not found.")

        with open(available_path, "r", encoding="utf-8", errors="ignore") as f:
            backup_content = f.read()

        final_content = req.content
        auth_meta_backup = read_site_auth_meta(safe_filename)
        auth_file_backup: Optional[str] = None
        auth_htpasswd_path = logic.site_htpasswd_path(safe_filename)
        if auth_htpasswd_path.is_file():
            auth_file_backup = auth_htpasswd_path.read_text(encoding="utf-8")

        if req.auth is not None:
            if not is_nginx_proxy_config(req.content):
                raise HTTPException(status_code=400, detail="HTTP Basic Auth only supports Nginx reverse proxy sites.")

            final_content = strip_site_auth(req.content)
            if req.auth.enabled:
                username = (req.auth.username or auth_meta_backup.get("username") or "").strip()
                if not username:
                    raise HTTPException(status_code=400, detail="Auth username is required.")

                password = (req.auth.password or "").strip()
                if password:
                    htpasswd_path = write_site_htpasswd(safe_filename, username, password)
                elif auth_htpasswd_path.is_file():
                    htpasswd_path = str(auth_htpasswd_path).replace("\\", "/")
                else:
                    raise HTTPException(status_code=400, detail="Auth password is required when enabling for the first time.")

                save_site_auth_meta(safe_filename, username, enabled=True)
                final_content = inject_site_auth(final_content, htpasswd_path)
            else:
                delete_site_auth_files(safe_filename)
        else:
            final_content = req.content

        with open(available_path, "w", encoding="utf-8") as f:
            f.write(final_content)

        if not IS_WINDOWS:
            try:
                nginx_reload_test()
            except subprocess.CalledProcessError as e:
                with open(available_path, "w", encoding="utf-8") as f:
                    f.write(backup_content)
                if auth_file_backup is not None:
                    auth_htpasswd_path.parent.mkdir(parents=True, exist_ok=True)
                    auth_htpasswd_path.write_text(auth_file_backup, encoding="utf-8")
                else:
                    delete_site_auth_files(safe_filename)
                if auth_meta_backup.get("enabled") and auth_meta_backup.get("username"):
                    save_site_auth_meta(
                        safe_filename,
                        str(auth_meta_backup.get("username")),
                        enabled=True,
                    )
                raise HTTPException(
                    status_code=400,
                    detail=f"Nginx configuration syntax error:\n{e.stderr or e.stdout}",
                )

        return {"status": "success", "message": "Configuration saved and reloaded successfully."}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/web_services")
async def list_web_services() -> Dict[str, Any]:
    """Retrieve status of main web server services with conflict info."""

    # Conflict rules: if a service is installed/running, it conflicts with others on port 80
    CONFLICT_MAP = {
        "nginx": ["apache2", "litespeed"],
        "apache2": ["nginx", "litespeed"],
        "litespeed": ["nginx", "apache2"],
    }

    services = [
        {"id": "nginx",     "name": "Nginx",           "description": "High-performance HTTP & reverse proxy server.", "installed": False, "status": "not_installed", "conflicts_with": []},
        {"id": "apache2",   "name": "Apache2",          "description": "Battle-tested web server with .htaccess support.", "installed": False, "status": "not_installed", "conflicts_with": []},
        {"id": "litespeed", "name": "OpenLiteSpeed",    "description": "Low-RAM alternative with LSPHP & LSCache support.", "installed": False, "status": "not_installed", "conflicts_with": []},
    ]

    if IS_WINDOWS:
        services[0].update({"installed": True, "status": "running"})
        # Populate conflicts based on installed state
        for s in services:
            if s["installed"]:
                s["conflicts_with"] = CONFLICT_MAP.get(s["id"], [])
        return {"status": "success", "services": services}

    # Query systemctl on Linux
    installed_ids = set()
    for s in services:
        sid = s["id"]
        if sid == "apache2":
            service_installed = logic.is_apache_installed()
        else:
            bin_exists = shutil.which(sid) or shutil.which("openlitespeed" if sid == "litespeed" else sid)
            service_installed = bool(bin_exists or os.path.exists(f"/etc/{sid}"))
        if service_installed:
            s["installed"] = True
            installed_ids.add(sid)
            try:
                active = False
                for unit in (sid, "httpd") if sid == "apache2" else (sid,):
                    res = subprocess.run(["systemctl", "is-active", unit], capture_output=True, text=True)
                    if res.stdout.strip() == "active":
                        active = True
                        break
                s["status"] = "running" if active else "stopped"
            except Exception:
                s["status"] = "stopped"

    # Populate conflicts: only list conflicts that are actually installed
    for s in services:
        s["conflicts_with"] = [c for c in CONFLICT_MAP.get(s["id"], []) if c in installed_ids]

    return {"status": "success", "services": services}


@router.get("/stack")
async def stack_overview() -> Dict[str, Any]:
    """Unified LEMP/LAMP-style overview: web servers, PHP-FPM, SQL services."""
    ws = await list_web_services()
    return {
        "status": "success",
        "web_servers": ws.get("services", []),
        "php_fpm": logic.list_php_fpm_versions(),
        "database_services": logic.database_service_rows(),
        "apache_detected": logic.is_apache_installed(),
    }


def _install_web_stack_sync(stack: str) -> Dict[str, Any]:
    """Install nginx, Apache, or OpenLiteSpeed off the event loop."""
    from core import sysexec

    if IS_WINDOWS:
        return {"status": "success", "message": f"Stack '{stack}' install simulated (Windows mock)."}
    family = logic.php_package_family()
    if not family:
        raise RuntimeError("No supported package manager found.")
    packages: List[str] = []
    if stack == "nginx":
        packages = ["nginx"]
    elif stack == "apache2":
        packages = ["apache2"] if family == "apt" else ["httpd"]
    elif stack == "nginx_apache":
        packages = ["nginx", "apache2" if family == "apt" else "httpd"]
        apache_conf = "/etc/apache2/ports.conf" if family == "apt" else "/etc/httpd/conf/httpd.conf"
        if os.path.exists(apache_conf):
            try:
                with open(apache_conf, "r", encoding="utf-8", errors="ignore") as handle:
                    content = handle.read()
                content = content.replace("Listen 80", "Listen 8080")
                with open(apache_conf, "w", encoding="utf-8") as handle:
                    handle.write(content)
            except OSError:
                pass
    elif stack == "litespeed":
        packages = ["wget"]
    else:
        raise RuntimeError(f"Unknown stack '{stack}'.")
    if packages:
        logic._require_pkg_install(packages)
    if stack == "litespeed":
        installer = "apt-get install -y openlitespeed" if family == "apt" else "yum install -y openlitespeed"
        result = sysexec.run(
            ["bash", "-c", f"wget -O - https://repo.litespeed.sh | bash && {installer}"],
            timeout=900,
            as_root=True,
        )
        if result.returncode != 0:
            raise RuntimeError(f"OpenLiteSpeed install failed. {sysexec.combined_output(result)}")
    if stack in {"nginx", "nginx_apache"}:
        sysexec.service_enable_now("nginx")
    return {"status": "success", "message": f"Stack '{stack}' installed successfully."}


@router.post("/stack/bootstrap")
def stack_bootstrap(req: StackBootstrapRequest) -> Dict[str, Any]:
    """Install a LEMP/LAMP preset as a background job so the panel stays responsive."""
    if IS_WINDOWS:
        return {"status": "success", "message": f"Bootstrap '{req.preset}' simulated (Windows)."}

    async def _handler(job, preset: str, php_version: Optional[str]):
        job.update(progress=10, message=f"Installing {preset}")
        job.log(f"Stack bootstrap {preset} (PHP {php_version or 'auto'})")
        result = await asyncio.to_thread(logic.bootstrap_stack_sync, preset, php_version, job.log)
        job.update(progress=100, message=result.get("message") or "Stack installed")
        return result

    job = jobs.submit(
        kind="web_manager.stack_bootstrap",
        title=f"Install {req.preset} stack",
        module="web_manager",
        payload={"preset": req.preset, "php_version": req.php_version},
        handler=_handler,
        args=(req.preset, req.php_version),
    )
    return {
        "status": "accepted",
        "job_id": job.id,
        "message": f"Stack bootstrap '{req.preset}' started.",
    }


@router.post("/web_services/install_stack")
def install_web_stack(req: dict) -> Dict[str, Any]:
    """Install a web server stack in a background job."""
    stack = req.get("stack", "nginx")  # nginx | apache2 | litespeed | nginx_apache
    if IS_WINDOWS:
        return {"status": "success", "message": f"Stack '{stack}' install simulated (Windows mock)."}

    async def _handler(job, stack_name: str):
        job.update(progress=10, message=f"Installing {stack_name}")
        result = await asyncio.to_thread(_install_web_stack_sync, stack_name)
        job.update(progress=100, message=result.get("message") or "Installed")
        return result

    job = jobs.submit(
        kind="web_manager.install_stack",
        title=f"Install {stack}",
        module="web_manager",
        payload={"stack": stack},
        handler=_handler,
        args=(stack,),
    )
    return {
        "status": "accepted",
        "job_id": job.id,
        "message": f"Stack '{stack}' install started.",
    }

@router.post("/web_services/{service_id}/{action}")
async def control_web_service(service_id: str, action: str) -> Dict[str, Any]:
    """Control starting, stopping, restarting, or removing web server services."""
    if IS_WINDOWS:
        return {"status": "success", "message": f"Service {service_id} action '{action}' performed successfully (Mock mode)."}

    if action == "install":
        # Run package installation using apt/yum
        pkg_manager = "apt-get" if shutil.which("apt-get") else ("yum" if shutil.which("yum") else None)
        if pkg_manager == "apt-get":
            subprocess.run(["sudo", "apt-get", "update", "-y"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            subprocess.run(["sudo", "apt-get", "install", "-y", service_id], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        elif pkg_manager == "yum":
            subprocess.run(["sudo", "yum", "install", "-y", service_id], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return {"status": "success", "message": f"{service_id} installed successfully."}

    if action in ["start", "stop", "restart"]:
        unit = service_id
        if service_id == "apache2":
            r_a = subprocess.run(["systemctl", "cat", "apache2"], capture_output=True, text=True)
            r_h = subprocess.run(["systemctl", "cat", "httpd"], capture_output=True, text=True)
            unit = "apache2" if r_a.returncode == 0 else ("httpd" if r_h.returncode == 0 else "apache2")
        try:
            subprocess.run(["sudo", "systemctl", action, unit], check=True, capture_output=True, text=True)
            return {"status": "success", "message": f"Service {unit} {action}ed successfully."}
        except subprocess.CalledProcessError as e:
            raise HTTPException(status_code=400, detail=f"Service control failed: {e.stderr or e.stdout}")

    return {"status": "error", "message": "Unknown action"}



@router.get("/db_admin_tools")
async def get_db_admin_tools() -> Dict[str, Any]:
    """Detect installed database engines and their admin tools."""

    def check_service_running(service: str) -> bool:
        if IS_WINDOWS:
            return False
        try:
            res = subprocess.run(["systemctl", "is-active", service], capture_output=True, text=True)
            return res.stdout.strip() == "active"
        except Exception:
            return False

    def get_db_version(cmd: List[str]) -> str:
        try:
            res = subprocess.run(cmd, capture_output=True, text=True, timeout=5)
            return res.stdout.strip().split("\n")[0] if res.returncode == 0 else ""
        except Exception:
            return ""

    engines = []

    # MySQL / MariaDB
    mysql_installed = bool(shutil.which("mysql") or shutil.which("mariadb") or os.path.exists("/var/lib/mysql"))
    mysql_version = ""
    if mysql_installed and not IS_WINDOWS:
        mysql_version = get_db_version(["mysql", "--version"])
    pma_installed = (
        os.path.exists("/usr/share/phpmyadmin")
        or os.path.exists("/usr/share/phpMyAdmin")
        or os.path.exists("/var/www/html/phpmyadmin")
        or os.path.exists("/var/www/html/phpMyAdmin")
        or _pkg_installed("phpmyadmin")
        or _pkg_installed("phpMyAdmin")
    )
    pma_url = "/phpmyadmin"
    if os.path.exists("/var/www/html/phpmyadmin/index.php") or os.path.exists("/usr/share/phpmyadmin/index.php"):
        pma_url = "/phpmyadmin/index.php"
    engines.append({
        "id": "mysql",
        "name": "MySQL / MariaDB",
        "installed": mysql_installed,
        "version": mysql_version,
        "status": "running" if (mysql_installed and check_service_running("mysql")) or (mysql_installed and check_service_running("mariadb")) else ("stopped" if mysql_installed else "not_installed"),
        "admin_tool": "phpmyadmin",
        "admin_name": "phpMyAdmin",
        "admin_url": pma_url,
        "admin_installed": pma_installed,
    })

    # PostgreSQL
    pg_installed = bool(shutil.which("psql") or os.path.exists("/var/lib/postgresql"))
    pg_version = ""
    if pg_installed and not IS_WINDOWS:
        pg_version = get_db_version(["psql", "--version"])
    pgadmin_installed = os.path.exists("/usr/lib/python3/dist-packages/pgadmin4") or os.path.exists("/etc/pgadmin")
    engines.append({
        "id": "postgresql",
        "name": "PostgreSQL",
        "installed": pg_installed,
        "version": pg_version,
        "status": "running" if (pg_installed and check_service_running("postgresql")) else ("stopped" if pg_installed else "not_installed"),
        "admin_tool": "pgadmin",
        "admin_name": "pgAdmin 4",
        "admin_url": "/pgadmin4",
        "admin_installed": pgadmin_installed,
    })

    # Adminer — universal lightweight fallback
    adminer_paths = ["/usr/share/adminer/adminer.php", "/var/www/html/adminer.php"]
    adminer_installed = any(os.path.exists(p) for p in adminer_paths)
    adminer_installed = adminer_installed or _pkg_installed("adminer")
    adminer_url = "/adminer.php"
    if os.path.exists("/usr/share/adminer/adminer.php"):
        adminer_url = "/adminer.php"
    elif os.path.exists("/var/www/html/adminer.php"):
        adminer_url = "/adminer.php"
    engines.append({
        "id": "adminer",
        "name": "Adminer",
        "installed": True,  # Always available as option
        "version": "latest",
        "status": "available",
        "admin_tool": "adminer",
        "admin_name": "Adminer (Universal)",
        "admin_url": adminer_url,
        "admin_installed": adminer_installed,
    })

    return {"status": "success", "engines": engines}


@router.post("/db_admin_tools/{tool_id}/install")
async def install_db_admin_tool(tool_id: str) -> Dict[str, Any]:
    """Install missing DB engine/admin tool packages."""
    if IS_WINDOWS:
        return {"status": "success", "message": f"{tool_id} install simulated (Windows mock)."}

    pkg = _pkg_manager()
    if not pkg:
        raise HTTPException(status_code=400, detail="No supported package manager found (apt-get/yum).")

    try:
        if tool_id == "mysql":
            if pkg == "apt-get":
                try:
                    run_with_optional_sudo([pkg, "install", "-y", "mariadb-server"])
                except Exception:
                    run_with_optional_sudo([pkg, "install", "-y", "mysql-server"])
            else:
                try:
                    run_with_optional_sudo([pkg, "install", "-y", "mariadb-server"])
                except Exception:
                    run_with_optional_sudo([pkg, "install", "-y", "mysql-server"])
            # Same post-install as Package Manager: PHP-FPM plus the panel nginx snippet.
            from modules.package_manager.phpmyadmin_nginx import install_phpmyadmin

            install_phpmyadmin()
            return {"status": "success", "message": "MySQL/MariaDB and phpMyAdmin installation completed."}

        if tool_id == "postgresql":
            if pkg == "apt-get":
                run_with_optional_sudo([pkg, "install", "-y", "postgresql"])
                run_with_optional_sudo([pkg, "install", "-y", "pgadmin4"])
            else:
                run_with_optional_sudo([pkg, "install", "-y", "postgresql-server"])
                run_with_optional_sudo([pkg, "install", "-y", "pgadmin4"])
            return {"status": "success", "message": "PostgreSQL and pgAdmin installation completed."}

        if tool_id == "adminer":
            return await install_adminer()

        raise HTTPException(status_code=404, detail=f"Unsupported db admin tool: {tool_id}")
    except subprocess.CalledProcessError as e:
        raise HTTPException(status_code=500, detail=(e.stderr or e.stdout or "Installation failed.").strip())


@router.post("/db_admin_tools/adminer/install")
async def install_adminer() -> Dict[str, Any]:
    """Download and configure Adminer as a universal DB admin tool."""
    if IS_WINDOWS:
        return {"status": "success", "message": "Adminer install simulated (Windows mock)."}

    adminer_dir = "/usr/share/adminer"
    adminer_path = f"{adminer_dir}/adminer.php"
    public_adminer_path = "/var/www/html/adminer.php"
    nginx_conf = "/etc/nginx/conf.d/adminer.conf"
    apache_conf = "/etc/apache2/conf-available/adminer.conf"

    try:
        os.makedirs(adminer_dir, exist_ok=True)
        os.makedirs("/var/www/html", exist_ok=True)
        url = "https://github.com/vrana/adminer/releases/download/v4.8.1/adminer-4.8.1.php"
        urllib.request.urlretrieve(url, adminer_path)
        try:
            shutil.copy2(adminer_path, public_adminer_path)
        except Exception:
            pass
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to download Adminer: {e}")

    # Create Nginx config for Adminer
    if shutil.which("nginx"):
        adminer_sock = None
        for v in ("8.3", "8.2", "8.1", "8.0", "7.4"):
            adminer_sock = detect_php_fpm_socket(v)
            if adminer_sock:
                break
        if not adminer_sock:
            adminer_sock = "/run/php/php8.2-fpm.sock"
        nginx_config = f"""server {{
    listen 80;
    server_name _;
    location /adminer {{
        alias {adminer_dir};
        index adminer.php;
        location ~ \\.php$ {{
            include fastcgi_params;
            fastcgi_pass unix:{adminer_sock};
            fastcgi_param SCRIPT_FILENAME $request_filename;
        }}
    }}
}}
"""
        try:
            with open(nginx_conf, "w") as f:
                f.write(nginx_config)
            subprocess.run(["nginx", "-t"], check=True, capture_output=True)
            subprocess.run(["systemctl", "reload", "nginx"], check=False)
        except Exception:
            pass

    # Create Apache config for Adminer
    if shutil.which("apache2ctl") and os.path.exists("/etc/apache2"):
        apache_config = f"""Alias /adminer {adminer_dir}
<Directory {adminer_dir}>
    Options Indexes FollowSymLinks
    AllowOverride None
    Require all granted
</Directory>
"""
        try:
            with open(apache_conf, "w") as f:
                f.write(apache_config)
            subprocess.run(["a2enconf", "adminer"], check=False, capture_output=True)
            subprocess.run(["systemctl", "reload", "apache2"], check=False)
        except Exception:
            pass

    return {"status": "success", "message": "Adminer installed successfully. Try /adminer.php (or /adminer if nginx alias is active)."}


class SavePhpMyAdminCredentialsRequest(BaseModel):
    user: str
    password: str

def _mysql_credentials_path():
    return config_dir() / "mysql_credentials.txt"


def _read_mysql_credentials() -> tuple:
    path = _mysql_credentials_path()
    user, password = "", ""
    if not path.is_file():
        return user, password
    for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
        line = line.strip()
        if line.startswith("MYSQL_USER="):
            user = line.split("=", 1)[1]
        elif line.startswith("MYSQL_PASS="):
            password = line.split("=", 1)[1]
    return user, password


@router.get("/phpmyadmin")
async def get_phpmyadmin_credentials() -> Dict[str, Any]:
    """Return phpMyAdmin login metadata. The password is never sent back."""
    pma_installed = bool(
        shutil.which("mysql") or os.path.exists("/usr/share/phpmyadmin")
    )
    try:
        user, password = _read_mysql_credentials()
    except OSError as exc:
        raise HTTPException(status_code=500, detail="Could not read MySQL credentials.") from exc
    return {
        "installed": pma_installed,
        "user": user,
        "has_password": bool(password),
    }


@router.post("/phpmyadmin/save")
async def save_phpmyadmin_credentials(req: SavePhpMyAdminCredentialsRequest) -> Dict[str, Any]:
    """Save or create phpMyAdmin/MySQL user."""
    try:
        user = validate_db_username(req.user)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    password = req.password or ""
    if not password or "\x00" in password or len(password) > 256:
        raise HTTPException(status_code=400, detail="Password is required.")

    creds_file = _mysql_credentials_path()
    write_private_text(creds_file, f"MYSQL_USER={user}\nMYSQL_PASS={password}\n")

    # On Linux, also try to create/update the MySQL user. SQL goes on stdin
    # so the password is not a shell word and does not show up in argv.
    if os.name != "nt":
        safe_pass = escape_mysql_literal(password)
        sql = (
            f"CREATE USER IF NOT EXISTS '{user}'@'localhost' IDENTIFIED BY '{safe_pass}';"
            f"ALTER USER '{user}'@'localhost' IDENTIFIED BY '{safe_pass}';"
            f"GRANT ALL PRIVILEGES ON *.* TO '{user}'@'localhost' WITH GRANT OPTION;"
            "FLUSH PRIVILEGES;"
        )
        try:
            subprocess.run(
                ["sudo", "mysql", "-u", "root"],
                input=sql,
                capture_output=True,
                text=True,
                timeout=30,
                shell=False,
            )
        except Exception:
            pass

    return {"status": "success", "message": "Credentials updated successfully."}


# --- PHP management (merged from php_manager) ---

class InstallPHPRequest(BaseModel):
    version: str


class SetActivePHPRequest(BaseModel):
    version: str


class PHPModuleToggleRequest(BaseModel):
    version: str
    module: str
    enable: bool


class SavePHPIniRequest(BaseModel):
    content: str


@router.get("/php/versions")
def get_php_versions_endpoint() -> Dict[str, Any]:
    payload = logic.get_php_versions_meta()
    return {"status": "success", **payload}


@router.get("/php/modules")
def get_php_modules_endpoint() -> Dict[str, Any]:
    return {"status": "success", "modules": logic.get_php_modules()}


@router.get("/php/modules/{version}")
def get_php_modules_for_version(version: str) -> Dict[str, Any]:
    return {
        "status": "success",
        "enabled": logic.get_enabled_modules(version),
        "all": logic.get_php_modules(),
    }


@router.post("/php/install")
def install_php(req: InstallPHPRequest) -> Dict[str, Any]:
    res = logic.install_php_version(req.version)
    if res.get("status") == "error":
        raise HTTPException(status_code=400, detail=res["message"])
    return res


@router.delete("/php/uninstall/{version}")
def uninstall_php(version: str) -> Dict[str, Any]:
    res = logic.uninstall_php_version(version)
    if res.get("status") == "error":
        raise HTTPException(status_code=400, detail=res["message"])
    return res


@router.post("/php/set_active")
def set_active_php(req: SetActivePHPRequest) -> Dict[str, Any]:
    res = logic.set_active_php_version(req.version)
    if res.get("status") == "error":
        raise HTTPException(status_code=400, detail=res["message"])
    return res


@router.post("/php/module_toggle")
def toggle_php_module(req: PHPModuleToggleRequest) -> Dict[str, Any]:
    res = logic.toggle_php_module(req.version, req.module, req.enable)
    if res.get("status") == "error":
        raise HTTPException(status_code=400, detail=res["message"])
    return res


@router.get("/php/php_ini/{version}")
def get_php_ini_endpoint(version: str) -> Dict[str, Any]:
    try:
        content = logic.get_php_ini(version)
        return {"status": "success", "content": content}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/php/php_ini/{version}")
def save_php_ini_endpoint(version: str, req: SavePHPIniRequest) -> Dict[str, Any]:
    res = logic.save_php_ini(version, req.content)
    if res.get("status") == "error":
        raise HTTPException(status_code=400, detail=res["message"])
    return res

