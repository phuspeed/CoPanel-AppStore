from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, Field


class ContainerActionRequest(BaseModel):
    container_id: str


class ContainerRenameRequest(BaseModel):
    container_id: str
    new_name: str


class ContainerRestartPolicyRequest(BaseModel):
    container_id: str
    policy: Literal["no", "on-failure", "always", "unless-stopped"] = "unless-stopped"
    maximum_retry_count: int = Field(default=0, ge=0, le=100)


class ImageCheckUpdatesRequest(BaseModel):
    image_refs: Optional[List[str]] = None


class ImageUpdateRequest(BaseModel):
    image_ref: str


class ContainerExecRequest(BaseModel):
    container_id: str
    command: List[str] = Field(default_factory=list)


class ComposePathRequest(BaseModel):
    path: str


class ComposeLogsQuery(BaseModel):
    path: str
    tail: int = 100
    since: Optional[str] = None
    timestamps: bool = False
    follow: bool = False


class ComposeUpRequest(BaseModel):
    path: str
    detach: bool = True


class ComposeBuildRequest(BaseModel):
    path: str
    no_cache: bool = False


class StackInitRequest(BaseModel):
    stack_id: str
    image: str = "nginx:alpine"
    host_port: int = 8080
    container_port: int = 80


class StackComposeUpdateRequest(BaseModel):
    compose_content: str


class ProjectInspectRequest(BaseModel):
    path: str


class ProjectTemplate(BaseModel):
    image: str = "nginx:alpine"
    host_port: int = 8080
    container_port: int = 80


class ProjectCreateRequest(BaseModel):
    project_name: str
    folder_mode: Literal["managed", "custom"] = "managed"
    folder_path: Optional[str] = None
    source: Literal["existing", "template", "paste"]
    compose_content: Optional[str] = None
    template: Optional[ProjectTemplate] = None
    deploy: bool = True
    overwrite_compose: bool = False


class ProjectValidateContentRequest(BaseModel):
    compose_content: str


class ProjectPathRequest(BaseModel):
    path: str


class ProjectComposeUpdateByPathRequest(BaseModel):
    path: str
    compose_content: str


class ProjectEnvUpdateRequest(BaseModel):
    path: str
    content: str


class DockerResponse(BaseModel):
    status: str
    message: Optional[str] = None
    data: Optional[Dict[str, Any]] = None
