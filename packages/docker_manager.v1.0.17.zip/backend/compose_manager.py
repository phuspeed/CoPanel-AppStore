import os
import re
import shutil
import subprocess
import tempfile
import threading
from pathlib import Path
from typing import Any, Dict, List, Optional

from .logic import DockerManagerError


class ComposeManager:
    def __init__(self, managed_root: Optional[str] = None, scan_depth: int = 5, command_timeout: int = 90):
        self.scan_depth = scan_depth
        self.command_timeout = command_timeout
        self.managed_root = Path(managed_root or os.environ.get("COPANEL_MANAGED_STACKS_ROOT", "/opt/copanel/stacks"))
        self.ignore_dirs = {".git", "node_modules", "venv", ".npm", ".cache", "__pycache__"}
        self._locks: Dict[str, threading.Lock] = {}

    def _safe_stack_id(self, stack_id: str) -> str:
        if not re.fullmatch(r"[a-zA-Z0-9_-]+", stack_id):
            raise DockerManagerError("Invalid stack id", code="invalid_stack_id")
        return stack_id

    def _resolve_compose_file(self, folder: Path) -> Optional[Path]:
        for name in ("docker-compose.yml", "docker-compose.yaml", "docker-composer.yml"):
            candidate = folder / name
            if candidate.exists() and candidate.is_file():
                return candidate
        return None

    def _resolve_within(self, path: Path, root: Path) -> Path:
        root_resolved = root.resolve()
        path_resolved = path.resolve()
        if root_resolved not in path_resolved.parents and path_resolved != root_resolved:
            raise DockerManagerError("Path is outside allowed root", code="path_forbidden")
        return path_resolved

    def _compose_cmd_base(self) -> List[str]:
        docker_bin = shutil.which("docker")
        if docker_bin:
            test = subprocess.run([docker_bin, "compose", "version"], capture_output=True, text=True, check=False)
            if test.returncode == 0:
                return [docker_bin, "compose"]
        docker_compose = shutil.which("docker-compose")
        if docker_compose:
            return [docker_compose]
        raise DockerManagerError("docker compose command not found", code="compose_unavailable")

    def _run_compose(self, path: str, args: List[str], timeout: Optional[int] = None) -> Dict[str, Any]:
        stack_path = Path(path)
        if not stack_path.exists() or not stack_path.is_dir():
            raise DockerManagerError(f"The path '{path}' does not exist.", code="path_not_found")
        cmd = self._compose_cmd_base() + args
        try:
            result = subprocess.run(
                cmd,
                cwd=str(stack_path),
                capture_output=True,
                text=True,
                check=False,
                timeout=timeout or self.command_timeout,
            )
        except subprocess.TimeoutExpired as exc:
            raise DockerManagerError("Compose command timed out", code="compose_timeout", details=str(exc)) from exc
        return {
            "status": "success" if result.returncode == 0 else "error",
            "output": result.stdout,
            "error": result.stderr,
            "code": result.returncode,
            "command": " ".join(cmd),
        }

    def scan_compose_files(self, custom_path: Optional[str] = None) -> List[Dict[str, str]]:
        scan_paths: List[Path] = []
        if custom_path:
            scan_paths = [Path(custom_path)]
        elif os.name == "nt":
            scan_paths = [Path("./test_docker"), Path("./test_nginx"), Path("./")]
        else:
            scan_paths = [Path("/home"), Path("/var/www"), Path("/opt/copanel"), Path("/root")]

        compose_files: List[Dict[str, str]] = []
        for base_path in scan_paths:
            if not base_path.exists() or not base_path.is_dir():
                continue
            try:
                for root, dirs, files in os.walk(str(base_path)):
                    depth = root.replace(str(base_path), "").count(os.sep)
                    if depth > self.scan_depth:
                        dirs[:] = []
                        continue
                    dirs[:] = [d for d in dirs if d not in self.ignore_dirs]
                    for file in files:
                        if file in {"docker-compose.yml", "docker-compose.yaml", "docker-composer.yml"}:
                            full_path = os.path.join(root, file)
                            compose_files.append(
                                {
                                    "path": root,
                                    "filename": file,
                                    "full_path": full_path,
                                    "source": "discovered",
                                }
                            )
            except Exception:
                continue
        return compose_files

    def validate(self, path: str) -> Dict[str, Any]:
        return self._run_compose(path, ["config"])

    def up(self, path: str, detach: bool = True) -> Dict[str, Any]:
        args = ["up"]
        if detach:
            args.append("-d")
        return self._run_compose(path, args, timeout=300)

    def down(self, path: str) -> Dict[str, Any]:
        return self._run_compose(path, ["down"], timeout=180)

    def restart(self, path: str) -> Dict[str, Any]:
        return self._run_compose(path, ["restart"], timeout=180)

    def pull(self, path: str) -> Dict[str, Any]:
        return self._run_compose(path, ["pull"], timeout=300)

    def _compose_output_text(self, result: Dict[str, Any]) -> str:
        return f"{result.get('output') or ''}{result.get('error') or ''}"

    def _pull_suggests_build(self, pull: Dict[str, Any]) -> bool:
        text = self._compose_output_text(pull).lower()
        return any(
            marker in text
            for marker in (
                "must be built from source",
                "compose build",
                "pull access denied",
                "repository does not exist",
            )
        )

    def services_need_build(self, path: str) -> bool:
        try:
            result = self._run_compose(path, ["config", "--format", "json"])
            if result.get("status") == "success":
                try:
                    import json

                    cfg = json.loads(result.get("output") or "{}")
                    for svc in (cfg.get("services") or {}).values():
                        if isinstance(svc, dict) and svc.get("build") is not None:
                            return True
                except Exception:
                    pass
        except DockerManagerError:
            pass
        folder = Path(path)
        compose_file = self._resolve_compose_file(folder)
        if compose_file and compose_file.is_file():
            return "build:" in compose_file.read_text(encoding="utf-8")
        return False

    def deploy_stack(self, path: str, detach: bool = True) -> Dict[str, Any]:
        """Pull registry images, build local Dockerfiles when needed, then up -d."""
        logs: List[str] = []
        pull = self.pull(path)
        logs.append(self._compose_output_text(pull))
        need_build = self.services_need_build(path) or (
            pull.get("status") != "success" and self._pull_suggests_build(pull)
        )
        if need_build:
            build = self.build(path, no_cache=False)
            logs.append(self._compose_output_text(build))
            if build.get("status") != "success":
                return {
                    "status": "error",
                    "error": build.get("error") or "compose build failed",
                    "output": "\n".join(logs),
                    "built": False,
                }
        elif pull.get("status") not in ("success", None):
            return {
                "status": "error",
                "error": pull.get("error") or "compose pull failed",
                "output": "\n".join(logs),
                "built": False,
            }
        up = self.up(path, detach=detach)
        logs.append(self._compose_output_text(up))
        if up.get("status") != "success":
            return {
                "status": "error",
                "error": up.get("error") or "compose up failed",
                "output": "\n".join(logs),
                "built": need_build,
            }
        return {"status": "success", "output": "\n".join(logs), "built": need_build}

    def build(self, path: str, no_cache: bool = False) -> Dict[str, Any]:
        args = ["build"]
        if no_cache:
            args.append("--no-cache")
        return self._run_compose(path, args, timeout=600)

    def ps(self, path: str) -> Dict[str, Any]:
        return self._run_compose(path, ["ps"])

    def logs(self, path: str, tail: int = 100, since: Optional[str] = None, timestamps: bool = False, follow: bool = False) -> Dict[str, Any]:
        args = ["logs", "--tail", str(tail)]
        if since:
            args.extend(["--since", since])
        if timestamps:
            args.append("--timestamps")
        if follow:
            args.append("--follow")
        return self._run_compose(path, args, timeout=300 if follow else 120)

    def list_managed_stacks(self) -> List[Dict[str, Any]]:
        self.managed_root.mkdir(parents=True, exist_ok=True)
        stacks: List[Dict[str, Any]] = []
        for child in self.managed_root.iterdir():
            if not child.is_dir():
                continue
            compose_file = self._resolve_compose_file(child)
            if compose_file:
                stacks.append(
                    {
                        "id": child.name,
                        "path": str(child),
                        "compose_file": str(compose_file),
                        "source": "managed",
                    }
                )
        return stacks

    def _custom_roots(self) -> List[Path]:
        if os.name == "nt":
            return [Path.cwd().resolve()]
        roots: List[Path] = []
        for entry in ("/home", "/var/www", "/opt/copanel", "/root"):
            candidate = Path(entry)
            if candidate.exists():
                roots.append(candidate.resolve())
        return roots

    def _all_allowed_roots(self) -> List[Path]:
        self.managed_root.mkdir(parents=True, exist_ok=True)
        roots = [self.managed_root.resolve(), *self._custom_roots()]
        seen: set[str] = set()
        unique: List[Path] = []
        for root in roots:
            key = str(root)
            if key not in seen:
                seen.add(key)
                unique.append(root)
        return unique

    def _path_under_managed(self, path: Path) -> bool:
        managed = self.managed_root.resolve()
        try:
            resolved = path.resolve()
        except OSError:
            resolved = path.absolute()
        return managed in resolved.parents or resolved == managed

    def _resolve_allowed_path(self, path: str, must_exist: bool = True) -> Path:
        target = Path(path)
        try:
            resolved = target.resolve()
        except OSError:
            resolved = target.absolute()
        if not must_exist and self._path_under_managed(resolved):
            self._resolve_within(resolved, self.managed_root.resolve())
            return resolved
        last_error: Optional[DockerManagerError] = None
        for root in self._all_allowed_roots():
            try:
                return self._resolve_within(resolved, root)
            except DockerManagerError as exc:
                last_error = exc
                continue
        if last_error:
            raise last_error
        raise DockerManagerError("Path is outside allowed root", code="path_forbidden")

    def _build_template_compose(self, service_name: str, image: str, host_port: int, container_port: int) -> str:
        safe_name = self._safe_stack_id(service_name.replace("-", "_"))
        return (
            "services:\n"
            f"  {safe_name}:\n"
            f"    image: {image}\n"
            "    restart: unless-stopped\n"
            "    ports:\n"
            f'      - "{host_port}:{container_port}"\n'
        )

    def resolve_project_folder(self, folder_mode: str, project_name: str, folder_path: Optional[str] = None) -> Path:
        if folder_mode == "managed":
            self.managed_root.mkdir(parents=True, exist_ok=True)
            sid = self._safe_stack_id(project_name)
            return self._resolve_within(self.managed_root / sid, self.managed_root.resolve())
        if not folder_path:
            raise DockerManagerError("folder_path is required for custom mode", code="invalid_request")
        folder = self._resolve_allowed_path(folder_path, must_exist=True)
        if not folder.is_dir():
            raise DockerManagerError(f"The path '{folder}' is not a directory.", code="path_not_found")
        return folder

    def inspect_folder(self, path: str) -> Dict[str, Any]:
        target = Path(path)
        try:
            resolved = target.resolve()
        except OSError:
            resolved = target.absolute()

        if not resolved.exists():
            if self._path_under_managed(resolved):
                self.managed_root.mkdir(parents=True, exist_ok=True)
                managed = self.managed_root.resolve()
                return {
                    "path": str(resolved),
                    "exists": False,
                    "has_compose": False,
                    "compose_file": None,
                    "compose_content": None,
                    "writable": os.access(managed, os.W_OK),
                }
            raise DockerManagerError(f"The path '{path}' does not exist.", code="path_not_found")

        folder = self._resolve_allowed_path(str(resolved), must_exist=True)
        if not folder.is_dir():
            raise DockerManagerError(f"The path '{path}' is not a directory.", code="path_not_found")

        compose_file = self._resolve_compose_file(folder)
        content: Optional[str] = None
        if compose_file:
            raw = compose_file.read_text(encoding="utf-8")
            content = raw if len(raw) <= 32768 else raw[:32768] + "\n# ... truncated ..."

        return {
            "path": str(folder),
            "exists": True,
            "has_compose": compose_file is not None,
            "compose_file": compose_file.name if compose_file else None,
            "compose_content": content,
            "writable": os.access(folder, os.W_OK),
        }

    def validate_compose_content(self, compose_content: str) -> Dict[str, Any]:
        with tempfile.TemporaryDirectory(prefix="copanel-compose-validate-") as tmp:
            folder = Path(tmp)
            (folder / "docker-compose.yml").write_text(compose_content, encoding="utf-8")
            return self.validate(str(folder))

    def create_project(
        self,
        project_name: str,
        folder_mode: str,
        source: str,
        folder_path: Optional[str] = None,
        compose_content: Optional[str] = None,
        template: Optional[Dict[str, Any]] = None,
        overwrite_compose: bool = False,
    ) -> Dict[str, Any]:
        sid = self._safe_stack_id(project_name)
        folder = self.resolve_project_folder(folder_mode, sid, folder_path)
        folder.mkdir(parents=True, exist_ok=True)

        existing = self._resolve_compose_file(folder)
        target_file = folder / "docker-compose.yml"

        if source == "existing":
            if not existing:
                raise DockerManagerError("No compose file found in the selected folder.", code="compose_missing")
            if compose_content and compose_content.strip():
                if existing and not overwrite_compose:
                    current = existing.read_text(encoding="utf-8")
                    if compose_content.strip() != current.strip():
                        raise DockerManagerError(
                            "Compose file already exists. Enable overwrite to replace it.",
                            code="compose_exists",
                        )
                target_file = existing
                if compose_content.strip() != existing.read_text(encoding="utf-8").strip():
                    target_file.write_text(compose_content, encoding="utf-8")
        elif source == "paste":
            if not compose_content or not compose_content.strip():
                raise DockerManagerError("Compose content is required.", code="compose_missing")
            if existing and not overwrite_compose:
                raise DockerManagerError(
                    "Compose file already exists. Enable overwrite to replace it.",
                    code="compose_exists",
                )
            target_file.write_text(compose_content, encoding="utf-8")
        elif source == "template":
            tpl = template or {}
            generated = self._build_template_compose(
                sid,
                str(tpl.get("image") or "nginx:alpine"),
                int(tpl.get("host_port") or 8080),
                int(tpl.get("container_port") or 80),
            )
            if existing and not overwrite_compose:
                raise DockerManagerError(
                    "Compose file already exists. Enable overwrite to replace it.",
                    code="compose_exists",
                )
            target_file.write_text(generated, encoding="utf-8")
            compose_content = generated
        else:
            raise DockerManagerError("Invalid project source.", code="invalid_request")

        validation = self.validate(str(folder))
        if validation["status"] != "success":
            raise DockerManagerError(
                "Compose validation failed",
                code="compose_invalid",
                details=validation.get("error") or validation.get("output"),
            )

        if not (folder / ".env.example").exists():
            (folder / ".env.example").write_text("# Add your env vars here\n", encoding="utf-8")
        if not (folder / "README.md").exists():
            (folder / "README.md").write_text(f"# Project {sid}\n\nManaged by CoPanel Docker Manager.\n", encoding="utf-8")

        final_content = target_file.read_text(encoding="utf-8")
        return {
            "project_name": sid,
            "path": str(folder),
            "compose_file": str(target_file),
            "compose_content": final_content,
            "source": source,
            "validated": True,
        }

    def _project_status(self, path: str) -> str:
        try:
            result = self.ps(path)
            if result.get("status") != "success":
                return "unknown"
            output = (result.get("output") or "").strip().lower()
            if not output or "name" not in output and "container" not in output:
                lines = [ln for ln in output.splitlines() if ln.strip()]
                if not lines:
                    return "stopped"
            if "running" in output or "up " in output:
                return "running"
            if "exited" in output or "stopped" in output:
                return "stopped"
            return "partial" if output else "stopped"
        except Exception:
            return "unknown"

    def _compose_project_statuses(self) -> Dict[str, str]:
        """Resolve managed project status via one `docker ps` instead of N× `compose ps`."""
        docker_bin = shutil.which("docker") or "/usr/bin/docker"
        try:
            result = subprocess.run(
                [
                    docker_bin,
                    "ps",
                    "-a",
                    "--format",
                    '{{.Label "com.docker.compose.project"}}\t{{.State}}',
                ],
                capture_output=True,
                text=True,
                check=False,
                timeout=20,
            )
        except Exception:
            return {}
        if result.returncode != 0:
            return {}
        by_project: Dict[str, set] = {}
        for line in (result.stdout or "").splitlines():
            parts = line.split("\t")
            if len(parts) < 2:
                continue
            project = (parts[0] or "").strip()
            state = (parts[1] or "").strip().lower()
            if not project:
                continue
            by_project.setdefault(project, set()).add(state)
        statuses: Dict[str, str] = {}
        for project, states in by_project.items():
            if "running" in states and len(states) == 1:
                statuses[project] = "running"
            elif "running" in states:
                statuses[project] = "partial"
            elif states & {"exited", "dead", "created", "paused"}:
                statuses[project] = "stopped"
            else:
                statuses[project] = "unknown"
        return statuses

    def list_projects(self) -> List[Dict[str, Any]]:
        status_map = self._compose_project_statuses()
        projects: List[Dict[str, Any]] = []
        for stack in self.list_managed_stacks():
            stack_id = stack["id"]
            status = status_map.get(stack_id)
            if status is None:
                # No containers labeled with this project yet.
                status = "stopped"
            projects.append(
                {
                    "id": stack_id,
                    "name": stack_id,
                    "path": stack["path"],
                    "compose_file": stack["compose_file"],
                    "source": "managed",
                    "status": status,
                }
            )
        return projects

    def get_compose_at_path(self, path: str) -> Dict[str, Any]:
        folder = self._resolve_allowed_path(path, must_exist=True)
        compose_file = self._resolve_compose_file(folder)
        if not compose_file:
            raise DockerManagerError("Compose file not found", code="compose_missing")
        return {
            "path": str(folder),
            "compose_file": str(compose_file),
            "content": compose_file.read_text(encoding="utf-8"),
        }

    def update_compose_at_path(self, path: str, compose_content: str) -> Dict[str, Any]:
        folder = self._resolve_allowed_path(path, must_exist=True)
        compose_file = self._resolve_compose_file(folder) or (folder / "docker-compose.yml")
        lock_key = str(folder)
        lock = self._locks.setdefault(lock_key, threading.Lock())
        with lock:
            backup = compose_file.read_text(encoding="utf-8") if compose_file.exists() else ""
            compose_file.write_text(compose_content, encoding="utf-8")
            validation = self.validate(str(folder))
            if validation["status"] != "success":
                if backup:
                    compose_file.write_text(backup, encoding="utf-8")
                raise DockerManagerError(
                    "Compose validation failed",
                    code="compose_invalid",
                    details=validation.get("error") or validation.get("output"),
                )
        return {"path": str(folder), "compose_file": str(compose_file), "validated": True}

    def get_env_at_path(self, path: str) -> Dict[str, Any]:
        folder = self._resolve_allowed_path(path, must_exist=True)
        env_file = folder / ".env"
        example_file = folder / ".env.example"
        if env_file.exists():
            content = env_file.read_text(encoding="utf-8")
            exists = True
        elif example_file.exists():
            content = example_file.read_text(encoding="utf-8")
            exists = False
        else:
            content = ""
            exists = False
        return {"path": str(folder), "content": content, "exists": exists}

    def update_env_at_path(self, path: str, content: str) -> Dict[str, Any]:
        folder = self._resolve_allowed_path(path, must_exist=True)
        if not os.access(folder, os.W_OK):
            raise DockerManagerError("Folder is not writable", code="path_forbidden")
        env_file = folder / ".env"
        env_file.write_text(content, encoding="utf-8")
        return {"path": str(folder), "env_file": str(env_file), "saved": True}

    def init_stack(self, stack_id: str, image: str, host_port: int, container_port: int) -> Dict[str, Any]:
        self.managed_root.mkdir(parents=True, exist_ok=True)
        sid = self._safe_stack_id(stack_id)
        stack_dir = self._resolve_within(self.managed_root / sid, self.managed_root)
        stack_dir.mkdir(parents=True, exist_ok=True)
        compose_content = (
            "services:\n"
            f"  {sid}:\n"
            f"    image: {image}\n"
            "    restart: unless-stopped\n"
            "    ports:\n"
            f"      - \"{host_port}:{container_port}\"\n"
        )
        (stack_dir / "docker-compose.yml").write_text(compose_content, encoding="utf-8")
        (stack_dir / ".env.example").write_text("# Add your env vars here\n", encoding="utf-8")
        (stack_dir / "README.md").write_text(f"# Stack {sid}\n\nManaged by CoPanel.\n", encoding="utf-8")
        return {"stack_id": sid, "path": str(stack_dir), "source": "managed"}

    def get_compose_content(self, stack_id: str) -> Dict[str, Any]:
        sid = self._safe_stack_id(stack_id)
        stack_dir = self._resolve_within(self.managed_root / sid, self.managed_root)
        compose_file = self._resolve_compose_file(stack_dir)
        if not compose_file:
            raise DockerManagerError("Compose file not found", code="compose_missing")
        return {
            "stack_id": sid,
            "path": str(stack_dir),
            "compose_file": str(compose_file),
            "content": compose_file.read_text(encoding="utf-8"),
        }

    def update_compose_content(self, stack_id: str, compose_content: str) -> Dict[str, Any]:
        sid = self._safe_stack_id(stack_id)
        stack_dir = self._resolve_within(self.managed_root / sid, self.managed_root)
        compose_file = stack_dir / "docker-compose.yml"
        lock = self._locks.setdefault(sid, threading.Lock())
        with lock:
            backup = compose_file.read_text(encoding="utf-8") if compose_file.exists() else ""
            compose_file.write_text(compose_content, encoding="utf-8")
            validation = self.validate(str(stack_dir))
            if validation["status"] != "success":
                if backup:
                    compose_file.write_text(backup, encoding="utf-8")
                raise DockerManagerError("Compose validation failed", code="compose_invalid", details=validation.get("error") or validation.get("output"))
        return {"stack_id": sid, "compose_file": str(compose_file), "validated": True}
