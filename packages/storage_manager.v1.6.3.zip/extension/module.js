// src/modules/storage_manager/index.tsx
import { useCallback as useCallback3, useEffect as useEffect4, useMemo as useMemo2, useState as useState4 } from "react";

// src/core/hooks/useAppShellContext.ts
import { useOutletContext } from "react-router-dom";

// src/core/shell/ShellContext.tsx
import { createContext, useContext } from "react";
import { jsx } from "react/jsx-runtime";
var ShellContext = createContext(null);
function useShellContext() {
  return useContext(ShellContext);
}

// src/core/hooks/useAppShellContext.ts
var FALLBACK = {
  theme: localStorage.getItem("copanel_theme") || "light",
  setTheme: () => {
  },
  language: localStorage.getItem("copanel_lang") || "en",
  setLanguage: () => {
  }
};
function useAppShellContext() {
  const shell = useShellContext();
  const outlet = useOutletContext();
  if (shell) return shell;
  if (outlet?.theme) {
    return {
      theme: outlet.theme,
      setTheme: outlet.setTheme ?? (() => {
      }),
      language: outlet.language ?? "en",
      setLanguage: outlet.setLanguage ?? (() => {
      })
    };
  }
  return FALLBACK;
}

// node_modules/clsx/dist/clsx.mjs
function r(e) {
  var t, f, n = "";
  if ("string" == typeof e || "number" == typeof e) n += e;
  else if ("object" == typeof e) if (Array.isArray(e)) {
    var o = e.length;
    for (t = 0; t < o; t++) e[t] && (f = r(e[t])) && (n && (n += " "), n += f);
  } else for (f in e) e[f] && (n && (n += " "), n += f);
  return n;
}
function clsx() {
  for (var e, t, f = 0, n = "", o = arguments.length; f < o; f++) (e = arguments[f]) && (t = r(e)) && (n && (n += " "), n += t);
  return n;
}

// node_modules/tailwind-merge/dist/bundle-mjs.mjs
var CLASS_PART_SEPARATOR = "-";
var createClassGroupUtils = (config) => {
  const classMap = createClassMap(config);
  const {
    conflictingClassGroups,
    conflictingClassGroupModifiers
  } = config;
  const getClassGroupId = (className) => {
    const classParts = className.split(CLASS_PART_SEPARATOR);
    if (classParts[0] === "" && classParts.length !== 1) {
      classParts.shift();
    }
    return getGroupRecursive(classParts, classMap) || getGroupIdForArbitraryProperty(className);
  };
  const getConflictingClassGroupIds = (classGroupId, hasPostfixModifier) => {
    const conflicts = conflictingClassGroups[classGroupId] || [];
    if (hasPostfixModifier && conflictingClassGroupModifiers[classGroupId]) {
      return [...conflicts, ...conflictingClassGroupModifiers[classGroupId]];
    }
    return conflicts;
  };
  return {
    getClassGroupId,
    getConflictingClassGroupIds
  };
};
var getGroupRecursive = (classParts, classPartObject) => {
  if (classParts.length === 0) {
    return classPartObject.classGroupId;
  }
  const currentClassPart = classParts[0];
  const nextClassPartObject = classPartObject.nextPart.get(currentClassPart);
  const classGroupFromNextClassPart = nextClassPartObject ? getGroupRecursive(classParts.slice(1), nextClassPartObject) : void 0;
  if (classGroupFromNextClassPart) {
    return classGroupFromNextClassPart;
  }
  if (classPartObject.validators.length === 0) {
    return void 0;
  }
  const classRest = classParts.join(CLASS_PART_SEPARATOR);
  return classPartObject.validators.find(({
    validator
  }) => validator(classRest))?.classGroupId;
};
var arbitraryPropertyRegex = /^\[(.+)\]$/;
var getGroupIdForArbitraryProperty = (className) => {
  if (arbitraryPropertyRegex.test(className)) {
    const arbitraryPropertyClassName = arbitraryPropertyRegex.exec(className)[1];
    const property = arbitraryPropertyClassName?.substring(0, arbitraryPropertyClassName.indexOf(":"));
    if (property) {
      return "arbitrary.." + property;
    }
  }
};
var createClassMap = (config) => {
  const {
    theme,
    prefix
  } = config;
  const classMap = {
    nextPart: /* @__PURE__ */ new Map(),
    validators: []
  };
  const prefixedClassGroupEntries = getPrefixedClassGroupEntries(Object.entries(config.classGroups), prefix);
  prefixedClassGroupEntries.forEach(([classGroupId, classGroup]) => {
    processClassesRecursively(classGroup, classMap, classGroupId, theme);
  });
  return classMap;
};
var processClassesRecursively = (classGroup, classPartObject, classGroupId, theme) => {
  classGroup.forEach((classDefinition) => {
    if (typeof classDefinition === "string") {
      const classPartObjectToEdit = classDefinition === "" ? classPartObject : getPart(classPartObject, classDefinition);
      classPartObjectToEdit.classGroupId = classGroupId;
      return;
    }
    if (typeof classDefinition === "function") {
      if (isThemeGetter(classDefinition)) {
        processClassesRecursively(classDefinition(theme), classPartObject, classGroupId, theme);
        return;
      }
      classPartObject.validators.push({
        validator: classDefinition,
        classGroupId
      });
      return;
    }
    Object.entries(classDefinition).forEach(([key, classGroup2]) => {
      processClassesRecursively(classGroup2, getPart(classPartObject, key), classGroupId, theme);
    });
  });
};
var getPart = (classPartObject, path) => {
  let currentClassPartObject = classPartObject;
  path.split(CLASS_PART_SEPARATOR).forEach((pathPart) => {
    if (!currentClassPartObject.nextPart.has(pathPart)) {
      currentClassPartObject.nextPart.set(pathPart, {
        nextPart: /* @__PURE__ */ new Map(),
        validators: []
      });
    }
    currentClassPartObject = currentClassPartObject.nextPart.get(pathPart);
  });
  return currentClassPartObject;
};
var isThemeGetter = (func) => func.isThemeGetter;
var getPrefixedClassGroupEntries = (classGroupEntries, prefix) => {
  if (!prefix) {
    return classGroupEntries;
  }
  return classGroupEntries.map(([classGroupId, classGroup]) => {
    const prefixedClassGroup = classGroup.map((classDefinition) => {
      if (typeof classDefinition === "string") {
        return prefix + classDefinition;
      }
      if (typeof classDefinition === "object") {
        return Object.fromEntries(Object.entries(classDefinition).map(([key, value]) => [prefix + key, value]));
      }
      return classDefinition;
    });
    return [classGroupId, prefixedClassGroup];
  });
};
var createLruCache = (maxCacheSize) => {
  if (maxCacheSize < 1) {
    return {
      get: () => void 0,
      set: () => {
      }
    };
  }
  let cacheSize = 0;
  let cache = /* @__PURE__ */ new Map();
  let previousCache = /* @__PURE__ */ new Map();
  const update = (key, value) => {
    cache.set(key, value);
    cacheSize++;
    if (cacheSize > maxCacheSize) {
      cacheSize = 0;
      previousCache = cache;
      cache = /* @__PURE__ */ new Map();
    }
  };
  return {
    get(key) {
      let value = cache.get(key);
      if (value !== void 0) {
        return value;
      }
      if ((value = previousCache.get(key)) !== void 0) {
        update(key, value);
        return value;
      }
    },
    set(key, value) {
      if (cache.has(key)) {
        cache.set(key, value);
      } else {
        update(key, value);
      }
    }
  };
};
var IMPORTANT_MODIFIER = "!";
var createParseClassName = (config) => {
  const {
    separator,
    experimentalParseClassName
  } = config;
  const isSeparatorSingleCharacter = separator.length === 1;
  const firstSeparatorCharacter = separator[0];
  const separatorLength = separator.length;
  const parseClassName = (className) => {
    const modifiers = [];
    let bracketDepth = 0;
    let modifierStart = 0;
    let postfixModifierPosition;
    for (let index = 0; index < className.length; index++) {
      let currentCharacter = className[index];
      if (bracketDepth === 0) {
        if (currentCharacter === firstSeparatorCharacter && (isSeparatorSingleCharacter || className.slice(index, index + separatorLength) === separator)) {
          modifiers.push(className.slice(modifierStart, index));
          modifierStart = index + separatorLength;
          continue;
        }
        if (currentCharacter === "/") {
          postfixModifierPosition = index;
          continue;
        }
      }
      if (currentCharacter === "[") {
        bracketDepth++;
      } else if (currentCharacter === "]") {
        bracketDepth--;
      }
    }
    const baseClassNameWithImportantModifier = modifiers.length === 0 ? className : className.substring(modifierStart);
    const hasImportantModifier = baseClassNameWithImportantModifier.startsWith(IMPORTANT_MODIFIER);
    const baseClassName = hasImportantModifier ? baseClassNameWithImportantModifier.substring(1) : baseClassNameWithImportantModifier;
    const maybePostfixModifierPosition = postfixModifierPosition && postfixModifierPosition > modifierStart ? postfixModifierPosition - modifierStart : void 0;
    return {
      modifiers,
      hasImportantModifier,
      baseClassName,
      maybePostfixModifierPosition
    };
  };
  if (experimentalParseClassName) {
    return (className) => experimentalParseClassName({
      className,
      parseClassName
    });
  }
  return parseClassName;
};
var sortModifiers = (modifiers) => {
  if (modifiers.length <= 1) {
    return modifiers;
  }
  const sortedModifiers = [];
  let unsortedModifiers = [];
  modifiers.forEach((modifier) => {
    const isArbitraryVariant = modifier[0] === "[";
    if (isArbitraryVariant) {
      sortedModifiers.push(...unsortedModifiers.sort(), modifier);
      unsortedModifiers = [];
    } else {
      unsortedModifiers.push(modifier);
    }
  });
  sortedModifiers.push(...unsortedModifiers.sort());
  return sortedModifiers;
};
var createConfigUtils = (config) => ({
  cache: createLruCache(config.cacheSize),
  parseClassName: createParseClassName(config),
  ...createClassGroupUtils(config)
});
var SPLIT_CLASSES_REGEX = /\s+/;
var mergeClassList = (classList, configUtils) => {
  const {
    parseClassName,
    getClassGroupId,
    getConflictingClassGroupIds
  } = configUtils;
  const classGroupsInConflict = [];
  const classNames = classList.trim().split(SPLIT_CLASSES_REGEX);
  let result = "";
  for (let index = classNames.length - 1; index >= 0; index -= 1) {
    const originalClassName = classNames[index];
    const {
      modifiers,
      hasImportantModifier,
      baseClassName,
      maybePostfixModifierPosition
    } = parseClassName(originalClassName);
    let hasPostfixModifier = Boolean(maybePostfixModifierPosition);
    let classGroupId = getClassGroupId(hasPostfixModifier ? baseClassName.substring(0, maybePostfixModifierPosition) : baseClassName);
    if (!classGroupId) {
      if (!hasPostfixModifier) {
        result = originalClassName + (result.length > 0 ? " " + result : result);
        continue;
      }
      classGroupId = getClassGroupId(baseClassName);
      if (!classGroupId) {
        result = originalClassName + (result.length > 0 ? " " + result : result);
        continue;
      }
      hasPostfixModifier = false;
    }
    const variantModifier = sortModifiers(modifiers).join(":");
    const modifierId = hasImportantModifier ? variantModifier + IMPORTANT_MODIFIER : variantModifier;
    const classId = modifierId + classGroupId;
    if (classGroupsInConflict.includes(classId)) {
      continue;
    }
    classGroupsInConflict.push(classId);
    const conflictGroups = getConflictingClassGroupIds(classGroupId, hasPostfixModifier);
    for (let i = 0; i < conflictGroups.length; ++i) {
      const group = conflictGroups[i];
      classGroupsInConflict.push(modifierId + group);
    }
    result = originalClassName + (result.length > 0 ? " " + result : result);
  }
  return result;
};
function twJoin() {
  let index = 0;
  let argument;
  let resolvedValue;
  let string = "";
  while (index < arguments.length) {
    if (argument = arguments[index++]) {
      if (resolvedValue = toValue(argument)) {
        string && (string += " ");
        string += resolvedValue;
      }
    }
  }
  return string;
}
var toValue = (mix) => {
  if (typeof mix === "string") {
    return mix;
  }
  let resolvedValue;
  let string = "";
  for (let k = 0; k < mix.length; k++) {
    if (mix[k]) {
      if (resolvedValue = toValue(mix[k])) {
        string && (string += " ");
        string += resolvedValue;
      }
    }
  }
  return string;
};
function createTailwindMerge(createConfigFirst, ...createConfigRest) {
  let configUtils;
  let cacheGet;
  let cacheSet;
  let functionToCall = initTailwindMerge;
  function initTailwindMerge(classList) {
    const config = createConfigRest.reduce((previousConfig, createConfigCurrent) => createConfigCurrent(previousConfig), createConfigFirst());
    configUtils = createConfigUtils(config);
    cacheGet = configUtils.cache.get;
    cacheSet = configUtils.cache.set;
    functionToCall = tailwindMerge;
    return tailwindMerge(classList);
  }
  function tailwindMerge(classList) {
    const cachedResult = cacheGet(classList);
    if (cachedResult) {
      return cachedResult;
    }
    const result = mergeClassList(classList, configUtils);
    cacheSet(classList, result);
    return result;
  }
  return function callTailwindMerge() {
    return functionToCall(twJoin.apply(null, arguments));
  };
}
var fromTheme = (key) => {
  const themeGetter = (theme) => theme[key] || [];
  themeGetter.isThemeGetter = true;
  return themeGetter;
};
var arbitraryValueRegex = /^\[(?:([a-z-]+):)?(.+)\]$/i;
var fractionRegex = /^\d+\/\d+$/;
var stringLengths = /* @__PURE__ */ new Set(["px", "full", "screen"]);
var tshirtUnitRegex = /^(\d+(\.\d+)?)?(xs|sm|md|lg|xl)$/;
var lengthUnitRegex = /\d+(%|px|r?em|[sdl]?v([hwib]|min|max)|pt|pc|in|cm|mm|cap|ch|ex|r?lh|cq(w|h|i|b|min|max))|\b(calc|min|max|clamp)\(.+\)|^0$/;
var colorFunctionRegex = /^(rgba?|hsla?|hwb|(ok)?(lab|lch)|color-mix)\(.+\)$/;
var shadowRegex = /^(inset_)?-?((\d+)?\.?(\d+)[a-z]+|0)_-?((\d+)?\.?(\d+)[a-z]+|0)/;
var imageRegex = /^(url|image|image-set|cross-fade|element|(repeating-)?(linear|radial|conic)-gradient)\(.+\)$/;
var isLength = (value) => isNumber(value) || stringLengths.has(value) || fractionRegex.test(value);
var isArbitraryLength = (value) => getIsArbitraryValue(value, "length", isLengthOnly);
var isNumber = (value) => Boolean(value) && !Number.isNaN(Number(value));
var isArbitraryNumber = (value) => getIsArbitraryValue(value, "number", isNumber);
var isInteger = (value) => Boolean(value) && Number.isInteger(Number(value));
var isPercent = (value) => value.endsWith("%") && isNumber(value.slice(0, -1));
var isArbitraryValue = (value) => arbitraryValueRegex.test(value);
var isTshirtSize = (value) => tshirtUnitRegex.test(value);
var sizeLabels = /* @__PURE__ */ new Set(["length", "size", "percentage"]);
var isArbitrarySize = (value) => getIsArbitraryValue(value, sizeLabels, isNever);
var isArbitraryPosition = (value) => getIsArbitraryValue(value, "position", isNever);
var imageLabels = /* @__PURE__ */ new Set(["image", "url"]);
var isArbitraryImage = (value) => getIsArbitraryValue(value, imageLabels, isImage);
var isArbitraryShadow = (value) => getIsArbitraryValue(value, "", isShadow);
var isAny = () => true;
var getIsArbitraryValue = (value, label, testValue) => {
  const result = arbitraryValueRegex.exec(value);
  if (result) {
    if (result[1]) {
      return typeof label === "string" ? result[1] === label : label.has(result[1]);
    }
    return testValue(result[2]);
  }
  return false;
};
var isLengthOnly = (value) => (
  // `colorFunctionRegex` check is necessary because color functions can have percentages in them which which would be incorrectly classified as lengths.
  // For example, `hsl(0 0% 0%)` would be classified as a length without this check.
  // I could also use lookbehind assertion in `lengthUnitRegex` but that isn't supported widely enough.
  lengthUnitRegex.test(value) && !colorFunctionRegex.test(value)
);
var isNever = () => false;
var isShadow = (value) => shadowRegex.test(value);
var isImage = (value) => imageRegex.test(value);
var getDefaultConfig = () => {
  const colors = fromTheme("colors");
  const spacing = fromTheme("spacing");
  const blur = fromTheme("blur");
  const brightness = fromTheme("brightness");
  const borderColor = fromTheme("borderColor");
  const borderRadius = fromTheme("borderRadius");
  const borderSpacing = fromTheme("borderSpacing");
  const borderWidth = fromTheme("borderWidth");
  const contrast = fromTheme("contrast");
  const grayscale = fromTheme("grayscale");
  const hueRotate = fromTheme("hueRotate");
  const invert = fromTheme("invert");
  const gap = fromTheme("gap");
  const gradientColorStops = fromTheme("gradientColorStops");
  const gradientColorStopPositions = fromTheme("gradientColorStopPositions");
  const inset = fromTheme("inset");
  const margin = fromTheme("margin");
  const opacity = fromTheme("opacity");
  const padding = fromTheme("padding");
  const saturate = fromTheme("saturate");
  const scale = fromTheme("scale");
  const sepia = fromTheme("sepia");
  const skew = fromTheme("skew");
  const space = fromTheme("space");
  const translate = fromTheme("translate");
  const getOverscroll = () => ["auto", "contain", "none"];
  const getOverflow = () => ["auto", "hidden", "clip", "visible", "scroll"];
  const getSpacingWithAutoAndArbitrary = () => ["auto", isArbitraryValue, spacing];
  const getSpacingWithArbitrary = () => [isArbitraryValue, spacing];
  const getLengthWithEmptyAndArbitrary = () => ["", isLength, isArbitraryLength];
  const getNumberWithAutoAndArbitrary = () => ["auto", isNumber, isArbitraryValue];
  const getPositions = () => ["bottom", "center", "left", "left-bottom", "left-top", "right", "right-bottom", "right-top", "top"];
  const getLineStyles = () => ["solid", "dashed", "dotted", "double", "none"];
  const getBlendModes = () => ["normal", "multiply", "screen", "overlay", "darken", "lighten", "color-dodge", "color-burn", "hard-light", "soft-light", "difference", "exclusion", "hue", "saturation", "color", "luminosity"];
  const getAlign = () => ["start", "end", "center", "between", "around", "evenly", "stretch"];
  const getZeroAndEmpty = () => ["", "0", isArbitraryValue];
  const getBreaks = () => ["auto", "avoid", "all", "avoid-page", "page", "left", "right", "column"];
  const getNumberAndArbitrary = () => [isNumber, isArbitraryValue];
  return {
    cacheSize: 500,
    separator: ":",
    theme: {
      colors: [isAny],
      spacing: [isLength, isArbitraryLength],
      blur: ["none", "", isTshirtSize, isArbitraryValue],
      brightness: getNumberAndArbitrary(),
      borderColor: [colors],
      borderRadius: ["none", "", "full", isTshirtSize, isArbitraryValue],
      borderSpacing: getSpacingWithArbitrary(),
      borderWidth: getLengthWithEmptyAndArbitrary(),
      contrast: getNumberAndArbitrary(),
      grayscale: getZeroAndEmpty(),
      hueRotate: getNumberAndArbitrary(),
      invert: getZeroAndEmpty(),
      gap: getSpacingWithArbitrary(),
      gradientColorStops: [colors],
      gradientColorStopPositions: [isPercent, isArbitraryLength],
      inset: getSpacingWithAutoAndArbitrary(),
      margin: getSpacingWithAutoAndArbitrary(),
      opacity: getNumberAndArbitrary(),
      padding: getSpacingWithArbitrary(),
      saturate: getNumberAndArbitrary(),
      scale: getNumberAndArbitrary(),
      sepia: getZeroAndEmpty(),
      skew: getNumberAndArbitrary(),
      space: getSpacingWithArbitrary(),
      translate: getSpacingWithArbitrary()
    },
    classGroups: {
      // Layout
      /**
       * Aspect Ratio
       * @see https://tailwindcss.com/docs/aspect-ratio
       */
      aspect: [{
        aspect: ["auto", "square", "video", isArbitraryValue]
      }],
      /**
       * Container
       * @see https://tailwindcss.com/docs/container
       */
      container: ["container"],
      /**
       * Columns
       * @see https://tailwindcss.com/docs/columns
       */
      columns: [{
        columns: [isTshirtSize]
      }],
      /**
       * Break After
       * @see https://tailwindcss.com/docs/break-after
       */
      "break-after": [{
        "break-after": getBreaks()
      }],
      /**
       * Break Before
       * @see https://tailwindcss.com/docs/break-before
       */
      "break-before": [{
        "break-before": getBreaks()
      }],
      /**
       * Break Inside
       * @see https://tailwindcss.com/docs/break-inside
       */
      "break-inside": [{
        "break-inside": ["auto", "avoid", "avoid-page", "avoid-column"]
      }],
      /**
       * Box Decoration Break
       * @see https://tailwindcss.com/docs/box-decoration-break
       */
      "box-decoration": [{
        "box-decoration": ["slice", "clone"]
      }],
      /**
       * Box Sizing
       * @see https://tailwindcss.com/docs/box-sizing
       */
      box: [{
        box: ["border", "content"]
      }],
      /**
       * Display
       * @see https://tailwindcss.com/docs/display
       */
      display: ["block", "inline-block", "inline", "flex", "inline-flex", "table", "inline-table", "table-caption", "table-cell", "table-column", "table-column-group", "table-footer-group", "table-header-group", "table-row-group", "table-row", "flow-root", "grid", "inline-grid", "contents", "list-item", "hidden"],
      /**
       * Floats
       * @see https://tailwindcss.com/docs/float
       */
      float: [{
        float: ["right", "left", "none", "start", "end"]
      }],
      /**
       * Clear
       * @see https://tailwindcss.com/docs/clear
       */
      clear: [{
        clear: ["left", "right", "both", "none", "start", "end"]
      }],
      /**
       * Isolation
       * @see https://tailwindcss.com/docs/isolation
       */
      isolation: ["isolate", "isolation-auto"],
      /**
       * Object Fit
       * @see https://tailwindcss.com/docs/object-fit
       */
      "object-fit": [{
        object: ["contain", "cover", "fill", "none", "scale-down"]
      }],
      /**
       * Object Position
       * @see https://tailwindcss.com/docs/object-position
       */
      "object-position": [{
        object: [...getPositions(), isArbitraryValue]
      }],
      /**
       * Overflow
       * @see https://tailwindcss.com/docs/overflow
       */
      overflow: [{
        overflow: getOverflow()
      }],
      /**
       * Overflow X
       * @see https://tailwindcss.com/docs/overflow
       */
      "overflow-x": [{
        "overflow-x": getOverflow()
      }],
      /**
       * Overflow Y
       * @see https://tailwindcss.com/docs/overflow
       */
      "overflow-y": [{
        "overflow-y": getOverflow()
      }],
      /**
       * Overscroll Behavior
       * @see https://tailwindcss.com/docs/overscroll-behavior
       */
      overscroll: [{
        overscroll: getOverscroll()
      }],
      /**
       * Overscroll Behavior X
       * @see https://tailwindcss.com/docs/overscroll-behavior
       */
      "overscroll-x": [{
        "overscroll-x": getOverscroll()
      }],
      /**
       * Overscroll Behavior Y
       * @see https://tailwindcss.com/docs/overscroll-behavior
       */
      "overscroll-y": [{
        "overscroll-y": getOverscroll()
      }],
      /**
       * Position
       * @see https://tailwindcss.com/docs/position
       */
      position: ["static", "fixed", "absolute", "relative", "sticky"],
      /**
       * Top / Right / Bottom / Left
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      inset: [{
        inset: [inset]
      }],
      /**
       * Right / Left
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      "inset-x": [{
        "inset-x": [inset]
      }],
      /**
       * Top / Bottom
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      "inset-y": [{
        "inset-y": [inset]
      }],
      /**
       * Start
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      start: [{
        start: [inset]
      }],
      /**
       * End
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      end: [{
        end: [inset]
      }],
      /**
       * Top
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      top: [{
        top: [inset]
      }],
      /**
       * Right
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      right: [{
        right: [inset]
      }],
      /**
       * Bottom
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      bottom: [{
        bottom: [inset]
      }],
      /**
       * Left
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      left: [{
        left: [inset]
      }],
      /**
       * Visibility
       * @see https://tailwindcss.com/docs/visibility
       */
      visibility: ["visible", "invisible", "collapse"],
      /**
       * Z-Index
       * @see https://tailwindcss.com/docs/z-index
       */
      z: [{
        z: ["auto", isInteger, isArbitraryValue]
      }],
      // Flexbox and Grid
      /**
       * Flex Basis
       * @see https://tailwindcss.com/docs/flex-basis
       */
      basis: [{
        basis: getSpacingWithAutoAndArbitrary()
      }],
      /**
       * Flex Direction
       * @see https://tailwindcss.com/docs/flex-direction
       */
      "flex-direction": [{
        flex: ["row", "row-reverse", "col", "col-reverse"]
      }],
      /**
       * Flex Wrap
       * @see https://tailwindcss.com/docs/flex-wrap
       */
      "flex-wrap": [{
        flex: ["wrap", "wrap-reverse", "nowrap"]
      }],
      /**
       * Flex
       * @see https://tailwindcss.com/docs/flex
       */
      flex: [{
        flex: ["1", "auto", "initial", "none", isArbitraryValue]
      }],
      /**
       * Flex Grow
       * @see https://tailwindcss.com/docs/flex-grow
       */
      grow: [{
        grow: getZeroAndEmpty()
      }],
      /**
       * Flex Shrink
       * @see https://tailwindcss.com/docs/flex-shrink
       */
      shrink: [{
        shrink: getZeroAndEmpty()
      }],
      /**
       * Order
       * @see https://tailwindcss.com/docs/order
       */
      order: [{
        order: ["first", "last", "none", isInteger, isArbitraryValue]
      }],
      /**
       * Grid Template Columns
       * @see https://tailwindcss.com/docs/grid-template-columns
       */
      "grid-cols": [{
        "grid-cols": [isAny]
      }],
      /**
       * Grid Column Start / End
       * @see https://tailwindcss.com/docs/grid-column
       */
      "col-start-end": [{
        col: ["auto", {
          span: ["full", isInteger, isArbitraryValue]
        }, isArbitraryValue]
      }],
      /**
       * Grid Column Start
       * @see https://tailwindcss.com/docs/grid-column
       */
      "col-start": [{
        "col-start": getNumberWithAutoAndArbitrary()
      }],
      /**
       * Grid Column End
       * @see https://tailwindcss.com/docs/grid-column
       */
      "col-end": [{
        "col-end": getNumberWithAutoAndArbitrary()
      }],
      /**
       * Grid Template Rows
       * @see https://tailwindcss.com/docs/grid-template-rows
       */
      "grid-rows": [{
        "grid-rows": [isAny]
      }],
      /**
       * Grid Row Start / End
       * @see https://tailwindcss.com/docs/grid-row
       */
      "row-start-end": [{
        row: ["auto", {
          span: [isInteger, isArbitraryValue]
        }, isArbitraryValue]
      }],
      /**
       * Grid Row Start
       * @see https://tailwindcss.com/docs/grid-row
       */
      "row-start": [{
        "row-start": getNumberWithAutoAndArbitrary()
      }],
      /**
       * Grid Row End
       * @see https://tailwindcss.com/docs/grid-row
       */
      "row-end": [{
        "row-end": getNumberWithAutoAndArbitrary()
      }],
      /**
       * Grid Auto Flow
       * @see https://tailwindcss.com/docs/grid-auto-flow
       */
      "grid-flow": [{
        "grid-flow": ["row", "col", "dense", "row-dense", "col-dense"]
      }],
      /**
       * Grid Auto Columns
       * @see https://tailwindcss.com/docs/grid-auto-columns
       */
      "auto-cols": [{
        "auto-cols": ["auto", "min", "max", "fr", isArbitraryValue]
      }],
      /**
       * Grid Auto Rows
       * @see https://tailwindcss.com/docs/grid-auto-rows
       */
      "auto-rows": [{
        "auto-rows": ["auto", "min", "max", "fr", isArbitraryValue]
      }],
      /**
       * Gap
       * @see https://tailwindcss.com/docs/gap
       */
      gap: [{
        gap: [gap]
      }],
      /**
       * Gap X
       * @see https://tailwindcss.com/docs/gap
       */
      "gap-x": [{
        "gap-x": [gap]
      }],
      /**
       * Gap Y
       * @see https://tailwindcss.com/docs/gap
       */
      "gap-y": [{
        "gap-y": [gap]
      }],
      /**
       * Justify Content
       * @see https://tailwindcss.com/docs/justify-content
       */
      "justify-content": [{
        justify: ["normal", ...getAlign()]
      }],
      /**
       * Justify Items
       * @see https://tailwindcss.com/docs/justify-items
       */
      "justify-items": [{
        "justify-items": ["start", "end", "center", "stretch"]
      }],
      /**
       * Justify Self
       * @see https://tailwindcss.com/docs/justify-self
       */
      "justify-self": [{
        "justify-self": ["auto", "start", "end", "center", "stretch"]
      }],
      /**
       * Align Content
       * @see https://tailwindcss.com/docs/align-content
       */
      "align-content": [{
        content: ["normal", ...getAlign(), "baseline"]
      }],
      /**
       * Align Items
       * @see https://tailwindcss.com/docs/align-items
       */
      "align-items": [{
        items: ["start", "end", "center", "baseline", "stretch"]
      }],
      /**
       * Align Self
       * @see https://tailwindcss.com/docs/align-self
       */
      "align-self": [{
        self: ["auto", "start", "end", "center", "stretch", "baseline"]
      }],
      /**
       * Place Content
       * @see https://tailwindcss.com/docs/place-content
       */
      "place-content": [{
        "place-content": [...getAlign(), "baseline"]
      }],
      /**
       * Place Items
       * @see https://tailwindcss.com/docs/place-items
       */
      "place-items": [{
        "place-items": ["start", "end", "center", "baseline", "stretch"]
      }],
      /**
       * Place Self
       * @see https://tailwindcss.com/docs/place-self
       */
      "place-self": [{
        "place-self": ["auto", "start", "end", "center", "stretch"]
      }],
      // Spacing
      /**
       * Padding
       * @see https://tailwindcss.com/docs/padding
       */
      p: [{
        p: [padding]
      }],
      /**
       * Padding X
       * @see https://tailwindcss.com/docs/padding
       */
      px: [{
        px: [padding]
      }],
      /**
       * Padding Y
       * @see https://tailwindcss.com/docs/padding
       */
      py: [{
        py: [padding]
      }],
      /**
       * Padding Start
       * @see https://tailwindcss.com/docs/padding
       */
      ps: [{
        ps: [padding]
      }],
      /**
       * Padding End
       * @see https://tailwindcss.com/docs/padding
       */
      pe: [{
        pe: [padding]
      }],
      /**
       * Padding Top
       * @see https://tailwindcss.com/docs/padding
       */
      pt: [{
        pt: [padding]
      }],
      /**
       * Padding Right
       * @see https://tailwindcss.com/docs/padding
       */
      pr: [{
        pr: [padding]
      }],
      /**
       * Padding Bottom
       * @see https://tailwindcss.com/docs/padding
       */
      pb: [{
        pb: [padding]
      }],
      /**
       * Padding Left
       * @see https://tailwindcss.com/docs/padding
       */
      pl: [{
        pl: [padding]
      }],
      /**
       * Margin
       * @see https://tailwindcss.com/docs/margin
       */
      m: [{
        m: [margin]
      }],
      /**
       * Margin X
       * @see https://tailwindcss.com/docs/margin
       */
      mx: [{
        mx: [margin]
      }],
      /**
       * Margin Y
       * @see https://tailwindcss.com/docs/margin
       */
      my: [{
        my: [margin]
      }],
      /**
       * Margin Start
       * @see https://tailwindcss.com/docs/margin
       */
      ms: [{
        ms: [margin]
      }],
      /**
       * Margin End
       * @see https://tailwindcss.com/docs/margin
       */
      me: [{
        me: [margin]
      }],
      /**
       * Margin Top
       * @see https://tailwindcss.com/docs/margin
       */
      mt: [{
        mt: [margin]
      }],
      /**
       * Margin Right
       * @see https://tailwindcss.com/docs/margin
       */
      mr: [{
        mr: [margin]
      }],
      /**
       * Margin Bottom
       * @see https://tailwindcss.com/docs/margin
       */
      mb: [{
        mb: [margin]
      }],
      /**
       * Margin Left
       * @see https://tailwindcss.com/docs/margin
       */
      ml: [{
        ml: [margin]
      }],
      /**
       * Space Between X
       * @see https://tailwindcss.com/docs/space
       */
      "space-x": [{
        "space-x": [space]
      }],
      /**
       * Space Between X Reverse
       * @see https://tailwindcss.com/docs/space
       */
      "space-x-reverse": ["space-x-reverse"],
      /**
       * Space Between Y
       * @see https://tailwindcss.com/docs/space
       */
      "space-y": [{
        "space-y": [space]
      }],
      /**
       * Space Between Y Reverse
       * @see https://tailwindcss.com/docs/space
       */
      "space-y-reverse": ["space-y-reverse"],
      // Sizing
      /**
       * Width
       * @see https://tailwindcss.com/docs/width
       */
      w: [{
        w: ["auto", "min", "max", "fit", "svw", "lvw", "dvw", isArbitraryValue, spacing]
      }],
      /**
       * Min-Width
       * @see https://tailwindcss.com/docs/min-width
       */
      "min-w": [{
        "min-w": [isArbitraryValue, spacing, "min", "max", "fit"]
      }],
      /**
       * Max-Width
       * @see https://tailwindcss.com/docs/max-width
       */
      "max-w": [{
        "max-w": [isArbitraryValue, spacing, "none", "full", "min", "max", "fit", "prose", {
          screen: [isTshirtSize]
        }, isTshirtSize]
      }],
      /**
       * Height
       * @see https://tailwindcss.com/docs/height
       */
      h: [{
        h: [isArbitraryValue, spacing, "auto", "min", "max", "fit", "svh", "lvh", "dvh"]
      }],
      /**
       * Min-Height
       * @see https://tailwindcss.com/docs/min-height
       */
      "min-h": [{
        "min-h": [isArbitraryValue, spacing, "min", "max", "fit", "svh", "lvh", "dvh"]
      }],
      /**
       * Max-Height
       * @see https://tailwindcss.com/docs/max-height
       */
      "max-h": [{
        "max-h": [isArbitraryValue, spacing, "min", "max", "fit", "svh", "lvh", "dvh"]
      }],
      /**
       * Size
       * @see https://tailwindcss.com/docs/size
       */
      size: [{
        size: [isArbitraryValue, spacing, "auto", "min", "max", "fit"]
      }],
      // Typography
      /**
       * Font Size
       * @see https://tailwindcss.com/docs/font-size
       */
      "font-size": [{
        text: ["base", isTshirtSize, isArbitraryLength]
      }],
      /**
       * Font Smoothing
       * @see https://tailwindcss.com/docs/font-smoothing
       */
      "font-smoothing": ["antialiased", "subpixel-antialiased"],
      /**
       * Font Style
       * @see https://tailwindcss.com/docs/font-style
       */
      "font-style": ["italic", "not-italic"],
      /**
       * Font Weight
       * @see https://tailwindcss.com/docs/font-weight
       */
      "font-weight": [{
        font: ["thin", "extralight", "light", "normal", "medium", "semibold", "bold", "extrabold", "black", isArbitraryNumber]
      }],
      /**
       * Font Family
       * @see https://tailwindcss.com/docs/font-family
       */
      "font-family": [{
        font: [isAny]
      }],
      /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */
      "fvn-normal": ["normal-nums"],
      /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */
      "fvn-ordinal": ["ordinal"],
      /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */
      "fvn-slashed-zero": ["slashed-zero"],
      /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */
      "fvn-figure": ["lining-nums", "oldstyle-nums"],
      /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */
      "fvn-spacing": ["proportional-nums", "tabular-nums"],
      /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */
      "fvn-fraction": ["diagonal-fractions", "stacked-fractions"],
      /**
       * Letter Spacing
       * @see https://tailwindcss.com/docs/letter-spacing
       */
      tracking: [{
        tracking: ["tighter", "tight", "normal", "wide", "wider", "widest", isArbitraryValue]
      }],
      /**
       * Line Clamp
       * @see https://tailwindcss.com/docs/line-clamp
       */
      "line-clamp": [{
        "line-clamp": ["none", isNumber, isArbitraryNumber]
      }],
      /**
       * Line Height
       * @see https://tailwindcss.com/docs/line-height
       */
      leading: [{
        leading: ["none", "tight", "snug", "normal", "relaxed", "loose", isLength, isArbitraryValue]
      }],
      /**
       * List Style Image
       * @see https://tailwindcss.com/docs/list-style-image
       */
      "list-image": [{
        "list-image": ["none", isArbitraryValue]
      }],
      /**
       * List Style Type
       * @see https://tailwindcss.com/docs/list-style-type
       */
      "list-style-type": [{
        list: ["none", "disc", "decimal", isArbitraryValue]
      }],
      /**
       * List Style Position
       * @see https://tailwindcss.com/docs/list-style-position
       */
      "list-style-position": [{
        list: ["inside", "outside"]
      }],
      /**
       * Placeholder Color
       * @deprecated since Tailwind CSS v3.0.0
       * @see https://tailwindcss.com/docs/placeholder-color
       */
      "placeholder-color": [{
        placeholder: [colors]
      }],
      /**
       * Placeholder Opacity
       * @see https://tailwindcss.com/docs/placeholder-opacity
       */
      "placeholder-opacity": [{
        "placeholder-opacity": [opacity]
      }],
      /**
       * Text Alignment
       * @see https://tailwindcss.com/docs/text-align
       */
      "text-alignment": [{
        text: ["left", "center", "right", "justify", "start", "end"]
      }],
      /**
       * Text Color
       * @see https://tailwindcss.com/docs/text-color
       */
      "text-color": [{
        text: [colors]
      }],
      /**
       * Text Opacity
       * @see https://tailwindcss.com/docs/text-opacity
       */
      "text-opacity": [{
        "text-opacity": [opacity]
      }],
      /**
       * Text Decoration
       * @see https://tailwindcss.com/docs/text-decoration
       */
      "text-decoration": ["underline", "overline", "line-through", "no-underline"],
      /**
       * Text Decoration Style
       * @see https://tailwindcss.com/docs/text-decoration-style
       */
      "text-decoration-style": [{
        decoration: [...getLineStyles(), "wavy"]
      }],
      /**
       * Text Decoration Thickness
       * @see https://tailwindcss.com/docs/text-decoration-thickness
       */
      "text-decoration-thickness": [{
        decoration: ["auto", "from-font", isLength, isArbitraryLength]
      }],
      /**
       * Text Underline Offset
       * @see https://tailwindcss.com/docs/text-underline-offset
       */
      "underline-offset": [{
        "underline-offset": ["auto", isLength, isArbitraryValue]
      }],
      /**
       * Text Decoration Color
       * @see https://tailwindcss.com/docs/text-decoration-color
       */
      "text-decoration-color": [{
        decoration: [colors]
      }],
      /**
       * Text Transform
       * @see https://tailwindcss.com/docs/text-transform
       */
      "text-transform": ["uppercase", "lowercase", "capitalize", "normal-case"],
      /**
       * Text Overflow
       * @see https://tailwindcss.com/docs/text-overflow
       */
      "text-overflow": ["truncate", "text-ellipsis", "text-clip"],
      /**
       * Text Wrap
       * @see https://tailwindcss.com/docs/text-wrap
       */
      "text-wrap": [{
        text: ["wrap", "nowrap", "balance", "pretty"]
      }],
      /**
       * Text Indent
       * @see https://tailwindcss.com/docs/text-indent
       */
      indent: [{
        indent: getSpacingWithArbitrary()
      }],
      /**
       * Vertical Alignment
       * @see https://tailwindcss.com/docs/vertical-align
       */
      "vertical-align": [{
        align: ["baseline", "top", "middle", "bottom", "text-top", "text-bottom", "sub", "super", isArbitraryValue]
      }],
      /**
       * Whitespace
       * @see https://tailwindcss.com/docs/whitespace
       */
      whitespace: [{
        whitespace: ["normal", "nowrap", "pre", "pre-line", "pre-wrap", "break-spaces"]
      }],
      /**
       * Word Break
       * @see https://tailwindcss.com/docs/word-break
       */
      break: [{
        break: ["normal", "words", "all", "keep"]
      }],
      /**
       * Hyphens
       * @see https://tailwindcss.com/docs/hyphens
       */
      hyphens: [{
        hyphens: ["none", "manual", "auto"]
      }],
      /**
       * Content
       * @see https://tailwindcss.com/docs/content
       */
      content: [{
        content: ["none", isArbitraryValue]
      }],
      // Backgrounds
      /**
       * Background Attachment
       * @see https://tailwindcss.com/docs/background-attachment
       */
      "bg-attachment": [{
        bg: ["fixed", "local", "scroll"]
      }],
      /**
       * Background Clip
       * @see https://tailwindcss.com/docs/background-clip
       */
      "bg-clip": [{
        "bg-clip": ["border", "padding", "content", "text"]
      }],
      /**
       * Background Opacity
       * @deprecated since Tailwind CSS v3.0.0
       * @see https://tailwindcss.com/docs/background-opacity
       */
      "bg-opacity": [{
        "bg-opacity": [opacity]
      }],
      /**
       * Background Origin
       * @see https://tailwindcss.com/docs/background-origin
       */
      "bg-origin": [{
        "bg-origin": ["border", "padding", "content"]
      }],
      /**
       * Background Position
       * @see https://tailwindcss.com/docs/background-position
       */
      "bg-position": [{
        bg: [...getPositions(), isArbitraryPosition]
      }],
      /**
       * Background Repeat
       * @see https://tailwindcss.com/docs/background-repeat
       */
      "bg-repeat": [{
        bg: ["no-repeat", {
          repeat: ["", "x", "y", "round", "space"]
        }]
      }],
      /**
       * Background Size
       * @see https://tailwindcss.com/docs/background-size
       */
      "bg-size": [{
        bg: ["auto", "cover", "contain", isArbitrarySize]
      }],
      /**
       * Background Image
       * @see https://tailwindcss.com/docs/background-image
       */
      "bg-image": [{
        bg: ["none", {
          "gradient-to": ["t", "tr", "r", "br", "b", "bl", "l", "tl"]
        }, isArbitraryImage]
      }],
      /**
       * Background Color
       * @see https://tailwindcss.com/docs/background-color
       */
      "bg-color": [{
        bg: [colors]
      }],
      /**
       * Gradient Color Stops From Position
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */
      "gradient-from-pos": [{
        from: [gradientColorStopPositions]
      }],
      /**
       * Gradient Color Stops Via Position
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */
      "gradient-via-pos": [{
        via: [gradientColorStopPositions]
      }],
      /**
       * Gradient Color Stops To Position
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */
      "gradient-to-pos": [{
        to: [gradientColorStopPositions]
      }],
      /**
       * Gradient Color Stops From
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */
      "gradient-from": [{
        from: [gradientColorStops]
      }],
      /**
       * Gradient Color Stops Via
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */
      "gradient-via": [{
        via: [gradientColorStops]
      }],
      /**
       * Gradient Color Stops To
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */
      "gradient-to": [{
        to: [gradientColorStops]
      }],
      // Borders
      /**
       * Border Radius
       * @see https://tailwindcss.com/docs/border-radius
       */
      rounded: [{
        rounded: [borderRadius]
      }],
      /**
       * Border Radius Start
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-s": [{
        "rounded-s": [borderRadius]
      }],
      /**
       * Border Radius End
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-e": [{
        "rounded-e": [borderRadius]
      }],
      /**
       * Border Radius Top
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-t": [{
        "rounded-t": [borderRadius]
      }],
      /**
       * Border Radius Right
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-r": [{
        "rounded-r": [borderRadius]
      }],
      /**
       * Border Radius Bottom
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-b": [{
        "rounded-b": [borderRadius]
      }],
      /**
       * Border Radius Left
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-l": [{
        "rounded-l": [borderRadius]
      }],
      /**
       * Border Radius Start Start
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-ss": [{
        "rounded-ss": [borderRadius]
      }],
      /**
       * Border Radius Start End
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-se": [{
        "rounded-se": [borderRadius]
      }],
      /**
       * Border Radius End End
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-ee": [{
        "rounded-ee": [borderRadius]
      }],
      /**
       * Border Radius End Start
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-es": [{
        "rounded-es": [borderRadius]
      }],
      /**
       * Border Radius Top Left
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-tl": [{
        "rounded-tl": [borderRadius]
      }],
      /**
       * Border Radius Top Right
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-tr": [{
        "rounded-tr": [borderRadius]
      }],
      /**
       * Border Radius Bottom Right
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-br": [{
        "rounded-br": [borderRadius]
      }],
      /**
       * Border Radius Bottom Left
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-bl": [{
        "rounded-bl": [borderRadius]
      }],
      /**
       * Border Width
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w": [{
        border: [borderWidth]
      }],
      /**
       * Border Width X
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-x": [{
        "border-x": [borderWidth]
      }],
      /**
       * Border Width Y
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-y": [{
        "border-y": [borderWidth]
      }],
      /**
       * Border Width Start
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-s": [{
        "border-s": [borderWidth]
      }],
      /**
       * Border Width End
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-e": [{
        "border-e": [borderWidth]
      }],
      /**
       * Border Width Top
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-t": [{
        "border-t": [borderWidth]
      }],
      /**
       * Border Width Right
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-r": [{
        "border-r": [borderWidth]
      }],
      /**
       * Border Width Bottom
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-b": [{
        "border-b": [borderWidth]
      }],
      /**
       * Border Width Left
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-l": [{
        "border-l": [borderWidth]
      }],
      /**
       * Border Opacity
       * @see https://tailwindcss.com/docs/border-opacity
       */
      "border-opacity": [{
        "border-opacity": [opacity]
      }],
      /**
       * Border Style
       * @see https://tailwindcss.com/docs/border-style
       */
      "border-style": [{
        border: [...getLineStyles(), "hidden"]
      }],
      /**
       * Divide Width X
       * @see https://tailwindcss.com/docs/divide-width
       */
      "divide-x": [{
        "divide-x": [borderWidth]
      }],
      /**
       * Divide Width X Reverse
       * @see https://tailwindcss.com/docs/divide-width
       */
      "divide-x-reverse": ["divide-x-reverse"],
      /**
       * Divide Width Y
       * @see https://tailwindcss.com/docs/divide-width
       */
      "divide-y": [{
        "divide-y": [borderWidth]
      }],
      /**
       * Divide Width Y Reverse
       * @see https://tailwindcss.com/docs/divide-width
       */
      "divide-y-reverse": ["divide-y-reverse"],
      /**
       * Divide Opacity
       * @see https://tailwindcss.com/docs/divide-opacity
       */
      "divide-opacity": [{
        "divide-opacity": [opacity]
      }],
      /**
       * Divide Style
       * @see https://tailwindcss.com/docs/divide-style
       */
      "divide-style": [{
        divide: getLineStyles()
      }],
      /**
       * Border Color
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color": [{
        border: [borderColor]
      }],
      /**
       * Border Color X
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-x": [{
        "border-x": [borderColor]
      }],
      /**
       * Border Color Y
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-y": [{
        "border-y": [borderColor]
      }],
      /**
       * Border Color S
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-s": [{
        "border-s": [borderColor]
      }],
      /**
       * Border Color E
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-e": [{
        "border-e": [borderColor]
      }],
      /**
       * Border Color Top
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-t": [{
        "border-t": [borderColor]
      }],
      /**
       * Border Color Right
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-r": [{
        "border-r": [borderColor]
      }],
      /**
       * Border Color Bottom
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-b": [{
        "border-b": [borderColor]
      }],
      /**
       * Border Color Left
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-l": [{
        "border-l": [borderColor]
      }],
      /**
       * Divide Color
       * @see https://tailwindcss.com/docs/divide-color
       */
      "divide-color": [{
        divide: [borderColor]
      }],
      /**
       * Outline Style
       * @see https://tailwindcss.com/docs/outline-style
       */
      "outline-style": [{
        outline: ["", ...getLineStyles()]
      }],
      /**
       * Outline Offset
       * @see https://tailwindcss.com/docs/outline-offset
       */
      "outline-offset": [{
        "outline-offset": [isLength, isArbitraryValue]
      }],
      /**
       * Outline Width
       * @see https://tailwindcss.com/docs/outline-width
       */
      "outline-w": [{
        outline: [isLength, isArbitraryLength]
      }],
      /**
       * Outline Color
       * @see https://tailwindcss.com/docs/outline-color
       */
      "outline-color": [{
        outline: [colors]
      }],
      /**
       * Ring Width
       * @see https://tailwindcss.com/docs/ring-width
       */
      "ring-w": [{
        ring: getLengthWithEmptyAndArbitrary()
      }],
      /**
       * Ring Width Inset
       * @see https://tailwindcss.com/docs/ring-width
       */
      "ring-w-inset": ["ring-inset"],
      /**
       * Ring Color
       * @see https://tailwindcss.com/docs/ring-color
       */
      "ring-color": [{
        ring: [colors]
      }],
      /**
       * Ring Opacity
       * @see https://tailwindcss.com/docs/ring-opacity
       */
      "ring-opacity": [{
        "ring-opacity": [opacity]
      }],
      /**
       * Ring Offset Width
       * @see https://tailwindcss.com/docs/ring-offset-width
       */
      "ring-offset-w": [{
        "ring-offset": [isLength, isArbitraryLength]
      }],
      /**
       * Ring Offset Color
       * @see https://tailwindcss.com/docs/ring-offset-color
       */
      "ring-offset-color": [{
        "ring-offset": [colors]
      }],
      // Effects
      /**
       * Box Shadow
       * @see https://tailwindcss.com/docs/box-shadow
       */
      shadow: [{
        shadow: ["", "inner", "none", isTshirtSize, isArbitraryShadow]
      }],
      /**
       * Box Shadow Color
       * @see https://tailwindcss.com/docs/box-shadow-color
       */
      "shadow-color": [{
        shadow: [isAny]
      }],
      /**
       * Opacity
       * @see https://tailwindcss.com/docs/opacity
       */
      opacity: [{
        opacity: [opacity]
      }],
      /**
       * Mix Blend Mode
       * @see https://tailwindcss.com/docs/mix-blend-mode
       */
      "mix-blend": [{
        "mix-blend": [...getBlendModes(), "plus-lighter", "plus-darker"]
      }],
      /**
       * Background Blend Mode
       * @see https://tailwindcss.com/docs/background-blend-mode
       */
      "bg-blend": [{
        "bg-blend": getBlendModes()
      }],
      // Filters
      /**
       * Filter
       * @deprecated since Tailwind CSS v3.0.0
       * @see https://tailwindcss.com/docs/filter
       */
      filter: [{
        filter: ["", "none"]
      }],
      /**
       * Blur
       * @see https://tailwindcss.com/docs/blur
       */
      blur: [{
        blur: [blur]
      }],
      /**
       * Brightness
       * @see https://tailwindcss.com/docs/brightness
       */
      brightness: [{
        brightness: [brightness]
      }],
      /**
       * Contrast
       * @see https://tailwindcss.com/docs/contrast
       */
      contrast: [{
        contrast: [contrast]
      }],
      /**
       * Drop Shadow
       * @see https://tailwindcss.com/docs/drop-shadow
       */
      "drop-shadow": [{
        "drop-shadow": ["", "none", isTshirtSize, isArbitraryValue]
      }],
      /**
       * Grayscale
       * @see https://tailwindcss.com/docs/grayscale
       */
      grayscale: [{
        grayscale: [grayscale]
      }],
      /**
       * Hue Rotate
       * @see https://tailwindcss.com/docs/hue-rotate
       */
      "hue-rotate": [{
        "hue-rotate": [hueRotate]
      }],
      /**
       * Invert
       * @see https://tailwindcss.com/docs/invert
       */
      invert: [{
        invert: [invert]
      }],
      /**
       * Saturate
       * @see https://tailwindcss.com/docs/saturate
       */
      saturate: [{
        saturate: [saturate]
      }],
      /**
       * Sepia
       * @see https://tailwindcss.com/docs/sepia
       */
      sepia: [{
        sepia: [sepia]
      }],
      /**
       * Backdrop Filter
       * @deprecated since Tailwind CSS v3.0.0
       * @see https://tailwindcss.com/docs/backdrop-filter
       */
      "backdrop-filter": [{
        "backdrop-filter": ["", "none"]
      }],
      /**
       * Backdrop Blur
       * @see https://tailwindcss.com/docs/backdrop-blur
       */
      "backdrop-blur": [{
        "backdrop-blur": [blur]
      }],
      /**
       * Backdrop Brightness
       * @see https://tailwindcss.com/docs/backdrop-brightness
       */
      "backdrop-brightness": [{
        "backdrop-brightness": [brightness]
      }],
      /**
       * Backdrop Contrast
       * @see https://tailwindcss.com/docs/backdrop-contrast
       */
      "backdrop-contrast": [{
        "backdrop-contrast": [contrast]
      }],
      /**
       * Backdrop Grayscale
       * @see https://tailwindcss.com/docs/backdrop-grayscale
       */
      "backdrop-grayscale": [{
        "backdrop-grayscale": [grayscale]
      }],
      /**
       * Backdrop Hue Rotate
       * @see https://tailwindcss.com/docs/backdrop-hue-rotate
       */
      "backdrop-hue-rotate": [{
        "backdrop-hue-rotate": [hueRotate]
      }],
      /**
       * Backdrop Invert
       * @see https://tailwindcss.com/docs/backdrop-invert
       */
      "backdrop-invert": [{
        "backdrop-invert": [invert]
      }],
      /**
       * Backdrop Opacity
       * @see https://tailwindcss.com/docs/backdrop-opacity
       */
      "backdrop-opacity": [{
        "backdrop-opacity": [opacity]
      }],
      /**
       * Backdrop Saturate
       * @see https://tailwindcss.com/docs/backdrop-saturate
       */
      "backdrop-saturate": [{
        "backdrop-saturate": [saturate]
      }],
      /**
       * Backdrop Sepia
       * @see https://tailwindcss.com/docs/backdrop-sepia
       */
      "backdrop-sepia": [{
        "backdrop-sepia": [sepia]
      }],
      // Tables
      /**
       * Border Collapse
       * @see https://tailwindcss.com/docs/border-collapse
       */
      "border-collapse": [{
        border: ["collapse", "separate"]
      }],
      /**
       * Border Spacing
       * @see https://tailwindcss.com/docs/border-spacing
       */
      "border-spacing": [{
        "border-spacing": [borderSpacing]
      }],
      /**
       * Border Spacing X
       * @see https://tailwindcss.com/docs/border-spacing
       */
      "border-spacing-x": [{
        "border-spacing-x": [borderSpacing]
      }],
      /**
       * Border Spacing Y
       * @see https://tailwindcss.com/docs/border-spacing
       */
      "border-spacing-y": [{
        "border-spacing-y": [borderSpacing]
      }],
      /**
       * Table Layout
       * @see https://tailwindcss.com/docs/table-layout
       */
      "table-layout": [{
        table: ["auto", "fixed"]
      }],
      /**
       * Caption Side
       * @see https://tailwindcss.com/docs/caption-side
       */
      caption: [{
        caption: ["top", "bottom"]
      }],
      // Transitions and Animation
      /**
       * Tranisition Property
       * @see https://tailwindcss.com/docs/transition-property
       */
      transition: [{
        transition: ["none", "all", "", "colors", "opacity", "shadow", "transform", isArbitraryValue]
      }],
      /**
       * Transition Duration
       * @see https://tailwindcss.com/docs/transition-duration
       */
      duration: [{
        duration: getNumberAndArbitrary()
      }],
      /**
       * Transition Timing Function
       * @see https://tailwindcss.com/docs/transition-timing-function
       */
      ease: [{
        ease: ["linear", "in", "out", "in-out", isArbitraryValue]
      }],
      /**
       * Transition Delay
       * @see https://tailwindcss.com/docs/transition-delay
       */
      delay: [{
        delay: getNumberAndArbitrary()
      }],
      /**
       * Animation
       * @see https://tailwindcss.com/docs/animation
       */
      animate: [{
        animate: ["none", "spin", "ping", "pulse", "bounce", isArbitraryValue]
      }],
      // Transforms
      /**
       * Transform
       * @see https://tailwindcss.com/docs/transform
       */
      transform: [{
        transform: ["", "gpu", "none"]
      }],
      /**
       * Scale
       * @see https://tailwindcss.com/docs/scale
       */
      scale: [{
        scale: [scale]
      }],
      /**
       * Scale X
       * @see https://tailwindcss.com/docs/scale
       */
      "scale-x": [{
        "scale-x": [scale]
      }],
      /**
       * Scale Y
       * @see https://tailwindcss.com/docs/scale
       */
      "scale-y": [{
        "scale-y": [scale]
      }],
      /**
       * Rotate
       * @see https://tailwindcss.com/docs/rotate
       */
      rotate: [{
        rotate: [isInteger, isArbitraryValue]
      }],
      /**
       * Translate X
       * @see https://tailwindcss.com/docs/translate
       */
      "translate-x": [{
        "translate-x": [translate]
      }],
      /**
       * Translate Y
       * @see https://tailwindcss.com/docs/translate
       */
      "translate-y": [{
        "translate-y": [translate]
      }],
      /**
       * Skew X
       * @see https://tailwindcss.com/docs/skew
       */
      "skew-x": [{
        "skew-x": [skew]
      }],
      /**
       * Skew Y
       * @see https://tailwindcss.com/docs/skew
       */
      "skew-y": [{
        "skew-y": [skew]
      }],
      /**
       * Transform Origin
       * @see https://tailwindcss.com/docs/transform-origin
       */
      "transform-origin": [{
        origin: ["center", "top", "top-right", "right", "bottom-right", "bottom", "bottom-left", "left", "top-left", isArbitraryValue]
      }],
      // Interactivity
      /**
       * Accent Color
       * @see https://tailwindcss.com/docs/accent-color
       */
      accent: [{
        accent: ["auto", colors]
      }],
      /**
       * Appearance
       * @see https://tailwindcss.com/docs/appearance
       */
      appearance: [{
        appearance: ["none", "auto"]
      }],
      /**
       * Cursor
       * @see https://tailwindcss.com/docs/cursor
       */
      cursor: [{
        cursor: ["auto", "default", "pointer", "wait", "text", "move", "help", "not-allowed", "none", "context-menu", "progress", "cell", "crosshair", "vertical-text", "alias", "copy", "no-drop", "grab", "grabbing", "all-scroll", "col-resize", "row-resize", "n-resize", "e-resize", "s-resize", "w-resize", "ne-resize", "nw-resize", "se-resize", "sw-resize", "ew-resize", "ns-resize", "nesw-resize", "nwse-resize", "zoom-in", "zoom-out", isArbitraryValue]
      }],
      /**
       * Caret Color
       * @see https://tailwindcss.com/docs/just-in-time-mode#caret-color-utilities
       */
      "caret-color": [{
        caret: [colors]
      }],
      /**
       * Pointer Events
       * @see https://tailwindcss.com/docs/pointer-events
       */
      "pointer-events": [{
        "pointer-events": ["none", "auto"]
      }],
      /**
       * Resize
       * @see https://tailwindcss.com/docs/resize
       */
      resize: [{
        resize: ["none", "y", "x", ""]
      }],
      /**
       * Scroll Behavior
       * @see https://tailwindcss.com/docs/scroll-behavior
       */
      "scroll-behavior": [{
        scroll: ["auto", "smooth"]
      }],
      /**
       * Scroll Margin
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-m": [{
        "scroll-m": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Margin X
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-mx": [{
        "scroll-mx": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Margin Y
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-my": [{
        "scroll-my": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Margin Start
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-ms": [{
        "scroll-ms": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Margin End
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-me": [{
        "scroll-me": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Margin Top
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-mt": [{
        "scroll-mt": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Margin Right
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-mr": [{
        "scroll-mr": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Margin Bottom
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-mb": [{
        "scroll-mb": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Margin Left
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-ml": [{
        "scroll-ml": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Padding
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-p": [{
        "scroll-p": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Padding X
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-px": [{
        "scroll-px": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Padding Y
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-py": [{
        "scroll-py": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Padding Start
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-ps": [{
        "scroll-ps": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Padding End
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-pe": [{
        "scroll-pe": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Padding Top
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-pt": [{
        "scroll-pt": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Padding Right
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-pr": [{
        "scroll-pr": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Padding Bottom
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-pb": [{
        "scroll-pb": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Padding Left
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-pl": [{
        "scroll-pl": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Snap Align
       * @see https://tailwindcss.com/docs/scroll-snap-align
       */
      "snap-align": [{
        snap: ["start", "end", "center", "align-none"]
      }],
      /**
       * Scroll Snap Stop
       * @see https://tailwindcss.com/docs/scroll-snap-stop
       */
      "snap-stop": [{
        snap: ["normal", "always"]
      }],
      /**
       * Scroll Snap Type
       * @see https://tailwindcss.com/docs/scroll-snap-type
       */
      "snap-type": [{
        snap: ["none", "x", "y", "both"]
      }],
      /**
       * Scroll Snap Type Strictness
       * @see https://tailwindcss.com/docs/scroll-snap-type
       */
      "snap-strictness": [{
        snap: ["mandatory", "proximity"]
      }],
      /**
       * Touch Action
       * @see https://tailwindcss.com/docs/touch-action
       */
      touch: [{
        touch: ["auto", "none", "manipulation"]
      }],
      /**
       * Touch Action X
       * @see https://tailwindcss.com/docs/touch-action
       */
      "touch-x": [{
        "touch-pan": ["x", "left", "right"]
      }],
      /**
       * Touch Action Y
       * @see https://tailwindcss.com/docs/touch-action
       */
      "touch-y": [{
        "touch-pan": ["y", "up", "down"]
      }],
      /**
       * Touch Action Pinch Zoom
       * @see https://tailwindcss.com/docs/touch-action
       */
      "touch-pz": ["touch-pinch-zoom"],
      /**
       * User Select
       * @see https://tailwindcss.com/docs/user-select
       */
      select: [{
        select: ["none", "text", "all", "auto"]
      }],
      /**
       * Will Change
       * @see https://tailwindcss.com/docs/will-change
       */
      "will-change": [{
        "will-change": ["auto", "scroll", "contents", "transform", isArbitraryValue]
      }],
      // SVG
      /**
       * Fill
       * @see https://tailwindcss.com/docs/fill
       */
      fill: [{
        fill: [colors, "none"]
      }],
      /**
       * Stroke Width
       * @see https://tailwindcss.com/docs/stroke-width
       */
      "stroke-w": [{
        stroke: [isLength, isArbitraryLength, isArbitraryNumber]
      }],
      /**
       * Stroke
       * @see https://tailwindcss.com/docs/stroke
       */
      stroke: [{
        stroke: [colors, "none"]
      }],
      // Accessibility
      /**
       * Screen Readers
       * @see https://tailwindcss.com/docs/screen-readers
       */
      sr: ["sr-only", "not-sr-only"],
      /**
       * Forced Color Adjust
       * @see https://tailwindcss.com/docs/forced-color-adjust
       */
      "forced-color-adjust": [{
        "forced-color-adjust": ["auto", "none"]
      }]
    },
    conflictingClassGroups: {
      overflow: ["overflow-x", "overflow-y"],
      overscroll: ["overscroll-x", "overscroll-y"],
      inset: ["inset-x", "inset-y", "start", "end", "top", "right", "bottom", "left"],
      "inset-x": ["right", "left"],
      "inset-y": ["top", "bottom"],
      flex: ["basis", "grow", "shrink"],
      gap: ["gap-x", "gap-y"],
      p: ["px", "py", "ps", "pe", "pt", "pr", "pb", "pl"],
      px: ["pr", "pl"],
      py: ["pt", "pb"],
      m: ["mx", "my", "ms", "me", "mt", "mr", "mb", "ml"],
      mx: ["mr", "ml"],
      my: ["mt", "mb"],
      size: ["w", "h"],
      "font-size": ["leading"],
      "fvn-normal": ["fvn-ordinal", "fvn-slashed-zero", "fvn-figure", "fvn-spacing", "fvn-fraction"],
      "fvn-ordinal": ["fvn-normal"],
      "fvn-slashed-zero": ["fvn-normal"],
      "fvn-figure": ["fvn-normal"],
      "fvn-spacing": ["fvn-normal"],
      "fvn-fraction": ["fvn-normal"],
      "line-clamp": ["display", "overflow"],
      rounded: ["rounded-s", "rounded-e", "rounded-t", "rounded-r", "rounded-b", "rounded-l", "rounded-ss", "rounded-se", "rounded-ee", "rounded-es", "rounded-tl", "rounded-tr", "rounded-br", "rounded-bl"],
      "rounded-s": ["rounded-ss", "rounded-es"],
      "rounded-e": ["rounded-se", "rounded-ee"],
      "rounded-t": ["rounded-tl", "rounded-tr"],
      "rounded-r": ["rounded-tr", "rounded-br"],
      "rounded-b": ["rounded-br", "rounded-bl"],
      "rounded-l": ["rounded-tl", "rounded-bl"],
      "border-spacing": ["border-spacing-x", "border-spacing-y"],
      "border-w": ["border-w-s", "border-w-e", "border-w-t", "border-w-r", "border-w-b", "border-w-l"],
      "border-w-x": ["border-w-r", "border-w-l"],
      "border-w-y": ["border-w-t", "border-w-b"],
      "border-color": ["border-color-s", "border-color-e", "border-color-t", "border-color-r", "border-color-b", "border-color-l"],
      "border-color-x": ["border-color-r", "border-color-l"],
      "border-color-y": ["border-color-t", "border-color-b"],
      "scroll-m": ["scroll-mx", "scroll-my", "scroll-ms", "scroll-me", "scroll-mt", "scroll-mr", "scroll-mb", "scroll-ml"],
      "scroll-mx": ["scroll-mr", "scroll-ml"],
      "scroll-my": ["scroll-mt", "scroll-mb"],
      "scroll-p": ["scroll-px", "scroll-py", "scroll-ps", "scroll-pe", "scroll-pt", "scroll-pr", "scroll-pb", "scroll-pl"],
      "scroll-px": ["scroll-pr", "scroll-pl"],
      "scroll-py": ["scroll-pt", "scroll-pb"],
      touch: ["touch-x", "touch-y", "touch-pz"],
      "touch-x": ["touch"],
      "touch-y": ["touch"],
      "touch-pz": ["touch"]
    },
    conflictingClassGroupModifiers: {
      "font-size": ["leading"]
    }
  };
};
var twMerge = /* @__PURE__ */ createTailwindMerge(getDefaultConfig);

// src/lib/utils.ts
function cn(...inputs) {
  return twMerge(clsx(inputs));
}

// src/core/viewportDesktopSite.ts
var MOBILE_DESKTOP_SITE_KEY = "copanel_mobile_desktop_site";
function isMobileDesktopSiteEnabled() {
  try {
    return localStorage.getItem(MOBILE_DESKTOP_SITE_KEY) === "1";
  } catch {
    return false;
  }
}
function isLayoutViewportWide(innerWidth = window.innerWidth) {
  return isMobileDesktopSiteEnabled() || innerWidth >= 1024;
}

// src/core/shell/WindowViewportContext.tsx
import { createContext as createContext2, useContext as useContext2, useRef } from "react";
import { jsx as jsx2 } from "react/jsx-runtime";
var WindowViewportContext = createContext2(null);
function useWindowViewport() {
  return useContext2(WindowViewportContext);
}
function useIsWindowedModule() {
  return useWindowViewport()?.isWindowed === true;
}

// src/core/shell/ModuleViewport.tsx
import { jsx as jsx3 } from "react/jsx-runtime";
function ModuleViewport({ children, className, constrained = false }) {
  const { theme } = useAppShellContext();
  const isWindowed = useIsWindowedModule();
  const isDark = theme === "dark";
  const isClassicMobile = !isWindowed && !isLayoutViewportWide();
  return /* @__PURE__ */ jsx3(
    "div",
    {
      className: cn(
        "flex flex-col transition-colors duration-200",
        isWindowed ? "h-full min-h-0" : isClassicMobile ? "min-h-0" : "min-h-screen",
        isDark ? "bg-slate-950 text-slate-100" : "bg-slate-50 text-slate-900",
        !isWindowed && constrained && "mx-auto max-w-7xl",
        className
      ),
      children
    }
  );
}

// src/core/shell/ModuleSidebarLayout.tsx
import { useEffect, useState } from "react";
import * as Icons from "lucide-react";
import { jsx as jsx4, jsxs } from "react/jsx-runtime";
function ModuleSidebarLayout({
  isDark,
  sidebar,
  children,
  mobileTitle,
  className
}) {
  const isWindowed = useIsWindowedModule();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [viewportWide, setViewportWide] = useState(() => isLayoutViewportWide());
  useEffect(() => {
    const onResize = () => setViewportWide(isLayoutViewportWide());
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  }, []);
  const useDrawer = !isWindowed && !viewportWide;
  useEffect(() => {
    if (viewportWide) setSidebarOpen(false);
  }, [viewportWide]);
  const closeSidebar = () => setSidebarOpen(false);
  if (!useDrawer) {
    return /* @__PURE__ */ jsxs("div", { className: cn("flex h-full min-h-0 flex-1 overflow-hidden", className), children: [
      sidebar,
      /* @__PURE__ */ jsx4("div", { className: "flex min-h-0 min-w-0 flex-1 flex-col overflow-hidden", children })
    ] });
  }
  return /* @__PURE__ */ jsxs("div", { className: cn("relative flex h-full min-h-0 flex-1 flex-col overflow-hidden", className), children: [
    /* @__PURE__ */ jsxs(
      "div",
      {
        className: cn(
          "flex shrink-0 items-center gap-2 border-b px-3 py-2.5",
          isDark ? "border-slate-800 bg-slate-950/90" : "border-slate-200 bg-white"
        ),
        children: [
          /* @__PURE__ */ jsx4(
            "button",
            {
              type: "button",
              onClick: () => setSidebarOpen(true),
              className: cn(
                "inline-flex items-center justify-center rounded-lg p-2",
                isDark ? "text-slate-200 hover:bg-slate-800" : "text-slate-700 hover:bg-slate-100"
              ),
              "aria-label": "Open module menu",
              children: /* @__PURE__ */ jsx4(Icons.PanelLeft, { className: "h-5 w-5" })
            }
          ),
          mobileTitle ? /* @__PURE__ */ jsx4("span", { className: cn("truncate text-sm font-semibold", isDark ? "text-slate-100" : "text-slate-900"), children: mobileTitle }) : null
        ]
      }
    ),
    sidebarOpen ? /* @__PURE__ */ jsx4(
      "button",
      {
        type: "button",
        className: "fixed inset-0 z-[60] bg-black/45",
        "aria-label": "Close module menu",
        onClick: closeSidebar
      }
    ) : null,
    /* @__PURE__ */ jsx4(
      "div",
      {
        className: cn(
          "fixed inset-y-0 left-0 z-[61] flex max-w-[min(85vw,280px)] transform shadow-xl transition-transform duration-200 ease-out",
          sidebarOpen ? "translate-x-0" : "-translate-x-full pointer-events-none"
        ),
        onClick: closeSidebar,
        children: sidebar
      }
    ),
    /* @__PURE__ */ jsx4("div", { className: "flex min-h-0 min-w-0 flex-1 flex-col overflow-hidden", children })
  ] });
}

// src/modules/storage_manager/index.tsx
import * as Icons6 from "lucide-react";

// src/modules/storage_manager/PartitionWizard.tsx
import { useCallback as useCallback2, useEffect as useEffect3, useMemo, useRef as useRef3, useState as useState3 } from "react";
import * as Icons5 from "lucide-react";

// src/core/shell/WindowModal.tsx
import { createPortal } from "react-dom";
import * as Icons2 from "lucide-react";
import { jsx as jsx5, jsxs as jsxs2 } from "react/jsx-runtime";
var MAX_W = {
  sm: "max-w-sm",
  md: "max-w-md",
  lg: "max-w-lg",
  xl: "max-w-xl",
  "2xl": "max-w-2xl",
  "4xl": "max-w-4xl",
  "5xl": "max-w-5xl"
};
function WindowModal({
  open,
  onClose,
  children,
  title,
  className,
  maxWidth = "lg",
  closeOnBackdropClick = true
}) {
  const { theme } = useAppShellContext();
  const isDark = theme === "dark";
  const viewport = useWindowViewport();
  if (!open) return null;
  const overlay = /* @__PURE__ */ jsx5(
    "div",
    {
      className: cn(
        "z-[80] flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm",
        viewport?.isWindowed ? "absolute inset-0" : "fixed inset-0"
      ),
      onClick: closeOnBackdropClick ? onClose : void 0,
      children: /* @__PURE__ */ jsxs2(
        "div",
        {
          className: cn(
            "flex w-full flex-col overflow-hidden rounded-2xl border shadow-2xl",
            MAX_W[maxWidth],
            isDark ? "border-slate-700 bg-slate-900 text-slate-100" : "border-slate-200 bg-white text-slate-900",
            className
          ),
          onClick: (e) => e.stopPropagation(),
          children: [
            title && /* @__PURE__ */ jsxs2(
              "div",
              {
                className: cn(
                  "flex items-center justify-between border-b px-4 py-3",
                  isDark ? "border-slate-800" : "border-slate-200"
                ),
                children: [
                  /* @__PURE__ */ jsx5("h3", { className: "text-sm font-bold", children: title }),
                  /* @__PURE__ */ jsx5("button", { type: "button", onClick: onClose, className: "rounded-lg p-1 hover:bg-slate-800/50", "aria-label": "Close", children: /* @__PURE__ */ jsx5(Icons2.X, { className: "h-4 w-4" }) })
                ]
              }
            ),
            children
          ]
        }
      )
    }
  );
  if (viewport?.isWindowed && viewport.viewportRef.current) {
    return createPortal(overlay, viewport.viewportRef.current);
  }
  return createPortal(overlay, document.body);
}

// src/modules/storage_manager/OperationQueuePanel.tsx
import * as Icons3 from "lucide-react";
import { jsx as jsx6, jsxs as jsxs3 } from "react/jsx-runtime";
function OperationQueuePanel({
  queue,
  log,
  isDark,
  busy,
  validationSummary,
  tr,
  onRemove,
  onClear,
  onValidate,
  onApply
}) {
  const border = isDark ? "border-slate-800" : "border-slate-200";
  const muted = isDark ? "text-slate-500" : "text-slate-400";
  return /* @__PURE__ */ jsxs3("aside", { className: `flex w-full shrink-0 flex-col border-t lg:w-52 lg:border-l lg:border-t-0 xl:w-56 ${border} ${isDark ? "bg-slate-950/25" : "bg-[#ececf0]/35"}`, children: [
    /* @__PURE__ */ jsxs3("div", { className: `p-3 border-b ${border}`, children: [
      /* @__PURE__ */ jsx6("p", { className: `text-[10px] font-bold uppercase tracking-wider mb-2 ${muted}`, children: tr.pendingOps }),
      queue.length === 0 ? /* @__PURE__ */ jsx6("p", { className: `text-[11px] ${muted}`, children: tr.pendingEmpty }) : /* @__PURE__ */ jsx6("ul", { className: "space-y-1.5 max-h-40 overflow-y-auto", children: queue.map((item, idx) => /* @__PURE__ */ jsxs3(
        "li",
        {
          className: `flex items-start gap-1.5 rounded-lg border px-2 py-1.5 text-[10px] ${isDark ? "border-slate-700 bg-slate-900/60" : "border-slate-200 bg-white"}`,
          children: [
            /* @__PURE__ */ jsxs3("span", { className: `shrink-0 font-mono font-bold ${isDark ? "text-cyan-400" : "text-cyan-700"}`, children: [
              idx + 1,
              "."
            ] }),
            /* @__PURE__ */ jsx6("span", { className: "flex-1 leading-snug break-words", children: item.summary }),
            /* @__PURE__ */ jsx6(
              "button",
              {
                type: "button",
                disabled: busy,
                onClick: () => onRemove(item.id),
                className: `shrink-0 p-0.5 rounded ${isDark ? "hover:bg-slate-800 text-slate-400" : "hover:bg-slate-100 text-slate-500"}`,
                title: tr.remove,
                children: /* @__PURE__ */ jsx6(Icons3.X, { className: "w-3 h-3" })
              }
            )
          ]
        },
        item.id
      )) }),
      /* @__PURE__ */ jsxs3("div", { className: "flex flex-col gap-1.5 mt-3", children: [
        /* @__PURE__ */ jsx6(
          "button",
          {
            type: "button",
            disabled: busy || queue.length === 0,
            onClick: onValidate,
            className: `w-full py-1.5 rounded-lg text-[10px] font-bold border ${isDark ? "border-slate-600 text-slate-200 hover:bg-slate-800" : "border-slate-300 text-slate-700 hover:bg-white"} disabled:opacity-40`,
            children: busy ? tr.validating : tr.validate
          }
        ),
        /* @__PURE__ */ jsx6(
          "button",
          {
            type: "button",
            disabled: busy || queue.length === 0,
            onClick: onApply,
            className: "w-full py-2 rounded-lg text-[10px] font-bold bg-amber-600 text-white hover:bg-amber-500 disabled:opacity-40",
            children: busy ? tr.applying : tr.applyAll
          }
        ),
        queue.length > 0 && /* @__PURE__ */ jsx6(
          "button",
          {
            type: "button",
            disabled: busy,
            onClick: onClear,
            className: `w-full py-1 text-[10px] font-semibold ${muted} hover:underline disabled:opacity-40`,
            children: tr.clearQueue
          }
        )
      ] }),
      validationSummary && /* @__PURE__ */ jsx6("p", { className: `mt-2 text-[10px] leading-relaxed ${validationSummary.includes("error") ? "text-red-500" : isDark ? "text-emerald-400" : "text-emerald-700"}`, children: validationSummary })
    ] }),
    /* @__PURE__ */ jsxs3("div", { className: "flex-1 p-3 min-h-[120px] overflow-y-auto", children: [
      /* @__PURE__ */ jsx6("p", { className: `text-[10px] font-bold uppercase tracking-wider mb-2 ${muted}`, children: tr.operationLog }),
      log.length === 0 ? /* @__PURE__ */ jsx6("p", { className: `text-[11px] ${muted}`, children: tr.logEmpty }) : /* @__PURE__ */ jsx6("ul", { className: "space-y-2", children: log.map((entry) => /* @__PURE__ */ jsxs3("li", { className: "text-[10px] leading-relaxed", children: [
        /* @__PURE__ */ jsxs3("div", { className: "flex items-center gap-1.5", children: [
          entry.status === "success" ? /* @__PURE__ */ jsx6(Icons3.CheckCircle2, { className: "w-3 h-3 text-emerald-500 shrink-0" }) : entry.status === "failed" ? /* @__PURE__ */ jsx6(Icons3.XCircle, { className: "w-3 h-3 text-red-500 shrink-0" }) : /* @__PURE__ */ jsx6(Icons3.Circle, { className: "w-3 h-3 text-slate-400 shrink-0" }),
          /* @__PURE__ */ jsx6("span", { className: "font-mono font-bold", children: entry.op })
        ] }),
        entry.preview && /* @__PURE__ */ jsx6("p", { className: `font-mono mt-0.5 pl-4 truncate ${muted}`, children: entry.preview }),
        /* @__PURE__ */ jsx6("p", { className: `pl-4 ${entry.status === "failed" ? "text-red-500" : muted}`, children: entry.message })
      ] }, `${entry.index}-${entry.preview}`)) })
    ] })
  ] });
}

// src/modules/storage_manager/DiskMapBar.tsx
import { useCallback, useEffect as useEffect2, useRef as useRef2, useState as useState2 } from "react";
import * as Icons4 from "lucide-react";

// src/modules/storage_manager/diskMapUtils.ts
var SHRINKABLE_FS = /* @__PURE__ */ new Set(["ext4", "ext3", "ext2", "ntfs"]);
function computeResizeBounds(part, layout) {
  const startMib = part.start_mib ?? 1;
  const currentEnd = part.end_mib ?? startMib;
  const diskEndMib = layout.size_bytes / (1024 * 1024);
  let maxEnd = diskEndMib;
  for (const other of layout.partitions) {
    if (other.path === part.path) continue;
    const otherStart = other.start_mib ?? 0;
    if (otherStart > currentEnd + 0.5 && otherStart < maxEnd + 0.5) {
      maxEnd = otherStart - 1;
    }
  }
  for (const gap of layout.unallocated || []) {
    const gapStart = gap.start_mib;
    const gapEnd = gap.end_mib;
    if (gapEnd <= currentEnd + 0.5) continue;
    if (gapStart <= currentEnd + 1 && gapEnd > currentEnd) {
      maxEnd = Math.max(maxEnd, gapEnd);
    }
  }
  const usedMib = part.used_bytes ? Math.ceil(part.used_bytes / (1024 * 1024)) : 0;
  const minShrinkEnd = startMib + Math.max(64, Math.ceil(usedMib * 1.12) + 32);
  const fs = (part.fstype || "").toLowerCase();
  const canShrinkFs = !fs || SHRINKABLE_FS.has(fs);
  const canShrink = Boolean(!part.is_mounted && canShrinkFs && minShrinkEnd < currentEnd - 1);
  const maxEndMib = Math.floor(maxEnd);
  const minEndMib = canShrink ? Math.floor(minShrinkEnd) : Math.ceil(currentEnd);
  const canExtend = maxEndMib > currentEnd + 0.5;
  return {
    minEndMib,
    maxEndMib,
    currentEndMib: currentEnd,
    canExtend,
    canShrink,
    canResize: canExtend || canShrink
  };
}
function clientXToEndMib(clientX, mapRect, diskSizeMib) {
  const ratio = (clientX - mapRect.left) / Math.max(1, mapRect.width);
  return Math.round(Math.max(1, Math.min(diskSizeMib, ratio * diskSizeMib)));
}
function clampEndMib(value, bounds) {
  return Math.max(bounds.minEndMib, Math.min(bounds.maxEndMib, Math.round(value)));
}
function isShrinkEnd(currentEndMib, newEndMib) {
  return newEndMib < currentEndMib - 0.5;
}

// src/modules/storage_manager/DiskMapBar.tsx
import { jsx as jsx7, jsxs as jsxs4 } from "react/jsx-runtime";
var FS_COLORS = {
  ext4: "bg-emerald-500",
  xfs: "bg-teal-500",
  btrfs: "bg-lime-500",
  vfat: "bg-sky-500",
  exfat: "bg-blue-500",
  ntfs: "bg-indigo-500",
  hfsplus: "bg-violet-500",
  swap: "bg-purple-500",
  lvm2: "bg-amber-500",
  unknown: "bg-slate-500"
};
function fsColor(fstype) {
  const key = (fstype || "unknown").toLowerCase();
  return FS_COLORS[key] || FS_COLORS.unknown;
}
function displayName(part) {
  if (part.label) return part.label;
  if (part.mountpoint) return part.mountpoint;
  if (part.name) return part.name;
  return `#${part.number}`;
}
function DiskMapBar({
  layout,
  mapSegments,
  selectedPath,
  canMutate,
  canCreatePartition,
  isUninitialized,
  isDark,
  formatBytes: formatBytes2,
  language,
  diskPath,
  tr,
  onSelectPartition,
  onClickFree,
  onDragResizeEnd
}) {
  const mapRef = useRef2(null);
  const [drag, setDrag] = useState2(null);
  const diskMib = layout.size_bytes / (1024 * 1024);
  const startDrag = useCallback(
    (e, part) => {
      if (!canMutate || !part.path || part.is_mounted) return;
      const bounds = computeResizeBounds(part, layout);
      if (!bounds.canResize) return;
      e.stopPropagation();
      e.preventDefault();
      e.currentTarget.setPointerCapture(e.pointerId);
      setDrag({
        partPath: part.path,
        previewEndMib: part.end_mib ?? bounds.minEndMib,
        bounds
      });
    },
    [canMutate, layout]
  );
  useEffect2(() => {
    if (!drag) return;
    const onMove = (e) => {
      if (!mapRef.current) return;
      const rect = mapRef.current.getBoundingClientRect();
      const absolute = clientXToEndMib(e.clientX, rect, diskMib);
      setDrag(
        (prev) => prev ? { ...prev, previewEndMib: clampEndMib(absolute, prev.bounds) } : null
      );
    };
    const onUp = () => {
      setDrag((prev) => {
        if (prev) {
          const part = layout.partitions.find((p) => p.path === prev.partPath);
          const currentEnd = part?.end_mib ?? 0;
          if (part && Math.abs(prev.previewEndMib - currentEnd) > 0.5) {
            onDragResizeEnd(part, prev.previewEndMib);
          }
        }
        return null;
      });
    };
    window.addEventListener("pointermove", onMove);
    window.addEventListener("pointerup", onUp);
    return () => {
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerup", onUp);
    };
  }, [drag, diskMib, layout.partitions, onDragResizeEnd]);
  const previewPart = drag ? layout.partitions.find((p) => p.path === drag.partPath) : null;
  return /* @__PURE__ */ jsxs4("div", { children: [
    /* @__PURE__ */ jsxs4(
      "div",
      {
        ref: mapRef,
        className: `rounded-xl border p-2 shadow-inner ${isDark ? "border-slate-700/80 bg-slate-950" : "border-slate-200 bg-white"}`,
        children: [
          /* @__PURE__ */ jsx7("div", { className: "flex h-16 gap-0.5 overflow-hidden rounded-lg relative", children: mapSegments.map((seg) => {
            if (seg.kind === "free") {
              const gap = seg.gap;
              return /* @__PURE__ */ jsx7(
                "button",
                {
                  type: "button",
                  disabled: !canCreatePartition || !gap,
                  onClick: () => gap && onClickFree(gap.start_mib, gap.end_mib),
                  style: { width: `${seg.widthPct}%` },
                  className: `relative min-w-[2px] h-full flex items-center justify-center text-[9px] font-bold border border-dashed transition ${canCreatePartition && gap ? isDark ? "bg-slate-900 border-cyan-700/50 text-cyan-400 hover:bg-cyan-950/50 cursor-pointer" : "bg-slate-100 border-cyan-300 text-cyan-700 hover:bg-cyan-50 cursor-pointer" : isDark ? "bg-slate-900 border-slate-600 text-slate-500" : "bg-slate-100 border-slate-300 text-slate-400"}`,
                  title: isUninitialized ? tr.rawDiskLabel : tr.unallocated,
                  children: /* @__PURE__ */ jsx7("span", { className: "truncate px-0.5 hidden sm:inline", children: isUninitialized ? tr.rawDiskLabel : tr.unallocated })
                },
                seg.key
              );
            }
            const part = seg.part;
            const selectedHere = part.path === selectedPath;
            const used = part.used_percent ?? 0;
            const isDragging = drag?.partPath === part.path;
            const bounds = computeResizeBounds(part, layout);
            const showHandle = selectedHere && canMutate && !part.is_mounted && bounds.canResize;
            let displayWidthPct = seg.widthPct;
            if (isDragging && previewPart && drag && layout.size_bytes) {
              const previewBytes = drag.previewEndMib * 1024 * 1024;
              const startBytes = (part.start_mib ?? 0) * 1024 * 1024;
              displayWidthPct = Math.max(0.5, (previewBytes - startBytes) / layout.size_bytes * 100);
            }
            return /* @__PURE__ */ jsxs4(
              "div",
              {
                style: { width: `${displayWidthPct}%` },
                className: `relative min-w-[24px] h-full ${isDragging ? "z-20" : ""}`,
                children: [
                  /* @__PURE__ */ jsxs4(
                    "button",
                    {
                      type: "button",
                      onClick: () => part.path && onSelectPartition(part.path),
                      className: `relative w-full h-full text-left overflow-hidden transition ring-2 ${selectedHere ? "ring-amber-400 z-10" : "ring-transparent hover:ring-cyan-500/50"} ${isDark ? "bg-slate-800" : "bg-slate-100"} ${isDragging ? "ring-cyan-400" : ""}`,
                      title: `${displayName(part)} \xB7 ${part.fstype_label || part.fstype || "\u2014"}`,
                      children: [
                        /* @__PURE__ */ jsx7("div", { className: `absolute inset-x-0 bottom-0 h-1.5 ${fsColor(part.fstype)} opacity-80` }),
                        /* @__PURE__ */ jsx7(
                          "div",
                          {
                            className: "absolute inset-x-0 bottom-1.5 h-2 bg-cyan-500/70",
                            style: { width: `${Math.min(100, used)}%` }
                          }
                        ),
                        /* @__PURE__ */ jsxs4("div", { className: "relative p-1 h-full flex flex-col justify-between", children: [
                          /* @__PURE__ */ jsx7("span", { className: `text-[9px] font-bold truncate leading-tight ${isDark ? "text-white" : "text-slate-800"}`, children: displayName(part) }),
                          /* @__PURE__ */ jsxs4("span", { className: `text-[8px] font-mono truncate ${isDark ? "text-slate-400" : "text-slate-500"}`, children: [
                            part.fstype_label || part.fstype || "\u2014",
                            part.size_bytes ? ` \xB7 ${formatBytes2(part.size_bytes, language)}` : ""
                          ] }),
                          part.is_boot && /* @__PURE__ */ jsx7(Icons4.Flag, { className: "absolute top-1 right-1 w-2.5 h-2.5 text-amber-400" })
                        ] })
                      ]
                    }
                  ),
                  showHandle && /* @__PURE__ */ jsx7(
                    "div",
                    {
                      role: "separator",
                      "aria-orientation": "vertical",
                      onPointerDown: (e) => startDrag(e, part),
                      className: `absolute top-0 right-0 w-2 h-full cursor-ew-resize z-30 flex items-center justify-center ${isDark ? "hover:bg-cyan-500/40" : "hover:bg-cyan-500/30"}`,
                      title: tr.dragResizeHint,
                      children: /* @__PURE__ */ jsx7("div", { className: `w-0.5 h-8 rounded-full ${isDark ? "bg-cyan-400" : "bg-cyan-600"}` })
                    }
                  )
                ]
              },
              seg.key
            );
          }) }),
          /* @__PURE__ */ jsxs4("div", { className: `mt-1.5 flex flex-wrap items-center justify-between gap-2 text-[9px] font-mono ${isDark ? "text-slate-500" : "text-slate-400"}`, children: [
            /* @__PURE__ */ jsxs4("span", { children: [
              diskPath,
              " \xB7 ",
              formatBytes2(layout.size_bytes, language)
            ] }),
            drag && previewPart && /* @__PURE__ */ jsx7("span", { className: isDark ? "text-cyan-400" : "text-cyan-700", children: isShrinkEnd(previewPart.end_mib ?? 0, drag.previewEndMib) ? tr.shrinkPreview(drag.previewEndMib) : tr.extendPreview(drag.previewEndMib) })
          ] })
        ]
      }
    ),
    canMutate && !drag && /* @__PURE__ */ jsx7("p", { className: `mt-1 text-[9px] ${isDark ? "text-slate-500" : "text-slate-400"}`, children: tr.dragResizeHint })
  ] });
}

// src/modules/storage_manager/operationTypes.ts
function newPendingId() {
  return `op-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;
}
function toApiPayload(op) {
  return {
    op: op.op,
    disk_name: op.disk_name,
    device: op.device,
    confirm_token: op.confirm_token,
    params: op.params
  };
}

// src/modules/storage_manager/PartitionWizard.tsx
import { Fragment, jsx as jsx8, jsxs as jsxs5 } from "react/jsx-runtime";
var FORMAT_FS_OPTIONS = [
  { value: "ext4", label: "ext4" },
  { value: "xfs", label: "XFS" },
  { value: "btrfs", label: "Btrfs" },
  { value: "vfat", label: "FAT32" },
  { value: "exfat", label: "exFAT" },
  { value: "ntfs", label: "NTFS" },
  { value: "hfsplus", label: "HFS+" }
];
var PARTITION_TYPE_OPTIONS = [
  { value: "linux", labelKey: "typeLinux" },
  { value: "efi", labelKey: "typeEfi" },
  { value: "swap", labelKey: "typeSwap" },
  { value: "ntfs", labelKey: "typeNtfs" },
  { value: "lvm", labelKey: "typeLvm" }
];
function buildLayoutFromDisks(diskName, disks, volumes) {
  const disk = disks.find((d) => d.name === diskName);
  if (!disk) return null;
  const parts = disk.partitions || [];
  let cursor = 1;
  const partitions = parts.map((part, idx) => {
    const usage = volumes.find((v) => v.device === part.path);
    const sizeMib = part.size_bytes / (1024 * 1024);
    const start = cursor;
    const end = start + sizeMib;
    cursor = end;
    return {
      number: idx + 1,
      name: part.name,
      path: part.path,
      start_mib: start,
      end_mib: end,
      size_bytes: part.size_bytes,
      fstype: part.fstype,
      fstype_label: part.fstype_label,
      mountpoint: part.mountpoint,
      flags: [],
      is_boot: false,
      label: null,
      used_percent: usage?.percent ?? null,
      used_bytes: usage?.used ?? null,
      free_bytes: usage?.free ?? null,
      is_mounted: Boolean(part.mountpoint)
    };
  });
  const diskMib = disk.size_bytes / (1024 * 1024);
  const unallocated = [];
  if (cursor < diskMib - 1) {
    unallocated.push({ start_mib: cursor, end_mib: diskMib, size_mib: diskMib - cursor });
  }
  return {
    disk: diskName,
    is_system_disk: disk.is_system_disk,
    size_bytes: disk.size_bytes,
    model: disk.model,
    partition_table: void 0,
    disk_state: parts.length ? "partitioned" : "uninitialized",
    partitions,
    unallocated
  };
}
function isPartitionsApiMissing(err) {
  const msg = err instanceof Error ? err.message : String(err);
  const lower = msg.toLowerCase();
  if (lower.includes("could not resolve partition number")) return false;
  if (lower.includes("confirmation must match")) return false;
  return msg === "Not Found" || msg.includes("API route not found") || lower.includes("service unavailable") || lower.includes("parted") && lower.includes("not found");
}
function displayName2(part) {
  if (part.label) return part.label;
  if (part.mountpoint) return part.mountpoint;
  if (part.name) return part.name;
  return `#${part.number}`;
}
function PartitionWizard({
  disks,
  volumes,
  language,
  isDark,
  actionLoading,
  actionErr,
  formatBytes: formatBytes2,
  fetchJson,
  runAction,
  postJson,
  tr
}) {
  const [activeDisk, setActiveDisk] = useState3("");
  const [layout, setLayout] = useState3(null);
  const [layoutLoading, setLayoutLoading] = useState3(false);
  const [layoutErr, setLayoutErr] = useState3(null);
  const [selectedPath, setSelectedPath] = useState3(null);
  const [modal, setModal] = useState3(null);
  const [partStart, setPartStart] = useState3("1MiB");
  const [partEnd, setPartEnd] = useState3("100%");
  const [partType, setPartType] = useState3("linux");
  const [initTableType, setInitTableType] = useState3("gpt");
  const [initConfirm, setInitConfirm] = useState3("");
  const [partConfirm, setPartConfirm] = useState3("");
  const [formatFs, setFormatFs] = useState3("ext4");
  const [formatLabel, setFormatLabel] = useState3("");
  const [formatConfirm, setFormatConfirm] = useState3("");
  const [resizeEnd, setResizeEnd] = useState3("100%");
  const [resizeGrowFs, setResizeGrowFs] = useState3(true);
  const [resizeShrinkFs, setResizeShrinkFs] = useState3(true);
  const [resizeConfirm, setResizeConfirm] = useState3("");
  const [labelText, setLabelText] = useState3("");
  const [labelConfirm, setLabelConfirm] = useState3("");
  const [deleteConfirm, setDeleteConfirm] = useState3("");
  const [bootConfirm, setBootConfirm] = useState3("");
  const [mountPoint, setMountPoint] = useState3("/mnt/data");
  const [mountFs, setMountFs] = useState3("ntfs");
  const [mountPersist, setMountPersist] = useState3(true);
  const partitionsApiAvailable = useRef3(null);
  const [pendingQueue, setPendingQueue] = useState3([]);
  const [opLog, setOpLog] = useState3([]);
  const [queueBusy, setQueueBusy] = useState3(false);
  const [validationSummary, setValidationSummary] = useState3(null);
  const enqueue = useCallback2((entry) => {
    setPendingQueue((prev) => [...prev, { ...entry, id: newPendingId() }]);
    setValidationSummary(null);
    setModal(null);
  }, []);
  const removeFromQueue = useCallback2((id) => {
    setPendingQueue((prev) => prev.filter((item) => item.id !== id));
    setValidationSummary(null);
  }, []);
  const clearQueue = useCallback2(() => {
    setPendingQueue([]);
    setValidationSummary(null);
  }, []);
  const handleValidateQueue = useCallback2(async () => {
    if (pendingQueue.length === 0) return;
    setQueueBusy(true);
    setValidationSummary(null);
    try {
      const data = await postJson(
        "/api/storage_manager/operations/validate",
        { operations: pendingQueue.map(toApiPayload) }
      );
      setValidationSummary(
        data.valid ? `${tr.queue.validationOk} \u2014 ${data.summary}` : `${tr.queue.validationFailed} \u2014 ${data.summary}`
      );
    } catch (err) {
      setValidationSummary(err instanceof Error ? err.message : String(err));
    } finally {
      setQueueBusy(false);
    }
  }, [pendingQueue, postJson, tr.queue.validationFailed, tr.queue.validationOk]);
  const applyCreateDefaults = useCallback2((diskName) => {
    setPartConfirm(diskName);
    const firstFree = layout?.unallocated?.[0];
    if (firstFree) {
      setPartStart(`${Math.ceil(firstFree.start_mib)}MiB`);
      setPartEnd(`${Math.floor(firstFree.end_mib)}MiB`);
    } else {
      setPartStart("1MiB");
      setPartEnd("100%");
    }
  }, [disks, layout]);
  useEffect3(() => {
    if (!activeDisk && disks.length > 0) {
      setActiveDisk(disks[0].name);
    }
  }, [disks, activeDisk]);
  const loadLayout = useCallback2(async (diskName) => {
    if (!diskName) return;
    setLayoutLoading(true);
    setLayoutErr(null);
    if (partitionsApiAvailable.current === false) {
      const fallback = buildLayoutFromDisks(diskName, disks, volumes);
      setLayout(fallback ?? null);
      if (!fallback) {
        setLayoutErr("Failed to load layout");
      }
      setLayoutLoading(false);
      return;
    }
    try {
      const data = await fetchJson(
        `/api/storage_manager/disks/${encodeURIComponent(diskName)}/partitions`
      );
      partitionsApiAvailable.current = true;
      const disk = disks.find((d) => d.name === diskName);
      const apiEmpty = (data.partitions?.length ?? 0) === 0;
      const diskHasParts = (disk?.partitions?.length ?? 0) > 0;
      if (apiEmpty && diskHasParts) {
        const fallback = buildLayoutFromDisks(diskName, disks, volumes);
        setLayout(fallback ?? data);
      } else {
        setLayout(data);
      }
    } catch (err) {
      if (isPartitionsApiMissing(err)) {
        partitionsApiAvailable.current = false;
        const fallback = buildLayoutFromDisks(diskName, disks, volumes);
        if (fallback) {
          setLayout(fallback);
          return;
        }
      }
      setLayout(null);
      setLayoutErr(err instanceof Error ? err.message : "Failed to load layout");
    } finally {
      setLayoutLoading(false);
    }
  }, [fetchJson, disks, volumes]);
  useEffect3(() => {
    if (activeDisk) {
      setSelectedPath(null);
      loadLayout(activeDisk);
    }
  }, [activeDisk, loadLayout]);
  const selected = useMemo(
    () => layout?.partitions.find((p) => p.path === selectedPath) ?? null,
    [layout, selectedPath]
  );
  const diskMeta = useMemo(
    () => disks.find((d) => d.name === activeDisk),
    [disks, activeDisk]
  );
  const canMutate = layout && !layout.is_system_disk;
  const diskState = layout?.disk_state ?? (!layout?.partition_table && !layout?.partitions?.length ? "uninitialized" : !layout?.partitions?.length ? "empty_table" : "partitioned");
  const isUninitialized = diskState === "uninitialized";
  const isEmptyTable = diskState === "empty_table";
  const canCreatePartition = canMutate && !isUninitialized;
  const hasSelection = Boolean(selected?.path && selected?.name);
  const openModal = (kind) => {
    if (kind === "initDisk") {
      if (!canMutate) return;
      setInitConfirm("");
      setInitTableType("gpt");
      setModal(kind);
      return;
    }
    if (!canMutate && kind !== "mount" && kind !== "unmount") return;
    if (kind === "create" && isUninitialized) return;
    if (kind !== "create" && !hasSelection) return;
    setModal(kind);
    if (selected?.name) {
      setFormatConfirm("");
      setDeleteConfirm("");
      setResizeConfirm("");
      setLabelConfirm("");
      setBootConfirm("");
      setResizeEnd("100%");
      setLabelText(selected.label || "");
    }
    if (kind === "create") {
      applyCreateDefaults(activeDisk);
      setPartType("linux");
    }
    if (kind === "mount" && selected) {
      const inferred = selected.fstype || "ntfs";
      setMountFs(FORMAT_FS_OPTIONS.some((o) => o.value === inferred) ? inferred : "ntfs");
      const partName = selected.name || selected.path?.replace("/dev/", "") || "data";
      setMountPoint(`/mnt/${partName}`);
      setMountPersist(false);
    }
  };
  const closeModal = () => setModal(null);
  const openCreateFromGap = useCallback2((startMib, endMib) => {
    if (!canMutate || isUninitialized) return;
    setPartStart(`${Math.ceil(startMib)}MiB`);
    setPartEnd(`${Math.floor(endMib)}MiB`);
    setPartConfirm(activeDisk);
    setPartType("linux");
    setModal("create");
  }, [activeDisk, canMutate, isUninitialized]);
  const handleDragResizeEnd = useCallback2((part, newEndMib) => {
    if (!part.name || !part.path) return;
    const currentEnd = part.end_mib ?? 0;
    const shrink = newEndMib < currentEnd - 0.5;
    enqueue({
      op: "resize",
      device: part.path,
      confirm_token: part.name,
      params: {
        end: `${newEndMib}MiB`,
        grow_filesystem: !shrink,
        shrink_filesystem: shrink
      },
      summary: shrink ? `${tr.shrinkPartition}: ${part.name} \u2192 ${newEndMib}MiB` : `${tr.resizePartition}: ${part.name} \u2192 ${newEndMib}MiB`
    });
    setSelectedPath(part.path);
  }, [enqueue, tr.resizePartition, tr.shrinkPartition]);
  const handleApplyQueue = useCallback2(async () => {
    if (pendingQueue.length === 0) return;
    setQueueBusy(true);
    setValidationSummary(null);
    try {
      const data = await postJson("/api/storage_manager/operations/apply", {
        operations: pendingQueue.map(toApiPayload)
      });
      setOpLog(
        (data.log || []).map((entry) => ({
          index: entry.index,
          op: entry.op,
          status: entry.status === "success" ? "success" : "failed",
          preview: entry.preview,
          message: entry.message
        }))
      );
      if (data.completed) {
        setPendingQueue([]);
        setValidationSummary(tr.queue.validationOk);
        await loadLayout(activeDisk);
      } else {
        setValidationSummary(
          `${tr.queue.validationFailed} \u2014 ${data.applied}/${pendingQueue.length}`
        );
      }
    } catch (err) {
      setValidationSummary(err instanceof Error ? err.message : String(err));
    } finally {
      setQueueBusy(false);
    }
  }, [activeDisk, loadLayout, pendingQueue, postJson, tr.queue.validationFailed, tr.queue.validationOk]);
  const modalTitle = useMemo(() => {
    if (!modal) return void 0;
    const titles = {
      initDisk: tr.initializeDiskTitle,
      create: tr.createPartition,
      format: tr.formatPartition,
      delete: tr.deletePartition,
      resize: tr.resizePartition,
      label: tr.changeLabel,
      boot: tr.setBoot,
      mount: tr.mountVolume,
      unmount: tr.unmountVolume
    };
    return titles[modal];
  }, [modal, tr]);
  const refreshAfter = async (fn) => {
    const ok = await runAction(async () => {
      const result = await fn();
      await loadLayout(activeDisk);
      return result;
    });
    if (ok) closeModal();
  };
  const mapSegments = useMemo(() => {
    if (!layout || !layout.size_bytes) return [];
    const total = layout.size_bytes;
    const raw = [];
    for (const part of layout.partitions) {
      const size = part.size_bytes || 0;
      raw.push({
        key: part.path || `p${part.number}`,
        kind: "part",
        start: part.start_mib ?? 0,
        widthPct: Math.max(0.5, size / total * 100),
        part,
        label: displayName2(part)
      });
    }
    for (const gap of layout.unallocated || []) {
      const gapBytes = gap.size_mib * 1024 * 1024;
      raw.push({
        key: `free-${gap.start_mib}`,
        kind: "free",
        start: gap.start_mib,
        widthPct: Math.max(0.5, gapBytes / total * 100),
        gap,
        label: isUninitialized ? tr.rawDiskLabel : tr.unallocated
      });
    }
    return raw.sort((a, b) => a.start - b.start);
  }, [layout, tr.unallocated, tr.rawDiskLabel, isUninitialized]);
  const actionBtn = (icon, label, onClick, disabled, danger) => /* @__PURE__ */ jsxs5(
    "button",
    {
      type: "button",
      disabled: disabled || actionLoading,
      onClick,
      className: `flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-left text-[11px] font-medium transition ${disabled ? isDark ? "cursor-not-allowed opacity-40 text-slate-500" : "cursor-not-allowed opacity-40 text-slate-400" : danger ? isDark ? "text-red-300 hover:bg-red-950/40" : "text-red-600 hover:bg-red-50" : isDark ? "text-slate-200 hover:bg-slate-800/70" : "text-slate-700 hover:bg-black/[0.04]"}`,
      children: [
        icon,
        /* @__PURE__ */ jsx8("span", { children: label })
      ]
    }
  );
  if (disks.length === 0) {
    return /* @__PURE__ */ jsx8("p", { className: `p-8 text-center text-xs ${isDark ? "text-slate-500" : "text-slate-400"}`, children: tr.noDisks });
  }
  return /* @__PURE__ */ jsxs5("div", { className: "flex h-full min-h-0 flex-col", children: [
    /* @__PURE__ */ jsx8("div", { className: `shrink-0 border-b px-3 py-2 ${isDark ? "border-slate-800 bg-slate-950/30" : "border-slate-200/90 bg-[#ececf0]/50"}`, children: /* @__PURE__ */ jsx8("div", { className: `inline-flex max-w-full flex-wrap gap-0.5 rounded-lg p-0.5 ${isDark ? "bg-slate-900/80" : "bg-black/[0.06]"}`, children: disks.map((disk) => {
      const active = disk.name === activeDisk;
      return /* @__PURE__ */ jsxs5(
        "button",
        {
          type: "button",
          onClick: () => setActiveDisk(disk.name),
          className: `rounded-md px-3 py-1.5 text-[11px] font-medium transition ${active ? isDark ? "bg-slate-700 text-white shadow-sm" : "bg-white text-slate-900 shadow-sm" : isDark ? "text-slate-400 hover:text-slate-200" : "text-slate-600 hover:text-slate-900"}`,
          children: [
            /* @__PURE__ */ jsx8("span", { className: "font-mono font-semibold", children: disk.name }),
            /* @__PURE__ */ jsx8("span", { className: "ml-1.5 font-normal opacity-70", children: formatBytes2(disk.size_bytes, language) }),
            disk.is_system_disk && /* @__PURE__ */ jsx8("span", { className: `ml-1 rounded px-1 text-[9px] ${active ? isDark ? "bg-white/15" : "bg-slate-100" : isDark ? "bg-blue-500/20 text-blue-300" : "bg-blue-100 text-blue-700"}`, children: tr.systemDisk })
          ]
        },
        disk.name
      );
    }) }) }),
    /* @__PURE__ */ jsxs5("div", { className: "flex min-h-0 flex-1 flex-col lg:flex-row", children: [
      /* @__PURE__ */ jsxs5("aside", { className: `w-full shrink-0 space-y-0.5 border-b p-2 lg:w-44 lg:border-b-0 lg:border-r xl:w-48 ${isDark ? "border-slate-800 bg-slate-950/25" : "border-slate-200/90 bg-[#ececf0]/40"}`, children: [
        /* @__PURE__ */ jsx8("p", { className: `text-[10px] font-bold uppercase tracking-wider mb-2 ${isDark ? "text-slate-500" : "text-slate-400"}`, children: tr.diskOperations }),
        actionBtn(
          /* @__PURE__ */ jsx8(Icons5.HardDrive, { className: "w-3.5 h-3.5" }),
          tr.initializeDisk,
          () => openModal("initDisk"),
          !canMutate || diskState === "partitioned",
          false
        ),
        /* @__PURE__ */ jsx8("p", { className: `text-[10px] font-bold uppercase tracking-wider mb-2 mt-3 pt-2 border-t ${isDark ? "text-slate-500 border-slate-800" : "text-slate-400 border-slate-200"}`, children: tr.operations }),
        actionBtn(/* @__PURE__ */ jsx8(Icons5.Plus, { className: "w-3.5 h-3.5" }), tr.createPartition, () => openModal("create"), !canCreatePartition),
        actionBtn(/* @__PURE__ */ jsx8(Icons5.Eraser, { className: "w-3.5 h-3.5" }), tr.formatPartition, () => openModal("format"), !canMutate || !hasSelection || selected?.is_mounted),
        actionBtn(/* @__PURE__ */ jsx8(Icons5.Trash2, { className: "w-3.5 h-3.5" }), tr.deletePartition, () => openModal("delete"), !canMutate || !hasSelection || selected?.is_mounted, true),
        actionBtn(/* @__PURE__ */ jsx8(Icons5.MoveHorizontal, { className: "w-3.5 h-3.5" }), tr.resizePartition, () => openModal("resize"), !canMutate || !hasSelection),
        actionBtn(/* @__PURE__ */ jsx8(Icons5.Tag, { className: "w-3.5 h-3.5" }), tr.changeLabel, () => openModal("label"), !canMutate || !hasSelection || !selected?.fstype),
        actionBtn(/* @__PURE__ */ jsx8(Icons5.Flag, { className: "w-3.5 h-3.5" }), tr.setBoot, () => openModal("boot"), !canMutate || !hasSelection),
        actionBtn(/* @__PURE__ */ jsx8(Icons5.FolderOpen, { className: "w-3.5 h-3.5" }), tr.mountVolume, () => openModal("mount"), !hasSelection || selected?.is_mounted || selected?.mountable === false),
        actionBtn(/* @__PURE__ */ jsx8(Icons5.FolderMinus, { className: "w-3.5 h-3.5" }), tr.unmountVolume, () => openModal("unmount"), !hasSelection || !selected?.is_mounted),
        layout?.is_system_disk && /* @__PURE__ */ jsx8("p", { className: `text-[10px] mt-3 px-1 ${isDark ? "text-amber-400/80" : "text-amber-700"}`, children: tr.protectedNote })
      ] }),
      /* @__PURE__ */ jsxs5("div", { className: "flex min-h-0 min-w-0 flex-1 flex-col overflow-hidden", children: [
        /* @__PURE__ */ jsxs5("div", { className: `shrink-0 border-b p-3 ${isDark ? "border-slate-800" : "border-slate-200/90"}`, children: [
          /* @__PURE__ */ jsxs5("div", { className: "flex items-center justify-between gap-2 mb-3", children: [
            /* @__PURE__ */ jsx8("p", { className: `text-[10px] font-bold uppercase tracking-wider ${isDark ? "text-slate-500" : "text-slate-400"}`, children: tr.diskMap }),
            diskMeta && /* @__PURE__ */ jsxs5("span", { className: `text-[10px] truncate ${isDark ? "text-slate-400" : "text-slate-500"}`, children: [
              diskMeta.model,
              " \xB7 ",
              isUninitialized ? tr.rawDiskLabel : layout?.partition_table?.toUpperCase() || "\u2014"
            ] })
          ] }),
          !layoutLoading && !layoutErr && isUninitialized && /* @__PURE__ */ jsxs5("div", { className: `mb-3 rounded-xl border px-3 py-2.5 text-[11px] leading-relaxed ${isDark ? "border-amber-500/40 bg-amber-950/30 text-amber-100" : "border-amber-200 bg-amber-50 text-amber-900"}`, children: [
            /* @__PURE__ */ jsx8("p", { className: "font-bold", children: tr.uninitializedBanner }),
            /* @__PURE__ */ jsx8("p", { className: "opacity-90 mt-1", children: tr.uninitializedStep })
          ] }),
          !layoutLoading && !layoutErr && isEmptyTable && /* @__PURE__ */ jsx8("div", { className: `mb-3 rounded-xl border px-3 py-2.5 text-[11px] ${isDark ? "border-cyan-500/30 bg-cyan-950/20 text-cyan-100" : "border-cyan-200 bg-cyan-50 text-cyan-900"}`, children: tr.emptyTableStep }),
          layoutLoading ? /* @__PURE__ */ jsx8("p", { className: `text-xs ${isDark ? "text-slate-500" : "text-slate-400"}`, children: tr.loadingLayout }) : layoutErr ? /* @__PURE__ */ jsx8("p", { className: "text-xs text-red-500", children: layoutErr }) : layout && /* @__PURE__ */ jsx8(
            DiskMapBar,
            {
              layout,
              mapSegments,
              selectedPath,
              canMutate: Boolean(canMutate),
              canCreatePartition: Boolean(canCreatePartition),
              isUninitialized,
              isDark,
              formatBytes: formatBytes2,
              language,
              diskPath: diskMeta?.path || `/dev/${activeDisk}`,
              tr: {
                unallocated: tr.unallocated,
                rawDiskLabel: tr.rawDiskLabel,
                dragResizeHint: tr.dragResizeHint,
                extendPreview: tr.extendPreview,
                shrinkPreview: tr.shrinkPreview
              },
              onSelectPartition: setSelectedPath,
              onClickFree: openCreateFromGap,
              onDragResizeEnd: handleDragResizeEnd
            }
          )
        ] }),
        /* @__PURE__ */ jsxs5("div", { className: "min-h-0 flex-1 overflow-auto", children: [
          /* @__PURE__ */ jsx8("p", { className: `px-3 pb-1 pt-2 text-[10px] font-bold uppercase tracking-wider ${isDark ? "text-slate-500" : "text-slate-400"}`, children: tr.partitionList }),
          /* @__PURE__ */ jsxs5("table", { className: "w-full text-left text-xs", children: [
            /* @__PURE__ */ jsx8("thead", { className: `sticky top-0 z-10 uppercase tracking-wider text-[10px] font-bold ${isDark ? "bg-slate-900 text-slate-400" : "bg-[#f5f5f7] text-slate-500"}`, children: /* @__PURE__ */ jsxs5("tr", { children: [
              /* @__PURE__ */ jsx8("th", { className: "p-2 pl-4", children: "#" }),
              /* @__PURE__ */ jsx8("th", { className: "p-2", children: tr.capacity }),
              /* @__PURE__ */ jsx8("th", { className: "p-2", children: tr.unused }),
              /* @__PURE__ */ jsx8("th", { className: "p-2", children: "FS" }),
              /* @__PURE__ */ jsx8("th", { className: "p-2", children: tr.type }),
              /* @__PURE__ */ jsx8("th", { className: "p-2", children: tr.status })
            ] }) }),
            /* @__PURE__ */ jsx8("tbody", { className: `divide-y ${isDark ? "divide-slate-800" : "divide-slate-100"}`, children: (layout?.partitions || []).map((part) => {
              const rowSel = part.path === selectedPath;
              const usedPct = part.used_percent;
              return /* @__PURE__ */ jsxs5(
                "tr",
                {
                  onClick: () => setSelectedPath(part.path || null),
                  className: `cursor-pointer transition ${rowSel ? isDark ? "bg-cyan-950/40" : "bg-cyan-50" : isDark ? "hover:bg-slate-800/40" : "hover:bg-slate-50"}`,
                  children: [
                    /* @__PURE__ */ jsxs5("td", { className: "p-2 pl-4 font-mono font-bold", children: [
                      part.label || part.name || part.number,
                      part.mountpoint && /* @__PURE__ */ jsx8("span", { className: `block text-[9px] font-normal ${isDark ? "text-slate-500" : "text-slate-400"}`, children: part.mountpoint })
                    ] }),
                    /* @__PURE__ */ jsx8("td", { className: "p-2 font-mono", children: formatBytes2(part.size_bytes || 0, language) }),
                    /* @__PURE__ */ jsx8("td", { className: "p-2", children: usedPct != null ? /* @__PURE__ */ jsxs5("div", { className: "flex items-center gap-2", children: [
                      /* @__PURE__ */ jsx8("div", { className: `w-16 h-1.5 rounded-full overflow-hidden ${isDark ? "bg-slate-800" : "bg-slate-200"}`, children: /* @__PURE__ */ jsx8("div", { className: "h-full bg-cyan-500 rounded-full", style: { width: `${100 - usedPct}%` } }) }),
                      /* @__PURE__ */ jsxs5("span", { className: "font-mono text-[10px]", children: [
                        100 - usedPct,
                        "%"
                      ] })
                    ] }) : "\u2014" }),
                    /* @__PURE__ */ jsx8("td", { className: "p-2", children: part.fstype_label || part.fstype || "\u2014" }),
                    /* @__PURE__ */ jsxs5("td", { className: "p-2 text-[10px]", children: [
                      (part.flags || []).join(", ") || "\u2014",
                      part.is_boot && /* @__PURE__ */ jsx8("span", { className: "ml-1 text-amber-500", children: tr.boot })
                    ] }),
                    /* @__PURE__ */ jsx8("td", { className: "p-2", children: /* @__PURE__ */ jsx8("span", { className: `text-[10px] px-1.5 py-0.5 rounded border font-bold ${part.is_mounted ? isDark ? "border-emerald-500/30 text-emerald-400" : "border-emerald-200 text-emerald-700" : isDark ? "border-slate-600 text-slate-400" : "border-slate-200 text-slate-500"}`, children: part.is_mounted ? tr.mounted : tr.unmounted }) })
                  ]
                },
                part.path || part.number
              );
            }) })
          ] }),
          !layoutLoading && (layout?.partitions.length || 0) === 0 && /* @__PURE__ */ jsx8("p", { className: `p-4 text-xs ${isDark ? "text-slate-500" : "text-slate-400"}`, children: tr.selectPartition })
        ] }),
        selected && /* @__PURE__ */ jsxs5("div", { className: `grid shrink-0 grid-cols-2 gap-2 border-t px-3 py-2 text-[11px] md:grid-cols-4 ${isDark ? "border-slate-800 bg-slate-950/30" : "border-slate-200/90 bg-[#ececf0]/30"}`, children: [
          /* @__PURE__ */ jsxs5("div", { children: [
            /* @__PURE__ */ jsxs5("span", { className: "opacity-60", children: [
              tr.properties,
              ":"
            ] }),
            " ",
            /* @__PURE__ */ jsx8("span", { className: "font-mono", children: selected.path })
          ] }),
          /* @__PURE__ */ jsxs5("div", { children: [
            /* @__PURE__ */ jsxs5("span", { className: "opacity-60", children: [
              tr.partitionTable,
              ":"
            ] }),
            " ",
            layout?.partition_table || "\u2014"
          ] }),
          /* @__PURE__ */ jsxs5("div", { children: [
            /* @__PURE__ */ jsxs5("span", { className: "opacity-60", children: [
              tr.capacity,
              ":"
            ] }),
            " ",
            formatBytes2(selected.size_bytes || 0, language)
          ] }),
          /* @__PURE__ */ jsxs5("div", { children: [
            /* @__PURE__ */ jsx8("span", { className: "opacity-60", children: "Label:" }),
            " ",
            selected.label || "\u2014"
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsx8(
        OperationQueuePanel,
        {
          queue: pendingQueue,
          log: opLog,
          isDark,
          busy: queueBusy || actionLoading,
          validationSummary,
          tr: tr.queue,
          onRemove: removeFromQueue,
          onClear: clearQueue,
          onValidate: handleValidateQueue,
          onApply: handleApplyQueue
        }
      )
    ] }),
    /* @__PURE__ */ jsx8(WindowModal, { open: !!modal, onClose: closeModal, title: modalTitle, maxWidth: "md", children: /* @__PURE__ */ jsxs5("div", { className: "space-y-4 p-5 max-h-[70vh] overflow-y-auto text-sm", children: [
      modal === "initDisk" && /* @__PURE__ */ jsxs5(Fragment, { children: [
        /* @__PURE__ */ jsx8("p", { className: "text-[11px] opacity-70", children: tr.initializeDiskHint }),
        /* @__PURE__ */ jsxs5("p", { className: "text-[11px] font-mono", children: [
          diskMeta?.path,
          " \xB7 ",
          formatBytes2(layout?.size_bytes || 0, language)
        ] }),
        /* @__PURE__ */ jsx8("p", { className: "text-[11px] text-red-500", children: tr.initWipeWarning }),
        /* @__PURE__ */ jsxs5("fieldset", { className: "space-y-2 text-[11px]", children: [
          /* @__PURE__ */ jsxs5("label", { className: "flex items-center gap-2 cursor-pointer", children: [
            /* @__PURE__ */ jsx8("input", { type: "radio", name: "tableType", checked: initTableType === "gpt", onChange: () => setInitTableType("gpt") }),
            tr.tableGpt
          ] }),
          /* @__PURE__ */ jsxs5("label", { className: "flex items-center gap-2 cursor-pointer", children: [
            /* @__PURE__ */ jsx8("input", { type: "radio", name: "tableType", checked: initTableType === "msdos", onChange: () => setInitTableType("msdos") }),
            tr.tableMbr
          ] })
        ] }),
        /* @__PURE__ */ jsxs5("label", { className: "block text-[11px] space-y-1", children: [
          tr.confirmDiskName,
          /* @__PURE__ */ jsx8("input", { value: initConfirm, onChange: (e) => setInitConfirm(e.target.value), placeholder: activeDisk, className: `w-full rounded-lg border px-3 py-2 text-xs font-mono ${isDark ? "bg-slate-950 border-slate-700" : "border-slate-200"}` })
        ] }),
        activeDisk && /* @__PURE__ */ jsxs5("p", { className: "text-[10px] opacity-60 font-mono", children: [
          language === "vi" ? "G\xF5:" : "Type:",
          " ",
          activeDisk
        ] }),
        actionErr && /* @__PURE__ */ jsx8("p", { className: "text-[11px] text-red-500 whitespace-pre-wrap", children: actionErr }),
        /* @__PURE__ */ jsxs5("div", { className: "flex gap-2", children: [
          /* @__PURE__ */ jsx8("button", { type: "button", onClick: closeModal, className: `flex-1 py-2 rounded-xl text-xs font-bold border ${isDark ? "border-slate-700" : "border-slate-200"}`, children: tr.cancel }),
          /* @__PURE__ */ jsx8(
            "button",
            {
              type: "button",
              disabled: actionLoading || initConfirm.trim() !== activeDisk,
              onClick: () => enqueue({
                op: "initialize",
                disk_name: activeDisk,
                confirm_token: initConfirm.trim(),
                params: { table_type: initTableType },
                summary: `${tr.initializeDisk}: ${activeDisk} (${initTableType.toUpperCase()})`
              }),
              className: `flex-1 py-2 rounded-xl text-xs font-bold border ${isDark ? "border-amber-700 text-amber-300" : "border-amber-300 text-amber-800"}`,
              children: tr.addToQueue
            }
          ),
          /* @__PURE__ */ jsx8(
            "button",
            {
              type: "button",
              disabled: actionLoading || initConfirm.trim() !== activeDisk,
              onClick: () => refreshAfter(() => postJson(`/api/storage_manager/disks/${encodeURIComponent(activeDisk)}/initialize`, {
                disk_name: activeDisk,
                table_type: initTableType,
                confirm_token: initConfirm.trim()
              })),
              className: "flex-1 py-2 rounded-xl text-xs font-bold bg-amber-600 text-white disabled:opacity-50",
              children: tr.runAction
            }
          )
        ] })
      ] }),
      modal === "create" && /* @__PURE__ */ jsxs5(Fragment, { children: [
        /* @__PURE__ */ jsx8("h3", { className: "font-bold", children: tr.createPartition }),
        /* @__PURE__ */ jsxs5("p", { className: "text-[11px] opacity-70", children: [
          tr.selectDisk,
          ": ",
          /* @__PURE__ */ jsx8("span", { className: "font-mono", children: activeDisk })
        ] }),
        /* @__PURE__ */ jsxs5("label", { className: "block text-[11px] space-y-1", children: [
          tr.start,
          /* @__PURE__ */ jsx8("input", { value: partStart, onChange: (e) => setPartStart(e.target.value), className: `w-full rounded-lg border px-3 py-2 text-xs font-mono ${isDark ? "bg-slate-950 border-slate-700" : "border-slate-200"}` })
        ] }),
        /* @__PURE__ */ jsxs5("label", { className: "block text-[11px] space-y-1", children: [
          tr.end,
          /* @__PURE__ */ jsx8("input", { value: partEnd, onChange: (e) => setPartEnd(e.target.value), className: `w-full rounded-lg border px-3 py-2 text-xs font-mono ${isDark ? "bg-slate-950 border-slate-700" : "border-slate-200"}` })
        ] }),
        /* @__PURE__ */ jsxs5("label", { className: "block text-[11px] space-y-1", children: [
          tr.partitionType,
          /* @__PURE__ */ jsx8(
            "select",
            {
              value: partType,
              onChange: (e) => setPartType(e.target.value),
              className: `w-full rounded-lg border px-3 py-2 text-xs ${isDark ? "bg-slate-950 border-slate-700" : "border-slate-200"}`,
              children: PARTITION_TYPE_OPTIONS.map((opt) => /* @__PURE__ */ jsx8("option", { value: opt.value, children: tr[opt.labelKey] }, opt.value))
            }
          )
        ] }),
        /* @__PURE__ */ jsxs5("label", { className: "block text-[11px] space-y-1", children: [
          tr.confirmDiskName,
          /* @__PURE__ */ jsx8("input", { value: partConfirm, onChange: (e) => setPartConfirm(e.target.value), placeholder: activeDisk, className: `w-full rounded-lg border px-3 py-2 text-xs font-mono ${isDark ? "bg-slate-950 border-slate-700" : "border-slate-200"}` })
        ] }),
        /* @__PURE__ */ jsxs5("div", { className: "flex gap-2", children: [
          /* @__PURE__ */ jsx8("button", { type: "button", onClick: closeModal, className: `flex-1 py-2 rounded-xl text-xs font-bold border ${isDark ? "border-slate-700" : "border-slate-200"}`, children: tr.cancel }),
          /* @__PURE__ */ jsx8(
            "button",
            {
              type: "button",
              disabled: actionLoading || partConfirm !== activeDisk,
              onClick: () => enqueue({
                op: "create",
                disk_name: activeDisk,
                confirm_token: partConfirm,
                params: { start: partStart, end: partEnd, partition_type: partType },
                summary: `${tr.createPartition}: ${activeDisk} ${tr[PARTITION_TYPE_OPTIONS.find((o) => o.value === partType)?.labelKey || "typeLinux"]} (${partStart} \u2192 ${partEnd})`
              }),
              className: `flex-1 py-2 rounded-xl text-xs font-bold border ${isDark ? "border-cyan-700 text-cyan-300" : "border-cyan-300 text-cyan-800"}`,
              children: tr.addToQueue
            }
          ),
          /* @__PURE__ */ jsx8(
            "button",
            {
              type: "button",
              disabled: actionLoading || partConfirm !== activeDisk,
              onClick: () => refreshAfter(() => postJson("/api/storage_manager/partitions/create", {
                disk_name: activeDisk,
                start: partStart,
                end: partEnd,
                partition_type: partType,
                initialize_gpt: false,
                confirm_token: partConfirm
              })),
              className: "flex-1 py-2 rounded-xl text-xs font-bold bg-cyan-600 text-white disabled:opacity-50",
              children: tr.runAction
            }
          )
        ] })
      ] }),
      modal === "format" && selected && /* @__PURE__ */ jsxs5(Fragment, { children: [
        /* @__PURE__ */ jsx8("h3", { className: "font-bold", children: tr.formatPartition }),
        /* @__PURE__ */ jsx8("p", { className: "text-[11px] text-red-500", children: tr.dataLossWarning }),
        /* @__PURE__ */ jsx8("p", { className: "text-[11px] font-mono", children: selected.path }),
        /* @__PURE__ */ jsx8("select", { value: formatFs, onChange: (e) => setFormatFs(e.target.value), className: `w-full rounded-lg border px-3 py-2 text-xs ${isDark ? "bg-slate-950 border-slate-700" : "border-slate-200"}`, children: FORMAT_FS_OPTIONS.map((o) => /* @__PURE__ */ jsx8("option", { value: o.value, children: o.label }, o.value)) }),
        /* @__PURE__ */ jsx8("input", { value: formatLabel, onChange: (e) => setFormatLabel(e.target.value), placeholder: tr.labelOptional, className: `w-full rounded-lg border px-3 py-2 text-xs ${isDark ? "bg-slate-950 border-slate-700" : "border-slate-200"}` }),
        /* @__PURE__ */ jsx8("input", { value: formatConfirm, onChange: (e) => setFormatConfirm(e.target.value), placeholder: tr.confirmPartName, className: `w-full rounded-lg border px-3 py-2 text-xs font-mono ${isDark ? "bg-slate-950 border-slate-700" : "border-slate-200"}` }),
        /* @__PURE__ */ jsxs5("div", { className: "flex gap-2", children: [
          /* @__PURE__ */ jsx8("button", { type: "button", onClick: closeModal, className: `flex-1 py-2 rounded-xl text-xs font-bold border ${isDark ? "border-slate-700" : "border-slate-200"}`, children: tr.cancel }),
          /* @__PURE__ */ jsx8(
            "button",
            {
              type: "button",
              disabled: actionLoading || formatConfirm !== selected.name,
              onClick: () => enqueue({
                op: "format",
                device: selected.path,
                confirm_token: formatConfirm,
                params: { fstype: formatFs, label: formatLabel || void 0 },
                summary: `${tr.formatPartition}: ${selected.name} \u2192 ${formatFs}`
              }),
              className: `flex-1 py-2 rounded-xl text-xs font-bold border ${isDark ? "border-red-800 text-red-300" : "border-red-300 text-red-800"}`,
              children: tr.addToQueue
            }
          ),
          /* @__PURE__ */ jsx8(
            "button",
            {
              type: "button",
              disabled: actionLoading || formatConfirm !== selected.name,
              onClick: () => refreshAfter(() => postJson("/api/storage_manager/format", {
                device: selected.path,
                fstype: formatFs,
                label: formatLabel || void 0,
                confirm_token: formatConfirm
              })),
              className: "flex-1 py-2 rounded-xl text-xs font-bold bg-red-600 text-white disabled:opacity-50",
              children: tr.runAction
            }
          )
        ] })
      ] }),
      modal === "delete" && selected && /* @__PURE__ */ jsxs5(Fragment, { children: [
        /* @__PURE__ */ jsx8("h3", { className: "font-bold text-red-500", children: tr.deletePartition }),
        /* @__PURE__ */ jsx8("p", { className: "text-[11px]", children: tr.deleteWarning }),
        /* @__PURE__ */ jsx8("p", { className: "text-[11px] font-mono", children: selected.path }),
        /* @__PURE__ */ jsx8("input", { value: deleteConfirm, onChange: (e) => setDeleteConfirm(e.target.value), placeholder: tr.confirmPartName, className: `w-full rounded-lg border px-3 py-2 text-xs font-mono ${isDark ? "bg-slate-950 border-slate-700" : "border-slate-200"}` }),
        selected.name && /* @__PURE__ */ jsxs5("p", { className: "text-[10px] opacity-60 font-mono", children: [
          language === "vi" ? "G\xF5:" : "Type:",
          " ",
          selected.name
        ] }),
        actionErr && /* @__PURE__ */ jsx8("p", { className: "text-[11px] text-red-500 whitespace-pre-wrap", children: actionErr }),
        /* @__PURE__ */ jsxs5("div", { className: "flex gap-2", children: [
          /* @__PURE__ */ jsx8("button", { type: "button", onClick: closeModal, className: `flex-1 py-2 rounded-xl text-xs font-bold border ${isDark ? "border-slate-700" : "border-slate-200"}`, children: tr.cancel }),
          /* @__PURE__ */ jsx8(
            "button",
            {
              type: "button",
              disabled: actionLoading || deleteConfirm.trim() !== (selected.name || ""),
              onClick: () => enqueue({
                op: "delete",
                device: selected.path,
                confirm_token: deleteConfirm.trim(),
                params: { partition_number: selected.number || null },
                summary: `${tr.deletePartition}: ${selected.name}`
              }),
              className: `flex-1 py-2 rounded-xl text-xs font-bold border ${isDark ? "border-red-800 text-red-300" : "border-red-300 text-red-800"}`,
              children: tr.addToQueue
            }
          ),
          /* @__PURE__ */ jsx8(
            "button",
            {
              type: "button",
              disabled: actionLoading || deleteConfirm.trim() !== (selected.name || ""),
              onClick: () => refreshAfter(() => postJson("/api/storage_manager/partitions/delete", {
                device: selected.path,
                confirm_token: deleteConfirm.trim(),
                partition_number: selected.number || null
              })),
              className: "flex-1 py-2 rounded-xl text-xs font-bold bg-red-600 text-white disabled:opacity-50",
              children: tr.runAction
            }
          )
        ] })
      ] }),
      modal === "resize" && selected && /* @__PURE__ */ jsxs5(Fragment, { children: [
        /* @__PURE__ */ jsx8("h3", { className: "font-bold", children: tr.resizePartition }),
        /* @__PURE__ */ jsx8("p", { className: "text-[11px] opacity-70", children: tr.resizeHint }),
        /* @__PURE__ */ jsx8("p", { className: "text-[11px] font-mono", children: selected.path }),
        /* @__PURE__ */ jsxs5("label", { className: "block text-[11px] space-y-1", children: [
          tr.end,
          /* @__PURE__ */ jsx8("input", { value: resizeEnd, onChange: (e) => setResizeEnd(e.target.value), placeholder: "100%", className: `w-full rounded-lg border px-3 py-2 text-xs font-mono ${isDark ? "bg-slate-950 border-slate-700" : "border-slate-200"}` })
        ] }),
        /* @__PURE__ */ jsxs5("label", { className: "flex items-center gap-2 text-[11px]", children: [
          /* @__PURE__ */ jsx8("input", { type: "checkbox", checked: resizeGrowFs, onChange: (e) => setResizeGrowFs(e.target.checked) }),
          tr.growFilesystem
        ] }),
        /* @__PURE__ */ jsxs5("label", { className: "flex items-center gap-2 text-[11px]", children: [
          /* @__PURE__ */ jsx8("input", { type: "checkbox", checked: resizeShrinkFs, onChange: (e) => setResizeShrinkFs(e.target.checked) }),
          tr.shrinkFilesystem
        ] }),
        /* @__PURE__ */ jsx8("p", { className: "text-[10px] opacity-60", children: tr.shrinkHint }),
        /* @__PURE__ */ jsx8("input", { value: resizeConfirm, onChange: (e) => setResizeConfirm(e.target.value), placeholder: tr.confirmPartName, className: `w-full rounded-lg border px-3 py-2 text-xs font-mono ${isDark ? "bg-slate-950 border-slate-700" : "border-slate-200"}` }),
        /* @__PURE__ */ jsxs5("div", { className: "flex gap-2", children: [
          /* @__PURE__ */ jsx8("button", { type: "button", onClick: closeModal, className: `flex-1 py-2 rounded-xl text-xs font-bold border ${isDark ? "border-slate-700" : "border-slate-200"}`, children: tr.cancel }),
          /* @__PURE__ */ jsx8(
            "button",
            {
              type: "button",
              disabled: actionLoading || resizeConfirm !== selected.name,
              onClick: () => enqueue({
                op: "resize",
                device: selected.path,
                confirm_token: resizeConfirm,
                params: { end: resizeEnd, grow_filesystem: resizeGrowFs, shrink_filesystem: resizeShrinkFs },
                summary: `${tr.resizePartition}: ${selected.name} \u2192 ${resizeEnd}`
              }),
              className: `flex-1 py-2 rounded-xl text-xs font-bold border ${isDark ? "border-cyan-700 text-cyan-300" : "border-cyan-300 text-cyan-800"}`,
              children: tr.addToQueue
            }
          ),
          /* @__PURE__ */ jsx8(
            "button",
            {
              type: "button",
              disabled: actionLoading || resizeConfirm !== selected.name,
              onClick: () => refreshAfter(() => postJson("/api/storage_manager/partitions/resize", {
                device: selected.path,
                end: resizeEnd,
                grow_filesystem: resizeGrowFs,
                shrink_filesystem: resizeShrinkFs,
                confirm_token: resizeConfirm
              })),
              className: "flex-1 py-2 rounded-xl text-xs font-bold bg-cyan-600 text-white disabled:opacity-50",
              children: tr.runAction
            }
          )
        ] })
      ] }),
      modal === "label" && selected && /* @__PURE__ */ jsxs5(Fragment, { children: [
        /* @__PURE__ */ jsx8("h3", { className: "font-bold", children: tr.changeLabel }),
        /* @__PURE__ */ jsx8("p", { className: "text-[11px] font-mono", children: selected.path }),
        /* @__PURE__ */ jsx8("input", { value: labelText, onChange: (e) => setLabelText(e.target.value), className: `w-full rounded-lg border px-3 py-2 text-xs ${isDark ? "bg-slate-950 border-slate-700" : "border-slate-200"}` }),
        /* @__PURE__ */ jsx8("input", { value: labelConfirm, onChange: (e) => setLabelConfirm(e.target.value), placeholder: tr.confirmPartName, className: `w-full rounded-lg border px-3 py-2 text-xs font-mono ${isDark ? "bg-slate-950 border-slate-700" : "border-slate-200"}` }),
        /* @__PURE__ */ jsxs5("div", { className: "flex gap-2", children: [
          /* @__PURE__ */ jsx8("button", { type: "button", onClick: closeModal, className: `flex-1 py-2 rounded-xl text-xs font-bold border ${isDark ? "border-slate-700" : "border-slate-200"}`, children: tr.cancel }),
          /* @__PURE__ */ jsx8(
            "button",
            {
              type: "button",
              disabled: actionLoading || labelConfirm !== selected.name || !labelText.trim(),
              onClick: () => enqueue({
                op: "label",
                device: selected.path,
                confirm_token: labelConfirm,
                params: { label: labelText.trim() },
                summary: `${tr.changeLabel}: ${selected.name} \u2192 ${labelText.trim()}`
              }),
              className: `flex-1 py-2 rounded-xl text-xs font-bold border ${isDark ? "border-cyan-700 text-cyan-300" : "border-cyan-300 text-cyan-800"}`,
              children: tr.addToQueue
            }
          ),
          /* @__PURE__ */ jsx8(
            "button",
            {
              type: "button",
              disabled: actionLoading || labelConfirm !== selected.name || !labelText.trim(),
              onClick: () => refreshAfter(() => postJson("/api/storage_manager/partitions/label", {
                device: selected.path,
                label: labelText.trim(),
                confirm_token: labelConfirm
              })),
              className: "flex-1 py-2 rounded-xl text-xs font-bold bg-cyan-600 text-white disabled:opacity-50",
              children: tr.runAction
            }
          )
        ] })
      ] }),
      modal === "boot" && selected && /* @__PURE__ */ jsxs5(Fragment, { children: [
        /* @__PURE__ */ jsx8("h3", { className: "font-bold", children: tr.setBoot }),
        /* @__PURE__ */ jsx8("p", { className: "text-[11px] font-mono", children: selected.path }),
        /* @__PURE__ */ jsx8("p", { className: "text-[10px] opacity-70", children: language === "vi" ? "GPT: FAT32 \u2192 EFI (esp), ext4/xfs/btrfs \u2192 legacy_boot. exFAT/NTFS kh\xF4ng h\u1ED7 tr\u1EE3." : "GPT: FAT32 \u2192 EFI (esp), ext4/xfs/btrfs \u2192 legacy_boot. exFAT/NTFS not supported." }),
        /* @__PURE__ */ jsx8("input", { value: bootConfirm, onChange: (e) => setBootConfirm(e.target.value), placeholder: tr.confirmPartName, className: `w-full rounded-lg border px-3 py-2 text-xs font-mono ${isDark ? "bg-slate-950 border-slate-700" : "border-slate-200"}` }),
        selected.name && /* @__PURE__ */ jsxs5("p", { className: "text-[10px] opacity-60 font-mono", children: [
          language === "vi" ? "G\xF5:" : "Type:",
          " ",
          selected.name
        ] }),
        actionErr && /* @__PURE__ */ jsx8("p", { className: "text-[11px] text-red-500 whitespace-pre-wrap", children: actionErr }),
        /* @__PURE__ */ jsxs5("div", { className: "flex gap-2", children: [
          /* @__PURE__ */ jsx8("button", { type: "button", onClick: closeModal, className: `flex-1 py-2 rounded-xl text-xs font-bold border ${isDark ? "border-slate-700" : "border-slate-200"}`, children: tr.cancel }),
          /* @__PURE__ */ jsx8(
            "button",
            {
              type: "button",
              disabled: actionLoading || bootConfirm.trim() !== (selected.name || ""),
              onClick: () => enqueue({
                op: "set_boot",
                device: selected.path,
                confirm_token: bootConfirm.trim(),
                params: { active: true, partition_number: selected.number || null },
                summary: `${tr.setBoot}: ${selected.name}`
              }),
              className: `flex-1 py-2 rounded-xl text-xs font-bold border ${isDark ? "border-cyan-700 text-cyan-300" : "border-cyan-300 text-cyan-800"}`,
              children: tr.addToQueue
            }
          ),
          /* @__PURE__ */ jsx8(
            "button",
            {
              type: "button",
              disabled: actionLoading || bootConfirm.trim() !== (selected.name || ""),
              onClick: () => refreshAfter(() => postJson("/api/storage_manager/partitions/boot", {
                device: selected.path,
                active: true,
                confirm_token: bootConfirm.trim(),
                partition_number: selected.number || null
              })),
              className: "flex-1 py-2 rounded-xl text-xs font-bold bg-cyan-600 text-white disabled:opacity-50",
              children: tr.runAction
            }
          )
        ] })
      ] }),
      modal === "mount" && selected && /* @__PURE__ */ jsxs5(Fragment, { children: [
        /* @__PURE__ */ jsx8("h3", { className: "font-bold", children: tr.mountVolume }),
        /* @__PURE__ */ jsx8("p", { className: "text-[11px] font-mono", children: selected.path }),
        selected.parttype_label && !selected.fstype && /* @__PURE__ */ jsxs5("p", { className: "text-[11px] text-amber-600 dark:text-amber-400", children: [
          selected.parttype_label,
          language === "vi" ? " \u2014 ch\u1ECDn NTFS/exFAT b\xEAn d\u01B0\u1EDBi. N\u1EBFu \u1ED5 tr\u1ED1ng, Format tr\u01B0\u1EDBc r\u1ED3i Mount." : " \u2014 pick NTFS/exFAT below. If empty, Format first, then Mount."
        ] }),
        actionErr && /* @__PURE__ */ jsx8("p", { className: "text-[11px] text-red-500 whitespace-pre-wrap", children: actionErr }),
        /* @__PURE__ */ jsxs5("label", { className: "block text-[11px] space-y-1", children: [
          language === "vi" ? "Lo\u1EA1i filesystem" : "Filesystem type",
          /* @__PURE__ */ jsx8(
            "select",
            {
              value: mountFs,
              onChange: (e) => setMountFs(e.target.value),
              className: `w-full rounded-lg border px-3 py-2 text-xs ${isDark ? "bg-slate-950 border-slate-700" : "border-slate-200"}`,
              children: FORMAT_FS_OPTIONS.map((o) => /* @__PURE__ */ jsx8("option", { value: o.value, children: o.label }, o.value))
            }
          )
        ] }),
        /* @__PURE__ */ jsx8("input", { value: mountPoint, onChange: (e) => setMountPoint(e.target.value), placeholder: tr.mountpoint, className: `w-full rounded-lg border px-3 py-2 text-xs font-mono ${isDark ? "bg-slate-950 border-slate-700" : "border-slate-200"}` }),
        /* @__PURE__ */ jsxs5("label", { className: "flex items-center gap-2 text-[11px]", children: [
          /* @__PURE__ */ jsx8("input", { type: "checkbox", checked: mountPersist, onChange: (e) => setMountPersist(e.target.checked) }),
          tr.persistFstab
        ] }),
        /* @__PURE__ */ jsxs5("div", { className: "flex gap-2", children: [
          /* @__PURE__ */ jsx8("button", { type: "button", onClick: closeModal, className: `flex-1 py-2 rounded-xl text-xs font-bold border ${isDark ? "border-slate-700" : "border-slate-200"}`, children: tr.cancel }),
          /* @__PURE__ */ jsx8(
            "button",
            {
              type: "button",
              disabled: actionLoading || !mountPoint.trim() || !mountPoint.trim().startsWith("/"),
              onClick: () => refreshAfter(() => postJson("/api/storage_manager/mount", {
                device: selected.path,
                mountpoint: mountPoint.trim(),
                fstype: mountFs,
                options: "defaults",
                persist_fstab: mountPersist
              })),
              className: "flex-1 py-2 rounded-xl text-xs font-bold bg-cyan-600 text-white disabled:opacity-50",
              children: tr.runAction
            }
          )
        ] })
      ] }),
      modal === "unmount" && selected?.mountpoint && /* @__PURE__ */ jsxs5(Fragment, { children: [
        /* @__PURE__ */ jsx8("h3", { className: "font-bold", children: tr.unmountVolume }),
        /* @__PURE__ */ jsx8("p", { className: "text-[11px] font-mono", children: selected.mountpoint }),
        /* @__PURE__ */ jsxs5("div", { className: "flex gap-2", children: [
          /* @__PURE__ */ jsx8("button", { type: "button", onClick: closeModal, className: `flex-1 py-2 rounded-xl text-xs font-bold border ${isDark ? "border-slate-700" : "border-slate-200"}`, children: tr.cancel }),
          /* @__PURE__ */ jsx8(
            "button",
            {
              type: "button",
              disabled: actionLoading,
              onClick: () => refreshAfter(() => postJson("/api/storage_manager/unmount", {
                mountpoint: selected.mountpoint,
                remove_fstab: false
              })),
              className: "flex-1 py-2 rounded-xl text-xs font-bold bg-cyan-600 text-white disabled:opacity-50",
              children: tr.runAction
            }
          )
        ] })
      ] })
    ] }) })
  ] });
}

// src/modules/storage_manager/storageTheme.ts
function storageTheme(isDark) {
  return {
    panel: isDark ? "bg-slate-900 border-slate-700/80 text-slate-100" : "bg-[#f5f5f7] border-slate-200/90 text-slate-900",
    muted: isDark ? "text-slate-400" : "text-slate-500",
    hoverNav: isDark ? "hover:bg-slate-800/80" : "hover:bg-black/[0.04]",
    activeNav: isDark ? "bg-cyan-500/15 text-cyan-300 shadow-sm shadow-cyan-500/10" : "bg-white text-cyan-700 shadow-sm border border-slate-200/80",
    btn: isDark ? "border-slate-600 bg-slate-800/80 hover:bg-slate-700 text-slate-200" : "border-slate-300/80 bg-white hover:bg-slate-50 text-slate-700",
    btnPrimary: "bg-cyan-600 hover:bg-cyan-500 text-white border-transparent",
    surface: isDark ? "bg-slate-950/50 border-slate-800" : "bg-white border-slate-200/90 shadow-sm",
    section: isDark ? "bg-slate-900/60 border-slate-800" : "bg-white border-slate-200/90",
    headerBorder: isDark ? "border-slate-700/80" : "border-slate-200/90",
    sidebar: isDark ? "bg-slate-950/40 border-slate-800" : "bg-[#ececf0]/80 border-slate-200/90"
  };
}

// src/modules/storage_manager/index.tsx
import { Fragment as Fragment3, jsx as jsx9, jsxs as jsxs6 } from "react/jsx-runtime";
var FORMAT_FS_OPTIONS2 = [
  { value: "ext4", label: "ext4 (Linux)" },
  { value: "xfs", label: "XFS (Linux)" },
  { value: "btrfs", label: "Btrfs (Linux)" },
  { value: "vfat", label: "FAT32 / VFAT" },
  { value: "exfat", label: "exFAT" },
  { value: "ntfs", label: "NTFS (Windows)" },
  { value: "hfsplus", label: "HFS+ (macOS)" }
];
var MOUNT_FS_OPTIONS = [
  ...FORMAT_FS_OPTIONS2,
  { value: "apfs", label: "APFS (Apple, read-only)" }
];
function displayFstype(item) {
  return item.fstype_label || item.fstype || "\u2014";
}
function formatPowerOnHours(hours, language) {
  if (hours == null) return "\u2014";
  const days = Math.floor(hours / 24);
  if (language === "vi") {
    return `${hours.toLocaleString("vi-VN")} gi\u1EDD (~${days.toLocaleString("vi-VN")} ng\xE0y)`;
  }
  return `${hours.toLocaleString("en-US")} h (~${days.toLocaleString("en-US")} days)`;
}
function formatHostIoGb(gb) {
  if (gb == null) return "\u2014";
  if (gb >= 1024) return `${(gb / 1024).toFixed(2)} TB`;
  return `${gb.toFixed(2)} GB`;
}
function formatMibs(mibs) {
  if (mibs == null) return "\u2014";
  return `${mibs.toFixed(1)} MiB/s`;
}
var PROTECTED_MOUNTS = ["/", "/boot", "/boot/efi", "/usr", "/var"];
var REQUIRED_STORAGE_ROUTES = [
  "/api/storage_manager/version",
  "/api/storage_manager/partitions/delete",
  "/api/storage_manager/partitions/create",
  "/api/storage_manager/disks/{disk_name}/initialize",
  "/api/storage_manager/format",
  "/api/storage_manager/mount",
  "/api/storage_manager/operations/validate",
  "/api/storage_manager/operations/apply"
];
function isProtectedMount(mountpoint) {
  if (PROTECTED_MOUNTS.includes(mountpoint)) return true;
  if (mountpoint.startsWith("/opt/copanel")) return true;
  return false;
}
function apiErrorMessage(body, status) {
  const wrapped = body.error;
  if (wrapped?.message) return wrapped.message;
  if (typeof body.detail === "string") {
    if (body.detail === "Not Found") {
      return "API route not found (404). Restart copanel service or reinstall the module from AppStore.";
    }
    if (body.detail.toLowerCase().includes("filesystem type")) {
      return `${body.detail} Format the partition first, then mount.`;
    }
    return body.detail;
  }
  if (typeof body.message === "string") return body.message;
  if (status === 404) {
    return "API route not found (404). Restart copanel service or reinstall the module from AppStore.";
  }
  return `HTTP ${status}`;
}
function formatBytes(bytes, language) {
  if (!Number.isFinite(bytes) || bytes <= 0) return "0 B";
  const units = language === "vi" ? ["B", "KB", "MB", "GB", "TB", "PB"] : ["B", "KB", "MB", "GB", "TB", "PB"];
  let value = bytes;
  let idx = 0;
  while (value >= 1024 && idx < units.length - 1) {
    value /= 1024;
    idx += 1;
  }
  return `${value >= 100 || idx === 0 ? value.toFixed(0) : value.toFixed(1)} ${units[idx]}`;
}
function healthStyles(level, isDark) {
  if (level === "critical") {
    return {
      ring: isDark ? "border-red-500/40 bg-red-950/30" : "border-red-200 bg-red-50",
      icon: isDark ? "text-red-400" : "text-red-600",
      text: isDark ? "text-red-200" : "text-red-800",
      badge: "bg-red-500/15 border-red-500/30 text-red-500"
    };
  }
  if (level === "warning") {
    return {
      ring: isDark ? "border-amber-500/40 bg-amber-950/20" : "border-amber-200 bg-amber-50",
      icon: isDark ? "text-amber-400" : "text-amber-600",
      text: isDark ? "text-amber-100" : "text-amber-900",
      badge: "bg-amber-500/15 border-amber-500/30 text-amber-500"
    };
  }
  return {
    ring: isDark ? "border-emerald-500/40 bg-emerald-950/20" : "border-emerald-200 bg-emerald-50",
    icon: isDark ? "text-emerald-400" : "text-emerald-600",
    text: isDark ? "text-emerald-100" : "text-emerald-900",
    badge: "bg-emerald-500/15 border-emerald-500/30 text-emerald-500"
  };
}
function smartBadge(smart, isDark) {
  const status = smart?.status || "unknown";
  if (status === "healthy" || smart?.passed === true) {
    return { label: "Healthy", cls: isDark ? "text-emerald-400 bg-emerald-500/10 border-emerald-500/20" : "text-emerald-700 bg-emerald-50 border-emerald-200" };
  }
  if (status === "critical" || smart?.passed === false) {
    return { label: "Critical", cls: isDark ? "text-red-400 bg-red-500/10 border-red-500/20" : "text-red-700 bg-red-50 border-red-200" };
  }
  return { label: "Unknown", cls: isDark ? "text-slate-400 bg-slate-800/60 border-slate-700" : "text-slate-600 bg-slate-100 border-slate-200" };
}
function StorageManagerDashboard() {
  const { theme, language } = useAppShellContext();
  const isDark = theme === "dark";
  const token = localStorage.getItem("copanel_token");
  const [tab, setTab] = useState4("disks");
  const [loading, setLoading] = useState4(true);
  const [error, setError] = useState4(null);
  const [overview, setOverview] = useState4(null);
  const [disks, setDisks] = useState4([]);
  const [volumes, setVolumes] = useState4([]);
  const [expandedDisk, setExpandedDisk] = useState4(null);
  const [fstab, setFstab] = useState4([]);
  const [actionMsg, setActionMsg] = useState4(null);
  const [actionErr, setActionErr] = useState4(null);
  const [actionLoading, setActionLoading] = useState4(false);
  const [backendVersion, setBackendVersion] = useState4(null);
  const [apiStale, setApiStale] = useState4(false);
  const [partDisk, setPartDisk] = useState4("");
  const [partStart, setPartStart] = useState4("1MiB");
  const [partEnd, setPartEnd] = useState4("100%");
  const [partInitGpt, setPartInitGpt] = useState4(false);
  const [partConfirm, setPartConfirm] = useState4("");
  const [formatDevice, setFormatDevice] = useState4("");
  const [formatFs, setFormatFs] = useState4("ext4");
  const [formatLabel, setFormatLabel] = useState4("");
  const [formatConfirm, setFormatConfirm] = useState4("");
  const [mountDevice, setMountDevice] = useState4("");
  const [mountPoint, setMountPoint] = useState4("/mnt/data");
  const [mountFs, setMountFs] = useState4("ext4");
  const [mountOptions, setMountOptions] = useState4("defaults");
  const [mountPersist, setMountPersist] = useState4(true);
  const [unmountPoint, setUnmountPoint] = useState4("");
  const [unmountRemoveFstab, setUnmountRemoveFstab] = useState4(false);
  const [pools, setPools] = useState4(null);
  const [vgName, setVgName] = useState4("data-vg");
  const [vgDevices, setVgDevices] = useState4([]);
  const [vgConfirm, setVgConfirm] = useState4("");
  const [lvVg, setLvVg] = useState4("");
  const [lvName, setLvName] = useState4("data-lv");
  const [lvSize, setLvSize] = useState4("100%FREE");
  const [lvConfirm, setLvConfirm] = useState4("");
  const [extVg, setExtVg] = useState4("");
  const [extLv, setExtLv] = useState4("");
  const [extSize, setExtSize] = useState4("100%FREE");
  const [extGrowFs, setExtGrowFs] = useState4(true);
  const [extConfirm, setExtConfirm] = useState4("");
  const [raidLevel, setRaidLevel] = useState4(1);
  const [raidDevices, setRaidDevices] = useState4([]);
  const [raidConfirm, setRaidConfirm] = useState4("");
  const [maintenance, setMaintenance] = useState4(null);
  const [alerts, setAlerts] = useState4([]);
  const [smartDisk, setSmartDisk] = useState4("");
  const [smartTestType, setSmartTestType] = useState4("short");
  const [scrubMount, setScrubMount] = useState4("");
  const [raidCheckDev, setRaidCheckDev] = useState4("");
  const [fsckDevice, setFsckDevice] = useState4("");
  const [fsckRepair, setFsckRepair] = useState4(false);
  const [fsckConfirm, setFsckConfirm] = useState4("");
  const [smartDetails, setSmartDetails] = useState4({});
  const [smartLoading, setSmartLoading] = useState4(null);
  const [benchmarkDisk, setBenchmarkDisk] = useState4(null);
  const [benchmarkStatus, setBenchmarkStatus] = useState4(null);
  const [benchmarkProfile, setBenchmarkProfile] = useState4("quick");
  const t = {
    en: {
      title: "Storage Manager",
      desc: "Monitor physical drives, mounted volumes, and SMART disk health on this server.",
      overview: "Overview",
      disks: "Disks",
      volumes: "Volumes",
      healthy: "Healthy",
      warning: "Warning",
      critical: "Critical",
      systemHealthy: "System is healthy.",
      refresh: "Refresh",
      loading: "Loading storage data...",
      totalDisks: "Physical disks",
      totalVolumes: "Mounted volumes",
      totalCapacity: "Raw disk capacity",
      smartMonitored: "SMART monitored",
      volumeUsage: "Volume usage",
      noVolumes: "No mounted volumes detected.",
      noDisks: "No physical block devices found.",
      diskName: "Disk",
      model: "Model",
      size: "Size",
      transport: "Bus",
      health: "Health",
      systemDisk: "System",
      partitions: "Partitions",
      mount: "Mount",
      fstype: "Filesystem",
      used: "Used",
      free: "Free",
      temperature: "Temperature",
      powerOn: "Power-on hours",
      reallocated: "Reallocated sectors",
      smartMsg: "SMART message",
      toolsMissing: "Optional tools not installed on this server:",
      lsblk: "lsblk (util-linux)",
      smartctl: "smartmontools (smartctl)",
      parted: "parted",
      adminNote: "Destructive actions require superadmin. System disks and mounts (/ , /boot, CoPanel) are protected.",
      manage: "Manage",
      adminOnly: "Superadmin only",
      createPartition: "Create partition",
      formatPartition: "Format partition",
      mountVolume: "Mount volume",
      unmountVolume: "Unmount volume",
      selectDisk: "Select disk",
      selectPartition: "Select partition",
      selectMount: "Select mount point",
      start: "Start",
      end: "End",
      initGpt: "Initialize GPT on empty disk",
      confirmDiskName: "Type disk name to confirm",
      confirmPartName: "Type partition name to confirm",
      labelOptional: "Label (optional)",
      mountpoint: "Mount point",
      options: "Mount options",
      persistFstab: "Add to /etc/fstab",
      removeFstab: "Remove from /etc/fstab",
      runAction: "Run",
      fstabTitle: "/etc/fstab entries",
      dataLossWarning: "Formatting erases all data on the partition permanently.",
      success: "Success",
      noCandidateDisk: "No non-system disks available.",
      noCandidatePart: "No unmounted partitions on data disks.",
      pools: "Pools",
      lvmTitle: "LVM storage pools",
      raidTitle: "Software RAID (mdadm)",
      volumeGroups: "Volume groups",
      logicalVolumes: "Logical volumes",
      physicalVolumes: "Physical volumes",
      raidArrays: "RAID arrays",
      noVg: "No volume groups yet.",
      noLv: "No logical volumes yet.",
      noRaid: "No RAID arrays detected.",
      createVg: "Create volume group",
      createLv: "Create logical volume",
      extendLv: "Extend logical volume",
      createRaid: "Create RAID array",
      vgName: "Volume group name",
      lvName: "Logical volume name",
      lvSize: "Size (100G or 100%FREE)",
      selectDevices: "Select devices",
      raidLevel: "RAID level",
      confirmVgName: "Type VG name to confirm",
      confirmLvPath: "Type vg_name/lv_name to confirm",
      confirmRaid: "Type CREATE-RAID to confirm",
      growFilesystem: "Grow filesystem after extend",
      vgFree: "free",
      raidConfirmWarning: "Creating RAID will erase data on selected devices.",
      lvm: "lvm2",
      mdadm: "mdadm",
      maintenance: "Maintenance",
      maintenanceTitle: "Drive health checks & scrub",
      smartTest: "SMART self-test",
      smartShort: "Short test (~2 min)",
      smartLong: "Long test (hours)",
      btrfsScrub: "Btrfs scrub",
      raidCheck: "RAID parity check",
      runTest: "Start test",
      runScrub: "Start scrub",
      runRaidCheck: "Start check",
      maintenanceHistory: "Recent maintenance",
      noHistory: "No maintenance actions yet.",
      activeAlerts: "Active alerts",
      noAlerts: "No storage alerts.",
      selectDrive: "Select drive",
      healthPercent: "Health",
      hostReads: "Host reads",
      hostWrites: "Host writes",
      powerCycles: "Power cycles",
      diskBenchmark: "Disk speed test",
      benchmarkHint: "Sequential & 4K random read/write (CrystalDiskMark-style). Write tests use an unmounted data partition.",
      runBenchmark: "Run speed test",
      benchmarkRunning: "Benchmark running\u2026",
      seqRead: "Seq. read",
      seqWrite: "Seq. write",
      rand4kRead: "4K random read",
      rand4kWrite: "4K random write",
      benchmarkSkipped: "Skipped",
      profileQuick: "Quick (~30s)",
      profileStandard: "Standard (~60s)",
      refreshSmart: "Refresh SMART",
      fsckTitle: "Filesystem check (fsck)",
      fsckCheck: "Check only (read-only)",
      fsckRepair: "Repair errors automatically",
      fsckConfirm: "Type partition name to confirm",
      fsckUnmountNote: "Partition must be unmounted. System disk partitions are blocked.",
      runFsck: "Run check",
      selectPartitionFsck: "Select unmounted partition",
      noFsckCandidates: "No unmounted partitions with a supported filesystem.",
      diskMap: "Disk map",
      partitionList: "Partition list",
      operations: "Operations",
      unallocated: "Unallocated",
      deletePartition: "Delete partition",
      resizePartition: "Move / resize",
      changeLabel: "Change label",
      setBoot: "Set boot / ESP",
      clearBoot: "Clear boot flag",
      properties: "Device",
      partitionTable: "Table",
      capacity: "Capacity",
      unused: "Unused",
      type: "Type",
      status: "Status",
      mounted: "Mounted",
      unmounted: "Unmounted",
      boot: "Boot",
      deleteWarning: "Deleting a partition erases all data on it permanently.",
      resizeHint: "New end position (e.g. 100% or 500GiB). Unmount first to shrink.",
      cancel: "Cancel",
      loadingLayout: "Loading partition layout\u2026",
      protectedNote: "System disk \u2014 partition changes blocked.",
      apiStaleBanner: "Backend API is outdated (missing routes after module update). Run: sudo systemctl restart copanel \u2014 or use AppStore \xABRestart CoPanel\xBB.",
      backendVersionLabel: (v) => `Backend module v${v}`,
      diskOperations: "Disk",
      initializeDisk: "Initialize partition table",
      initializeDiskTitle: "Initialize disk (step 1)",
      initializeDiskHint: "Create a GPT or MBR partition table on a raw/unformatted disk before creating partitions.",
      tableGpt: "GPT \u2014 recommended for UEFI and disks over 2 TB",
      tableMbr: "MBR (msdos) \u2014 legacy BIOS, max 4 primary partitions",
      uninitializedBanner: "This disk has no partition table (raw / unformatted).",
      uninitializedStep: "Step 1: Initialize disk (GPT or MBR). Step 2: Create partition. Step 3: Format.",
      emptyTableStep: "Partition table ready \u2014 step 2: create a partition in the free space, then format.",
      rawDiskLabel: "Raw disk",
      initWipeWarning: "Erases any existing partition table on this disk. All data will be lost.",
      addToQueue: "Add to queue",
      partitionType: "Partition type",
      typeLinux: "Linux data (ext4)",
      typeEfi: "EFI System (FAT32)",
      typeSwap: "Linux swap",
      typeNtfs: "Microsoft NTFS",
      typeLvm: "LVM physical volume",
      dragResizeHint: "Select a partition, drag the right edge to extend or shrink (unmounted only; ext4/ntfs shrink).",
      extendPreview: (mib) => `Extend to ${mib} MiB`,
      shrinkPreview: (mib) => `Shrink to ${mib} MiB`,
      shrinkPartition: "Shrink partition",
      shrinkFilesystem: "Shrink filesystem before partition shrink",
      shrinkHint: "Shrink requires the partition to be unmounted. ext4/ntfs supported; XFS cannot shrink.",
      queue: {
        pendingOps: "Pending operations",
        pendingEmpty: "Queue empty \u2014 use \xABAdd to queue\xBB in dialogs.",
        applyAll: "Apply all",
        validate: "Validate",
        clearQueue: "Clear queue",
        operationLog: "Operation log",
        logEmpty: "No operations applied yet.",
        remove: "Remove",
        validating: "Validating\u2026",
        applying: "Applying\u2026",
        validationOk: "Validation passed",
        validationFailed: "Validation failed"
      }
    },
    vi: {
      title: "Qu\u1EA3n l\xFD L\u01B0u tr\u1EEF",
      desc: "Theo d\xF5i \u1ED5 \u0111\u0129a v\u1EADt l\xFD, volume \u0111\xE3 mount v\xE0 s\u1EE9c kh\u1ECFe SMART tr\xEAn m\xE1y ch\u1EE7.",
      overview: "T\u1ED5ng quan",
      disks: "\u1ED4 \u0111\u0129a",
      volumes: "Volume",
      healthy: "Kh\u1ECFe m\u1EA1nh",
      warning: "C\u1EA3nh b\xE1o",
      critical: "Nguy hi\u1EC3m",
      systemHealthy: "H\u1EC7 th\u1ED1ng l\u01B0u tr\u1EEF kh\u1ECFe m\u1EA1nh.",
      refresh: "L\xE0m m\u1EDBi",
      loading: "\u0110ang t\u1EA3i d\u1EEF li\u1EC7u l\u01B0u tr\u1EEF...",
      totalDisks: "\u1ED4 \u0111\u0129a v\u1EADt l\xFD",
      totalVolumes: "Volume \u0111\xE3 mount",
      totalCapacity: "Dung l\u01B0\u1EE3ng \u1ED5 th\xF4",
      smartMonitored: "\u0110ang gi\xE1m s\xE1t SMART",
      volumeUsage: "Dung l\u01B0\u1EE3ng volume",
      noVolumes: "Kh\xF4ng ph\xE1t hi\u1EC7n volume \u0111\xE3 mount.",
      noDisks: "Kh\xF4ng t\xECm th\u1EA5y block device v\u1EADt l\xFD.",
      diskName: "\u1ED4 \u0111\u0129a",
      model: "Model",
      size: "Dung l\u01B0\u1EE3ng",
      transport: "Bus",
      health: "S\u1EE9c kh\u1ECFe",
      systemDisk: "H\u1EC7 th\u1ED1ng",
      partitions: "Ph\xE2n v\xF9ng",
      mount: "Mount",
      fstype: "H\u1EC7 th\u1ED1ng t\u1EC7p",
      used: "\u0110\xE3 d\xF9ng",
      free: "C\xF2n tr\u1ED1ng",
      temperature: "Nhi\u1EC7t \u0111\u1ED9",
      powerOn: "Gi\u1EDD ho\u1EA1t \u0111\u1ED9ng",
      reallocated: "Sector t\xE1i ph\xE2n b\u1ED5",
      smartMsg: "Th\xF4ng b\xE1o SMART",
      toolsMissing: "Thi\u1EBFu c\xF4ng c\u1EE5 t\xF9y ch\u1ECDn tr\xEAn m\xE1y ch\u1EE7:",
      lsblk: "lsblk (util-linux)",
      smartctl: "smartmontools (smartctl)",
      parted: "parted",
      adminNote: "Thao t\xE1c ph\xE1 ho\u1EA1i c\u1EA7n superadmin. \u1ED4 h\u1EC7 th\u1ED1ng v\xE0 mount (/, /boot, CoPanel) \u0111\u01B0\u1EE3c b\u1EA3o v\u1EC7.",
      manage: "Qu\u1EA3n l\xFD",
      adminOnly: "Ch\u1EC9 superadmin",
      createPartition: "T\u1EA1o ph\xE2n v\xF9ng",
      formatPartition: "\u0110\u1ECBnh d\u1EA1ng ph\xE2n v\xF9ng",
      mountVolume: "Mount volume",
      unmountVolume: "G\u1EE1 mount",
      selectDisk: "Ch\u1ECDn \u1ED5 \u0111\u0129a",
      selectPartition: "Ch\u1ECDn ph\xE2n v\xF9ng",
      selectMount: "Ch\u1ECDn \u0111i\u1EC3m mount",
      start: "B\u1EAFt \u0111\u1EA7u",
      end: "K\u1EBFt th\xFAc",
      initGpt: "Kh\u1EDFi t\u1EA1o GPT cho \u1ED5 m\u1EDBi",
      confirmDiskName: "Nh\u1EADp t\xEAn \u1ED5 \u0111\u1EC3 x\xE1c nh\u1EADn",
      confirmPartName: "Nh\u1EADp t\xEAn ph\xE2n v\xF9ng \u0111\u1EC3 x\xE1c nh\u1EADn",
      labelOptional: "Nh\xE3n (t\xF9y ch\u1ECDn)",
      mountpoint: "\u0110i\u1EC3m mount",
      options: "T\xF9y ch\u1ECDn mount",
      persistFstab: "Th\xEAm v\xE0o /etc/fstab",
      removeFstab: "X\xF3a kh\u1ECFi /etc/fstab",
      runAction: "Th\u1EF1c hi\u1EC7n",
      fstabTitle: "M\u1EE5c /etc/fstab",
      dataLossWarning: "\u0110\u1ECBnh d\u1EA1ng s\u1EBD x\xF3a v\u0129nh vi\u1EC5n m\u1ECDi d\u1EEF li\u1EC7u tr\xEAn ph\xE2n v\xF9ng.",
      success: "Th\xE0nh c\xF4ng",
      noCandidateDisk: "Kh\xF4ng c\xF3 \u1ED5 d\u1EEF li\u1EC7u kh\u1EA3 d\u1EE5ng.",
      noCandidatePart: "Kh\xF4ng c\xF3 ph\xE2n v\xF9ng ch\u01B0a mount tr\xEAn \u1ED5 d\u1EEF li\u1EC7u.",
      pools: "Pool",
      lvmTitle: "Pool l\u01B0u tr\u1EEF LVM",
      raidTitle: "RAID ph\u1EA7n m\u1EC1m (mdadm)",
      volumeGroups: "Volume group",
      logicalVolumes: "Logical volume",
      physicalVolumes: "Physical volume",
      raidArrays: "M\u1EA3ng RAID",
      noVg: "Ch\u01B0a c\xF3 volume group.",
      noLv: "Ch\u01B0a c\xF3 logical volume.",
      noRaid: "Kh\xF4ng ph\xE1t hi\u1EC7n m\u1EA3ng RAID.",
      createVg: "T\u1EA1o volume group",
      createLv: "T\u1EA1o logical volume",
      extendLv: "M\u1EDF r\u1ED9ng logical volume",
      createRaid: "T\u1EA1o m\u1EA3ng RAID",
      vgName: "T\xEAn volume group",
      lvName: "T\xEAn logical volume",
      lvSize: "Dung l\u01B0\u1EE3ng (100G ho\u1EB7c 100%FREE)",
      selectDevices: "Ch\u1ECDn thi\u1EBFt b\u1ECB",
      raidLevel: "C\u1EA5p RAID",
      confirmVgName: "Nh\u1EADp t\xEAn VG \u0111\u1EC3 x\xE1c nh\u1EADn",
      confirmLvPath: "Nh\u1EADp vg_name/lv_name \u0111\u1EC3 x\xE1c nh\u1EADn",
      confirmRaid: "Nh\u1EADp CREATE-RAID \u0111\u1EC3 x\xE1c nh\u1EADn",
      growFilesystem: "M\u1EDF r\u1ED9ng filesystem sau extend",
      vgFree: "c\xF2n tr\u1ED1ng",
      raidConfirmWarning: "T\u1EA1o RAID s\u1EBD x\xF3a d\u1EEF li\u1EC7u tr\xEAn c\xE1c thi\u1EBFt b\u1ECB \u0111\xE3 ch\u1ECDn.",
      lvm: "lvm2",
      mdadm: "mdadm",
      maintenance: "B\u1EA3o tr\xEC",
      maintenanceTitle: "Ki\u1EC3m tra s\u1EE9c kh\u1ECFe \u1ED5 & scrub",
      smartTest: "SMART self-test",
      smartShort: "Test ng\u1EAFn (~2 ph\xFAt)",
      smartLong: "Test d\xE0i (nhi\u1EC1u gi\u1EDD)",
      btrfsScrub: "Btrfs scrub",
      raidCheck: "Ki\u1EC3m tra RAID",
      runTest: "B\u1EAFt \u0111\u1EA7u test",
      runScrub: "B\u1EAFt \u0111\u1EA7u scrub",
      runRaidCheck: "B\u1EAFt \u0111\u1EA7u ki\u1EC3m tra",
      maintenanceHistory: "B\u1EA3o tr\xEC g\u1EA7n \u0111\xE2y",
      noHistory: "Ch\u01B0a c\xF3 thao t\xE1c b\u1EA3o tr\xEC.",
      activeAlerts: "C\u1EA3nh b\xE1o \u0111ang ho\u1EA1t \u0111\u1ED9ng",
      noAlerts: "Kh\xF4ng c\xF3 c\u1EA3nh b\xE1o l\u01B0u tr\u1EEF.",
      selectDrive: "Ch\u1ECDn \u1ED5 \u0111\u0129a",
      healthPercent: "S\u1EE9c kh\u1ECFe",
      hostReads: "\u0110\xE3 \u0111\u1ECDc",
      hostWrites: "\u0110\xE3 ghi",
      powerCycles: "Chu k\u1EF3 ngu\u1ED3n",
      diskBenchmark: "Test t\u1ED1c \u0111\u1ED9 \u1ED5 \u0111\u0129a",
      benchmarkHint: "\u0110\u1ECDc/ghi tu\u1EA7n t\u1EF1 & ng\u1EABu nhi\xEAn 4K (ki\u1EC3u CrystalDiskMark). Ghi d\xF9ng ph\xE2n v\xF9ng d\u1EEF li\u1EC7u ch\u01B0a mount.",
      runBenchmark: "Ch\u1EA1y test t\u1ED1c \u0111\u1ED9",
      benchmarkRunning: "\u0110ang ch\u1EA1y benchmark\u2026",
      seqRead: "\u0110\u1ECDc tu\u1EA7n t\u1EF1",
      seqWrite: "Ghi tu\u1EA7n t\u1EF1",
      rand4kRead: "\u0110\u1ECDc 4K ng\u1EABu nhi\xEAn",
      rand4kWrite: "Ghi 4K ng\u1EABu nhi\xEAn",
      benchmarkSkipped: "B\u1ECF qua",
      profileQuick: "Nhanh (~30 gi\xE2y)",
      profileStandard: "\u0110\u1EA7y \u0111\u1EE7 (~60 gi\xE2y)",
      refreshSmart: "L\xE0m m\u1EDBi SMART",
      fsckTitle: "Ki\u1EC3m tra / s\u1EEDa l\u1ED7i filesystem (fsck)",
      fsckCheck: "Ch\u1EC9 ki\u1EC3m tra (read-only)",
      fsckRepair: "T\u1EF1 \u0111\u1ED9ng s\u1EEDa l\u1ED7i",
      fsckConfirm: "Nh\u1EADp t\xEAn ph\xE2n v\xF9ng \u0111\u1EC3 x\xE1c nh\u1EADn",
      fsckUnmountNote: "Ph\xE2n v\xF9ng ph\u1EA3i \u0111\xE3 g\u1EE1 mount. Ph\xE2n v\xF9ng \u1ED5 h\u1EC7 th\u1ED1ng b\u1ECB ch\u1EB7n.",
      runFsck: "Ch\u1EA1y ki\u1EC3m tra",
      selectPartitionFsck: "Ch\u1ECDn ph\xE2n v\xF9ng ch\u01B0a mount",
      noFsckCandidates: "Kh\xF4ng c\xF3 ph\xE2n v\xF9ng ch\u01B0a mount h\u1ED7 tr\u1EE3 fsck.",
      diskMap: "S\u01A1 \u0111\u1ED3 \u1ED5 \u0111\u0129a",
      partitionList: "Danh s\xE1ch ph\xE2n v\xF9ng",
      operations: "Thao t\xE1c",
      unallocated: "Ch\u01B0a ph\xE2n b\u1ED5",
      deletePartition: "X\xF3a ph\xE2n v\xF9ng",
      resizePartition: "Di chuy\u1EC3n / thay \u0111\u1ED5i k\xEDch th\u01B0\u1EDBc",
      changeLabel: "\u0110\u1ED5i nh\xE3n",
      setBoot: "\u0110\u1EB7t boot / ESP",
      clearBoot: "B\u1ECF c\u1EDD boot",
      properties: "Thi\u1EBFt b\u1ECB",
      partitionTable: "B\u1EA3ng ph\xE2n v\xF9ng",
      capacity: "Dung l\u01B0\u1EE3ng",
      unused: "C\xF2n tr\u1ED1ng",
      type: "Lo\u1EA1i",
      status: "Tr\u1EA1ng th\xE1i",
      mounted: "\u0110\xE3 mount",
      unmounted: "Ch\u01B0a mount",
      boot: "Boot",
      deleteWarning: "X\xF3a ph\xE2n v\xF9ng s\u1EBD x\xF3a v\u0129nh vi\u1EC5n m\u1ECDi d\u1EEF li\u1EC7u tr\xEAn \u0111\xF3.",
      resizeHint: "V\u1ECB tr\xED k\u1EBFt th\xFAc m\u1EDBi (vd. 100% ho\u1EB7c 500GiB). G\u1EE1 mount tr\u01B0\u1EDBc khi thu nh\u1ECF.",
      cancel: "H\u1EE7y",
      loadingLayout: "\u0110ang t\u1EA3i b\u1ED1 c\u1EE5c ph\xE2n v\xF9ng\u2026",
      protectedNote: "\u1ED4 h\u1EC7 th\u1ED1ng \u2014 kh\xF4ng cho s\u1EEDa ph\xE2n v\xF9ng.",
      apiStaleBanner: "API backend \u0111\xE3 c\u0169 (thi\u1EBFu route sau khi c\u1EADp nh\u1EADt module). Ch\u1EA1y: sudo systemctl restart copanel \u2014 ho\u1EB7c b\u1EA5m \xABRestart CoPanel\xBB trong AppStore.",
      backendVersionLabel: (v) => `Module backend v${v}`,
      diskOperations: "\u1ED4 \u0111\u0129a",
      initializeDisk: "Kh\u1EDFi t\u1EA1o b\u1EA3ng ph\xE2n v\xF9ng",
      initializeDiskTitle: "Kh\u1EDFi t\u1EA1o \u1ED5 \u0111\u0129a (b\u01B0\u1EDBc 1)",
      initializeDiskHint: "T\u1EA1o b\u1EA3ng ph\xE2n v\xF9ng GPT ho\u1EB7c MBR tr\xEAn \u1ED5 tr\u1ED1ng/ch\u01B0a \u0111\u1ECBnh d\u1EA1ng tr\u01B0\u1EDBc khi t\u1EA1o ph\xE2n v\xF9ng.",
      tableGpt: "GPT \u2014 khuy\u1EBFn ngh\u1ECB cho UEFI v\xE0 \u1ED5 tr\xEAn 2 TB",
      tableMbr: "MBR (msdos) \u2014 BIOS c\u0169, t\u1ED1i \u0111a 4 ph\xE2n v\xF9ng primary",
      uninitializedBanner: "\u1ED4 \u0111\u0129a ch\u01B0a c\xF3 b\u1EA3ng ph\xE2n v\xF9ng (raw / ch\u01B0a \u0111\u1ECBnh d\u1EA1ng).",
      uninitializedStep: "B\u01B0\u1EDBc 1: Kh\u1EDFi t\u1EA1o \u1ED5 (GPT ho\u1EB7c MBR). B\u01B0\u1EDBc 2: T\u1EA1o ph\xE2n v\xF9ng. B\u01B0\u1EDBc 3: \u0110\u1ECBnh d\u1EA1ng.",
      emptyTableStep: "\u0110\xE3 c\xF3 b\u1EA3ng ph\xE2n v\xF9ng \u2014 b\u01B0\u1EDBc 2: t\u1EA1o ph\xE2n v\xF9ng trong v\xF9ng tr\u1ED1ng, r\u1ED3i \u0111\u1ECBnh d\u1EA1ng.",
      rawDiskLabel: "\u1ED4 th\xF4",
      initWipeWarning: "X\xF3a m\u1ECDi b\u1EA3ng ph\xE2n v\xF9ng hi\u1EC7n c\xF3. M\u1EA5t to\xE0n b\u1ED9 d\u1EEF li\u1EC7u tr\xEAn \u1ED5.",
      addToQueue: "Th\xEAm v\xE0o h\xE0ng \u0111\u1EE3i",
      partitionType: "Lo\u1EA1i ph\xE2n v\xF9ng",
      typeLinux: "Linux d\u1EEF li\u1EC7u (ext4)",
      typeEfi: "EFI System (FAT32)",
      typeSwap: "Linux swap",
      typeNtfs: "Microsoft NTFS",
      typeLvm: "LVM physical volume",
      dragResizeHint: "Ch\u1ECDn ph\xE2n v\xF9ng, k\xE9o c\u1EA1nh ph\u1EA3i \u0111\u1EC3 m\u1EDF r\u1ED9ng ho\u1EB7c thu nh\u1ECF (ch\u01B0a mount; ext4/ntfs).",
      extendPreview: (mib) => `M\u1EDF r\u1ED9ng t\u1EDBi ${mib} MiB`,
      shrinkPreview: (mib) => `Thu nh\u1ECF t\u1EDBi ${mib} MiB`,
      shrinkPartition: "Thu nh\u1ECF ph\xE2n v\xF9ng",
      shrinkFilesystem: "Thu nh\u1ECF filesystem tr\u01B0\u1EDBc khi thu ph\xE2n v\xF9ng",
      shrinkHint: "Thu nh\u1ECF c\u1EA7n unmount ph\xE2n v\xF9ng. H\u1ED7 tr\u1EE3 ext4/ntfs; XFS kh\xF4ng thu nh\u1ECF \u0111\u01B0\u1EE3c.",
      queue: {
        pendingOps: "Thao t\xE1c ch\u1EDD",
        pendingEmpty: "H\xE0ng \u0111\u1EE3i tr\u1ED1ng \u2014 d\xF9ng \xABTh\xEAm v\xE0o h\xE0ng \u0111\u1EE3i\xBB trong h\u1ED9p tho\u1EA1i.",
        applyAll: "\xC1p d\u1EE5ng t\u1EA5t c\u1EA3",
        validate: "Ki\u1EC3m tra",
        clearQueue: "X\xF3a h\xE0ng \u0111\u1EE3i",
        operationLog: "Nh\u1EADt k\xFD thao t\xE1c",
        logEmpty: "Ch\u01B0a \xE1p d\u1EE5ng thao t\xE1c n\xE0o.",
        remove: "X\xF3a",
        validating: "\u0110ang ki\u1EC3m tra\u2026",
        applying: "\u0110ang \xE1p d\u1EE5ng\u2026",
        validationOk: "Ki\u1EC3m tra OK",
        validationFailed: "Ki\u1EC3m tra th\u1EA5t b\u1EA1i"
      }
    }
  };
  const tr = t[language || "en"];
  const authHeaders = useMemo2(() => {
    const h = {};
    if (token) h.Authorization = `Bearer ${token}`;
    return h;
  }, [token]);
  const fetchJson = useCallback3(async (path) => {
    const res = await fetch(path, { headers: authHeaders });
    const body = await res.json().catch(() => ({}));
    if (!res.ok) {
      throw new Error(apiErrorMessage(body, res.status));
    }
    return body.data;
  }, [authHeaders]);
  const postJson = useCallback3(async (path, payload) => {
    const res = await fetch(path, {
      method: "POST",
      headers: { ...authHeaders, "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    const body = await res.json().catch(() => ({}));
    if (!res.ok) {
      throw new Error(apiErrorMessage(body, res.status));
    }
    return body.data;
  }, [authHeaders]);
  const loadAll = useCallback3(async () => {
    setLoading(true);
    setError(null);
    const errors = [];
    const settled = await Promise.allSettled([
      fetchJson("/api/storage_manager/overview"),
      fetchJson("/api/storage_manager/disks"),
      fetchJson("/api/storage_manager/volumes"),
      fetchJson("/api/storage_manager/fstab"),
      fetchJson("/api/storage_manager/pools"),
      fetchJson("/api/storage_manager/maintenance"),
      fetchJson("/api/storage_manager/alerts")
    ]);
    const [ovR, dkR, volR, fstR, poolR, maintR, alertR] = settled;
    if (ovR.status === "fulfilled") setOverview(ovR.value);
    else errors.push(ovR.reason instanceof Error ? ovR.reason.message : "overview failed");
    if (dkR.status === "fulfilled") setDisks(dkR.value);
    else {
      setDisks([]);
      errors.push(dkR.reason instanceof Error ? dkR.reason.message : "disks failed");
    }
    if (volR.status === "fulfilled") setVolumes(volR.value);
    else {
      setVolumes([]);
      errors.push(volR.reason instanceof Error ? volR.reason.message : "volumes failed");
    }
    setFstab(fstR.status === "fulfilled" ? fstR.value : []);
    setPools(poolR.status === "fulfilled" ? poolR.value : null);
    setMaintenance(maintR.status === "fulfilled" ? maintR.value : null);
    setAlerts(alertR.status === "fulfilled" ? alertR.value?.alerts || [] : []);
    if (errors.length > 0) {
      setError(errors.join(" \xB7 "));
    }
    try {
      const [verResult, modResult] = await Promise.allSettled([
        fetchJson("/api/storage_manager/version"),
        fetch("/api/modules", { headers: authHeaders }).then(async (res) => {
          const body = await res.json().catch(() => ({}));
          if (!res.ok) throw new Error("modules list failed");
          return body;
        })
      ]);
      if (verResult.status === "fulfilled") {
        setBackendVersion(verResult.value.version);
      } else {
        setBackendVersion(null);
      }
      const routes = modResult.status === "fulfilled" ? modResult.value.modules?.storage_manager?.routes || [] : [];
      const routeCount = modResult.status === "fulfilled" ? modResult.value.modules?.storage_manager?.route_count ?? routes.length : 0;
      const hasRouteCatalog = modResult.status === "fulfilled" && modResult.value.modules?.storage_manager != null && typeof modResult.value.modules === "object" && !Array.isArray(modResult.value.modules) && routeCount > 0;
      const routesMissing = hasRouteCatalog ? REQUIRED_STORAGE_ROUTES.some((path) => !routes.includes(path)) : false;
      const versionMissing = verResult.status !== "fulfilled";
      setApiStale(versionMissing || routesMissing);
    } catch {
      setBackendVersion(null);
      setApiStale(true);
    }
    setLoading(false);
  }, [fetchJson, authHeaders]);
  useEffect4(() => {
    loadAll();
  }, [loadAll, language]);
  const loadSmartDetail = useCallback3(async (diskName) => {
    setSmartLoading(diskName);
    try {
      const data = await fetchJson(`/api/storage_manager/disks/${encodeURIComponent(diskName)}/smart`);
      setSmartDetails((prev) => ({ ...prev, [diskName]: data }));
    } catch {
    } finally {
      setSmartLoading(null);
    }
  }, [fetchJson]);
  useEffect4(() => {
    if (expandedDisk) {
      loadSmartDetail(expandedDisk);
    }
  }, [expandedDisk, loadSmartDetail]);
  const pollBenchmark = useCallback3(async (diskName) => {
    const data = await fetchJson(
      `/api/storage_manager/disks/${encodeURIComponent(diskName)}/benchmark`
    );
    setBenchmarkStatus(data);
    return data;
  }, [fetchJson]);
  const startBenchmark = useCallback3(async (diskName) => {
    setBenchmarkDisk(diskName);
    setBenchmarkStatus({ status: "running", progress: 5 });
    try {
      await postJson(`/api/storage_manager/disks/${encodeURIComponent(diskName)}/benchmark`, {
        profile: benchmarkProfile
      });
      const poll = async () => {
        try {
          const st = await pollBenchmark(diskName);
          if (st.status === "running") {
            window.setTimeout(poll, 1500);
          }
        } catch (err) {
          setBenchmarkStatus({
            status: "failed",
            error: err instanceof Error ? err.message : "Benchmark poll failed"
          });
        }
      };
      poll();
    } catch (err) {
      setBenchmarkStatus({
        status: "failed",
        error: err instanceof Error ? err.message : "Failed to start benchmark"
      });
    }
  }, [benchmarkProfile, pollBenchmark, postJson]);
  const health = overview?.health || "healthy";
  const hs = healthStyles(health, isDark);
  const healthLabel = health === "critical" ? tr.critical : health === "warning" ? tr.warning : tr.healthy;
  const tabs = [
    { id: "overview", label: tr.overview, icon: Icons6.LayoutDashboard },
    { id: "disks", label: tr.disks, icon: Icons6.HardDrive },
    { id: "volumes", label: tr.volumes, icon: Icons6.Database },
    { id: "pools", label: tr.pools, icon: Icons6.Layers },
    { id: "maintenance", label: tr.maintenance, icon: Icons6.Stethoscope },
    { id: "manage", label: tr.manage, icon: Icons6.Settings2 }
  ];
  const usedPvPaths = useMemo2(
    () => new Set((pools?.lvm.physical_volumes || []).map((p) => p.pv_name)),
    [pools]
  );
  const togglePoolDevice = (path, list, setter) => {
    setter(list.includes(path) ? list.filter((p) => p !== path) : [...list, path]);
  };
  const dataDisks = useMemo2(() => disks.filter((d) => !d.is_system_disk), [disks]);
  const formatCandidates = useMemo2(() => {
    return dataDisks.flatMap(
      (d) => d.partitions.filter((p) => !p.mountpoint).map((p) => ({ ...p, diskName: d.name }))
    );
  }, [dataDisks]);
  const poolDeviceCandidates = useMemo2(
    () => formatCandidates.filter((p) => !usedPvPaths.has(p.path)),
    [formatCandidates, usedPvPaths]
  );
  const unmountCandidates = useMemo2(
    () => volumes.filter((v) => !isProtectedMount(v.mountpoint)),
    [volumes]
  );
  const runAction = async (fn) => {
    setActionLoading(true);
    setActionErr(null);
    setActionMsg(null);
    try {
      const result = await fn();
      setActionMsg(result.message || tr.success);
      await loadAll();
      return true;
    } catch (err) {
      setActionErr(err instanceof Error ? err.message : "Action failed");
      return false;
    } finally {
      setActionLoading(false);
    }
  };
  const missingTools = overview ? [
    !overview.tools.lsblk ? tr.lsblk : null,
    !overview.tools.smartctl ? tr.smartctl : null,
    overview.tools.parted === false ? tr.parted : null,
    overview.tools.lvm === false ? tr.lvm : null,
    overview.tools.mdadm === false ? tr.mdadm : null
  ].filter(Boolean) : [];
  const windowed = useIsWindowedModule();
  const ui = storageTheme(isDark);
  return /* @__PURE__ */ jsx9(
    ModuleViewport,
    {
      constrained: true,
      className: `h-full min-h-0 ${windowed ? "p-0" : "p-3 md:p-4"}`,
      children: /* @__PURE__ */ jsxs6(
        "div",
        {
          className: `flex h-full min-h-0 flex-col overflow-hidden border ${ui.panel} ${windowed ? "rounded-none border-0" : "rounded-xl shadow-sm"}`,
          children: [
            /* @__PURE__ */ jsxs6("header", { className: `flex shrink-0 items-center gap-3 border-b px-4 py-2.5 ${ui.headerBorder}`, children: [
              /* @__PURE__ */ jsx9("div", { className: `flex h-9 w-9 shrink-0 items-center justify-center rounded-lg ${isDark ? "bg-cyan-500/15" : "bg-cyan-50"}`, children: /* @__PURE__ */ jsx9(Icons6.HardDrive, { className: `h-5 w-5 ${isDark ? "text-cyan-400" : "text-cyan-600"}` }) }),
              /* @__PURE__ */ jsxs6("div", { className: "min-w-0 flex-1", children: [
                /* @__PURE__ */ jsx9("h1", { className: "truncate text-sm font-semibold leading-tight", children: tr.title }),
                /* @__PURE__ */ jsx9("p", { className: `truncate text-[11px] ${ui.muted}`, children: tr.desc })
              ] }),
              /* @__PURE__ */ jsxs6("div", { className: "hidden items-center gap-2 sm:flex", children: [
                /* @__PURE__ */ jsxs6(
                  "span",
                  {
                    className: `inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[10px] font-bold ${hs.ring}`,
                    children: [
                      /* @__PURE__ */ jsx9("span", { className: `h-1.5 w-1.5 rounded-full ${health === "healthy" ? "bg-emerald-500" : health === "warning" ? "bg-amber-500" : "bg-red-500"}` }),
                      healthLabel
                    ]
                  }
                ),
                overview && /* @__PURE__ */ jsxs6("span", { className: `text-[10px] font-mono ${ui.muted}`, children: [
                  overview.disk_count,
                  " ",
                  tr.disks.toLowerCase(),
                  " \xB7 ",
                  overview.volume_count,
                  " ",
                  tr.volumes.toLowerCase()
                ] })
              ] }),
              /* @__PURE__ */ jsxs6(
                "button",
                {
                  type: "button",
                  onClick: loadAll,
                  disabled: loading,
                  className: `flex shrink-0 items-center gap-1.5 rounded-lg border px-3 py-1.5 text-[11px] font-semibold transition ${ui.btn}`,
                  children: [
                    /* @__PURE__ */ jsx9(Icons6.RefreshCw, { className: `h-3.5 w-3.5 ${loading ? "animate-spin" : ""}` }),
                    tr.refresh
                  ]
                }
              )
            ] }),
            apiStale && /* @__PURE__ */ jsx9("div", { className: `shrink-0 border-b px-4 py-2 text-[11px] ${isDark ? "border-red-900/40 bg-red-950/30 text-red-200" : "border-red-200 bg-red-50 text-red-800"}`, children: tr.apiStaleBanner }),
            error && /* @__PURE__ */ jsxs6("div", { className: `mx-3 mt-2 flex shrink-0 items-center gap-2 rounded-lg border px-3 py-2 text-[11px] ${isDark ? "border-red-800/50 bg-red-950/30 text-red-300" : "border-red-200 bg-red-50 text-red-700"}`, children: [
              /* @__PURE__ */ jsx9(Icons6.AlertCircle, { className: "h-3.5 w-3.5 shrink-0" }),
              /* @__PURE__ */ jsx9("span", { className: "flex-1", children: error }),
              /* @__PURE__ */ jsx9("button", { type: "button", onClick: () => setError(null), className: ui.muted, children: /* @__PURE__ */ jsx9(Icons6.X, { className: "h-3.5 w-3.5" }) })
            ] }),
            /* @__PURE__ */ jsx9(
              ModuleSidebarLayout,
              {
                isDark,
                mobileTitle: tr.title,
                sidebar: /* @__PURE__ */ jsxs6("aside", { className: `flex h-full w-48 shrink-0 flex-col border-r xl:w-52 ${ui.sidebar}`, children: [
                  /* @__PURE__ */ jsx9("nav", { className: "flex-1 space-y-0.5 overflow-y-auto p-2", children: tabs.map((item) => {
                    const Icon = item.icon;
                    const active = tab === item.id;
                    return /* @__PURE__ */ jsxs6(
                      "button",
                      {
                        type: "button",
                        onClick: () => setTab(item.id),
                        className: `flex w-full items-center gap-2.5 rounded-lg px-3 py-2 text-left text-[12px] font-medium transition ${active ? ui.activeNav : `${ui.muted} ${ui.hoverNav}`}`,
                        children: [
                          /* @__PURE__ */ jsx9(Icon, { className: `h-4 w-4 shrink-0 ${active ? isDark ? "text-cyan-400" : "text-cyan-600" : ""}` }),
                          /* @__PURE__ */ jsx9("span", { className: "truncate", children: item.label })
                        ]
                      },
                      item.id
                    );
                  }) }),
                  /* @__PURE__ */ jsxs6("div", { className: `shrink-0 border-t p-2 text-[10px] leading-snug ${ui.headerBorder} ${ui.muted}`, children: [
                    /* @__PURE__ */ jsx9("p", { children: tr.adminNote }),
                    backendVersion && /* @__PURE__ */ jsx9("p", { className: "mt-1 font-mono opacity-70", children: tr.backendVersionLabel(backendVersion) }),
                    missingTools.length > 0 && /* @__PURE__ */ jsxs6("p", { className: `mt-1 ${isDark ? "text-amber-400/90" : "text-amber-700"}`, children: [
                      tr.toolsMissing,
                      " ",
                      missingTools.join(", ")
                    ] })
                  ] })
                ] }),
                children: /* @__PURE__ */ jsx9("main", { className: "flex min-h-0 min-w-0 flex-1 flex-col", children: loading && !overview ? /* @__PURE__ */ jsxs6("div", { className: `flex flex-1 flex-col items-center justify-center ${ui.muted}`, children: [
                  /* @__PURE__ */ jsx9(Icons6.Loader2, { className: "mb-2 h-8 w-8 animate-spin text-cyan-500" }),
                  /* @__PURE__ */ jsx9("p", { className: "text-xs", children: tr.loading })
                ] }) : /* @__PURE__ */ jsxs6("div", { className: `min-h-0 flex-1 ${tab === "disks" ? "flex flex-col overflow-hidden" : "overflow-y-auto p-3"}`, children: [
                  tab === "overview" && overview && /* @__PURE__ */ jsxs6("div", { className: "space-y-4", children: [
                    /* @__PURE__ */ jsxs6("div", { className: `rounded-xl border p-4 flex flex-col md:flex-row md:items-center gap-4 ${ui.section}`, children: [
                      /* @__PURE__ */ jsx9("div", { className: `w-16 h-16 rounded-full border-4 flex items-center justify-center shrink-0 ${health === "healthy" ? isDark ? "border-emerald-500/50 bg-emerald-500/10" : "border-emerald-400 bg-emerald-100" : health === "warning" ? isDark ? "border-amber-500/50 bg-amber-500/10" : "border-amber-400 bg-amber-100" : isDark ? "border-red-500/50 bg-red-500/10" : "border-red-400 bg-red-100"}`, children: health === "healthy" ? /* @__PURE__ */ jsx9(Icons6.CheckCircle2, { className: `w-8 h-8 ${hs.icon}` }) : /* @__PURE__ */ jsx9(Icons6.AlertTriangle, { className: `w-8 h-8 ${hs.icon}` }) }),
                      /* @__PURE__ */ jsxs6("div", { className: "min-w-0 flex-1", children: [
                        /* @__PURE__ */ jsxs6("div", { className: "flex items-center gap-2 flex-wrap", children: [
                          /* @__PURE__ */ jsx9("h2", { className: `text-xl font-extrabold ${hs.text}`, children: healthLabel }),
                          /* @__PURE__ */ jsx9("span", { className: `text-[10px] uppercase font-bold px-2 py-0.5 rounded-full border ${hs.badge}`, children: health })
                        ] }),
                        /* @__PURE__ */ jsx9("p", { className: `text-sm mt-1 ${isDark ? "text-slate-300" : "text-slate-600"}`, children: overview.message || tr.systemHealthy }),
                        overview.issues.length > 0 && /* @__PURE__ */ jsx9("ul", { className: `mt-2 text-xs space-y-1 ${isDark ? "text-slate-400" : "text-slate-500"}`, children: overview.issues.map((issue) => /* @__PURE__ */ jsxs6("li", { className: "flex items-start gap-1.5", children: [
                          /* @__PURE__ */ jsx9("span", { className: "shrink-0 mt-0.5", children: "\u2022" }),
                          /* @__PURE__ */ jsx9("span", { children: issue })
                        ] }, issue)) })
                      ] })
                    ] }),
                    /* @__PURE__ */ jsx9("div", { className: "grid grid-cols-2 md:grid-cols-4 gap-4", children: [
                      { label: tr.totalDisks, value: String(overview.disk_count), icon: Icons6.HardDrive },
                      { label: tr.totalVolumes, value: String(overview.volume_count), icon: Icons6.FolderOpen },
                      { label: tr.totalCapacity, value: formatBytes(overview.total_disk_bytes, language || "en"), icon: Icons6.Layers },
                      { label: tr.smartMonitored, value: `${overview.smart_passed}/${overview.smart_monitored}`, icon: Icons6.Activity }
                    ].map((card) => {
                      const Icon = card.icon;
                      return /* @__PURE__ */ jsxs6("div", { className: `rounded-xl border p-4 ${ui.section}`, children: [
                        /* @__PURE__ */ jsxs6("div", { className: "flex items-center justify-between mb-2", children: [
                          /* @__PURE__ */ jsx9("p", { className: `text-[10px] uppercase font-bold tracking-wider ${isDark ? "text-slate-500" : "text-slate-400"}`, children: card.label }),
                          /* @__PURE__ */ jsx9(Icon, { className: `w-4 h-4 ${isDark ? "text-cyan-400" : "text-cyan-600"}` })
                        ] }),
                        /* @__PURE__ */ jsx9("p", { className: `text-lg font-extrabold ${isDark ? "text-white" : "text-slate-800"}`, children: card.value })
                      ] }, card.label);
                    }) }),
                    missingTools.length > 0 && /* @__PURE__ */ jsxs6("div", { className: `rounded-xl border p-4 text-xs ${isDark ? "border-amber-800/40 bg-amber-950/20 text-amber-200" : "border-amber-200 bg-amber-50 text-amber-900"}`, children: [
                      /* @__PURE__ */ jsx9("p", { className: "font-bold mb-1", children: tr.toolsMissing }),
                      /* @__PURE__ */ jsx9("ul", { className: "list-disc pl-5 space-y-0.5", children: missingTools.map((tool) => /* @__PURE__ */ jsx9("li", { children: tool }, tool)) })
                    ] }),
                    /* @__PURE__ */ jsxs6("div", { children: [
                      /* @__PURE__ */ jsx9("h3", { className: `text-sm font-bold mb-3 ${isDark ? "text-slate-200" : "text-slate-800"}`, children: tr.volumeUsage }),
                      volumes.length === 0 ? /* @__PURE__ */ jsx9("p", { className: `text-xs ${isDark ? "text-slate-500" : "text-slate-400"}`, children: tr.noVolumes }) : /* @__PURE__ */ jsx9("div", { className: "grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4", children: volumes.map((vol) => /* @__PURE__ */ jsxs6("div", { className: `rounded-xl border p-4 space-y-3 ${isDark ? "bg-slate-900/50 border-slate-800" : "bg-white border-slate-200 shadow-sm"}`, children: [
                        /* @__PURE__ */ jsxs6("div", { className: "flex items-start justify-between gap-2", children: [
                          /* @__PURE__ */ jsxs6("div", { className: "min-w-0", children: [
                            /* @__PURE__ */ jsx9("p", { className: `font-bold text-sm truncate ${isDark ? "text-slate-100" : "text-slate-800"}`, children: vol.mountpoint }),
                            /* @__PURE__ */ jsxs6("p", { className: `text-[11px] font-mono truncate ${isDark ? "text-slate-500" : "text-slate-400"}`, children: [
                              vol.device,
                              " \xB7 ",
                              displayFstype(vol)
                            ] })
                          ] }),
                          /* @__PURE__ */ jsx9(Icons6.CheckCircle2, { className: `w-5 h-5 shrink-0 ${vol.percent >= 95 ? "text-red-500" : vol.percent >= 85 ? "text-amber-500" : isDark ? "text-emerald-400" : "text-emerald-600"}` })
                        ] }),
                        /* @__PURE__ */ jsx9("div", { className: `h-2 rounded-full overflow-hidden ${isDark ? "bg-slate-800" : "bg-slate-100"}`, children: /* @__PURE__ */ jsx9(
                          "div",
                          {
                            className: `h-full rounded-full transition-all ${vol.percent >= 95 ? "bg-red-500" : vol.percent >= 85 ? "bg-amber-500" : "bg-cyan-500"}`,
                            style: { width: `${Math.min(100, vol.percent)}%` }
                          }
                        ) }),
                        /* @__PURE__ */ jsxs6("div", { className: `flex justify-between text-[11px] ${isDark ? "text-slate-400" : "text-slate-500"}`, children: [
                          /* @__PURE__ */ jsxs6("span", { children: [
                            formatBytes(vol.used, language || "en"),
                            " ",
                            tr.used
                          ] }),
                          /* @__PURE__ */ jsxs6("span", { children: [
                            formatBytes(vol.free, language || "en"),
                            " ",
                            tr.free
                          ] })
                        ] })
                      ] }, `${vol.device}-${vol.mountpoint}`)) })
                    ] })
                  ] }),
                  tab === "disks" && /* @__PURE__ */ jsxs6("div", { className: "flex min-h-0 flex-1 flex-col", children: [
                    /* @__PURE__ */ jsx9("div", { className: "flex min-h-0 flex-1 flex-col overflow-hidden", children: /* @__PURE__ */ jsx9(
                      PartitionWizard,
                      {
                        disks,
                        volumes,
                        language: language || "en",
                        isDark,
                        actionLoading,
                        actionErr,
                        formatBytes,
                        fetchJson,
                        runAction,
                        postJson,
                        tr: {
                          diskMap: tr.diskMap,
                          partitionList: tr.partitionList,
                          operations: tr.operations,
                          unallocated: tr.unallocated,
                          selectPartition: tr.selectPartition,
                          capacity: tr.capacity,
                          unused: tr.unused,
                          type: tr.type,
                          status: tr.status,
                          mounted: tr.mounted,
                          unmounted: tr.unmounted,
                          boot: tr.boot,
                          createPartition: tr.createPartition,
                          formatPartition: tr.formatPartition,
                          deletePartition: tr.deletePartition,
                          resizePartition: tr.resizePartition,
                          changeLabel: tr.changeLabel,
                          setBoot: tr.setBoot,
                          clearBoot: tr.clearBoot,
                          mountVolume: tr.mountVolume,
                          unmountVolume: tr.unmountVolume,
                          properties: tr.properties,
                          partitionTable: tr.partitionTable,
                          confirmPartName: tr.confirmPartName,
                          confirmDiskName: tr.confirmDiskName,
                          dataLossWarning: tr.dataLossWarning,
                          deleteWarning: tr.deleteWarning,
                          resizeHint: tr.resizeHint,
                          growFilesystem: tr.growFilesystem,
                          runAction: tr.runAction,
                          cancel: tr.cancel,
                          labelOptional: tr.labelOptional,
                          initGpt: tr.initGpt,
                          start: tr.start,
                          end: tr.end,
                          noDisks: tr.noDisks,
                          loadingLayout: tr.loadingLayout,
                          systemDisk: tr.systemDisk,
                          protectedNote: tr.protectedNote,
                          selectDisk: tr.selectDisk,
                          mountpoint: tr.mountpoint,
                          persistFstab: tr.persistFstab,
                          removeFstab: tr.removeFstab,
                          diskOperations: tr.diskOperations,
                          initializeDisk: tr.initializeDisk,
                          initializeDiskTitle: tr.initializeDiskTitle,
                          initializeDiskHint: tr.initializeDiskHint,
                          tableGpt: tr.tableGpt,
                          tableMbr: tr.tableMbr,
                          uninitializedBanner: tr.uninitializedBanner,
                          uninitializedStep: tr.uninitializedStep,
                          emptyTableStep: tr.emptyTableStep,
                          rawDiskLabel: tr.rawDiskLabel,
                          initWipeWarning: tr.initWipeWarning,
                          addToQueue: tr.addToQueue,
                          partitionType: tr.partitionType,
                          typeLinux: tr.typeLinux,
                          typeEfi: tr.typeEfi,
                          typeSwap: tr.typeSwap,
                          typeNtfs: tr.typeNtfs,
                          typeLvm: tr.typeLvm,
                          dragResizeHint: tr.dragResizeHint,
                          extendPreview: tr.extendPreview,
                          shrinkPreview: tr.shrinkPreview,
                          shrinkPartition: tr.shrinkPartition,
                          shrinkFilesystem: tr.shrinkFilesystem,
                          shrinkHint: tr.shrinkHint,
                          queue: tr.queue
                        }
                      }
                    ) }),
                    disks.length > 0 && /* @__PURE__ */ jsxs6("div", { className: `shrink-0 border-t ${ui.headerBorder} ${ui.section}`, children: [
                      /* @__PURE__ */ jsxs6("div", { className: `px-4 py-3 border-b flex flex-wrap items-center justify-between gap-2 ${isDark ? "border-slate-800" : "border-slate-200"}`, children: [
                        /* @__PURE__ */ jsxs6("p", { className: "text-xs font-bold uppercase tracking-wider opacity-70", children: [
                          "SMART & ",
                          tr.diskBenchmark
                        ] }),
                        /* @__PURE__ */ jsx9(
                          "select",
                          {
                            value: expandedDisk || disks[0]?.name || "",
                            onChange: (e) => setExpandedDisk(e.target.value),
                            className: `rounded-lg border px-3 py-1.5 text-[11px] font-mono ${isDark ? "bg-slate-950 border-slate-700" : "bg-white border-slate-200"}`,
                            children: disks.map((d) => /* @__PURE__ */ jsxs6("option", { value: d.name, children: [
                              d.name,
                              " \u2014 ",
                              d.model
                            ] }, d.name))
                          }
                        )
                      ] }),
                      (() => {
                        const diskName = expandedDisk || disks[0]?.name;
                        const disk = disks.find((d) => d.name === diskName);
                        if (!disk) return null;
                        const sm = smartDetails[disk.name] || disk.smart;
                        const benchActive = benchmarkDisk === disk.name ? benchmarkStatus : null;
                        const badge = smartBadge(disk.smart, isDark);
                        return /* @__PURE__ */ jsxs6("div", { className: "p-4 grid grid-cols-1 lg:grid-cols-3 gap-4", children: [
                          /* @__PURE__ */ jsxs6("div", { className: `rounded-xl border p-3 space-y-3 lg:col-span-2 ${isDark ? "border-slate-800" : "border-slate-200"}`, children: [
                            /* @__PURE__ */ jsxs6("div", { className: "flex items-center justify-between gap-2", children: [
                              /* @__PURE__ */ jsxs6("div", { className: "flex items-center gap-2", children: [
                                /* @__PURE__ */ jsx9("span", { className: `inline-flex px-2 py-0.5 rounded-full border text-[10px] font-bold ${badge.cls}`, children: badge.label }),
                                /* @__PURE__ */ jsx9("span", { className: "font-mono text-xs font-bold", children: disk.name })
                              ] }),
                              /* @__PURE__ */ jsx9(
                                "button",
                                {
                                  type: "button",
                                  onClick: () => loadSmartDetail(disk.name),
                                  className: `text-[10px] font-bold px-2 py-1 rounded-lg border ${isDark ? "border-slate-700 hover:bg-slate-800" : "border-slate-200 hover:bg-slate-100"}`,
                                  children: smartLoading === disk.name ? "\u2026" : tr.refreshSmart
                                }
                              )
                            ] }),
                            sm.health_percent != null && /* @__PURE__ */ jsxs6("div", { children: [
                              /* @__PURE__ */ jsxs6("div", { className: "flex justify-between text-[10px] mb-1", children: [
                                /* @__PURE__ */ jsx9("span", { className: "opacity-60", children: tr.healthPercent }),
                                /* @__PURE__ */ jsxs6("span", { className: "font-bold", children: [
                                  sm.health_percent,
                                  "%"
                                ] })
                              ] }),
                              /* @__PURE__ */ jsx9("div", { className: `h-2 rounded-full overflow-hidden ${isDark ? "bg-slate-800" : "bg-slate-200"}`, children: /* @__PURE__ */ jsx9(
                                "div",
                                {
                                  className: `h-full rounded-full ${sm.health_percent >= 80 ? "bg-emerald-500" : sm.health_percent >= 50 ? "bg-amber-500" : "bg-red-500"}`,
                                  style: { width: `${Math.min(100, sm.health_percent)}%` }
                                }
                              ) })
                            ] }),
                            /* @__PURE__ */ jsxs6("div", { className: "grid grid-cols-2 md:grid-cols-3 gap-2 text-[11px]", children: [
                              /* @__PURE__ */ jsxs6("div", { children: [
                                /* @__PURE__ */ jsxs6("span", { className: "opacity-60", children: [
                                  tr.temperature,
                                  ":"
                                ] }),
                                " ",
                                sm.temperature_c != null ? `${sm.temperature_c}\xB0C` : "\u2014"
                              ] }),
                              /* @__PURE__ */ jsxs6("div", { children: [
                                /* @__PURE__ */ jsxs6("span", { className: "opacity-60", children: [
                                  tr.powerOn,
                                  ":"
                                ] }),
                                " ",
                                formatPowerOnHours(sm.power_on_hours, language || "en")
                              ] }),
                              /* @__PURE__ */ jsxs6("div", { children: [
                                /* @__PURE__ */ jsxs6("span", { className: "opacity-60", children: [
                                  tr.powerCycles,
                                  ":"
                                ] }),
                                " ",
                                sm.power_cycle_count ?? "\u2014"
                              ] }),
                              /* @__PURE__ */ jsxs6("div", { children: [
                                /* @__PURE__ */ jsxs6("span", { className: "opacity-60", children: [
                                  tr.hostReads,
                                  ":"
                                ] }),
                                " ",
                                formatHostIoGb(sm.host_reads_gb)
                              ] }),
                              /* @__PURE__ */ jsxs6("div", { children: [
                                /* @__PURE__ */ jsxs6("span", { className: "opacity-60", children: [
                                  tr.hostWrites,
                                  ":"
                                ] }),
                                " ",
                                formatHostIoGb(sm.host_writes_gb)
                              ] }),
                              /* @__PURE__ */ jsxs6("div", { children: [
                                /* @__PURE__ */ jsxs6("span", { className: "opacity-60", children: [
                                  tr.reallocated,
                                  ":"
                                ] }),
                                " ",
                                sm.reallocated_sectors ?? "\u2014"
                              ] })
                            ] })
                          ] }),
                          /* @__PURE__ */ jsxs6("div", { className: `rounded-xl border p-3 space-y-3 ${isDark ? "border-cyan-900/40 bg-cyan-950/10" : "border-cyan-200 bg-cyan-50/40"}`, children: [
                            /* @__PURE__ */ jsxs6("p", { className: "font-bold text-[11px] uppercase tracking-wider flex items-center gap-2", children: [
                              /* @__PURE__ */ jsx9(Icons6.Gauge, { className: "w-4 h-4" }),
                              tr.diskBenchmark
                            ] }),
                            /* @__PURE__ */ jsxs6("div", { className: "flex flex-wrap items-center gap-2", children: [
                              /* @__PURE__ */ jsxs6(
                                "select",
                                {
                                  value: benchmarkProfile,
                                  onChange: (e) => setBenchmarkProfile(e.target.value),
                                  className: `rounded-lg border px-3 py-1.5 text-[11px] ${isDark ? "bg-slate-950 border-slate-700" : "bg-white border-slate-200"}`,
                                  children: [
                                    /* @__PURE__ */ jsx9("option", { value: "quick", children: tr.profileQuick }),
                                    /* @__PURE__ */ jsx9("option", { value: "standard", children: tr.profileStandard })
                                  ]
                                }
                              ),
                              /* @__PURE__ */ jsx9(
                                "button",
                                {
                                  type: "button",
                                  disabled: actionLoading || benchActive?.status === "running",
                                  onClick: () => startBenchmark(disk.name),
                                  className: "px-4 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 disabled:opacity-50 text-white text-[11px] font-bold",
                                  children: benchActive?.status === "running" ? tr.benchmarkRunning : tr.runBenchmark
                                }
                              )
                            ] }),
                            benchActive && benchActive.status !== "not_started" && /* @__PURE__ */ jsx9("div", { className: "grid grid-cols-2 gap-2 text-[11px]", children: [
                              { label: tr.seqRead, val: benchActive.results?.seq_read_mibs },
                              { label: tr.seqWrite, val: benchActive.results?.seq_write_mibs, skip: benchActive.results?.seq_write_skipped },
                              { label: tr.rand4kRead, val: benchActive.results?.rand4k_read_mibs },
                              { label: tr.rand4kWrite, val: benchActive.results?.rand4k_write_mibs, skip: benchActive.results?.rand4k_write_skipped }
                            ].map((item) => /* @__PURE__ */ jsxs6("div", { className: `rounded-lg border p-2 ${isDark ? "border-slate-800 bg-slate-950/50" : "border-slate-200 bg-white"}`, children: [
                              /* @__PURE__ */ jsx9("div", { className: "opacity-60 text-[10px]", children: item.label }),
                              /* @__PURE__ */ jsx9("div", { className: "font-mono font-bold text-sm mt-0.5", children: item.skip ? tr.benchmarkSkipped : formatMibs(item.val ?? null) })
                            ] }, item.label)) })
                          ] })
                        ] });
                      })()
                    ] })
                  ] }),
                  tab === "volumes" && /* @__PURE__ */ jsx9("div", { className: `overflow-hidden rounded-xl border ${ui.section}`, children: volumes.length === 0 ? /* @__PURE__ */ jsx9("p", { className: `p-8 text-center text-xs ${isDark ? "text-slate-500" : "text-slate-400"}`, children: tr.noVolumes }) : /* @__PURE__ */ jsx9("div", { className: "overflow-x-auto", children: /* @__PURE__ */ jsxs6("table", { className: "w-full text-left text-xs", children: [
                    /* @__PURE__ */ jsx9("thead", { className: `uppercase tracking-wider text-[10px] font-bold ${isDark ? "bg-slate-950/70 text-slate-400" : "bg-slate-50 text-slate-500"}`, children: /* @__PURE__ */ jsxs6("tr", { children: [
                      /* @__PURE__ */ jsx9("th", { className: "p-3", children: tr.mount }),
                      /* @__PURE__ */ jsx9("th", { className: "p-3", children: tr.diskName }),
                      /* @__PURE__ */ jsx9("th", { className: "p-3", children: tr.fstype }),
                      /* @__PURE__ */ jsx9("th", { className: "p-3", children: tr.used }),
                      /* @__PURE__ */ jsx9("th", { className: "p-3", children: tr.free }),
                      /* @__PURE__ */ jsx9("th", { className: "p-3", children: "%" })
                    ] }) }),
                    /* @__PURE__ */ jsx9("tbody", { className: `divide-y ${isDark ? "divide-slate-800" : "divide-slate-100"}`, children: volumes.map((vol) => /* @__PURE__ */ jsxs6("tr", { className: isDark ? "hover:bg-slate-800/30" : "hover:bg-slate-50", children: [
                      /* @__PURE__ */ jsx9("td", { className: `p-3 font-bold ${isDark ? "text-slate-100" : "text-slate-800"}`, children: vol.mountpoint }),
                      /* @__PURE__ */ jsx9("td", { className: "p-3 font-mono", children: vol.device }),
                      /* @__PURE__ */ jsx9("td", { className: "p-3", children: displayFstype(vol) }),
                      /* @__PURE__ */ jsx9("td", { className: "p-3 font-mono", children: formatBytes(vol.used, language || "en") }),
                      /* @__PURE__ */ jsx9("td", { className: "p-3 font-mono", children: formatBytes(vol.free, language || "en") }),
                      /* @__PURE__ */ jsx9("td", { className: "p-3", children: /* @__PURE__ */ jsxs6("span", { className: `font-bold ${vol.percent >= 95 ? "text-red-500" : vol.percent >= 85 ? "text-amber-500" : isDark ? "text-cyan-400" : "text-cyan-700"}`, children: [
                        vol.percent.toFixed(1),
                        "%"
                      ] }) })
                    ] }, `${vol.device}-${vol.mountpoint}`)) })
                  ] }) }) }),
                  tab === "pools" && /* @__PURE__ */ jsx9("div", { className: "space-y-4", children: !pools ? /* @__PURE__ */ jsx9("p", { className: `text-xs ${isDark ? "text-slate-500" : "text-slate-400"}`, children: tr.loading }) : /* @__PURE__ */ jsxs6(Fragment3, { children: [
                    (actionMsg || actionErr) && /* @__PURE__ */ jsx9("div", { className: `p-3 rounded-xl border text-xs ${actionErr ? isDark ? "bg-red-950/30 border-red-800 text-red-300" : "bg-red-50 border-red-200 text-red-700" : isDark ? "bg-emerald-950/30 border-emerald-800 text-emerald-300" : "bg-emerald-50 border-emerald-200 text-emerald-800"}`, children: actionErr || actionMsg }),
                    /* @__PURE__ */ jsxs6("div", { className: "grid grid-cols-1 xl:grid-cols-2 gap-4", children: [
                      /* @__PURE__ */ jsxs6("div", { className: `rounded-2xl border p-4 space-y-4 ${isDark ? "border-slate-800 bg-slate-900/40" : "border-slate-200 bg-white"}`, children: [
                        /* @__PURE__ */ jsxs6("h3", { className: "text-sm font-bold flex items-center gap-2", children: [
                          /* @__PURE__ */ jsx9(Icons6.Layers, { className: "w-4 h-4" }),
                          tr.lvmTitle
                        ] }),
                        /* @__PURE__ */ jsxs6("div", { children: [
                          /* @__PURE__ */ jsx9("p", { className: "text-[11px] font-bold uppercase opacity-60 mb-2", children: tr.volumeGroups }),
                          pools.lvm.volume_groups.length === 0 ? /* @__PURE__ */ jsx9("p", { className: "text-xs opacity-60", children: tr.noVg }) : /* @__PURE__ */ jsx9("div", { className: "space-y-2", children: pools.lvm.volume_groups.map((vg) => /* @__PURE__ */ jsxs6("div", { className: `rounded-lg border px-3 py-2 text-xs ${isDark ? "border-slate-800" : "border-slate-100"}`, children: [
                            /* @__PURE__ */ jsx9("div", { className: "font-bold", children: vg.vg_name }),
                            /* @__PURE__ */ jsxs6("div", { className: `font-mono ${isDark ? "text-slate-400" : "text-slate-500"}`, children: [
                              formatBytes(vg.vg_size_bytes, language || "en"),
                              " \xB7 ",
                              tr.vgFree,
                              " ",
                              formatBytes(vg.vg_free_bytes, language || "en")
                            ] })
                          ] }, vg.vg_name)) })
                        ] }),
                        /* @__PURE__ */ jsxs6("div", { children: [
                          /* @__PURE__ */ jsx9("p", { className: "text-[11px] font-bold uppercase opacity-60 mb-2", children: tr.logicalVolumes }),
                          pools.lvm.logical_volumes.length === 0 ? /* @__PURE__ */ jsx9("p", { className: "text-xs opacity-60", children: tr.noLv }) : /* @__PURE__ */ jsx9("div", { className: "space-y-2", children: pools.lvm.logical_volumes.map((lv) => /* @__PURE__ */ jsxs6("div", { className: `rounded-lg border px-3 py-2 text-xs font-mono ${isDark ? "border-slate-800" : "border-slate-100"}`, children: [
                            /* @__PURE__ */ jsxs6("div", { className: "font-bold", children: [
                              lv.vg_name,
                              "/",
                              lv.lv_name
                            ] }),
                            /* @__PURE__ */ jsxs6("div", { className: "opacity-70", children: [
                              formatBytes(lv.lv_size_bytes, language || "en"),
                              " \xB7 ",
                              lv.mountpoint || "\u2014",
                              " \xB7 ",
                              lv.fstype || "\u2014"
                            ] })
                          ] }, lv.lv_path)) })
                        ] })
                      ] }),
                      /* @__PURE__ */ jsxs6("div", { className: `rounded-2xl border p-4 space-y-4 ${isDark ? "border-slate-800 bg-slate-900/40" : "border-slate-200 bg-white"}`, children: [
                        /* @__PURE__ */ jsxs6("h3", { className: "text-sm font-bold flex items-center gap-2", children: [
                          /* @__PURE__ */ jsx9(Icons6.Shield, { className: "w-4 h-4" }),
                          tr.raidTitle
                        ] }),
                        pools.raid.arrays.length === 0 ? /* @__PURE__ */ jsx9("p", { className: "text-xs opacity-60", children: tr.noRaid }) : /* @__PURE__ */ jsx9("div", { className: "space-y-2", children: pools.raid.arrays.map((raid) => /* @__PURE__ */ jsxs6("div", { className: `rounded-lg border px-3 py-2 text-xs ${isDark ? "border-slate-800" : "border-slate-100"}`, children: [
                          /* @__PURE__ */ jsxs6("div", { className: "font-bold font-mono", children: [
                            raid.path,
                            " \xB7 ",
                            raid.level
                          ] }),
                          /* @__PURE__ */ jsxs6("div", { className: "opacity-70", children: [
                            raid.state,
                            " \xB7 ",
                            raid.health,
                            " \xB7 ",
                            formatBytes(raid.size_bytes, language || "en")
                          ] }),
                          /* @__PURE__ */ jsx9("div", { className: "font-mono opacity-60 mt-1", children: raid.devices.join(", ") })
                        ] }, raid.path)) })
                      ] })
                    ] }),
                    /* @__PURE__ */ jsxs6("div", { className: "grid grid-cols-1 xl:grid-cols-2 gap-4", children: [
                      /* @__PURE__ */ jsxs6("div", { className: `rounded-2xl border p-4 space-y-3 ${isDark ? "border-slate-800 bg-slate-900/40" : "border-slate-200 bg-white"}`, children: [
                        /* @__PURE__ */ jsx9("h4", { className: "text-xs font-bold", children: tr.createVg }),
                        /* @__PURE__ */ jsx9("input", { value: vgName, onChange: (e) => setVgName(e.target.value), placeholder: tr.vgName, className: `w-full rounded-lg border px-3 py-2 text-xs ${isDark ? "bg-slate-950 border-slate-700" : "bg-slate-50 border-slate-200"}` }),
                        /* @__PURE__ */ jsx9("p", { className: "text-[11px] opacity-60", children: tr.selectDevices }),
                        /* @__PURE__ */ jsx9("div", { className: "max-h-28 overflow-y-auto space-y-1", children: poolDeviceCandidates.map((p) => /* @__PURE__ */ jsxs6("label", { className: "flex items-center gap-2 text-xs font-mono", children: [
                          /* @__PURE__ */ jsx9("input", { type: "checkbox", checked: vgDevices.includes(p.path), onChange: () => togglePoolDevice(p.path, vgDevices, setVgDevices) }),
                          p.path
                        ] }, p.path)) }),
                        /* @__PURE__ */ jsx9("input", { value: vgConfirm, onChange: (e) => setVgConfirm(e.target.value), placeholder: tr.confirmVgName, className: `w-full rounded-lg border px-3 py-2 text-xs font-mono ${isDark ? "bg-slate-950 border-slate-700" : "bg-slate-50 border-slate-200"}` }),
                        /* @__PURE__ */ jsx9("button", { disabled: actionLoading || !vgName || vgDevices.length === 0 || vgConfirm !== vgName, onClick: () => runAction(() => postJson("/api/storage_manager/pools/lvm/vg/create", { vg_name: vgName, devices: vgDevices, confirm_token: vgConfirm })), className: "w-full bg-cyan-600 hover:bg-cyan-500 disabled:opacity-50 text-white text-xs font-bold py-2 rounded-xl", children: tr.runAction })
                      ] }),
                      /* @__PURE__ */ jsxs6("div", { className: `rounded-2xl border p-4 space-y-3 ${isDark ? "border-slate-800 bg-slate-900/40" : "border-slate-200 bg-white"}`, children: [
                        /* @__PURE__ */ jsx9("h4", { className: "text-xs font-bold", children: tr.createLv }),
                        /* @__PURE__ */ jsxs6("select", { value: lvVg, onChange: (e) => setLvVg(e.target.value), className: `w-full rounded-lg border px-3 py-2 text-xs ${isDark ? "bg-slate-950 border-slate-700" : "bg-slate-50 border-slate-200"}`, children: [
                          /* @__PURE__ */ jsx9("option", { value: "", children: tr.vgName }),
                          pools.lvm.volume_groups.map((vg) => /* @__PURE__ */ jsx9("option", { value: vg.vg_name, children: vg.vg_name }, vg.vg_name))
                        ] }),
                        /* @__PURE__ */ jsx9("input", { value: lvName, onChange: (e) => setLvName(e.target.value), placeholder: tr.lvName, className: `w-full rounded-lg border px-3 py-2 text-xs ${isDark ? "bg-slate-950 border-slate-700" : "bg-slate-50 border-slate-200"}` }),
                        /* @__PURE__ */ jsx9("input", { value: lvSize, onChange: (e) => setLvSize(e.target.value), placeholder: tr.lvSize, className: `w-full rounded-lg border px-3 py-2 text-xs font-mono ${isDark ? "bg-slate-950 border-slate-700" : "bg-slate-50 border-slate-200"}` }),
                        /* @__PURE__ */ jsx9("input", { value: lvConfirm, onChange: (e) => setLvConfirm(e.target.value), placeholder: tr.confirmLvPath, className: `w-full rounded-lg border px-3 py-2 text-xs font-mono ${isDark ? "bg-slate-950 border-slate-700" : "bg-slate-50 border-slate-200"}` }),
                        /* @__PURE__ */ jsx9("button", { disabled: actionLoading || !lvVg || !lvName || lvConfirm !== `${lvVg}/${lvName}`, onClick: () => runAction(() => postJson("/api/storage_manager/pools/lvm/lv/create", { vg_name: lvVg, lv_name: lvName, size: lvSize, confirm_token: lvConfirm })), className: "w-full bg-cyan-600 hover:bg-cyan-500 disabled:opacity-50 text-white text-xs font-bold py-2 rounded-xl", children: tr.runAction })
                      ] }),
                      /* @__PURE__ */ jsxs6("div", { className: `rounded-2xl border p-4 space-y-3 ${isDark ? "border-slate-800 bg-slate-900/40" : "border-slate-200 bg-white"}`, children: [
                        /* @__PURE__ */ jsx9("h4", { className: "text-xs font-bold", children: tr.extendLv }),
                        /* @__PURE__ */ jsxs6("select", { value: extVg, onChange: (e) => setExtVg(e.target.value), className: `w-full rounded-lg border px-3 py-2 text-xs ${isDark ? "bg-slate-950 border-slate-700" : "bg-slate-50 border-slate-200"}`, children: [
                          /* @__PURE__ */ jsx9("option", { value: "", children: tr.vgName }),
                          pools.lvm.volume_groups.map((vg) => /* @__PURE__ */ jsx9("option", { value: vg.vg_name, children: vg.vg_name }, vg.vg_name))
                        ] }),
                        /* @__PURE__ */ jsxs6("select", { value: extLv, onChange: (e) => setExtLv(e.target.value), className: `w-full rounded-lg border px-3 py-2 text-xs ${isDark ? "bg-slate-950 border-slate-700" : "bg-slate-50 border-slate-200"}`, children: [
                          /* @__PURE__ */ jsx9("option", { value: "", children: tr.lvName }),
                          pools.lvm.logical_volumes.filter((lv) => !extVg || lv.vg_name === extVg).map((lv) => /* @__PURE__ */ jsx9("option", { value: lv.lv_name, children: lv.lv_name }, lv.lv_path))
                        ] }),
                        /* @__PURE__ */ jsx9("input", { value: extSize, onChange: (e) => setExtSize(e.target.value), placeholder: tr.lvSize, className: `w-full rounded-lg border px-3 py-2 text-xs font-mono ${isDark ? "bg-slate-950 border-slate-700" : "bg-slate-50 border-slate-200"}` }),
                        /* @__PURE__ */ jsxs6("label", { className: "flex items-center gap-2 text-xs", children: [
                          /* @__PURE__ */ jsx9("input", { type: "checkbox", checked: extGrowFs, onChange: (e) => setExtGrowFs(e.target.checked) }),
                          tr.growFilesystem
                        ] }),
                        /* @__PURE__ */ jsx9("input", { value: extConfirm, onChange: (e) => setExtConfirm(e.target.value), placeholder: tr.confirmLvPath, className: `w-full rounded-lg border px-3 py-2 text-xs font-mono ${isDark ? "bg-slate-950 border-slate-700" : "bg-slate-50 border-slate-200"}` }),
                        /* @__PURE__ */ jsx9("button", { disabled: actionLoading || !extVg || !extLv || extConfirm !== `${extVg}/${extLv}`, onClick: () => runAction(() => postJson("/api/storage_manager/pools/lvm/lv/extend", { vg_name: extVg, lv_name: extLv, size: extSize, grow_filesystem: extGrowFs, confirm_token: extConfirm })), className: "w-full bg-cyan-600 hover:bg-cyan-500 disabled:opacity-50 text-white text-xs font-bold py-2 rounded-xl", children: tr.runAction })
                      ] }),
                      /* @__PURE__ */ jsxs6("div", { className: `rounded-2xl border p-4 space-y-3 ${isDark ? "border-red-900/40 bg-red-950/10" : "border-red-200 bg-red-50/40"}`, children: [
                        /* @__PURE__ */ jsx9("h4", { className: "text-xs font-bold text-red-500", children: tr.createRaid }),
                        /* @__PURE__ */ jsx9("p", { className: "text-[11px] text-red-500", children: tr.raidConfirmWarning }),
                        /* @__PURE__ */ jsxs6("select", { value: raidLevel, onChange: (e) => setRaidLevel(Number(e.target.value)), className: `w-full rounded-lg border px-3 py-2 text-xs ${isDark ? "bg-slate-950 border-slate-700" : "bg-slate-50 border-slate-200"}`, children: [
                          /* @__PURE__ */ jsx9("option", { value: 1, children: "RAID 1 (mirror)" }),
                          /* @__PURE__ */ jsx9("option", { value: 5, children: "RAID 5" }),
                          /* @__PURE__ */ jsx9("option", { value: 10, children: "RAID 10" })
                        ] }),
                        /* @__PURE__ */ jsx9("div", { className: "max-h-28 overflow-y-auto space-y-1", children: poolDeviceCandidates.map((p) => /* @__PURE__ */ jsxs6("label", { className: "flex items-center gap-2 text-xs font-mono", children: [
                          /* @__PURE__ */ jsx9("input", { type: "checkbox", checked: raidDevices.includes(p.path), onChange: () => togglePoolDevice(p.path, raidDevices, setRaidDevices) }),
                          p.path
                        ] }, `raid-${p.path}`)) }),
                        /* @__PURE__ */ jsx9("input", { value: raidConfirm, onChange: (e) => setRaidConfirm(e.target.value), placeholder: tr.confirmRaid, className: `w-full rounded-lg border px-3 py-2 text-xs font-mono ${isDark ? "bg-slate-950 border-slate-700" : "bg-slate-50 border-slate-200"}` }),
                        /* @__PURE__ */ jsx9("button", { disabled: actionLoading || raidDevices.length < 2 || raidConfirm !== "CREATE-RAID", onClick: () => runAction(() => postJson("/api/storage_manager/pools/raid/create", { level: raidLevel, devices: raidDevices, confirm_token: raidConfirm })), className: "w-full bg-red-600 hover:bg-red-500 disabled:opacity-50 text-white text-xs font-bold py-2 rounded-xl", children: tr.runAction })
                      ] })
                    ] })
                  ] }) }),
                  tab === "maintenance" && /* @__PURE__ */ jsxs6("div", { className: "space-y-4", children: [
                    (actionMsg || actionErr) && /* @__PURE__ */ jsx9("div", { className: `p-3 rounded-xl border text-xs ${actionErr ? isDark ? "bg-red-950/30 border-red-800 text-red-300" : "bg-red-50 border-red-200 text-red-700" : isDark ? "bg-emerald-950/30 border-emerald-800 text-emerald-300" : "bg-emerald-50 border-emerald-200 text-emerald-800"}`, children: actionErr || actionMsg }),
                    /* @__PURE__ */ jsxs6("div", { className: `rounded-2xl border p-4 ${isDark ? "border-slate-800 bg-slate-900/40" : "border-slate-200 bg-white"}`, children: [
                      /* @__PURE__ */ jsx9("h3", { className: "text-sm font-bold mb-2", children: tr.activeAlerts }),
                      alerts.length === 0 ? /* @__PURE__ */ jsx9("p", { className: "text-xs opacity-60", children: tr.noAlerts }) : /* @__PURE__ */ jsx9("ul", { className: "space-y-1.5 text-xs", children: alerts.map((a, i) => /* @__PURE__ */ jsxs6("li", { className: `flex gap-2 ${a.level === "critical" ? "text-red-500" : "text-amber-500"}`, children: [
                        /* @__PURE__ */ jsx9(Icons6.AlertTriangle, { className: "w-3.5 h-3.5 shrink-0 mt-0.5" }),
                        /* @__PURE__ */ jsx9("span", { children: a.message })
                      ] }, `${a.message}-${i}`)) })
                    ] }),
                    /* @__PURE__ */ jsx9("p", { className: `text-xs ${isDark ? "text-slate-400" : "text-slate-500"}`, children: tr.maintenanceTitle }),
                    /* @__PURE__ */ jsxs6("div", { className: "grid grid-cols-1 xl:grid-cols-2 gap-4", children: [
                      /* @__PURE__ */ jsxs6("div", { className: `rounded-2xl border p-4 space-y-3 ${isDark ? "border-slate-800 bg-slate-900/40" : "border-slate-200 bg-white"}`, children: [
                        /* @__PURE__ */ jsx9("h4", { className: "text-xs font-bold", children: tr.smartTest }),
                        /* @__PURE__ */ jsxs6("select", { value: smartDisk, onChange: (e) => setSmartDisk(e.target.value), className: `w-full rounded-lg border px-3 py-2 text-xs ${isDark ? "bg-slate-950 border-slate-700" : "bg-slate-50 border-slate-200"}`, children: [
                          /* @__PURE__ */ jsx9("option", { value: "", children: tr.selectDrive }),
                          (maintenance?.targets.smart_disks || []).map((d) => /* @__PURE__ */ jsxs6("option", { value: d.name, children: [
                            d.name,
                            " \u2014 ",
                            d.model
                          ] }, d.name))
                        ] }),
                        /* @__PURE__ */ jsxs6("select", { value: smartTestType, onChange: (e) => setSmartTestType(e.target.value), className: `w-full rounded-lg border px-3 py-2 text-xs ${isDark ? "bg-slate-950 border-slate-700" : "bg-slate-50 border-slate-200"}`, children: [
                          /* @__PURE__ */ jsx9("option", { value: "short", children: tr.smartShort }),
                          /* @__PURE__ */ jsx9("option", { value: "long", children: tr.smartLong })
                        ] }),
                        /* @__PURE__ */ jsx9(
                          "button",
                          {
                            disabled: actionLoading || !smartDisk,
                            onClick: () => runAction(() => postJson("/api/storage_manager/maintenance/smart-test", { disk_name: smartDisk, test_type: smartTestType })),
                            className: "w-full bg-cyan-600 hover:bg-cyan-500 disabled:opacity-50 text-white text-xs font-bold py-2 rounded-xl",
                            children: tr.runTest
                          }
                        )
                      ] }),
                      /* @__PURE__ */ jsxs6("div", { className: `rounded-2xl border p-4 space-y-3 ${isDark ? "border-slate-800 bg-slate-900/40" : "border-slate-200 bg-white"}`, children: [
                        /* @__PURE__ */ jsx9("h4", { className: "text-xs font-bold", children: tr.btrfsScrub }),
                        /* @__PURE__ */ jsxs6("select", { value: scrubMount, onChange: (e) => setScrubMount(e.target.value), className: `w-full rounded-lg border px-3 py-2 text-xs font-mono ${isDark ? "bg-slate-950 border-slate-700" : "bg-slate-50 border-slate-200"}`, children: [
                          /* @__PURE__ */ jsx9("option", { value: "", children: tr.mount }),
                          (maintenance?.targets.btrfs_volumes || []).map((v) => /* @__PURE__ */ jsx9("option", { value: v.mountpoint, children: v.mountpoint }, v.mountpoint))
                        ] }),
                        /* @__PURE__ */ jsx9(
                          "button",
                          {
                            disabled: actionLoading || !scrubMount,
                            onClick: () => runAction(() => postJson("/api/storage_manager/maintenance/scrub/btrfs", { mountpoint: scrubMount })),
                            className: "w-full bg-cyan-600 hover:bg-cyan-500 disabled:opacity-50 text-white text-xs font-bold py-2 rounded-xl",
                            children: tr.runScrub
                          }
                        )
                      ] }),
                      /* @__PURE__ */ jsxs6("div", { className: `rounded-2xl border p-4 space-y-3 ${isDark ? "border-slate-800 bg-slate-900/40" : "border-slate-200 bg-white"}`, children: [
                        /* @__PURE__ */ jsx9("h4", { className: "text-xs font-bold", children: tr.raidCheck }),
                        /* @__PURE__ */ jsxs6("select", { value: raidCheckDev, onChange: (e) => setRaidCheckDev(e.target.value), className: `w-full rounded-lg border px-3 py-2 text-xs font-mono ${isDark ? "bg-slate-950 border-slate-700" : "bg-slate-50 border-slate-200"}`, children: [
                          /* @__PURE__ */ jsx9("option", { value: "", children: "RAID" }),
                          (maintenance?.targets.raid_arrays || []).map((r2) => /* @__PURE__ */ jsxs6("option", { value: r2.path, children: [
                            r2.path,
                            " (",
                            r2.level,
                            ")"
                          ] }, r2.path))
                        ] }),
                        /* @__PURE__ */ jsx9(
                          "button",
                          {
                            disabled: actionLoading || !raidCheckDev,
                            onClick: () => runAction(() => postJson("/api/storage_manager/maintenance/scrub/raid", { md_device: raidCheckDev })),
                            className: "w-full bg-cyan-600 hover:bg-cyan-500 disabled:opacity-50 text-white text-xs font-bold py-2 rounded-xl",
                            children: tr.runRaidCheck
                          }
                        )
                      ] }),
                      /* @__PURE__ */ jsxs6("div", { className: `rounded-2xl border p-4 space-y-3 xl:col-span-2 ${isDark ? "border-amber-900/40 bg-amber-950/10" : "border-amber-200 bg-amber-50/40"}`, children: [
                        /* @__PURE__ */ jsxs6("h4", { className: "text-xs font-bold flex items-center gap-2", children: [
                          /* @__PURE__ */ jsx9(Icons6.Wrench, { className: "w-4 h-4" }),
                          tr.fsckTitle
                        ] }),
                        /* @__PURE__ */ jsx9("p", { className: "text-[11px] opacity-70", children: tr.fsckUnmountNote }),
                        (maintenance?.targets.fsck_partitions || []).length === 0 ? /* @__PURE__ */ jsx9("p", { className: "text-xs opacity-60", children: tr.noFsckCandidates }) : /* @__PURE__ */ jsxs6(Fragment3, { children: [
                          /* @__PURE__ */ jsxs6(
                            "select",
                            {
                              value: fsckDevice,
                              onChange: (e) => setFsckDevice(e.target.value),
                              className: `w-full rounded-lg border px-3 py-2 text-xs font-mono ${isDark ? "bg-slate-950 border-slate-700" : "bg-slate-50 border-slate-200"}`,
                              children: [
                                /* @__PURE__ */ jsx9("option", { value: "", children: tr.selectPartitionFsck }),
                                (maintenance?.targets.fsck_partitions || []).map((p) => /* @__PURE__ */ jsxs6("option", { value: p.path, children: [
                                  p.path,
                                  " \u2014 ",
                                  p.fstype_label || p.fstype
                                ] }, p.path))
                              ]
                            }
                          ),
                          /* @__PURE__ */ jsxs6("label", { className: "flex items-center gap-2 text-xs", children: [
                            /* @__PURE__ */ jsx9("input", { type: "checkbox", checked: fsckRepair, onChange: (e) => setFsckRepair(e.target.checked) }),
                            tr.fsckRepair
                          ] }),
                          !fsckRepair && /* @__PURE__ */ jsx9("p", { className: "text-[10px] opacity-60", children: tr.fsckCheck }),
                          /* @__PURE__ */ jsx9(
                            "input",
                            {
                              value: fsckConfirm,
                              onChange: (e) => setFsckConfirm(e.target.value),
                              placeholder: tr.fsckConfirm,
                              className: `w-full rounded-lg border px-3 py-2 text-xs font-mono ${isDark ? "bg-slate-950 border-slate-700" : "bg-slate-50 border-slate-200"}`
                            }
                          ),
                          /* @__PURE__ */ jsx9(
                            "button",
                            {
                              disabled: actionLoading || !fsckDevice || fsckConfirm !== fsckDevice.replace("/dev/", ""),
                              onClick: () => runAction(() => postJson("/api/storage_manager/maintenance/fsck", {
                                device: fsckDevice,
                                repair: fsckRepair,
                                confirm_token: fsckConfirm
                              })),
                              className: "w-full bg-amber-600 hover:bg-amber-500 disabled:opacity-50 text-white text-xs font-bold py-2 rounded-xl",
                              children: tr.runFsck
                            }
                          )
                        ] })
                      ] })
                    ] }),
                    /* @__PURE__ */ jsxs6("div", { className: `rounded-2xl border p-4 ${isDark ? "border-slate-800 bg-slate-900/40" : "border-slate-200 bg-white"}`, children: [
                      /* @__PURE__ */ jsx9("h4", { className: "text-sm font-bold mb-3", children: tr.maintenanceHistory }),
                      !maintenance?.history?.length ? /* @__PURE__ */ jsx9("p", { className: "text-xs opacity-60", children: tr.noHistory }) : /* @__PURE__ */ jsx9("div", { className: "space-y-2 max-h-48 overflow-y-auto", children: maintenance.history.map((item, idx) => /* @__PURE__ */ jsxs6("div", { className: `text-[11px] font-mono border-b pb-2 ${isDark ? "border-slate-800 text-slate-400" : "border-slate-100 text-slate-600"}`, children: [
                        /* @__PURE__ */ jsx9("span", { className: "font-bold", children: item.action }),
                        " \xB7 ",
                        item.target,
                        " \u2014 ",
                        item.result
                      ] }, `${item.at}-${idx}`)) })
                    ] })
                  ] }),
                  tab === "manage" && /* @__PURE__ */ jsxs6("div", { className: "space-y-4", children: [
                    (actionMsg || actionErr) && /* @__PURE__ */ jsx9("div", { className: `p-3 rounded-xl border text-xs ${actionErr ? isDark ? "bg-red-950/30 border-red-800 text-red-300" : "bg-red-50 border-red-200 text-red-700" : isDark ? "bg-emerald-950/30 border-emerald-800 text-emerald-300" : "bg-emerald-50 border-emerald-200 text-emerald-800"}`, children: actionErr || actionMsg }),
                    /* @__PURE__ */ jsxs6("div", { className: "grid grid-cols-1 xl:grid-cols-2 gap-4", children: [
                      /* @__PURE__ */ jsxs6("div", { className: `rounded-2xl border p-4 space-y-3 ${isDark ? "border-slate-800 bg-slate-900/40" : "border-slate-200 bg-white"}`, children: [
                        /* @__PURE__ */ jsxs6("h3", { className: "text-sm font-bold flex items-center gap-2", children: [
                          /* @__PURE__ */ jsx9(Icons6.Plus, { className: "w-4 h-4" }),
                          tr.createPartition
                        ] }),
                        /* @__PURE__ */ jsx9("p", { className: `text-[11px] ${isDark ? "text-slate-500" : "text-slate-400"}`, children: tr.adminOnly }),
                        dataDisks.length === 0 ? /* @__PURE__ */ jsx9("p", { className: "text-xs opacity-60", children: tr.noCandidateDisk }) : /* @__PURE__ */ jsxs6(Fragment3, { children: [
                          /* @__PURE__ */ jsxs6("select", { value: partDisk, onChange: (e) => setPartDisk(e.target.value), className: `w-full rounded-lg border px-3 py-2 text-xs ${isDark ? "bg-slate-950 border-slate-700" : "bg-slate-50 border-slate-200"}`, children: [
                            /* @__PURE__ */ jsx9("option", { value: "", children: tr.selectDisk }),
                            dataDisks.map((d) => /* @__PURE__ */ jsxs6("option", { value: d.name, children: [
                              d.name,
                              " \u2014 ",
                              d.model
                            ] }, d.name))
                          ] }),
                          /* @__PURE__ */ jsxs6("div", { className: "grid grid-cols-2 gap-2", children: [
                            /* @__PURE__ */ jsx9("input", { value: partStart, onChange: (e) => setPartStart(e.target.value), placeholder: tr.start, className: `rounded-lg border px-3 py-2 text-xs font-mono ${isDark ? "bg-slate-950 border-slate-700" : "bg-slate-50 border-slate-200"}` }),
                            /* @__PURE__ */ jsx9("input", { value: partEnd, onChange: (e) => setPartEnd(e.target.value), placeholder: tr.end, className: `rounded-lg border px-3 py-2 text-xs font-mono ${isDark ? "bg-slate-950 border-slate-700" : "bg-slate-50 border-slate-200"}` })
                          ] }),
                          /* @__PURE__ */ jsxs6("label", { className: "flex items-center gap-2 text-xs", children: [
                            /* @__PURE__ */ jsx9("input", { type: "checkbox", checked: partInitGpt, onChange: (e) => setPartInitGpt(e.target.checked) }),
                            tr.initGpt
                          ] }),
                          /* @__PURE__ */ jsx9("input", { value: partConfirm, onChange: (e) => setPartConfirm(e.target.value), placeholder: tr.confirmDiskName, className: `w-full rounded-lg border px-3 py-2 text-xs font-mono ${isDark ? "bg-slate-950 border-slate-700" : "bg-slate-50 border-slate-200"}` }),
                          /* @__PURE__ */ jsx9(
                            "button",
                            {
                              disabled: actionLoading || !partDisk || partConfirm !== partDisk,
                              onClick: () => runAction(() => postJson("/api/storage_manager/partitions/create", {
                                disk_name: partDisk,
                                start: partStart,
                                end: partEnd,
                                initialize_gpt: partInitGpt,
                                confirm_token: partConfirm
                              })),
                              className: "w-full bg-cyan-600 hover:bg-cyan-500 disabled:opacity-50 text-white text-xs font-bold py-2 rounded-xl",
                              children: tr.runAction
                            }
                          )
                        ] })
                      ] }),
                      /* @__PURE__ */ jsxs6("div", { className: `rounded-2xl border p-4 space-y-3 ${isDark ? "border-red-900/40 bg-red-950/10" : "border-red-200 bg-red-50/40"}`, children: [
                        /* @__PURE__ */ jsxs6("h3", { className: "text-sm font-bold flex items-center gap-2 text-red-500", children: [
                          /* @__PURE__ */ jsx9(Icons6.Eraser, { className: "w-4 h-4" }),
                          tr.formatPartition
                        ] }),
                        /* @__PURE__ */ jsx9("p", { className: "text-[11px] text-red-500", children: tr.dataLossWarning }),
                        formatCandidates.length === 0 ? /* @__PURE__ */ jsx9("p", { className: "text-xs opacity-60", children: tr.noCandidatePart }) : /* @__PURE__ */ jsxs6(Fragment3, { children: [
                          /* @__PURE__ */ jsxs6("select", { value: formatDevice, onChange: (e) => setFormatDevice(e.target.value), className: `w-full rounded-lg border px-3 py-2 text-xs font-mono ${isDark ? "bg-slate-950 border-slate-700" : "bg-slate-50 border-slate-200"}`, children: [
                            /* @__PURE__ */ jsx9("option", { value: "", children: tr.selectPartition }),
                            formatCandidates.map((p) => /* @__PURE__ */ jsx9("option", { value: p.path, children: p.path }, p.path))
                          ] }),
                          /* @__PURE__ */ jsx9("select", { value: formatFs, onChange: (e) => setFormatFs(e.target.value), className: `w-full rounded-lg border px-3 py-2 text-xs ${isDark ? "bg-slate-950 border-slate-700" : "bg-slate-50 border-slate-200"}`, children: FORMAT_FS_OPTIONS2.map((opt) => /* @__PURE__ */ jsx9("option", { value: opt.value, children: opt.label }, opt.value)) }),
                          /* @__PURE__ */ jsx9("input", { value: formatLabel, onChange: (e) => setFormatLabel(e.target.value), placeholder: tr.labelOptional, className: `w-full rounded-lg border px-3 py-2 text-xs ${isDark ? "bg-slate-950 border-slate-700" : "bg-slate-50 border-slate-200"}` }),
                          /* @__PURE__ */ jsx9("input", { value: formatConfirm, onChange: (e) => setFormatConfirm(e.target.value), placeholder: tr.confirmPartName, className: `w-full rounded-lg border px-3 py-2 text-xs font-mono ${isDark ? "bg-slate-950 border-slate-700" : "bg-slate-50 border-slate-200"}` }),
                          /* @__PURE__ */ jsx9(
                            "button",
                            {
                              disabled: actionLoading || !formatDevice || formatConfirm !== formatDevice.replace("/dev/", ""),
                              onClick: () => runAction(() => postJson("/api/storage_manager/format", {
                                device: formatDevice,
                                fstype: formatFs,
                                label: formatLabel || null,
                                confirm_token: formatConfirm
                              })),
                              className: "w-full bg-red-600 hover:bg-red-500 disabled:opacity-50 text-white text-xs font-bold py-2 rounded-xl",
                              children: tr.runAction
                            }
                          )
                        ] })
                      ] }),
                      /* @__PURE__ */ jsxs6("div", { className: `rounded-2xl border p-4 space-y-3 ${isDark ? "border-slate-800 bg-slate-900/40" : "border-slate-200 bg-white"}`, children: [
                        /* @__PURE__ */ jsxs6("h3", { className: "text-sm font-bold flex items-center gap-2", children: [
                          /* @__PURE__ */ jsx9(Icons6.FolderInput, { className: "w-4 h-4" }),
                          tr.mountVolume
                        ] }),
                        /* @__PURE__ */ jsx9("input", { value: mountDevice, onChange: (e) => setMountDevice(e.target.value), placeholder: "/dev/sdb1", className: `w-full rounded-lg border px-3 py-2 text-xs font-mono ${isDark ? "bg-slate-950 border-slate-700" : "bg-slate-50 border-slate-200"}` }),
                        /* @__PURE__ */ jsx9("input", { value: mountPoint, onChange: (e) => setMountPoint(e.target.value), placeholder: tr.mountpoint, className: `w-full rounded-lg border px-3 py-2 text-xs font-mono ${isDark ? "bg-slate-950 border-slate-700" : "bg-slate-50 border-slate-200"}` }),
                        /* @__PURE__ */ jsxs6("select", { value: mountFs, onChange: (e) => setMountFs(e.target.value), className: `w-full rounded-lg border px-3 py-2 text-xs ${isDark ? "bg-slate-950 border-slate-700" : "bg-slate-50 border-slate-200"}`, children: [
                          /* @__PURE__ */ jsxs6("option", { value: "", children: [
                            tr.fstype,
                            " (auto)"
                          ] }),
                          MOUNT_FS_OPTIONS.map((opt) => /* @__PURE__ */ jsx9("option", { value: opt.value, children: opt.label }, opt.value))
                        ] }),
                        /* @__PURE__ */ jsx9("input", { value: mountOptions, onChange: (e) => setMountOptions(e.target.value), placeholder: tr.options, className: `w-full rounded-lg border px-3 py-2 text-xs font-mono ${isDark ? "bg-slate-950 border-slate-700" : "bg-slate-50 border-slate-200"}` }),
                        /* @__PURE__ */ jsxs6("label", { className: "flex items-center gap-2 text-xs", children: [
                          /* @__PURE__ */ jsx9("input", { type: "checkbox", checked: mountPersist, onChange: (e) => setMountPersist(e.target.checked) }),
                          tr.persistFstab
                        ] }),
                        /* @__PURE__ */ jsx9(
                          "button",
                          {
                            disabled: actionLoading || !mountDevice || !mountPoint,
                            onClick: () => runAction(() => postJson("/api/storage_manager/mount", {
                              device: mountDevice,
                              mountpoint: mountPoint,
                              fstype: mountFs || null,
                              options: mountOptions,
                              persist_fstab: mountPersist
                            })),
                            className: "w-full bg-cyan-600 hover:bg-cyan-500 disabled:opacity-50 text-white text-xs font-bold py-2 rounded-xl",
                            children: tr.runAction
                          }
                        )
                      ] }),
                      /* @__PURE__ */ jsxs6("div", { className: `rounded-2xl border p-4 space-y-3 ${isDark ? "border-slate-800 bg-slate-900/40" : "border-slate-200 bg-white"}`, children: [
                        /* @__PURE__ */ jsxs6("h3", { className: "text-sm font-bold flex items-center gap-2", children: [
                          /* @__PURE__ */ jsx9(Icons6.FolderOutput, { className: "w-4 h-4" }),
                          tr.unmountVolume
                        ] }),
                        unmountCandidates.length === 0 ? /* @__PURE__ */ jsx9("p", { className: "text-xs opacity-60", children: tr.noVolumes }) : /* @__PURE__ */ jsxs6("select", { value: unmountPoint, onChange: (e) => setUnmountPoint(e.target.value), className: `w-full rounded-lg border px-3 py-2 text-xs font-mono ${isDark ? "bg-slate-950 border-slate-700" : "bg-slate-50 border-slate-200"}`, children: [
                          /* @__PURE__ */ jsx9("option", { value: "", children: tr.selectMount }),
                          unmountCandidates.map((v) => /* @__PURE__ */ jsxs6("option", { value: v.mountpoint, children: [
                            v.mountpoint,
                            " (",
                            v.device,
                            ")"
                          ] }, v.mountpoint))
                        ] }),
                        /* @__PURE__ */ jsxs6("label", { className: "flex items-center gap-2 text-xs", children: [
                          /* @__PURE__ */ jsx9("input", { type: "checkbox", checked: unmountRemoveFstab, onChange: (e) => setUnmountRemoveFstab(e.target.checked) }),
                          tr.removeFstab
                        ] }),
                        /* @__PURE__ */ jsx9(
                          "button",
                          {
                            disabled: actionLoading || !unmountPoint,
                            onClick: () => runAction(() => postJson("/api/storage_manager/unmount", {
                              mountpoint: unmountPoint,
                              remove_fstab: unmountRemoveFstab
                            })),
                            className: "w-full bg-slate-700 hover:bg-slate-600 disabled:opacity-50 text-white text-xs font-bold py-2 rounded-xl",
                            children: tr.runAction
                          }
                        )
                      ] })
                    ] }),
                    /* @__PURE__ */ jsxs6("div", { className: `rounded-2xl border p-4 ${isDark ? "border-slate-800 bg-slate-900/40" : "border-slate-200 bg-white"}`, children: [
                      /* @__PURE__ */ jsx9("h3", { className: "text-sm font-bold mb-3", children: tr.fstabTitle }),
                      fstab.length === 0 ? /* @__PURE__ */ jsx9("p", { className: `text-xs ${isDark ? "text-slate-500" : "text-slate-400"}`, children: "\u2014" }) : /* @__PURE__ */ jsx9("div", { className: "overflow-x-auto", children: /* @__PURE__ */ jsxs6("table", { className: "w-full text-left text-[11px] font-mono", children: [
                        /* @__PURE__ */ jsx9("thead", { className: isDark ? "text-slate-500" : "text-slate-400", children: /* @__PURE__ */ jsxs6("tr", { children: [
                          /* @__PURE__ */ jsx9("th", { className: "p-2", children: "spec" }),
                          /* @__PURE__ */ jsx9("th", { className: "p-2", children: "mount" }),
                          /* @__PURE__ */ jsx9("th", { className: "p-2", children: "fstype" }),
                          /* @__PURE__ */ jsx9("th", { className: "p-2", children: "options" })
                        ] }) }),
                        /* @__PURE__ */ jsx9("tbody", { children: fstab.map((row) => /* @__PURE__ */ jsxs6("tr", { className: isDark ? "border-t border-slate-800" : "border-t border-slate-100", children: [
                          /* @__PURE__ */ jsx9("td", { className: "p-2", children: row.spec }),
                          /* @__PURE__ */ jsx9("td", { className: "p-2", children: row.mountpoint }),
                          /* @__PURE__ */ jsx9("td", { className: "p-2", children: row.fstype }),
                          /* @__PURE__ */ jsx9("td", { className: "p-2", children: row.options })
                        ] }, row.raw)) })
                      ] }) })
                    ] })
                  ] })
                ] }) })
              }
            )
          ]
        }
      )
    }
  );
}
export {
  StorageManagerDashboard as default
};
